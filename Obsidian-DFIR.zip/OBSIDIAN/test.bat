@echo off
REM ===========================================================================
REM  OBSIDIAN - Run the test suite and quality checks
REM ===========================================================================

setlocal EnableExtensions
cd /d "%~dp0"

set "ROOT=%CD%"
set "API=%ROOT%\apps\api"
set "WEB=%ROOT%\apps\web"
set "VENV=%API%\.venv"

if not exist "%VENV%\Scripts\python.exe" (
    echo  [X] The Python environment is missing. Run setup.bat first.
    echo.
    pause
    exit /b 1
)

echo.
echo  ===========================================================
echo    OBSIDIAN - Tests
echo  ===========================================================
echo.

echo  -----------------------------------------------------------
echo   Backend test suite
echo  -----------------------------------------------------------
call :run_backend
set "API_RESULT=%ERRORLEVEL%"

echo.
echo  -----------------------------------------------------------
echo   Frontend type check
echo  -----------------------------------------------------------
call :run_frontend
set "WEB_RESULT=%ERRORLEVEL%"

echo.
echo  ===========================================================
if "%API_RESULT%"=="0" (echo    Backend tests  PASSED) else (echo    Backend tests  FAILED)
if "%WEB_RESULT%"=="0" (echo    Type check     PASSED) else (echo    Type check     FAILED)
echo  ===========================================================
echo.
pause

if not "%API_RESULT%"=="0" exit /b 1
if not "%WEB_RESULT%"=="0" exit /b 1
exit /b 0

REM ===========================================================================
REM  Subroutines.
REM
REM  Each check runs in its own subroutine rather than inside a parenthesised
REM  block. Inside a block, %ERRORLEVEL% is substituted when the block is
REM  PARSED, not when it executes, so it would always report the value from
REM  before the command ran. Calling out avoids that entirely.
REM ===========================================================================

:run_backend
pushd "%API%"
"%VENV%\Scripts\python.exe" -m pytest -v
set "RC=%ERRORLEVEL%"
popd
exit /b %RC%

:run_frontend
if not exist "%WEB%\node_modules" (
    echo  [--] Skipped: node_modules is missing. Run setup.bat first.
    exit /b 0
)
pushd "%WEB%"
call npm run typecheck
set "RC=%ERRORLEVEL%"
popd
exit /b %RC%
