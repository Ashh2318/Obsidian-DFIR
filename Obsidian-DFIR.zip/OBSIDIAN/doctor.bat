@echo off
REM ===========================================================================
REM  OBSIDIAN - Diagnostics
REM
REM  Finds out why the API will not start and writes everything to
REM  doctor-log.txt. Send that file if you need help.
REM ===========================================================================

setlocal EnableExtensions
cd /d "%~dp0"

set "ROOT=%CD%"
set "API=%ROOT%\apps\api"
set "VENV=%API%\.venv"
set "VPY=%VENV%\Scripts\python.exe"
set "LOG=%ROOT%\doctor-log.txt"

if exist "%LOG%" del /q "%LOG%"

echo. > "%LOG%"
echo  ===========================================================
echo    OBSIDIAN - Diagnostics
echo  ===========================================================
echo.
echo  Writing results to doctor-log.txt
echo.

call :log "OBSIDIAN diagnostics"
call :log "===================="

REM --- 1. Python environment -------------------------------------------------
call :section "1. Python environment"
if not exist "%VPY%" (
    call :both "  [X] .venv is missing. Run setup.bat first."
    goto :done
)
"%VPY%" -c "import sys" >nul 2>&1
if errorlevel 1 (
    call :both "  [X] The virtual environment exists but its base Python is gone."
    call :both "      Fix:  run setup.bat (it rebuilds the environment), or delete apps\api\.venv first."
    goto :done
)
call :both "  [OK] Virtual environment found and runnable."
"%VPY%" --version >> "%LOG%" 2>&1
for /f "delims=" %%V in ('"%VPY%" --version 2^>^&1') do call :both "  [OK] %%V"

REM --- 2. Package import -----------------------------------------------------
call :section "2. Package import"
"%VPY%" -c "import obsidian" >> "%LOG%" 2>&1
if errorlevel 1 (
    call :both "  [X] Cannot import 'obsidian'. The editable install is missing."
    call :both "      Fix:  cd apps\api  then  .venv\Scripts\python.exe -m pip install -e ."
    goto :done
)
call :both "  [OK] Package 'obsidian' imports."

REM --- 3. Configuration ------------------------------------------------------
call :section "3. Configuration - .env"
if not exist "%API%\.env" (
    call :both "  [X] apps\api\.env is missing. Run setup.bat."
    goto :done
)
pushd "%API%"
"%VPY%" -c "from obsidian.core.config import Settings; s=Settings(); print('  [OK] environment =', s.environment); print('  [OK] database    =', s.database_url); print('  [OK] cors        =', s.cors_origins); print('  [OK] secret      =', len(s.secret_key), 'chars')" > "%TEMP%\obsdiag.txt" 2>&1
set "CFG_RC=%ERRORLEVEL%"
popd
type "%TEMP%\obsdiag.txt"
type "%TEMP%\obsdiag.txt" >> "%LOG%"
del /q "%TEMP%\obsdiag.txt" 2>nul
if not "%CFG_RC%"=="0" (
    call :both "  [X] .env failed to load. See the error above."
    goto :done
)

REM --- 4. Application import -------------------------------------------------
call :section "4. Application import"
pushd "%API%"
"%VPY%" -c "from obsidian.main import app; print('  [OK] app imported,', len(app.routes), 'routes')" > "%TEMP%\obsdiag.txt" 2>&1
set "APP_RC=%ERRORLEVEL%"
popd
type "%TEMP%\obsdiag.txt"
type "%TEMP%\obsdiag.txt" >> "%LOG%"
del /q "%TEMP%\obsdiag.txt" 2>nul
if not "%APP_RC%"=="0" (
    call :both "  [X] The application failed to import. That traceback is the cause."
    goto :done
)

REM --- 5. Port 8000 ----------------------------------------------------------
call :section "5. Port 8000"
netstat -ano -p tcp | findstr /r /c:"LISTENING" | findstr /c:":8000 " > "%TEMP%\obsdiag.txt" 2>&1
if errorlevel 1 (
    call :both "  [OK] Port 8000 is free."
    goto :port_done
)
call :both "  [!] Port 8000 is already in use:"
type "%TEMP%\obsdiag.txt"
type "%TEMP%\obsdiag.txt" >> "%LOG%"
call :name_owner
call :api_answers
:port_done
del /q "%TEMP%\obsdiag.txt" 2>nul

REM --- 6. Live start ---------------------------------------------------------
call :section "6. Starting the API in the foreground"
call :both "  Reload is disabled here so any startup error is printed plainly."
call :both "  If this works, the API is fine and start.bat is the problem."
call :blank
call :both "  Press Ctrl+C to stop, then check http://localhost:8000/docs"
call :blank

pushd "%API%"
"%VENV%\Scripts\uvicorn.exe" obsidian.main:app --port 8000 2>&1
popd

:done
echo.
echo  ===========================================================
echo    Diagnostics finished. Results saved to doctor-log.txt
echo  ===========================================================
echo.
pause
exit /b 0

REM ===========================================================================
:name_owner
REM A bare PID is not actionable. Resolve it to an image name.
for /f "tokens=5" %%P in ('netstat -ano -p tcp ^| findstr /r /c:"LISTENING" ^| findstr /c:":8000 "') do (
    call :both "      Held by PID %%P:"
    for /f "tokens=1 delims=," %%N in ('tasklist /fi "PID eq %%P" /fo csv /nh 2^>nul') do (
        call :both "        image: %%~N"
    )
)
exit /b 0

:api_answers
REM Distinguishes "OBSIDIAN is already running" from "something else owns 8000".
curl -s -m 3 "http://127.0.0.1:8000/api/v1/health" 2>nul | findstr /c:"\"environment\"" >nul 2>&1
if errorlevel 1 (
    call :both "      It does NOT answer as the OBSIDIAN API (another program owns the port)."
    call :both "      Splunk, Jenkins and other tools use port 8000 by default."
    call :both "      Fix 1: stop that program, then run start.bat again."
    call :both "      Fix 2: run OBSIDIAN on port 8010 - see 'Port 8000 already in use' in README.md."
) else (
    call :both "      It answers as the OBSIDIAN API - the backend is already up."
    call :both "      If the workspace still cannot reach it, the browser is"
    call :both "      likely resolving localhost to IPv6. The API now binds"
    call :both "      0.0.0.0 and the frontend calls 127.0.0.1 to avoid that."
)
exit /b 0

:section
echo.
echo  -----------------------------------------------------------
echo   %~1
echo  -----------------------------------------------------------
echo.>> "%LOG%"
echo --- %~1 --->> "%LOG%"
exit /b 0

:both
echo %~1
echo %~1>> "%LOG%"
exit /b 0

:blank
echo.
echo.>> "%LOG%"
exit /b 0

:log
echo %~1>> "%LOG%"
exit /b 0
