<div align="center">

# OBSIDIAN

**AI-Powered Cybersecurity Investigation Platform**

`Observe. Analyze. Defend.`

v0.1.0 · © 2026 Aastha Rawal · All rights reserved (see [LICENSE](LICENSE))

</div>

---

## What this is

OBSIDIAN is an investigation workspace for SOC analysts, DFIR practitioners and
security students. It ingests cyber evidence — packet captures, event logs,
documents, mobile artefacts — and lets an analyst work through it with an AI
assistant that explains what it found and why it matters.

**Phase 0 is complete and running.** It delivers the foundation the rest of the
platform is built on: authentication, authorization, audit, the AI provider
abstraction, and the Analyst Mode workspace shell.

---

## Quick start (Windows)

### Prerequisites

| Tool | Version | Check with |
|---|---|---|
| Python | 3.10 or newer (3.12 recommended) | `python --version` |
| Node.js | 20 or newer | `node --version` |

Install Python from https://www.python.org/downloads/ and tick **Add python.exe
to PATH**. Install Node.js from https://nodejs.org/. Open a new terminal
afterwards so PATH updates apply.

### Step by step

1. Unzip the project somewhere without special permissions, e.g. `C:\OBSIDIAN`.
2. Double-click **`setup.bat`**. It will:
   - create `apps\api\.venv` (and rebuild it automatically if it points at a
     Python that has since been uninstalled),
   - install the Python dependencies,
   - create `apps\api\.env` from `.env.example` with a fresh `OBSIDIAN_SECRET_KEY`,
   - apply database migrations and seed the admin account plus one demo case,
   - create `apps\web\.env.local` and run `npm install`.
3. Double-click **`start.bat`**. It opens the API and web app in two windows and
   your browser.
4. Sign in at **http://localhost:3000**:

```
email     admin@obsidian.io
password  ChangeMe!2026
```

### Running the pieces by hand (Windows, cmd)

```bat
:: Backend  ->  http://127.0.0.1:8000  (docs at /docs)
cd apps\api
.venv\Scripts\activate
uvicorn obsidian.main:app --reload --port 8000

:: Frontend  ->  http://localhost:3000   (in a second terminal)
cd apps\web
npm run dev
```

### Environment variables

Backend, `apps\api\.env` (copy from `.env.example`; every name is prefixed `OBSIDIAN_`):

| Variable | Needed? | Notes |
|---|---|---|
| `OBSIDIAN_SECRET_KEY` | yes | 32+ chars. `setup.bat` generates it. |
| `OBSIDIAN_DATABASE_URL` | yes | Default SQLite file, no server needed. |
| `OBSIDIAN_CORS_ORIGINS` | yes | Default allows `localhost:3000` / `127.0.0.1:3000`. |
| `OBSIDIAN_AI_PROVIDER` | yes | `mock` (default, offline) / `ollama` / `openai` / `anthropic`. |
| `OBSIDIAN_AI_MODEL` | no | Model **name** only, e.g. `gpt-oss:20b`. |
| `OBSIDIAN_OPENAI_API_KEY`, `OBSIDIAN_ANTHROPIC_API_KEY`, `OBSIDIAN_OLLAMA_API_KEY` | only for that provider | Keys go here, never in a URL field. |
| `OBSIDIAN_OPENAI_BASE_URL` | no | An `https://` endpoint (Groq, OpenRouter...), or blank. |
| `OBSIDIAN_THREATINTEL_PROVIDERS` | no | `mock` by default; `abuseipdb,virustotal` need their keys. |
| `OBSIDIAN_SEED_ADMIN_EMAIL` / `_PASSWORD` | no | Used by `seed.py`. Change the password. |

Frontend, `apps\web\.env.local` (copy from `.env.local.example`):

| Variable | Needed? | Notes |
|---|---|---|
| `API_PROXY_TARGET` | no | Where Next forwards `/api/*`. Must be a real environment variable (set by `scripts\run-web.bat`), not only in the file. Default `http://127.0.0.1:8000`. |
| `NEXT_PUBLIC_API_URL` | no | Only if the API lives on a different origin. Blank = same-origin. |
| `NEXT_PUBLIC_APP_NAME` | no | Display name. |

### Port 8000 already in use

Error `WinError 10013` or a message that port 8000 is taken means another program owns the port
(Splunk and Jenkins both use 8000). Run `doctor.bat` to see which one. Either stop that program, or
run OBSIDIAN on another port in two separate Command Prompt windows:

```bat
:: Window 1 - API
cd apps\api
.venv\Scripts\activate
uvicorn obsidian.main:app --port 8010

:: Window 2 - web app
cd apps\web
set API_PROXY_TARGET=http://127.0.0.1:8010
npm run dev
```

### Troubleshooting

| Script | What it does |
|---|---|
| `doctor.bat` | Diagnoses a backend that will not start; writes `doctor-log.txt`. |
| `configure.bat` | Guided setup for AI provider and threat-intel keys; backs up `.env` first. |
| `test.bat` | Backend test suite + frontend type check. |
| `scripts\run-api.bat`, `scripts\run-web.bat` | Start only one half. |

The AI assistant shows "unavailable" if `OBSIDIAN_AI_PROVIDER=ollama` but Ollama
is not running. Start Ollama, or set the provider to `mock`. Nothing else is affected.

---

## Manual setup (macOS / Linux, or if you prefer the steps)


You need **Python 3.10+** and **Node.js 20+**. You do not need Docker,
PostgreSQL, Redis, or an AI API key.

### 1. Backend

```bash
cd apps/api

python -m venv .venv
.venv\Scripts\activate          # Windows
source .venv/bin/activate       # macOS / Linux

pip install -r requirements-dev.txt
pip install -e .                # puts `obsidian` on the import path
```

Create your configuration:

```bash
copy .env.example .env          # Windows
cp .env.example .env            # macOS / Linux
```

Generate a signing secret and paste it into `OBSIDIAN_SECRET_KEY` in `.env`:

```bash
python -c "import secrets; print(secrets.token_urlsafe(64))"
```

Create the schema, seed the first administrator, and start the server:

```bash
alembic upgrade head
python seed.py
uvicorn obsidian.main:app --reload --port 8000
```

The API is now on **http://localhost:8000**, with interactive documentation at
**http://localhost:8000/docs**.

### 2. Frontend

```bash
cd apps/web
npm install
cp .env.local.example .env.local     # copy on Windows
npm run dev
```

> The frontend reaches the API through a same-origin rewrite defined in
> `next.config.mjs`, so the browser only ever talks to `localhost:3000`.
> Point `API_PROXY_TARGET` elsewhere if your API is not on port 8000.

The workspace is on **http://localhost:3000**.

Sign in with the seeded administrator, or register a new account — **the first
account created on a deployment automatically becomes the administrator**.

```
email:    admin@obsidian.io
password: ChangeMe!2026
```

> Change `OBSIDIAN_SEED_ADMIN_PASSWORD` in `.env` before exposing this instance
> to anyone.

---

## Tests

```bash
cd apps/api
pytest -v
```

301 tests cover password hashing, JWT validation and tampering, the full
authentication lifecycle, refresh-token rotation and reuse detection, role
enforcement, administrative guardrails, and the AI provider abstraction.

---

## Project layout

```
OBSIDIAN/
├── apps/
│   ├── api/                    FastAPI service
│   │   ├── pyproject.toml      Package definition (installable via `pip install -e .`)
│   │   ├── src/obsidian/
│   │   │   ├── core/           Config, security, logging, errors, rate limiting
│   │   │   ├── db/             Engine, session, ORM models
│   │   │   ├── domain/         Enums and domain rules
│   │   │   ├── repositories/   Data access (the only place queries are built)
│   │   │   ├── services/       Business logic
│   │   │   ├── schemas/        Pydantic request/response contracts
│   │   │   ├── ai/             Provider abstraction + adapters
│   │   │   └── api/v1/         HTTP routers
│   │   ├── alembic/            Migrations
│   │   └── tests/              Test suite
│   └── web/                    Next.js 15 PWA
│       ├── components.json     shadcn/ui configuration
│       └── src/
│           ├── app/(auth)/     Login, register
│           ├── app/(app)/      Authenticated workspace
│           ├── components/ui/  shadcn/ui primitives (Radix-based)
│           ├── components/     Layout and providers
│           ├── hooks/          Shared client state
│           └── lib/            API client, token store, utilities
└── docs/
    ├── ARCHITECTURE.md         System design
    ├── ROADMAP.md              Phase plan
    └── adr/                    Architecture decision records
```

---

## Configuration

Everything is driven by environment variables prefixed `OBSIDIAN_`. See
`apps/api/.env.example` for the annotated list.

### Switching to PostgreSQL and Redis

```bash
OBSIDIAN_DATABASE_URL=postgresql+asyncpg://obsidian:password@localhost:5432/obsidian
OBSIDIAN_REDIS_URL=redis://localhost:6379/0
pip install -r requirements-prod.txt
```

No application code changes. See [ADR 0001](docs/adr/0001-dialect-agnostic-persistence.md).

### Switching AI provider and adding threat-intel keys

Run **`configure.bat`**. It walks through the options, detects a running Ollama
and lists its installed models, writes `.env` for you and backs it up first.

The default `mock` provider is deterministic and requires no key, so the whole
platform is usable offline.

Free options worth knowing:

| Service | Free tier | Notes |
|---|---|---|
| **Ollama** | unlimited, local | No key, no signup. Nothing leaves the machine — the right choice when evidence legally cannot. |
| **AbuseIPDB** | 1,000 checks/day | 3,000 if you verify a domain. Addresses only. |
| **VirusTotal** | 4/min, 500/day | Non-commercial use only. Covers hashes and domains too. |
| **Groq / OpenRouter** | varies | Any OpenAI-compatible endpoint works via `OBSIDIAN_OPENAI_BASE_URL`. |

See [ADR 0002](docs/adr/0002-ai-provider-abstraction.md).

---

## Design system

The UI is built on **shadcn/ui** — components are generated into
`src/components/ui/` and owned by this repository rather than imported from a
package, so they can be modified freely.

```bash
cd apps/web
npx shadcn@latest add <component>     # e.g. table, sheet, select
```

`components.json` is configured for the New York style with CSS variables. The
OBSIDIAN palette is mapped onto shadcn's token contract (`--card`, `--popover`,
`--secondary`, ...) in `src/app/globals.css`, so newly generated components
inherit the cyberpunk theme with no hand-editing.

Interactive components are built on **Radix UI**, which supplies the behaviour
that hand-rolled equivalents almost always miss: focus trapping and restoration,
portal rendering, background `aria-hidden` isolation, scroll locking, roving
tabindex, and `aria-activedescendant` tracking in the command palette.

---

## Security

| Control | Implementation |
|---|---|
| Password storage | Argon2id, OWASP-baseline cost parameters |
| Access tokens | 15-minute JWT, held in memory only — never `localStorage` |
| Refresh tokens | Opaque, stored as SHA-256 digests, single-use |
| Token theft | Rotation + reuse detection → whole session family revoked |
| Brute force | Account lockout after 5 failures, plus per-IP rate limiting |
| Enumeration | Login responses and timing are identical for unknown accounts |
| Authorization | Four ordered roles enforced by dependency injection |
| Audit | Append-only trail with actor, IP, user agent and request ID |
| Headers | HSTS, CSP, X-Frame-Options, nosniff, Referrer-Policy |
| Dependencies | `npm audit` clean; transitive CVEs pinned via `overrides` |

---

## What's next

Phase 1 adds case management and evidence ingestion with chain-of-custody
hashing. The full plan is in [docs/ROADMAP.md](docs/ROADMAP.md).

Voice Command Mode is deliberately scheduled for Phase 6 — the reasoning is in
[ADR 0004](docs/adr/0004-defer-voice-mode.md).

## License and Copyright

Copyright © 2026 Aastha Rawal. All rights reserved. The source may be viewed for evaluation
(for example academic assessment or recruitment review). Copying, modifying, redistributing
or using it in other projects needs written permission. See [LICENSE](LICENSE).
Third-party libraries keep their own licences.

Before pushing to GitHub, read [PUBLISHING.md](PUBLISHING.md) and run `python scripts/check_secrets.py`.
