"""Translation of exceptions into HTTP responses.

This is the *only* place in the codebase that maps a failure onto a status code.
"""

from __future__ import annotations

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from obsidian.core.config import settings
from obsidian.core.exceptions import ObsidianError, RateLimitExceededError
from obsidian.core.logging import get_logger

logger = get_logger(__name__)


def _response(
    request: Request, status_code: int, payload: dict, headers: dict | None = None
) -> JSONResponse:
    payload["request_id"] = getattr(request.state, "request_id", "-")
    return JSONResponse(status_code=status_code, content=payload, headers=headers)


def register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(ObsidianError)
    async def _handle_domain_error(
        request: Request, exc: ObsidianError
    ) -> JSONResponse:
        headers = None
        if isinstance(exc, RateLimitExceededError):
            retry = exc.details.get("retry_after_seconds")
            if retry is not None:
                headers = {"Retry-After": str(retry)}

        log = logger.warning if exc.status_code < 500 else logger.error
        log(
            "domain.error",
            error_code=exc.error_code,
            status_code=exc.status_code,
            path=request.url.path,
        )
        return _response(request, exc.status_code, exc.to_dict(), headers)

    @app.exception_handler(RequestValidationError)
    async def _handle_validation_error(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        fields = [
            {
                "field": ".".join(str(part) for part in error["loc"][1:]) or "body",
                "message": error["msg"],
                "type": error["type"],
            }
            for error in exc.errors()
        ]
        return _response(
            request,
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            {
                "error": "validation_error",
                "message": "The request payload failed validation.",
                "details": {"fields": fields},
            },
        )

    @app.exception_handler(StarletteHTTPException)
    async def _handle_http_exception(
        request: Request, exc: StarletteHTTPException
    ) -> JSONResponse:
        return _response(
            request,
            exc.status_code,
            {"error": "http_error", "message": str(exc.detail)},
            dict(exc.headers) if exc.headers else None,
        )

    @app.exception_handler(Exception)
    async def _handle_unexpected(request: Request, exc: Exception) -> JSONResponse:
        logger.exception("unhandled.exception", path=request.url.path)
        # Internal detail is surfaced only outside production; leaking stack
        # context to clients is an information-disclosure finding.
        message = (
            f"{type(exc).__name__}: {exc}"
            if settings.debug
            else "An unexpected error occurred."
        )
        return _response(
            request,
            status.HTTP_500_INTERNAL_SERVER_ERROR,
            {"error": "internal_error", "message": message},
        )
