"""Structured logging with request correlation.

Every log line emitted while handling a request carries the same ``request_id``,
which is also returned to the client in the ``X-Request-ID`` header. When a user
reports a failure, that one value retrieves the entire server-side trace.
"""

from __future__ import annotations

import logging
import sys
from contextvars import ContextVar

import structlog

from obsidian.core.config import settings

request_id_ctx: ContextVar[str] = ContextVar("request_id", default="-")


def _inject_request_id(
    _logger: object, _name: str, event_dict: dict
) -> dict:
    event_dict["request_id"] = request_id_ctx.get()
    return event_dict


def configure_logging() -> None:
    """Configure structlog and route stdlib logging through it."""
    renderer = (
        structlog.dev.ConsoleRenderer(colors=True)
        if not settings.is_production
        else structlog.processors.JSONRenderer()
    )

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            _inject_request_id,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            renderer,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            logging.DEBUG if settings.debug else logging.INFO
        ),
        logger_factory=structlog.PrintLoggerFactory(file=sys.stdout),
        cache_logger_on_first_use=True,
    )

    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=logging.DEBUG if settings.debug else logging.INFO,
    )
    for noisy in ("uvicorn.access", "sqlalchemy.engine.Engine", "aiosqlite"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    return structlog.get_logger(name)
