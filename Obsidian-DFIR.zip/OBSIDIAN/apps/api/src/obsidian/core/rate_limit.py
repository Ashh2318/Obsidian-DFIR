"""Fixed-window rate limiting built on the cache abstraction.

Authentication endpoints are limited far more aggressively than the general API,
because they are the ones an attacker actually hammers.

Implementation note
-------------------
The dependency is a **closure**, not an instance of a callable class. FastAPI
resolves a dependency's string annotations (this module uses
``from __future__ import annotations``) through ``call.__globals__``. A class
instance has no ``__globals__``, so ``request: Request`` would fail to resolve
and FastAPI would silently reinterpret it as a required request-body field —
turning every rate-limited route into an automatic HTTP 422.
"""

from __future__ import annotations

from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from typing import Any

from fastapi import Request

from obsidian.core.cache import get_cache
from obsidian.core.config import settings
from obsidian.core.exceptions import RateLimitExceededError


@dataclass(frozen=True, slots=True)
class RateLimitPolicy:
    """A named request budget over a fixed time window."""

    name: str
    requests: int
    window_seconds: int


def default_policy() -> RateLimitPolicy:
    return RateLimitPolicy(
        name="default",
        requests=settings.rate_limit_default_requests,
        window_seconds=settings.rate_limit_default_window_seconds,
    )


def auth_policy() -> RateLimitPolicy:
    return RateLimitPolicy(
        name="auth",
        requests=settings.rate_limit_auth_requests,
        window_seconds=settings.rate_limit_auth_window_seconds,
    )


def client_identifier(request: Request) -> str:
    """Best-effort client identity.

    ``X-Forwarded-For`` is only consulted in production, where the service is
    expected to sit behind a trusted reverse proxy. Trusting it in development
    would let any client spoof its own identity and bypass the limiter entirely.
    """
    if settings.is_production:
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def rate_limiter(
    policy: RateLimitPolicy,
) -> Callable[[Request], Coroutine[Any, Any, None]]:
    """Build a FastAPI dependency enforcing ``policy``."""

    async def _dependency(request: Request) -> None:
        if not settings.rate_limit_enabled:
            return

        identity = client_identifier(request)
        key = f"ratelimit:{policy.name}:{identity}:{request.url.path}"
        count = await get_cache().increment(key, policy.window_seconds)

        if count > policy.requests:
            raise RateLimitExceededError(
                f"Rate limit exceeded: {policy.requests} requests per "
                f"{policy.window_seconds}s.",
                details={
                    "limit": policy.requests,
                    "window_seconds": policy.window_seconds,
                    "retry_after_seconds": policy.window_seconds,
                },
            )

    return _dependency


def rate_limit_default() -> Callable[[Request], Coroutine[Any, Any, None]]:
    return rate_limiter(default_policy())


def rate_limit_auth() -> Callable[[Request], Coroutine[Any, Any, None]]:
    return rate_limiter(auth_policy())
