"""Cryptographic primitives: password hashing and JWT issuance/verification.

Design notes
------------
* **Argon2id**, not bcrypt-via-passlib. passlib has been unmaintained since 2020
  and breaks against bcrypt 4.x; Argon2id is also memory-hard, which raises the
  cost of GPU cracking far more than bcrypt does.
* **Refresh tokens are opaque random strings**, not JWTs, and only their SHA-256
  digest is persisted. A database dump therefore yields nothing replayable.
* Every JWT carries ``jti`` (for revocation and correlation) and ``typ`` (so an
  access token cannot be replayed at the refresh endpoint, or vice versa).
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Final

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

from obsidian.core.config import settings
from obsidian.core.exceptions import TokenError

TOKEN_TYPE_ACCESS: Final = "access"
TOKEN_TYPE_REFRESH: Final = "refresh"

# Cost parameters follow the OWASP Password Storage Cheat Sheet baseline for
# Argon2id (19 MiB memory, 2 iterations, 1 degree of parallelism).
_hasher = PasswordHasher(
    time_cost=2,
    memory_cost=19 * 1024,
    parallelism=1,
    hash_len=32,
    salt_len=16,
)


def utcnow() -> datetime:
    """Timezone-aware UTC now. Naive datetimes are banned in this codebase."""
    return datetime.now(timezone.utc)


# ── Passwords ────────────────────────────────────────────────────────────────
def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return _hasher.verify(password_hash, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def password_needs_rehash(password_hash: str) -> bool:
    """True when a stored hash predates the current cost parameters."""
    try:
        return _hasher.check_needs_rehash(password_hash)
    except InvalidHashError:
        return True


# ── JSON Web Tokens ──────────────────────────────────────────────────────────
def _encode(payload: dict[str, Any]) -> str:
    return jwt.encode(payload, settings.secret_key, algorithm=settings.jwt_algorithm)


def create_access_token(
    subject: str,
    *,
    role: str,
    extra_claims: dict[str, Any] | None = None,
) -> tuple[str, datetime]:
    """Issue a short-lived access token. Returns ``(token, expires_at)``."""
    issued_at = utcnow()
    expires_at = issued_at + timedelta(minutes=settings.access_token_ttl_minutes)
    payload: dict[str, Any] = {
        "sub": subject,
        "role": role,
        "typ": TOKEN_TYPE_ACCESS,
        "jti": str(uuid.uuid4()),
        "iat": int(issued_at.timestamp()),
        "exp": int(expires_at.timestamp()),
        "iss": settings.app_name,
    }
    if extra_claims:
        payload.update(extra_claims)
    return _encode(payload), expires_at


def decode_access_token(token: str) -> dict[str, Any]:
    """Decode and validate an access token, or raise :class:`TokenError`."""
    try:
        payload: dict[str, Any] = jwt.decode(
            token,
            settings.secret_key,
            algorithms=[settings.jwt_algorithm],
            issuer=settings.app_name,
            options={"require": ["exp", "iat", "sub", "jti"]},
        )
    except jwt.ExpiredSignatureError as exc:
        raise TokenError("The access token has expired.") from exc
    except jwt.InvalidTokenError as exc:
        raise TokenError("The access token is invalid.") from exc

    if payload.get("typ") != TOKEN_TYPE_ACCESS:
        # Refusing a refresh token here is what stops a long-lived credential
        # from being used as a bearer token against the whole API.
        raise TokenError("Expected an access token.")
    return payload


# ── Refresh tokens (opaque) ──────────────────────────────────────────────────
def generate_refresh_token() -> tuple[str, str]:
    """Return ``(plaintext, sha256_digest)``. Only the digest is persisted."""
    plaintext = secrets.token_urlsafe(48)
    return plaintext, hash_refresh_token(plaintext)


def hash_refresh_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def refresh_token_expiry() -> datetime:
    return utcnow() + timedelta(days=settings.refresh_token_ttl_days)


def constant_time_compare(left: str, right: str) -> bool:
    return secrets.compare_digest(left, right)


# ── Report integrity ─────────────────────────────────────────────────────────
def sign_content(content: bytes) -> str:
    """HMAC-SHA256 over rendered report bytes, keyed by the instance secret.

    This is a symmetric signature. It attests that the document was produced by
    *this* OBSIDIAN instance and has not been altered since — which is what an
    evidence-handling workflow needs to detect tampering in transit or storage.

    It deliberately does not provide non-repudiation: anyone holding the
    instance secret could forge it. Non-repudiation requires asymmetric signing
    against a key the server never holds alone, which is a PKI decision rather
    than an application one.
    """
    return hmac.new(
        settings.secret_key.encode("utf-8"), content, hashlib.sha256
    ).hexdigest()


def verify_content(content: bytes, signature: str) -> bool:
    """Constant-time verification, so a mismatch leaks nothing by timing."""
    return hmac.compare_digest(sign_content(content), signature)
