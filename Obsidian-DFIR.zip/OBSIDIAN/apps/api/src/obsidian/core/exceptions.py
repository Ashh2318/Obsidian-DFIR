"""Domain exception hierarchy.

Services raise these. The interface layer translates them into HTTP responses in
exactly one place, so no service ever imports FastAPI and no handler duplicates
error-mapping logic.
"""

from __future__ import annotations

from typing import Any


class ObsidianError(Exception):
    """Base class for every expected, domain-level failure."""

    status_code: int = 500
    error_code: str = "internal_error"
    message: str = "An unexpected error occurred."

    def __init__(
        self,
        message: str | None = None,
        *,
        details: dict[str, Any] | None = None,
    ) -> None:
        self.message = message or self.__class__.message
        self.details = details or {}
        super().__init__(self.message)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "error": self.error_code,
            "message": self.message,
        }
        if self.details:
            payload["details"] = self.details
        return payload


# ── 4xx ──────────────────────────────────────────────────────────────────────
class ValidationError(ObsidianError):
    status_code = 422
    error_code = "validation_error"
    message = "The request payload failed validation."


class AuthenticationError(ObsidianError):
    status_code = 401
    error_code = "authentication_failed"
    message = "Authentication failed."


class InvalidCredentialsError(AuthenticationError):
    error_code = "invalid_credentials"
    # Deliberately does not distinguish unknown email from wrong password:
    # doing so turns the login endpoint into an account-enumeration oracle.
    message = "Incorrect email or password."


class TokenError(AuthenticationError):
    error_code = "invalid_token"
    message = "The provided token is invalid or has expired."


class TokenReuseError(AuthenticationError):
    error_code = "token_reuse_detected"
    message = "Session revoked: refresh token reuse was detected."


class AccountDisabledError(AuthenticationError):
    error_code = "account_disabled"
    message = "This account has been disabled."


class PermissionDeniedError(ObsidianError):
    status_code = 403
    error_code = "permission_denied"
    message = "You do not have permission to perform this action."


class NotFoundError(ObsidianError):
    status_code = 404
    error_code = "not_found"
    message = "The requested resource was not found."


class ConflictError(ObsidianError):
    status_code = 409
    error_code = "conflict"
    message = "The request conflicts with the current state of the resource."


class EmailAlreadyRegisteredError(ConflictError):
    error_code = "email_already_registered"
    message = "An account with this email address already exists."


class RateLimitExceededError(ObsidianError):
    status_code = 429
    error_code = "rate_limit_exceeded"
    message = "Too many requests. Please slow down."


# ── 5xx ──────────────────────────────────────────────────────────────────────
class ProviderError(ObsidianError):
    status_code = 502
    error_code = "provider_error"
    message = "An upstream provider failed to respond correctly."


class ConfigurationError(ObsidianError):
    status_code = 500
    error_code = "configuration_error"
    message = "The service is misconfigured."
