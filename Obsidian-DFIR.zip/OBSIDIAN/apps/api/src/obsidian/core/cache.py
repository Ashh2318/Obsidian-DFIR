"""Cache abstraction with an in-memory default and a Redis backend.

Rate limiting and, later, job coordination depend on shared counters. Requiring
Redis for local development would block work on infrastructure, so the interface
is defined here and the backend is selected from configuration at startup.
"""

from __future__ import annotations

import asyncio
import time
from typing import Protocol, runtime_checkable

from obsidian.core.config import settings
from obsidian.core.logging import get_logger

logger = get_logger(__name__)


@runtime_checkable
class CacheBackend(Protocol):
    """Minimal cache surface required by the application."""

    async def increment(self, key: str, ttl_seconds: int) -> int:
        """Atomically increment ``key``, setting its TTL on first write."""
        ...

    async def get(self, key: str) -> str | None: ...

    async def set(self, key: str, value: str, ttl_seconds: int) -> None: ...

    async def delete(self, key: str) -> None: ...

    async def close(self) -> None: ...


class InMemoryCache:
    """Process-local cache backend.

    Correct for single-process development and tests. It is *not* correct across
    replicas, which is precisely why production sets ``OBSIDIAN_REDIS_URL``.
    """

    def __init__(self) -> None:
        self._store: dict[str, tuple[str, float]] = {}
        self._lock = asyncio.Lock()

    def _purge_expired(self, now: float) -> None:
        expired = [k for k, (_, exp) in self._store.items() if exp <= now]
        for key in expired:
            self._store.pop(key, None)

    async def increment(self, key: str, ttl_seconds: int) -> int:
        async with self._lock:
            now = time.monotonic()
            self._purge_expired(now)
            current, expires_at = self._store.get(key, ("0", 0.0))
            if expires_at <= now:
                value, expires_at = 1, now + ttl_seconds
            else:
                value = int(current) + 1
            self._store[key] = (str(value), expires_at)
            return value

    async def get(self, key: str) -> str | None:
        async with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            value, expires_at = entry
            if expires_at <= time.monotonic():
                self._store.pop(key, None)
                return None
            return value

    async def set(self, key: str, value: str, ttl_seconds: int) -> None:
        async with self._lock:
            self._store[key] = (value, time.monotonic() + ttl_seconds)

    async def delete(self, key: str) -> None:
        async with self._lock:
            self._store.pop(key, None)

    async def close(self) -> None:
        async with self._lock:
            self._store.clear()


class RedisCache:
    """Redis-backed cache. Imported lazily so redis stays an optional dependency."""

    def __init__(self, url: str) -> None:
        try:
            from redis.asyncio import from_url
        except ImportError as exc:  # pragma: no cover - depends on environment
            raise RuntimeError(
                "OBSIDIAN_REDIS_URL is set but the 'redis' package is not "
                "installed. Install it with: pip install redis"
            ) from exc
        self._client = from_url(url, encoding="utf-8", decode_responses=True)

    async def increment(self, key: str, ttl_seconds: int) -> int:
        # Pipelined so INCR and EXPIRE cannot interleave with another client,
        # which would otherwise leave a counter with no TTL — a permanent ban.
        async with self._client.pipeline(transaction=True) as pipe:
            pipe.incr(key)
            pipe.expire(key, ttl_seconds, nx=True)
            result = await pipe.execute()
        return int(result[0])

    async def get(self, key: str) -> str | None:
        return await self._client.get(key)

    async def set(self, key: str, value: str, ttl_seconds: int) -> None:
        await self._client.set(key, value, ex=ttl_seconds)

    async def delete(self, key: str) -> None:
        await self._client.delete(key)

    async def close(self) -> None:
        await self._client.aclose()


_cache: CacheBackend | None = None


def get_cache() -> CacheBackend:
    """Return the process-wide cache backend, creating it on first use."""
    global _cache
    if _cache is None:
        if settings.redis_url:
            logger.info("cache.backend.selected", backend="redis")
            _cache = RedisCache(settings.redis_url)
        else:
            logger.info("cache.backend.selected", backend="in-memory")
            _cache = InMemoryCache()
    return _cache


async def close_cache() -> None:
    global _cache
    if _cache is not None:
        await _cache.close()
        _cache = None
