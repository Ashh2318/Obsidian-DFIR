"""Content-addressed evidence storage.

Files are written under a SHA-256 derived path rather than their original name.
Two artefacts with identical content occupy one blob, an attacker cannot choose
where a file lands, and the storage layout carries no attacker-controlled text.
"""

from __future__ import annotations

import hashlib
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Protocol, runtime_checkable

from obsidian.core.config import settings
from obsidian.core.logging import get_logger

logger = get_logger(__name__)

CHUNK_SIZE = 1024 * 1024  # 1 MiB


@dataclass(frozen=True, slots=True)
class StoredObject:
    """Result of persisting an artefact."""

    relative_path: str
    size_bytes: int
    sha256: str
    md5: str
    header: bytes


@runtime_checkable
class StorageBackend(Protocol):
    async def store(self, source: BinaryIO, *, filename: str) -> StoredObject: ...
    def resolve(self, relative_path: str) -> Path: ...
    async def delete(self, relative_path: str) -> None: ...


class LocalStorage:
    """Filesystem backend rooted at ``OBSIDIAN_STORAGE_ROOT``."""

    def __init__(self, root: str | None = None) -> None:
        self._root = Path(root or settings.storage_root).resolve()
        self._root.mkdir(parents=True, exist_ok=True)

    async def store(self, source: BinaryIO, *, filename: str) -> StoredObject:
        """Stream ``source`` to disk, hashing as it goes.

        Hashes are computed during the single pass rather than by re-reading the
        file afterwards: evidence can be gigabytes, and a second full read
        doubles the I/O for no benefit.
        """
        sha256 = hashlib.sha256()
        md5 = hashlib.md5(usedforsecurity=False)
        size = 0
        header = b""

        temp_path = self._root / f".incoming-{os.urandom(8).hex()}"
        try:
            with temp_path.open("wb") as destination:
                while chunk := source.read(CHUNK_SIZE):
                    if not header:
                        header = chunk[:64]
                    sha256.update(chunk)
                    md5.update(chunk)
                    size += len(chunk)
                    destination.write(chunk)

            digest = sha256.hexdigest()
            # Two-level fan-out keeps directory sizes manageable; a single flat
            # directory degrades badly past a few tens of thousands of entries.
            relative = Path(digest[:2]) / digest[2:4] / digest
            final_path = self._root / relative
            final_path.parent.mkdir(parents=True, exist_ok=True)

            if final_path.exists():
                # Identical content already stored. Discard the duplicate blob;
                # the database still records a distinct evidence row.
                temp_path.unlink(missing_ok=True)
                logger.info("storage.deduplicated", sha256=digest)
            else:
                _replace_with_retry(temp_path, final_path)

            return StoredObject(
                relative_path=str(relative).replace("\\", "/"),
                size_bytes=size,
                sha256=digest,
                md5=md5.hexdigest(),
                header=header,
            )
        except Exception:
            temp_path.unlink(missing_ok=True)
            raise

    def resolve(self, relative_path: str) -> Path:
        """Resolve a stored path, refusing anything that escapes the root."""
        candidate = (self._root / relative_path).resolve()
        if not candidate.is_relative_to(self._root):
            raise ValueError("Resolved path escapes the storage root.")
        return candidate

    async def delete(self, relative_path: str) -> None:
        self.resolve(relative_path).unlink(missing_ok=True)


def _replace_with_retry(source: Path, destination: Path, attempts: int = 5) -> None:
    """Move a completed upload into place, retrying briefly on Windows.

    On Windows a file that was just written is frequently still held open by
    real-time antivirus — Defender scans freshly written executables and APKs
    aggressively — and ``os.replace`` then fails with WinError 32. The file is
    released within milliseconds, so a short backoff turns a hard 500 into a
    successful upload. On POSIX this loop never iterates.
    """
    delay = 0.05
    for attempt in range(attempts):
        try:
            source.replace(destination)
            return
        except PermissionError:
            if attempt == attempts - 1:
                logger.error(
                    "storage.rename.locked",
                    path=str(destination),
                    detail="The file was still locked after retrying; antivirus "
                    "or another process is holding it.",
                )
                raise
            time.sleep(delay)
            delay *= 2


_storage: StorageBackend | None = None


def get_storage() -> StorageBackend:
    global _storage
    if _storage is None:
        _storage = LocalStorage()
        logger.info("storage.backend.selected", backend="local", root=settings.storage_root)
    return _storage
