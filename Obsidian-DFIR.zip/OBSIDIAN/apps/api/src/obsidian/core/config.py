"""Typed application configuration.

Settings are the single source of truth for runtime behaviour. Nothing in the
codebase reads ``os.environ`` directly; everything resolves through this module,
which makes configuration auditable and testable via dependency override.
"""

from __future__ import annotations

import secrets
from functools import lru_cache
from typing import Literal

from pydantic import Field, computed_field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

Environment = Literal["development", "staging", "production", "test"]
AIProviderName = Literal["mock", "anthropic", "openai", "ollama"]


class Settings(BaseSettings):
    """Runtime configuration loaded from environment and ``.env``."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="OBSIDIAN_",
        extra="ignore",
        case_sensitive=False,
    )

    # ── Application ──────────────────────────────────────────────────────────
    app_name: str = "OBSIDIAN"
    app_tagline: str = "Observe. Analyze. Defend."
    api_v1_prefix: str = "/api/v1"
    environment: Environment = "development"
    debug: bool = False
    api_host: str = "0.0.0.0"
    api_port: int = 8000

    # ── Security ─────────────────────────────────────────────────────────────
    secret_key: str = Field(default_factory=lambda: secrets.token_urlsafe(64))
    jwt_algorithm: str = "HS256"
    access_token_ttl_minutes: int = Field(default=15, ge=1, le=1440)
    refresh_token_ttl_days: int = Field(default=7, ge=1, le=90)
    password_min_length: int = Field(default=12, ge=8, le=128)

    # ── Persistence ──────────────────────────────────────────────────────────
    database_url: str = "sqlite+aiosqlite:///./obsidian.db"
    database_echo: bool = False
    database_pool_size: int = Field(default=10, ge=1, le=100)
    database_max_overflow: int = Field(default=20, ge=0, le=100)

    # ── Cache / rate limiting ────────────────────────────────────────────────
    redis_url: str = ""
    rate_limit_enabled: bool = True
    rate_limit_default_requests: int = Field(default=300, ge=1)
    rate_limit_default_window_seconds: int = Field(default=60, ge=1)
    rate_limit_auth_requests: int = Field(default=10, ge=1)
    rate_limit_auth_window_seconds: int = Field(default=60, ge=1)

    # ── CORS ─────────────────────────────────────────────────────────────────
    cors_origins: list[str] = Field(
        default_factory=lambda: ["http://localhost:3000", "http://127.0.0.1:3000"]
    )

    # ── Storage ──────────────────────────────────────────────────────────────
    storage_root: str = "./storage"
    max_upload_bytes: int = Field(default=512 * 1024 * 1024)  # 512 MiB

    # ── AI ───────────────────────────────────────────────────────────────────
    ai_provider: AIProviderName = "mock"
    ai_model: str = ""
    ai_timeout_seconds: int = Field(default=120, ge=1)
    ai_max_tokens: int = Field(default=4096, ge=1)
    anthropic_api_key: str = ""
    openai_api_key: str = ""
    # Any OpenAI-compatible endpoint: Groq, OpenRouter, Together, LM Studio, vLLM.
    openai_base_url: str = ""
    ollama_base_url: str = "http://localhost:11434"
    # Ollama's hosted service (ollama.com) authenticates with a bearer token.
    # Setting a key switches the default base URL to the cloud endpoint, so the
    # two deployments differ by one setting rather than two.
    ollama_api_key: str = ""

    # ── Threat intelligence ──────────────────────────────────────────────────
    # Comma-separated. Feeds run concurrently and their verdicts are combined.
    threatintel_providers: str = "mock"
    threatintel_cache_hours: int = Field(default=24, ge=1, le=720)
    virustotal_api_key: str = ""
    abuseipdb_api_key: str = ""

    # ── Bootstrap ────────────────────────────────────────────────────────────
    seed_admin_email: str = "admin@obsidian.io"
    seed_admin_password: str = "ChangeMe!2026"

    # ── Validation ───────────────────────────────────────────────────────────
    @field_validator("cors_origins", mode="before")
    @classmethod
    def _split_origins(cls, value: object) -> object:
        """Accept both a JSON array and a comma-separated string."""
        if isinstance(value, str) and not value.strip().startswith("["):
            return [item.strip() for item in value.split(",") if item.strip()]
        return value

    @field_validator("secret_key")
    @classmethod
    def _reject_weak_secret(cls, value: str) -> str:
        if len(value) < 32:
            raise ValueError(
                "OBSIDIAN_SECRET_KEY must be at least 32 characters. "
                'Generate one with: python -c "import secrets; '
                'print(secrets.token_urlsafe(64))"'
            )
        return value

    # ── Derived ──────────────────────────────────────────────────────────────
    @computed_field  # type: ignore[prop-decorator]
    @property
    def is_production(self) -> bool:
        return self.environment == "production"

    @computed_field  # type: ignore[prop-decorator]
    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")

    def model_post_init(self, __context: object) -> None:
        # A production deployment must never fall back to a generated secret,
        # because every process restart would silently invalidate all sessions
        # and every replica would sign tokens with a different key.
        if self.is_production and self.debug:
            raise ValueError("OBSIDIAN_DEBUG must be false in production.")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the process-wide settings singleton."""
    return Settings()


settings = get_settings()
