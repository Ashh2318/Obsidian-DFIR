"""Application factory and lifespan management."""

from __future__ import annotations

from contextlib import asynccontextmanager
from collections.abc import AsyncIterator

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from obsidian.ai.registry import close_provider, get_provider
from obsidian.api.v1.router import api_router
from obsidian.core.cache import close_cache, get_cache
from obsidian.core.config import settings
from obsidian.core.errors import register_exception_handlers
from obsidian.core.logging import configure_logging, get_logger
from obsidian.core.middleware import RequestContextMiddleware, SecurityHeadersMiddleware
from obsidian.core.rate_limit import rate_limit_default
from obsidian.db.session import dispose_engine

logger = get_logger(__name__)

DESCRIPTION = """
**OBSIDIAN** — AI-powered cybersecurity investigation platform.

*Observe. Analyze. Defend.*

### Authentication
Call `POST /api/v1/auth/login` to obtain a token pair, then send the access
token as `Authorization: Bearer <token>`.

Access tokens are short-lived. When one expires, call
`POST /api/v1/auth/refresh` with the refresh token to rotate it. A refresh token
is single-use: replaying a spent token revokes every session in its family.

### Roles
`viewer` < `analyst` < `investigator` < `admin`
"""


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
    configure_logging()
    logger.info(
        "application.starting",
        environment=settings.environment,
        database="sqlite" if settings.is_sqlite else "postgresql",
    )
    # Constructing these at startup surfaces misconfiguration immediately rather
    # than on the first request that happens to need them.
    get_cache()
    get_provider()
    logger.info("application.ready", port=settings.api_port)
    try:
        yield
    finally:
        await close_provider()
        await close_cache()
        await dispose_engine()
        logger.info("application.stopped")


def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.app_name,
        description=DESCRIPTION,
        summary=settings.app_tagline,
        version="0.1.0",
        lifespan=lifespan,
        # API documentation is a reconnaissance aid; it is disabled in production.
        docs_url=None if settings.is_production else "/docs",
        redoc_url=None if settings.is_production else "/redoc",
        openapi_url=None if settings.is_production else "/openapi.json",
    )

    # Middleware executes in reverse registration order, so security headers are
    # added last and therefore applied to every response, including errors.
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RequestContextMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
        expose_headers=["X-Request-ID", "X-Response-Time-ms"],
        max_age=3600,
    )

    register_exception_handlers(app)

    app.include_router(
        api_router,
        prefix=settings.api_v1_prefix,
        dependencies=[Depends(rate_limit_default())],
    )

    @app.get("/", include_in_schema=False)
    async def root() -> dict[str, str]:
        return {
            "name": settings.app_name,
            "tagline": settings.app_tagline,
            "version": "0.1.0",
            "docs": "/docs" if not settings.is_production else "disabled",
            "api": settings.api_v1_prefix,
        }

    return app


app = create_app()
