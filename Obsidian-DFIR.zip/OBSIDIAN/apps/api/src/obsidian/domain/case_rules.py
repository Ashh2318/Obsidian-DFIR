"""Case workflow rules.

Kept in the domain layer, free of SQLAlchemy and FastAPI, so the transition
table is testable in isolation and has exactly one definition. A service that
encoded these as scattered ``if`` statements would drift the moment a second
caller appeared.
"""

from __future__ import annotations

from obsidian.domain.enums import CaseStatus

# An incident moves forward through triage, may be reopened from CONTAINED or
# CLOSED when new evidence lands, and ARCHIVED is terminal — archived cases are
# a retention artefact and must not silently re-enter the active queue.
ALLOWED_TRANSITIONS: dict[CaseStatus, frozenset[CaseStatus]] = {
    CaseStatus.OPEN: frozenset({CaseStatus.IN_PROGRESS, CaseStatus.CLOSED}),
    CaseStatus.IN_PROGRESS: frozenset(
        {CaseStatus.CONTAINED, CaseStatus.CLOSED, CaseStatus.OPEN}
    ),
    CaseStatus.CONTAINED: frozenset({CaseStatus.CLOSED, CaseStatus.IN_PROGRESS}),
    CaseStatus.CLOSED: frozenset({CaseStatus.ARCHIVED, CaseStatus.IN_PROGRESS}),
    CaseStatus.ARCHIVED: frozenset(),
}

TERMINAL_STATUSES = frozenset({CaseStatus.ARCHIVED})
CLOSING_STATUSES = frozenset({CaseStatus.CLOSED, CaseStatus.ARCHIVED})


def can_transition(current: CaseStatus, target: CaseStatus) -> bool:
    """True when ``current`` may move to ``target``."""
    if current is target:
        return True
    return target in ALLOWED_TRANSITIONS.get(current, frozenset())


def allowed_next(current: CaseStatus) -> frozenset[CaseStatus]:
    return ALLOWED_TRANSITIONS.get(current, frozenset())
