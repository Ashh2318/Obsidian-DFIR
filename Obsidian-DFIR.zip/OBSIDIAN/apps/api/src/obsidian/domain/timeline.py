"""Timeline event contract.

One shape for every event regardless of origin, so the API and the UI have a
single renderer rather than a branch per source.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from obsidian.domain.enums import Severity, TimelineEventKind, TimelineSource


@dataclass(slots=True)
class TimelineEvent:
    """One dated occurrence on a case."""

    id: str
    occurred_at: datetime
    kind: TimelineEventKind
    source: TimelineSource
    title: str
    description: str | None = None
    severity: Severity = Severity.INFO
    case_id: str | None = None
    case_reference: str | None = None
    actor: str | None = None
    evidence_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "occurred_at": self.occurred_at.isoformat(),
            "kind": self.kind.value,
            "source": self.source.value,
            "title": self.title,
            "description": self.description,
            "severity": self.severity.value,
            "case_id": self.case_id,
            "case_reference": self.case_reference,
            "actor": self.actor,
            "evidence_id": self.evidence_id,
            "metadata": self.metadata,
        }


def sort_events(events: list[TimelineEvent], *, newest_first: bool = True) -> list[TimelineEvent]:
    """Order chronologically, breaking ties deterministically.

    Events assembled from different sources routinely share a timestamp — an
    upload and its audit record are written in the same transaction. Sorting on
    time alone leaves their order at the mercy of dict iteration, so the id is
    used as a stable secondary key.
    """
    return sorted(
        events,
        key=lambda event: (event.occurred_at, event.id),
        reverse=newest_first,
    )
