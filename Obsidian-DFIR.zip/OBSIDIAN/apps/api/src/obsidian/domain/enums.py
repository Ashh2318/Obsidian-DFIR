"""Domain enumerations.

``str`` is mixed in rather than using :class:`enum.StrEnum` so the codebase runs
on Python 3.10 as well as 3.11+, and so values serialise transparently to JSON
and persist as readable strings in the database.
"""

from __future__ import annotations

from enum import Enum


class Role(str, Enum):
    """Access roles, strictly ordered by privilege."""

    VIEWER = "viewer"
    ANALYST = "analyst"
    INVESTIGATOR = "investigator"
    ADMIN = "admin"

    @property
    def level(self) -> int:
        return _ROLE_LEVELS[self]

    def satisfies(self, required: "Role") -> bool:
        """True when this role meets or exceeds ``required``."""
        return self.level >= required.level


_ROLE_LEVELS: dict[Role, int] = {
    Role.VIEWER: 10,
    Role.ANALYST: 20,
    Role.INVESTIGATOR: 30,
    Role.ADMIN: 40,
}


class AuditAction(str, Enum):
    """Security-relevant events recorded in the append-only audit trail."""

    USER_REGISTERED = "user.registered"
    USER_LOGIN_SUCCEEDED = "user.login.succeeded"
    USER_LOGIN_FAILED = "user.login.failed"
    USER_LOGGED_OUT = "user.logged_out"
    USER_ROLE_CHANGED = "user.role.changed"
    USER_DISABLED = "user.disabled"
    USER_ENABLED = "user.enabled"
    TOKEN_REFRESHED = "token.refreshed"
    TOKEN_REUSE_DETECTED = "token.reuse_detected"
    SESSIONS_REVOKED = "sessions.revoked"
    CASE_CREATED = "case.created"
    CASE_UPDATED = "case.updated"
    CASE_STATUS_CHANGED = "case.status_changed"
    EVIDENCE_UPLOADED = "evidence.uploaded"
    EVIDENCE_DELETED = "evidence.deleted"
    ANALYSIS_STARTED = "analysis.started"
    ANALYSIS_COMPLETED = "analysis.completed"
    REPORT_GENERATED = "report.generated"
    IOC_ENRICHED = "ioc.enriched"
    CONVERSATION_STARTED = "conversation.started"
    ASSISTANT_QUERIED = "assistant.queried"


class CaseStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    CONTAINED = "contained"
    CLOSED = "closed"
    ARCHIVED = "archived"


class Severity(str, Enum):
    """Aligned with common SOC triage scales."""

    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @property
    def rank(self) -> int:
        return _SEVERITY_RANKS[self]


_SEVERITY_RANKS: dict[Severity, int] = {
    Severity.INFO: 0,
    Severity.LOW: 1,
    Severity.MEDIUM: 2,
    Severity.HIGH: 3,
    Severity.CRITICAL: 4,
}


class EvidenceType(str, Enum):
    PCAP = "pcap"
    EVTX = "evtx"
    LOG = "log"
    CSV = "csv"
    JSON = "json"
    TEXT = "text"
    DOCUMENT = "document"
    PDF = "pdf"
    APK = "apk"
    ARCHIVE = "archive"
    HASH = "hash"
    URL = "url"
    YARA = "yara"
    SIGMA = "sigma"
    UNKNOWN = "unknown"


class EvidenceStatus(str, Enum):
    UPLOADED = "uploaded"
    QUEUED = "queued"
    ANALYZING = "analyzing"
    ANALYZED = "analyzed"
    FAILED = "failed"
    QUARANTINED = "quarantined"


class IOCType(str, Enum):
    """Indicator categories OBSIDIAN extracts and pivots on."""

    IPV4 = "ipv4"
    IPV6 = "ipv6"
    DOMAIN = "domain"
    URL = "url"
    EMAIL = "email"
    MD5 = "md5"
    SHA1 = "sha1"
    SHA256 = "sha256"
    FILENAME = "filename"
    REGISTRY_KEY = "registry_key"
    USER_AGENT = "user_agent"
    PORT = "port"


class FindingCategory(str, Enum):
    """Detection families produced by the analysis engines."""

    BEACONING = "beaconing"
    PORT_SCAN = "port_scan"
    BRUTE_FORCE = "brute_force"
    DNS_TUNNELING = "dns_tunneling"
    DATA_EXFILTRATION = "data_exfiltration"
    SUSPICIOUS_PROTOCOL = "suspicious_protocol"
    PLAINTEXT_CREDENTIALS = "plaintext_credentials"
    ANOMALY = "anomaly"


class MessageRole(str, Enum):
    """Conversation roles persisted alongside assistant exchanges."""

    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


class TimelineSource(str, Enum):
    """Where a timeline event came from.

    The distinction between INCIDENT and INVESTIGATION is the point of a
    forensic timeline. An artefact uploaded at 09:00 may describe traffic from
    three days earlier; conflating the two produces a chronology that looks
    coherent and is wrong.
    """

    INCIDENT = "incident"          # derived from evidence content — when it happened
    INVESTIGATION = "investigation"  # analyst and system activity — when we responded


class TimelineEventKind(str, Enum):
    CASE_OPENED = "case.opened"
    CASE_STATUS_CHANGED = "case.status_changed"
    EVIDENCE_UPLOADED = "evidence.uploaded"
    ANALYSIS_COMPLETED = "analysis.completed"
    FINDING_RAISED = "finding.raised"
    CAPTURE_WINDOW = "capture.window"
    INDICATOR_OBSERVED = "indicator.observed"


class ThreatVerdict(str, Enum):
    """Aggregated reputation judgement for an indicator."""

    UNKNOWN = "unknown"        # no provider had an opinion
    BENIGN = "benign"
    SUSPICIOUS = "suspicious"
    MALICIOUS = "malicious"

    @property
    def rank(self) -> int:
        return _VERDICT_RANKS[self]


_VERDICT_RANKS: dict[ThreatVerdict, int] = {
    ThreatVerdict.UNKNOWN: 0,
    ThreatVerdict.BENIGN: 1,
    ThreatVerdict.SUSPICIOUS: 2,
    ThreatVerdict.MALICIOUS: 3,
}


class IntentAction(str, Enum):
    """Actions Voice Command Mode can invoke.

    Each maps onto a service call the UI already makes. Voice is a second
    entry point to the same behaviour, never a parallel implementation of it.
    """

    NAVIGATE = "navigate"
    LIST_CASES = "list_cases"
    OPEN_CASE = "open_case"
    CASE_SUMMARY = "case_summary"
    CHANGE_STATUS = "change_status"
    ANALYZE_EVIDENCE = "analyze_evidence"
    LIST_FINDINGS = "list_findings"
    LIST_IOCS = "list_iocs"
    UPLOAD_EVIDENCE = "upload_evidence"
    ENRICH_IOCS = "enrich_iocs"
    GENERATE_REPORT = "generate_report"
    ASK_ASSISTANT = "ask_assistant"
    FOLLOW_UP = "follow_up"
    OFF_TOPIC = "off_topic"
    HELP = "help"
    UNKNOWN = "unknown"


class IntentConfidence(str, Enum):
    """How the intent was determined, which governs whether to confirm first."""

    EXACT = "exact"        # matched a deterministic pattern
    INFERRED = "inferred"  # classified by the AI provider
    AMBIGUOUS = "ambiguous"
    NONE = "none"
