"""Evidence classification.

Type detection is by magic bytes first, extension second. A filename is
attacker-controlled metadata; on a forensics platform it is a hint, never an
authority.
"""

from __future__ import annotations

from obsidian.domain.enums import EvidenceType

# (offset, signature, type). Ordered most specific first.
MAGIC_SIGNATURES: tuple[tuple[int, bytes, EvidenceType], ...] = (
    (0, b"\xd4\xc3\xb2\xa1", EvidenceType.PCAP),      # libpcap, little-endian
    (0, b"\xa1\xb2\xc3\xd4", EvidenceType.PCAP),      # libpcap, big-endian
    (0, b"\x0a\x0d\x0d\x0a", EvidenceType.PCAP),      # pcapng
    (0, b"ElfFile\x00", EvidenceType.EVTX),           # Windows EVTX
    (0, b"%PDF-", EvidenceType.PDF),
    (0, b"PK\x03\x04", EvidenceType.ARCHIVE),         # zip container
    (0, b"Rar!\x1a\x07", EvidenceType.ARCHIVE),
    (0, b"\x37\x7a\xbc\xaf\x27\x1c", EvidenceType.ARCHIVE),  # 7z
    (0, b"\x1f\x8b", EvidenceType.ARCHIVE),           # gzip
    (0, b"\xd0\xcf\x11\xe0", EvidenceType.DOCUMENT),  # legacy OLE2 office
)

EXTENSION_MAP: dict[str, EvidenceType] = {
    "pcap": EvidenceType.PCAP,
    "pcapng": EvidenceType.PCAP,
    "cap": EvidenceType.PCAP,
    "evtx": EvidenceType.EVTX,
    "evt": EvidenceType.EVTX,
    "log": EvidenceType.LOG,
    "csv": EvidenceType.CSV,
    "tsv": EvidenceType.CSV,
    "json": EvidenceType.JSON,
    "txt": EvidenceType.TEXT,
    "md": EvidenceType.TEXT,
    "pdf": EvidenceType.PDF,
    "docx": EvidenceType.DOCUMENT,
    "doc": EvidenceType.DOCUMENT,
    "rtf": EvidenceType.DOCUMENT,
    "apk": EvidenceType.APK,
    "zip": EvidenceType.ARCHIVE,
    "rar": EvidenceType.ARCHIVE,
    "7z": EvidenceType.ARCHIVE,
    "gz": EvidenceType.ARCHIVE,
    "tar": EvidenceType.ARCHIVE,
    "yar": EvidenceType.YARA,
    "yara": EvidenceType.YARA,
    "yml": EvidenceType.SIGMA,
    "yaml": EvidenceType.SIGMA,
}


def extension_of(filename: str) -> str:
    _, _, extension = filename.rpartition(".")
    return extension.lower() if extension and extension != filename else ""


def detect_type(filename: str, header: bytes) -> EvidenceType:
    """Classify an artefact from its leading bytes, falling back to extension."""
    for offset, signature, evidence_type in MAGIC_SIGNATURES:
        if header[offset : offset + len(signature)] == signature:
            # A zip container is ambiguous: APK, DOCX and plain archives all
            # share it. The extension is the only available discriminator
            # without opening the container, which belongs to Phase 2.
            if evidence_type is EvidenceType.ARCHIVE:
                by_extension = EXTENSION_MAP.get(extension_of(filename))
                if by_extension in (EvidenceType.APK, EvidenceType.DOCUMENT):
                    return by_extension
            return evidence_type

    return EXTENSION_MAP.get(extension_of(filename), EvidenceType.UNKNOWN)


def sanitize_filename(filename: str) -> str:
    """Strip path components and control characters.

    An uploaded name may contain '../' or a Windows drive prefix; both are
    classic path-traversal vectors. Only the basename is ever retained, and the
    stored path is generated server-side regardless.
    """
    name = filename.replace("\\", "/").split("/")[-1]
    cleaned = "".join(c for c in name if c.isprintable() and c not in '<>:"|?*')
    cleaned = cleaned.strip(". ")
    return cleaned[:255] or "unnamed"
