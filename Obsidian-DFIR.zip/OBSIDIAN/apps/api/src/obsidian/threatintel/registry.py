"""Threat-intel provider resolution.

Several feeds run concurrently and their answers are combined, unlike the AI
layer where exactly one provider serves a request. Configuration is therefore a
list rather than a single name.
"""

from __future__ import annotations

from obsidian.core.config import settings
from obsidian.core.logging import get_logger
from obsidian.threatintel.base import ThreatIntelProvider
from obsidian.threatintel.providers.abuseipdb import AbuseIPDBProvider
from obsidian.threatintel.providers.mock import MockThreatIntelProvider
from obsidian.threatintel.providers.virustotal import VirusTotalProvider

logger = get_logger(__name__)

_providers: list[ThreatIntelProvider] | None = None


def _build() -> list[ThreatIntelProvider]:
    configured = [
        name.strip().lower()
        for name in settings.threatintel_providers.split(",")
        if name.strip()
    ]
    built: list[ThreatIntelProvider] = []

    for name in configured:
        if name == "mock":
            built.append(MockThreatIntelProvider())
        elif name == "virustotal":
            if settings.virustotal_api_key:
                built.append(VirusTotalProvider(settings.virustotal_api_key))
            else:
                # Skipped rather than raised: one missing key must not disable
                # every other feed the deployment did configure correctly.
                logger.warning("threatintel.provider.skipped", provider=name,
                               reason="OBSIDIAN_VIRUSTOTAL_API_KEY is not set")
        elif name == "abuseipdb":
            if settings.abuseipdb_api_key:
                built.append(AbuseIPDBProvider(settings.abuseipdb_api_key))
            else:
                logger.warning("threatintel.provider.skipped", provider=name,
                               reason="OBSIDIAN_ABUSEIPDB_API_KEY is not set")
        else:
            logger.warning("threatintel.provider.unknown", provider=name)

    if not built:
        logger.info("threatintel.provider.fallback", provider="mock")
        built.append(MockThreatIntelProvider())

    logger.info("threatintel.providers.selected", providers=[p.name for p in built])
    return built


def get_providers() -> list[ThreatIntelProvider]:
    global _providers
    if _providers is None:
        _providers = _build()
    return _providers


def provider_names() -> list[str]:
    return [p.name for p in get_providers()]


async def close_providers() -> None:
    global _providers
    if _providers is not None:
        for provider in _providers:
            await provider.close()
        _providers = None
