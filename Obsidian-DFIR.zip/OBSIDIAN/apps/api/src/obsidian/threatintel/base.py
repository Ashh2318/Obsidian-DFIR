"""Threat-intelligence provider contract.

Mirrors the AI provider pattern deliberately: one protocol, a registry that
resolves from configuration, and a deterministic mock so the feature is usable
and testable with no API keys and no network.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from obsidian.domain.enums import IOCType, ThreatVerdict


@dataclass(slots=True)
class ProviderResult:
    """One feed's opinion about one indicator."""

    provider: str
    verdict: ThreatVerdict
    #: 0-100. The meaning is provider-specific; the aggregator normalises it.
    score: int = 0
    detail: str = ""
    #: Raw fields worth surfacing, e.g. ASN, country, detection ratio.
    attributes: dict[str, Any] = field(default_factory=dict)
    #: Set when the provider could not be reached or refused the query. A
    #: failure is recorded rather than silently treated as "benign", because
    #: absence of evidence is not evidence of absence.
    error: str | None = None

    @property
    def succeeded(self) -> bool:
        return self.error is None

    def to_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "verdict": self.verdict.value,
            "score": self.score,
            "detail": self.detail,
            "attributes": self.attributes,
            "error": self.error,
        }


@runtime_checkable
class ThreatIntelProvider(Protocol):
    """Contract every reputation feed implements."""

    name: str

    def supports(self, ioc_type: IOCType) -> bool: ...

    async def lookup(self, ioc_type: IOCType, value: str) -> ProviderResult: ...

    async def close(self) -> None: ...
