"""Deterministic offline reputation provider.

Seeded from the indicator value, so the same address always yields the same
verdict. That reproducibility is what makes enrichment testable — you cannot
write a stable assertion against a live feed whose answer changes hourly.

It is not a simulation of real threat intelligence and does not pretend to be:
the detail string says so plainly, so nobody mistakes a mock verdict for
evidence in a report.
"""

from __future__ import annotations

import hashlib

from obsidian.domain.enums import IOCType, ThreatVerdict
from obsidian.threatintel.base import ProviderResult

SUPPORTED = frozenset(
    {
        IOCType.IPV4,
        IOCType.IPV6,
        IOCType.DOMAIN,
        IOCType.URL,
        IOCType.MD5,
        IOCType.SHA1,
        IOCType.SHA256,
    }
)

_COUNTRIES = ("NL", "RU", "US", "DE", "CN", "SE", "PA", "SC")


class MockThreatIntelProvider:
    name = "mock"

    def supports(self, ioc_type: IOCType) -> bool:
        return ioc_type in SUPPORTED

    async def lookup(self, ioc_type: IOCType, value: str) -> ProviderResult:
        digest = hashlib.sha256(f"{ioc_type.value}:{value}".encode()).digest()
        bucket = digest[0] % 100

        if bucket < 12:
            verdict, score = ThreatVerdict.MALICIOUS, 70 + (digest[1] % 30)
        elif bucket < 30:
            verdict, score = ThreatVerdict.SUSPICIOUS, 40 + (digest[1] % 30)
        elif bucket < 75:
            verdict, score = ThreatVerdict.BENIGN, digest[1] % 20
        else:
            verdict, score = ThreatVerdict.UNKNOWN, 0

        return ProviderResult(
            provider=self.name,
            verdict=verdict,
            score=score,
            detail=(
                "Deterministic offline verdict. Configure a live feed via "
                "OBSIDIAN_THREATINTEL_PROVIDERS for real reputation data."
            ),
            attributes={
                "country": _COUNTRIES[digest[2] % len(_COUNTRIES)],
                "asn": f"AS{10000 + (digest[3] << 8 | digest[4]) % 55000}",
                "first_seen_days_ago": digest[5] % 900,
                "simulated": True,
            },
        )

    async def close(self) -> None:
        return None
