"""AbuseIPDB reputation lookups."""

from __future__ import annotations

import httpx

from obsidian.domain.enums import IOCType, ThreatVerdict
from obsidian.threatintel.base import ProviderResult

BASE_URL = "https://api.abuseipdb.com/api/v2/check"


class AbuseIPDBProvider:
    name = "abuseipdb"

    def __init__(self, api_key: str, timeout: int = 20) -> None:
        self._client = httpx.AsyncClient(
            timeout=timeout, headers={"Key": api_key, "Accept": "application/json"}
        )

    def supports(self, ioc_type: IOCType) -> bool:
        # Address reputation only; this feed has no opinion on hashes or domains.
        return ioc_type in (IOCType.IPV4, IOCType.IPV6)

    async def lookup(self, ioc_type: IOCType, value: str) -> ProviderResult:
        if not self.supports(ioc_type):
            return ProviderResult(
                self.name, ThreatVerdict.UNKNOWN, error=f"{ioc_type.value} unsupported"
            )

        try:
            response = await self._client.get(
                BASE_URL, params={"ipAddress": value, "maxAgeInDays": 90}
            )
        except httpx.HTTPError as exc:
            return ProviderResult(self.name, ThreatVerdict.UNKNOWN, error=str(exc))

        if response.status_code >= 400:
            return ProviderResult(
                self.name,
                ThreatVerdict.UNKNOWN,
                error=f"AbuseIPDB returned {response.status_code}.",
            )

        data = response.json().get("data", {})
        confidence = int(data.get("abuseConfidenceScore", 0))

        if confidence >= 75:
            verdict = ThreatVerdict.MALICIOUS
        elif confidence >= 25:
            verdict = ThreatVerdict.SUSPICIOUS
        elif data.get("totalReports", 0) == 0:
            verdict = ThreatVerdict.BENIGN
        else:
            verdict = ThreatVerdict.SUSPICIOUS

        return ProviderResult(
            provider=self.name,
            verdict=verdict,
            score=confidence,
            detail=(
                f"{data.get('totalReports', 0)} report(s), "
                f"{confidence}% abuse confidence."
            ),
            attributes={
                "total_reports": data.get("totalReports"),
                "country": data.get("countryCode"),
                "isp": data.get("isp"),
                "usage_type": data.get("usageType"),
                "is_tor": data.get("isTor"),
            },
        )

    async def close(self) -> None:
        await self._client.aclose()
