"""VirusTotal reputation lookups (API v3)."""

from __future__ import annotations

import httpx

from obsidian.domain.enums import IOCType, ThreatVerdict
from obsidian.threatintel.base import ProviderResult

BASE_URL = "https://www.virustotal.com/api/v3"

ENDPOINTS = {
    IOCType.IPV4: "ip_addresses",
    IOCType.IPV6: "ip_addresses",
    IOCType.DOMAIN: "domains",
    IOCType.MD5: "files",
    IOCType.SHA1: "files",
    IOCType.SHA256: "files",
}


class VirusTotalProvider:
    name = "virustotal"

    def __init__(self, api_key: str, timeout: int = 20) -> None:
        self._api_key = api_key
        self._client = httpx.AsyncClient(
            timeout=timeout, headers={"x-apikey": api_key, "accept": "application/json"}
        )

    def supports(self, ioc_type: IOCType) -> bool:
        return ioc_type in ENDPOINTS

    async def lookup(self, ioc_type: IOCType, value: str) -> ProviderResult:
        endpoint = ENDPOINTS.get(ioc_type)
        if endpoint is None:
            return ProviderResult(
                self.name, ThreatVerdict.UNKNOWN, error=f"{ioc_type.value} unsupported"
            )

        try:
            response = await self._client.get(f"{BASE_URL}/{endpoint}/{value}")
        except httpx.HTTPError as exc:
            return ProviderResult(self.name, ThreatVerdict.UNKNOWN, error=str(exc))

        if response.status_code == 404:
            # Genuinely "not in the corpus" - distinct from an outage, and a
            # meaningful answer in its own right.
            return ProviderResult(
                self.name, ThreatVerdict.UNKNOWN, detail="Not present in VirusTotal."
            )
        if response.status_code == 429:
            return ProviderResult(
                self.name, ThreatVerdict.UNKNOWN, error="Rate limit exceeded."
            )
        if response.status_code >= 400:
            return ProviderResult(
                self.name,
                ThreatVerdict.UNKNOWN,
                error=f"VirusTotal returned {response.status_code}.",
            )

        attributes = response.json().get("data", {}).get("attributes", {})
        stats = attributes.get("last_analysis_stats", {})
        malicious = int(stats.get("malicious", 0))
        suspicious = int(stats.get("suspicious", 0))
        total = sum(int(v) for v in stats.values()) or 1

        if malicious >= 3:
            verdict = ThreatVerdict.MALICIOUS
        elif malicious or suspicious:
            verdict = ThreatVerdict.SUSPICIOUS
        elif total > 1:
            verdict = ThreatVerdict.BENIGN
        else:
            verdict = ThreatVerdict.UNKNOWN

        return ProviderResult(
            provider=self.name,
            verdict=verdict,
            score=min(100, round((malicious + suspicious) / total * 100)),
            detail=f"{malicious}/{total} engines flagged this indicator.",
            attributes={
                "malicious": malicious,
                "suspicious": suspicious,
                "engines": total,
                "reputation": attributes.get("reputation"),
                "country": attributes.get("country"),
                "asn": attributes.get("asn"),
            },
        )

    async def close(self) -> None:
        await self._client.aclose()
