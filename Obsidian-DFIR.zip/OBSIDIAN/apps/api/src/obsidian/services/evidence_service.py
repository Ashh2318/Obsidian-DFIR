"""Evidence ingestion and chain of custody."""

from __future__ import annotations

from typing import BinaryIO

from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.core.config import settings
from obsidian.core.exceptions import ConflictError, NotFoundError, ValidationError
from obsidian.core.logging import get_logger
from obsidian.core.storage import get_storage
from obsidian.db.models.evidence import Evidence
from obsidian.db.models.user import User
from obsidian.domain.enums import AuditAction, EvidenceStatus
from obsidian.domain.evidence_rules import detect_type, sanitize_filename
from obsidian.repositories.case_repository import CaseRepository
from obsidian.repositories.evidence_repository import EvidenceRepository
from obsidian.services.audit_service import AuditService, RequestContext

logger = get_logger(__name__)


class EvidenceService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._evidence = EvidenceRepository(session)
        self._cases = CaseRepository(session)
        self._audit = AuditService(session)
        self._storage = get_storage()

    async def get(self, evidence_id: str) -> Evidence:
        item = await self._evidence.get(evidence_id)
        if item is None:
            raise NotFoundError("No evidence exists with that identifier.")
        return item

    async def list_for_case(
        self, case_id: str, *, limit: int, offset: int
    ) -> tuple[list[Evidence], int]:
        if await self._cases.get(case_id) is None:
            raise NotFoundError("No case exists with that identifier.")
        rows, total = await self._evidence.list_for_case(case_id, limit=limit, offset=offset)
        return list(rows), total

    async def ingest(
        self,
        *,
        actor: User,
        case_id: str,
        source: BinaryIO,
        filename: str,
        media_type: str | None = None,
        notes: str | None = None,
        context: RequestContext | None = None,
    ) -> Evidence:
        """Persist an artefact and record its chain of custody.

        Both SHA-256 and MD5 are captured at ingest. SHA-256 is the integrity
        anchor; MD5 exists only because most threat-intel corpora are still
        keyed on it, and is never used to make an integrity decision.
        """
        case = await self._cases.get(case_id)
        if case is None:
            raise NotFoundError("No case exists with that identifier.")

        safe_name = sanitize_filename(filename)
        stored = await self._storage.store(source, filename=safe_name)

        if stored.size_bytes == 0:
            await self._storage.delete(stored.relative_path)
            raise ValidationError("The uploaded file is empty.")

        if stored.size_bytes > settings.max_upload_bytes:
            await self._storage.delete(stored.relative_path)
            raise ValidationError(
                f"File exceeds the maximum upload size of "
                f"{settings.max_upload_bytes // (1024 * 1024)} MB.",
                details={"size_bytes": stored.size_bytes},
            )

        duplicate = await self._evidence.find_by_sha256(case_id, stored.sha256)
        if duplicate is not None:
            # The blob is content-addressed and shared, so it is deliberately not
            # deleted here — another evidence row still references it.
            raise ConflictError(
                "This artefact is already attached to the case.",
                details={
                    "existing_evidence_id": duplicate.id,
                    "sha256": stored.sha256,
                },
            )

        evidence = Evidence(
            case_id=case_id,
            uploaded_by_id=actor.id,
            original_filename=safe_name,
            stored_path=stored.relative_path,
            media_type=media_type,
            size_bytes=stored.size_bytes,
            evidence_type=detect_type(safe_name, stored.header),
            status=EvidenceStatus.UPLOADED,
            sha256=stored.sha256,
            md5=stored.md5,
            notes=notes,
        )
        await self._evidence.add(evidence)

        await self._audit.record(
            AuditAction.EVIDENCE_UPLOADED,
            actor=actor,
            resource_type="evidence",
            resource_id=evidence.id,
            context=context,
            metadata={
                "case_id": case_id,
                "case_reference": case.reference,
                "filename": safe_name,
                "sha256": stored.sha256,
                "size_bytes": stored.size_bytes,
                "detected_type": evidence.evidence_type.value,
            },
        )
        logger.info(
            "evidence.ingested",
            evidence_id=evidence.id,
            case_id=case_id,
            sha256=stored.sha256,
            size=stored.size_bytes,
        )
        return evidence

    async def delete(
        self,
        *,
        actor: User,
        evidence_id: str,
        context: RequestContext | None = None,
    ) -> None:
        evidence = await self.get(evidence_id)

        await self._audit.record(
            AuditAction.EVIDENCE_DELETED,
            actor=actor,
            resource_type="evidence",
            resource_id=evidence.id,
            context=context,
            metadata={
                "case_id": evidence.case_id,
                "filename": evidence.original_filename,
                "sha256": evidence.sha256,
            },
        )
        await self._evidence.delete(evidence)

        # The blob is intentionally retained. Storage is content-addressed and
        # may be referenced by another case; reclaiming it belongs to an
        # out-of-band garbage collector that can prove no references remain.

    async def statistics(self, case_id: str | None = None) -> dict[str, object]:
        return {
            "by_type": await self._evidence.count_by_type(case_id),
            "total_bytes": await self._evidence.total_bytes(case_id),
        }
