"""Case context assembly for the AI assistant.

This module is the difference between an analyst tool and a chatbot. The model
never sees the database; it sees a bounded, ordered digest of the investigation
assembled here.

Two constraints shape the design:

* **Budget.** Context windows are finite and tokens cost money. Sections are
  prioritised — findings before raw statistics, high-severity indicators before
  low — and truncated at a character budget rather than dumping everything and
  hoping.
* **Honesty.** The digest states what is *absent* as clearly as what is present.
  A model told nothing about evidence will confidently invent some.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.db.models.case import Case
from obsidian.domain.enums import Severity
from obsidian.repositories.case_repository import CaseRepository
from obsidian.repositories.evidence_repository import EvidenceRepository
from obsidian.repositories.ioc_repository import IOCRepository

# Roughly 4 characters per token; this keeps the digest near 3k tokens, leaving
# the rest of the window for conversation history and the answer itself.
MAX_CONTEXT_CHARS = 12_000

MAX_EVIDENCE_ITEMS = 20
MAX_FINDINGS = 15
MAX_IOCS = 40

SYSTEM_PROMPT = """You are the OBSIDIAN investigation assistant, supporting a \
security analyst during an active incident investigation.

Ground every answer in the case context provided below. When the context does \
not contain what is needed to answer, say so plainly and name what evidence \
would resolve it — do not speculate and do not invent findings, indicators, \
hostnames or timestamps.

Refer to indicators and artefacts by their exact values as given. Where a \
detection maps to MITRE ATT&CK, cite the technique identifier. Be concise and \
concrete: an analyst is reading this mid-incident, not for background. Prefer \
short paragraphs and tight lists over prose. Use markdown, including tables \
where a comparison is genuinely clearer as one.

If asked to assess severity or next steps, distinguish clearly between what the \
evidence shows and what it merely suggests.

SCOPE. You assist with security investigations in OBSIDIAN and nothing else: \
cases, evidence, analysis findings, indicators of compromise, threat \
intelligence, timelines, reports, and the security concepts an analyst needs to \
interpret them. General security and forensics questions are in scope, because \
an analyst reasoning about an incident needs them.

If asked about anything outside that — weather, sport, entertainment, cooking, \
personal advice, general trivia, or unrelated programming help — reply exactly: \
"Sorry, I cannot help with that. I only work with security investigations in \
OBSIDIAN." Do not answer the question, do not apologise at length, and do not \
explain the restriction further."""


async def build_case_context(session: AsyncSession, case_id: str) -> str:
    """Render an investigation into a prompt-ready digest."""
    case: Case | None = await CaseRepository(session).get(case_id)
    if case is None:
        return ""

    evidence_repo = EvidenceRepository(session)
    ioc_repo = IOCRepository(session)

    evidence_items, evidence_total = await evidence_repo.list_for_case(
        case_id, limit=MAX_EVIDENCE_ITEMS, offset=0
    )
    iocs, ioc_total = await ioc_repo.search(limit=MAX_IOCS, offset=0, case_id=case_id)

    lines: list[str] = [
        "# CASE CONTEXT",
        "",
        f"Reference: {case.reference}",
        f"Title: {case.title}",
        f"Status: {case.status.value}",
        f"Severity: {case.severity.value}",
    ]
    if case.summary:
        lines.append(f"Summary: {case.summary}")

    # ── Evidence ─────────────────────────────────────────────────────────────
    lines += ["", f"## EVIDENCE ({evidence_total} item(s))"]
    if not evidence_items:
        lines.append("No evidence has been uploaded to this case yet.")
    else:
        for item in evidence_items:
            state = item.status.value
            lines.append(
                f"- {item.original_filename} "
                f"[type={item.evidence_type.value}, size={item.size_bytes}B, "
                f"status={state}, sha256={item.sha256[:16]}...]"
            )
        if evidence_total > len(evidence_items):
            lines.append(
                f"({evidence_total - len(evidence_items)} further item(s) not shown.)"
            )

    # ── Findings, ordered by severity ────────────────────────────────────────
    findings: list[tuple[int, str]] = []
    for item in evidence_items:
        summary = item.analysis_summary or {}
        for finding in summary.get("findings", []):
            try:
                rank = Severity(finding.get("severity", "info")).rank
            except ValueError:
                rank = 0
            techniques = ", ".join(finding.get("mitre_techniques", [])) or "none"
            findings.append(
                (
                    rank,
                    f"- [{finding.get('severity', 'info').upper()}] "
                    f"{finding.get('title', 'Untitled')} "
                    f"(confidence {finding.get('confidence', 0)}%, "
                    f"ATT&CK: {techniques}) — {finding.get('description', '')}",
                )
            )

    analysed = [i for i in evidence_items if i.analysis_summary]
    lines += ["", f"## FINDINGS ({len(findings)} across {len(analysed)} analysed artefact(s))"]
    if not findings:
        if analysed:
            lines.append("Analysis completed with no detections raised.")
        else:
            lines.append(
                "No artefact has been analysed yet, so no detections exist. "
                "Do not infer findings that are not listed here."
            )
    else:
        findings.sort(key=lambda pair: pair[0], reverse=True)
        lines += [text for _, text in findings[:MAX_FINDINGS]]
        if len(findings) > MAX_FINDINGS:
            lines.append(f"({len(findings) - MAX_FINDINGS} lower-severity finding(s) omitted.)")

    # ── Indicators ───────────────────────────────────────────────────────────
    lines += ["", f"## INDICATORS ({ioc_total} total)"]
    if not iocs:
        lines.append("No indicators have been extracted from this case.")
    else:
        for ioc in iocs:
            lines.append(
                f"- {ioc.ioc_type.value}: {ioc.value} "
                f"(severity {ioc.severity.value}, confidence {ioc.confidence}%, "
                f"{ioc.sightings} sighting(s))"
            )
        if ioc_total > len(iocs):
            lines.append(f"({ioc_total - len(iocs)} further indicator(s) not shown.)")

    digest = "\n".join(lines)
    if len(digest) > MAX_CONTEXT_CHARS:
        # Truncate at a line boundary so the model never receives a half-written
        # indicator that it might then quote as fact.
        digest = digest[:MAX_CONTEXT_CHARS].rsplit("\n", 1)[0]
        digest += "\n\n[Context truncated to fit the model's budget.]"
    return digest


def build_system_prompt(case_context: str | None) -> str:
    if not case_context:
        return (
            SYSTEM_PROMPT
            + "\n\nNo case is currently attached to this conversation, so you have "
            "no evidence, findings or indicators to work from. Answer general "
            "security questions, and when asked about specifics say that a case "
            "must be attached first."
        )
    return f"{SYSTEM_PROMPT}\n\n{case_context}"
