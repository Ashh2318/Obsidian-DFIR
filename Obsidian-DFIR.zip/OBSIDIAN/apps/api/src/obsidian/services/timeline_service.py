"""Forensic timeline assembly.

Events are derived from records that already exist — the audit trail, evidence
metadata and stored analysis results — rather than written to a separate table
during each action. A parallel event log would drift from the records it
duplicates the moment any write path forgot to append to it, and a timeline that
disagrees with the audit trail is worse than none.
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.core.exceptions import NotFoundError
from obsidian.db.models.audit_log import AuditLog
from obsidian.db.models.case import Case
from obsidian.db.models.evidence import Evidence
from obsidian.domain.enums import (
    AuditAction,
    Severity,
    TimelineEventKind,
    TimelineSource,
)
from obsidian.domain.timeline import TimelineEvent, sort_events
from obsidian.repositories.case_repository import CaseRepository

# Audit actions that belong on an investigation timeline. Everything else —
# logins, token refreshes — is security telemetry, not case chronology, and
# would bury the events an analyst is looking for.
RELEVANT_AUDIT_ACTIONS = {
    AuditAction.CASE_CREATED: TimelineEventKind.CASE_OPENED,
    AuditAction.CASE_STATUS_CHANGED: TimelineEventKind.CASE_STATUS_CHANGED,
    AuditAction.EVIDENCE_UPLOADED: TimelineEventKind.EVIDENCE_UPLOADED,
    AuditAction.ANALYSIS_COMPLETED: TimelineEventKind.ANALYSIS_COMPLETED,
}


def _as_utc(value: datetime) -> datetime:
    """Normalise to aware UTC.

    SQLite returns naive datetimes while PostgreSQL returns aware ones. Sorting
    a mixed list raises, so every timestamp is normalised on the way in.
    """
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value


class TimelineService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._cases = CaseRepository(session)

    async def for_case(self, case_id: str) -> list[TimelineEvent]:
        case = await self._cases.get(case_id)
        if case is None:
            raise NotFoundError("No case exists with that identifier.")

        events: list[TimelineEvent] = []
        events += await self._investigation_events(case)
        events += await self._incident_events(case)
        return sort_events(events)

    async def recent(self, *, limit: int = 100) -> list[TimelineEvent]:
        """Cross-case activity, for the global timeline view."""
        stmt = (
            select(AuditLog)
            .where(AuditLog.action.in_(list(RELEVANT_AUDIT_ACTIONS)))
            .order_by(AuditLog.created_at.desc())
            .limit(limit)
        )
        rows = (await self._session.execute(stmt)).scalars().all()

        # Resolve case references in one query rather than per row.
        case_ids = {
            r.meta.get("case_id")
            for r in rows
            if r.meta and r.meta.get("case_id")
        } | {r.resource_id for r in rows if r.resource_type == "case" and r.resource_id}
        references: dict[str, str] = {}
        if case_ids:
            case_rows = (
                await self._session.execute(
                    select(Case.id, Case.reference).where(Case.id.in_(list(case_ids)))
                )
            ).all()
            references = {cid: ref for cid, ref in case_rows}

        events = [
            self._from_audit(entry, references)
            for entry in rows
            if entry.action in RELEVANT_AUDIT_ACTIONS
        ]
        return sort_events([e for e in events if e is not None])

    # ── Investigation activity ───────────────────────────────────────────────
    async def _investigation_events(self, case: Case) -> list[TimelineEvent]:
        stmt = select(AuditLog).where(
            AuditLog.action.in_(list(RELEVANT_AUDIT_ACTIONS))
        )
        rows = (await self._session.execute(stmt)).scalars().all()

        relevant = [
            entry
            for entry in rows
            if entry.resource_id == case.id
            or (entry.meta or {}).get("case_id") == case.id
        ]
        references = {case.id: case.reference}
        return [
            event
            for event in (self._from_audit(entry, references) for entry in relevant)
            if event is not None
        ]

    def _from_audit(
        self, entry: AuditLog, references: dict[str, str]
    ) -> TimelineEvent | None:
        kind = RELEVANT_AUDIT_ACTIONS.get(entry.action)
        if kind is None:
            return None

        meta = entry.meta or {}
        case_id = (
            entry.resource_id if entry.resource_type == "case" else meta.get("case_id")
        )

        if kind is TimelineEventKind.CASE_OPENED:
            title = f"Case opened — {meta.get('reference', '')}".strip(" —")
            description = f"Severity assessed as {meta.get('severity', 'unknown')}."
            severity = Severity.INFO
        elif kind is TimelineEventKind.CASE_STATUS_CHANGED:
            title = f"Status changed to {meta.get('to', 'unknown')}"
            description = f"Previously {meta.get('from', 'unknown')}."
            severity = Severity.INFO
        elif kind is TimelineEventKind.EVIDENCE_UPLOADED:
            title = f"Evidence ingested — {meta.get('filename', 'artefact')}"
            description = (
                f"{meta.get('detected_type', 'unknown')} artefact, "
                f"{meta.get('size_bytes', 0)} bytes, "
                f"sha256 {str(meta.get('sha256', ''))[:16]}..."
            )
            severity = Severity.INFO
        else:  # ANALYSIS_COMPLETED
            findings = meta.get("findings", 0)
            risk = meta.get("risk_score", 0)
            title = f"Analysis completed — {findings} finding(s)"
            description = f"Engine {meta.get('engine', 'unknown')} scored risk {risk}/100."
            severity = (
                Severity.HIGH
                if risk >= 70
                else Severity.MEDIUM
                if risk >= 40
                else Severity.INFO
            )

        return TimelineEvent(
            id=f"audit:{entry.id}",
            occurred_at=_as_utc(entry.created_at),
            kind=kind,
            source=TimelineSource.INVESTIGATION,
            title=title,
            description=description,
            severity=severity,
            case_id=case_id,
            case_reference=references.get(case_id or "", None),
            actor=entry.actor_email,
            evidence_id=entry.resource_id if entry.resource_type == "evidence" else None,
            metadata=meta,
        )

    # ── Incident activity, derived from evidence content ─────────────────────
    async def _incident_events(self, case: Case) -> list[TimelineEvent]:
        stmt = select(Evidence).where(Evidence.case_id == case.id)
        artefacts = (await self._session.execute(stmt)).scalars().all()

        events: list[TimelineEvent] = []
        for artefact in artefacts:
            summary = artefact.analysis_summary or {}
            statistics = summary.get("statistics") or {}

            # When the traffic actually occurred, which is rarely when it was
            # uploaded. This is the whole reason the timeline separates sources.
            first_epoch = statistics.get("first_packet_epoch")
            last_epoch = statistics.get("last_packet_epoch")
            if isinstance(first_epoch, (int, float)) and first_epoch > 0:
                captured_from = datetime.fromtimestamp(first_epoch, timezone.utc)
                captured_to = (
                    datetime.fromtimestamp(last_epoch, timezone.utc)
                    if isinstance(last_epoch, (int, float))
                    else captured_from
                )
                events.append(
                    TimelineEvent(
                        id=f"capture:{artefact.id}",
                        occurred_at=captured_from,
                        kind=TimelineEventKind.CAPTURE_WINDOW,
                        source=TimelineSource.INCIDENT,
                        title=f"Capture window — {artefact.original_filename}",
                        description=(
                            f"Traffic recorded from {captured_from.isoformat()} to "
                            f"{captured_to.isoformat()} "
                            f"({statistics.get('packets', 0):,} packets)."
                        ),
                        severity=Severity.INFO,
                        case_id=case.id,
                        case_reference=case.reference,
                        evidence_id=artefact.id,
                        metadata={
                            "from": captured_from.isoformat(),
                            "to": captured_to.isoformat(),
                            "packets": statistics.get("packets", 0),
                        },
                    )
                )

            # Findings are attributed to the capture window where one exists, so
            # a detection sits at the time of the activity rather than the time
            # of the upload.
            anchor = (
                datetime.fromtimestamp(first_epoch, timezone.utc)
                if isinstance(first_epoch, (int, float)) and first_epoch > 0
                else _as_utc(artefact.created_at)
            )
            for index, finding in enumerate(summary.get("findings", [])):
                try:
                    severity = Severity(finding.get("severity", "info"))
                except ValueError:
                    severity = Severity.INFO
                events.append(
                    TimelineEvent(
                        id=f"finding:{artefact.id}:{index}",
                        occurred_at=anchor,
                        kind=TimelineEventKind.FINDING_RAISED,
                        source=TimelineSource.INCIDENT,
                        title=finding.get("title", "Detection"),
                        description=finding.get("description"),
                        severity=severity,
                        case_id=case.id,
                        case_reference=case.reference,
                        evidence_id=artefact.id,
                        metadata={
                            "confidence": finding.get("confidence", 0),
                            "mitre_techniques": finding.get("mitre_techniques", []),
                            "category": finding.get("category"),
                            "artefact": artefact.original_filename,
                        },
                    )
                )
        return events
