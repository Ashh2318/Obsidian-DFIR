"""IOC enrichment against threat-intelligence feeds."""

from __future__ import annotations

import asyncio
from datetime import timedelta

from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.core.config import settings
from obsidian.core.exceptions import NotFoundError
from obsidian.core.logging import get_logger
from obsidian.core.security import utcnow
from obsidian.db.models.enrichment import IOCEnrichment
from obsidian.db.models.user import User
from obsidian.domain.enums import AuditAction, IOCType, Severity, ThreatVerdict
from obsidian.repositories.enrichment_repository import EnrichmentRepository
from obsidian.repositories.ioc_repository import IOCRepository
from obsidian.services.audit_service import AuditService, RequestContext
from obsidian.threatintel.base import ProviderResult
from obsidian.threatintel.registry import get_providers

logger = get_logger(__name__)


class EnrichmentService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._cache = EnrichmentRepository(session)
        self._iocs = IOCRepository(session)
        self._audit = AuditService(session)

    # ── Aggregation ──────────────────────────────────────────────────────────
    @staticmethod
    def aggregate(results: list[ProviderResult]) -> tuple[ThreatVerdict, int]:
        """Combine provider opinions into one verdict and score.

        The rule is deliberately asymmetric: the **worst** successful verdict
        wins. In reputation data a single credible malicious hit outweighs any
        number of feeds that simply have no record of the indicator, and
        averaging would let silence dilute a true positive into "benign".

        Failed lookups are excluded entirely rather than counted as benign — a
        feed being unreachable says nothing about the indicator.
        """
        successful = [r for r in results if r.succeeded]
        if not successful:
            return ThreatVerdict.UNKNOWN, 0

        worst = max(successful, key=lambda r: (r.verdict.rank, r.score))
        if worst.verdict is ThreatVerdict.UNKNOWN:
            return ThreatVerdict.UNKNOWN, 0

        # Score is the highest reported by any provider sharing the winning
        # verdict, so a strong signal is not averaged away by a weak agreement.
        score = max(
            r.score for r in successful if r.verdict is worst.verdict
        )
        return worst.verdict, score

    # ── Enrichment ───────────────────────────────────────────────────────────
    async def enrich_value(
        self,
        *,
        ioc_type: IOCType,
        value: str,
        force: bool = False,
    ) -> IOCEnrichment:
        """Return a cached verdict, refreshing it when stale or forced."""
        now = utcnow()
        cached = await self._cache.find(ioc_type, value)
        if cached is not None and not force and cached.is_fresh(now):
            logger.debug("threatintel.cache.hit", value=value)
            return cached

        providers = [p for p in get_providers() if p.supports(ioc_type)]
        if not providers:
            results: list[ProviderResult] = []
        else:
            # Queried concurrently: feeds are independent and network-bound, so
            # serialising them would make enrichment as slow as their sum.
            # return_exceptions keeps one misbehaving feed from cancelling the rest.
            raw = await asyncio.gather(
                *(p.lookup(ioc_type, value) for p in providers),
                return_exceptions=True,
            )
            results = []
            for provider, outcome in zip(providers, raw):
                if isinstance(outcome, BaseException):
                    results.append(
                        ProviderResult(
                            provider.name, ThreatVerdict.UNKNOWN, error=str(outcome)
                        )
                    )
                else:
                    results.append(outcome)

        verdict, score = self.aggregate(results)
        expires = now + timedelta(hours=settings.threatintel_cache_hours)
        payload = {r.provider: r.to_dict() for r in results}

        if cached is None:
            cached = IOCEnrichment(
                ioc_type=ioc_type,
                value=value,
                verdict=verdict,
                score=score,
                providers=payload,
                fetched_at=now,
                expires_at=expires,
            )
            await self._cache.add(cached)
        else:
            cached.verdict = verdict
            cached.score = score
            cached.providers = payload
            cached.fetched_at = now
            cached.expires_at = expires
            await self._cache.flush()

        logger.info(
            "threatintel.enriched",
            value=value,
            verdict=verdict.value,
            score=score,
            providers=len(results),
        )
        return cached

    async def enrich_ioc(
        self,
        *,
        actor: User,
        ioc_id: str,
        force: bool = False,
        context: RequestContext | None = None,
    ) -> tuple[IOCEnrichment, str]:
        ioc = await self._iocs.get(ioc_id)
        if ioc is None:
            raise NotFoundError("No indicator exists with that identifier.")

        enrichment = await self.enrich_value(
            ioc_type=ioc.ioc_type, value=ioc.value, force=force
        )

        # A malicious verdict is new information about the case, so the
        # indicator's own severity is raised to match rather than left stale.
        if enrichment.verdict is ThreatVerdict.MALICIOUS:
            if ioc.severity.rank < Severity.HIGH.rank:
                ioc.severity = Severity.HIGH
            ioc.confidence = min(99, max(ioc.confidence, enrichment.score))

        await self._audit.record(
            AuditAction.IOC_ENRICHED,
            actor=actor,
            resource_type="ioc",
            resource_id=ioc.id,
            context=context,
            metadata={
                "case_id": ioc.case_id,
                "value": ioc.value,
                "verdict": enrichment.verdict.value,
                "score": enrichment.score,
            },
        )
        return enrichment, ioc.case_id

    async def enrich_case(
        self,
        *,
        actor: User,
        case_id: str,
        limit: int = 25,
        context: RequestContext | None = None,
    ) -> list[IOCEnrichment]:
        """Enrich a case's most significant indicators in one pass."""
        iocs, _ = await self._iocs.search(limit=limit, offset=0, case_id=case_id)
        enrichments = []
        for ioc in iocs:
            enrichment, _ = await self.enrich_ioc(
                actor=actor, ioc_id=ioc.id, context=context
            )
            enrichments.append(enrichment)
        return enrichments

    async def statistics(self) -> dict[str, int]:
        return await self._cache.count_by_verdict()
