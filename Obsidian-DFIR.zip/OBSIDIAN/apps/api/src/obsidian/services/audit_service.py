"""Append-only audit trail service."""

from __future__ import annotations

from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.core.logging import request_id_ctx
from obsidian.db.models.audit_log import AuditLog
from obsidian.db.models.user import User
from obsidian.domain.enums import AuditAction
from obsidian.repositories.audit_repository import AuditRepository


class RequestContext:
    """Client attribution captured at the edge and passed down to services.

    Services must not import ``Request``; passing this value object keeps the
    application layer transport-agnostic, which is also what will let Voice Mode
    invoke the same services later without an HTTP request existing at all.
    """

    __slots__ = ("ip_address", "user_agent", "request_id")

    def __init__(
        self,
        ip_address: str | None = None,
        user_agent: str | None = None,
        request_id: str | None = None,
    ) -> None:
        self.ip_address = ip_address
        self.user_agent = (user_agent or "")[:512] or None
        self.request_id = request_id or request_id_ctx.get()


class AuditService:
    def __init__(self, session: AsyncSession) -> None:
        self._repo = AuditRepository(session)

    async def record(
        self,
        action: AuditAction,
        *,
        actor: User | None = None,
        actor_email: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        succeeded: bool = True,
        message: str | None = None,
        context: RequestContext | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> AuditLog:
        ctx = context or RequestContext()
        entry = AuditLog(
            actor_id=actor.id if actor else None,
            # Denormalised so the trail survives the account being deleted.
            actor_email=actor.email if actor else actor_email,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            succeeded=succeeded,
            message=message,
            ip_address=ctx.ip_address,
            user_agent=ctx.user_agent,
            request_id=ctx.request_id,
            meta=metadata,
        )
        return await self._repo.add(entry)

    async def list(
        self, *, limit: int, offset: int, actor_id: str | None = None
    ) -> tuple[list[AuditLog], int]:
        rows, total = await self._repo.list_paginated(
            limit=limit, offset=offset, actor_id=actor_id
        )
        return list(rows), total
