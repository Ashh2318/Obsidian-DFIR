"""Authentication and session lifecycle.

Implements ADR 0003: short-lived access tokens, rotating refresh tokens stored
as digests, and family revocation on reuse.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta

from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.core.config import settings
from obsidian.core.exceptions import (
    AccountDisabledError,
    EmailAlreadyRegisteredError,
    InvalidCredentialsError,
    TokenError,
    TokenReuseError,
)
from obsidian.core.logging import get_logger
from obsidian.core.security import (
    create_access_token,
    generate_refresh_token,
    hash_password,
    hash_refresh_token,
    password_needs_rehash,
    refresh_token_expiry,
    utcnow,
    verify_password,
)
from obsidian.db.models.refresh_token import RefreshToken
from obsidian.db.models.user import User
from obsidian.domain.enums import AuditAction, Role
from obsidian.repositories.refresh_token_repository import RefreshTokenRepository
from obsidian.repositories.user_repository import UserRepository
from obsidian.services.audit_service import AuditService, RequestContext

logger = get_logger(__name__)

MAX_FAILED_ATTEMPTS = 5
LOCKOUT_DURATION = timedelta(minutes=15)


@dataclass(slots=True)
class TokenPair:
    access_token: str
    refresh_token: str
    expires_at: datetime
    token_type: str = "bearer"

    @property
    def expires_in(self) -> int:
        return max(0, int((self.expires_at - utcnow()).total_seconds()))


@dataclass(slots=True)
class AuthResult:
    user: User
    tokens: TokenPair


class AuthService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._users = UserRepository(session)
        self._tokens = RefreshTokenRepository(session)
        self._audit = AuditService(session)

    # ── Registration ─────────────────────────────────────────────────────────
    async def register(
        self,
        *,
        email: str,
        password: str,
        full_name: str,
        organization: str | None = None,
        job_title: str | None = None,
        context: RequestContext | None = None,
    ) -> User:
        normalized = email.strip().lower()
        if await self._users.email_exists(normalized):
            raise EmailAlreadyRegisteredError()

        # The very first account becomes the administrator; otherwise a fresh
        # deployment has no way to reach admin-only functionality.
        is_first_user = await self._users.count() == 0
        role = Role.ADMIN if is_first_user else Role.ANALYST

        user = User(
            email=normalized,
            full_name=full_name.strip(),
            password_hash=hash_password(password),
            role=role,
            organization=organization,
            job_title=job_title,
            is_active=True,
            is_verified=is_first_user,
        )
        await self._users.add(user)
        await self._audit.record(
            AuditAction.USER_REGISTERED,
            actor=user,
            resource_type="user",
            resource_id=user.id,
            context=context,
            metadata={"role": role.value, "bootstrap_admin": is_first_user},
        )
        logger.info("auth.registered", user_id=user.id, role=role.value)
        return user

    # ── Login ────────────────────────────────────────────────────────────────
    async def authenticate(
        self,
        *,
        email: str,
        password: str,
        context: RequestContext | None = None,
    ) -> AuthResult:
        normalized = email.strip().lower()
        user = await self._users.get_by_email(normalized)
        now = utcnow()

        if user is None:
            # Hash a throwaway password anyway so the response time for an
            # unknown address matches that of a known one. Skipping this turns
            # login latency into an account-enumeration side channel.
            hash_password(password)
            await self._audit.record(
                AuditAction.USER_LOGIN_FAILED,
                actor_email=normalized,
                succeeded=False,
                message="No account exists for this address.",
                context=context,
            )
            await self._session.commit()
            raise InvalidCredentialsError()

        if self._is_locked(user, now):
            await self._audit.record(
                AuditAction.USER_LOGIN_FAILED,
                actor=user,
                succeeded=False,
                message="Account is temporarily locked.",
                context=context,
            )
            await self._session.commit()
            raise InvalidCredentialsError(
                "Too many failed attempts. Try again shortly."
            )

        if not verify_password(password, user.password_hash):
            await self._register_failure(user, now, context)
            raise InvalidCredentialsError()

        if not user.is_active:
            await self._audit.record(
                AuditAction.USER_LOGIN_FAILED,
                actor=user,
                succeeded=False,
                message="Account disabled.",
                context=context,
            )
            raise AccountDisabledError()

        # Opportunistic upgrade when Argon2 cost parameters have been raised.
        if password_needs_rehash(user.password_hash):
            user.password_hash = hash_password(password)

        user.failed_login_attempts = 0
        user.locked_until = None
        user.last_login_at = now

        tokens = await self._issue_tokens(user, family_id=str(uuid.uuid4()), context=context)
        await self._audit.record(
            AuditAction.USER_LOGIN_SUCCEEDED,
            actor=user,
            resource_type="user",
            resource_id=user.id,
            context=context,
        )
        logger.info("auth.login", user_id=user.id)
        return AuthResult(user=user, tokens=tokens)

    # ── Refresh ──────────────────────────────────────────────────────────────
    async def refresh(
        self, *, refresh_token: str, context: RequestContext | None = None
    ) -> AuthResult:
        now = utcnow()
        record = await self._tokens.get_by_hash(hash_refresh_token(refresh_token))
        if record is None:
            raise TokenError("The refresh token is not recognised.")

        if record.is_revoked:
            # A spent token was replayed. Either it was stolen, or the legitimate
            # client raced itself. Both warrant killing the lineage.
            revoked = await self._tokens.revoke_family(
                record.family_id, reason="reuse_detected", at=now
            )
            await self._audit.record(
                AuditAction.TOKEN_REUSE_DETECTED,
                actor_email=None,
                resource_type="user",
                resource_id=record.user_id,
                succeeded=False,
                message="Refresh token reuse detected; token family revoked.",
                context=context,
                metadata={"family_id": record.family_id, "revoked_count": revoked},
            )
            logger.warning(
                "auth.token.reuse", user_id=record.user_id, family=record.family_id
            )
            # Persist before raising. The session dependency rolls back on any
            # exception, which would otherwise undo the family revocation and
            # leave the stolen tokens live — the endpoint would return 401 while
            # silently revoking nothing.
            await self._session.commit()
            raise TokenReuseError()

        if record.is_expired(now):
            raise TokenError("The refresh token has expired.")

        user = await self._users.get(record.user_id)
        if user is None or not user.is_active:
            raise AccountDisabledError()

        # Rotate: spend the presented token, then issue its successor in the
        # same family so lineage is preserved for reuse detection.
        await self._tokens.revoke(record, reason="rotated", at=now)
        tokens = await self._issue_tokens(
            user, family_id=record.family_id, context=context
        )
        await self._audit.record(
            AuditAction.TOKEN_REFRESHED,
            actor=user,
            resource_type="user",
            resource_id=user.id,
            context=context,
            metadata={"family_id": record.family_id},
        )
        return AuthResult(user=user, tokens=tokens)

    # ── Logout ───────────────────────────────────────────────────────────────
    async def logout(
        self,
        *,
        user: User,
        refresh_token: str | None,
        all_sessions: bool = False,
        context: RequestContext | None = None,
    ) -> int:
        now = utcnow()
        if all_sessions:
            count = await self._tokens.revoke_all_for_user(
                user.id, reason="logout_all", at=now
            )
            await self._audit.record(
                AuditAction.SESSIONS_REVOKED,
                actor=user,
                resource_type="user",
                resource_id=user.id,
                context=context,
                metadata={"revoked_count": count},
            )
            return count

        count = 0
        if refresh_token:
            record = await self._tokens.get_by_hash(hash_refresh_token(refresh_token))
            # Only revoke a token that belongs to the caller — otherwise this
            # endpoint becomes a way to log arbitrary users out.
            if record is not None and record.user_id == user.id and not record.is_revoked:
                await self._tokens.revoke(record, reason="logout", at=now)
                count = 1

        await self._audit.record(
            AuditAction.USER_LOGGED_OUT,
            actor=user,
            resource_type="user",
            resource_id=user.id,
            context=context,
        )
        return count

    # ── Internals ────────────────────────────────────────────────────────────
    async def _issue_tokens(
        self, user: User, *, family_id: str, context: RequestContext | None
    ) -> TokenPair:
        access_token, expires_at = create_access_token(
            user.id, role=user.role.value, extra_claims={"email": user.email}
        )
        plaintext, digest = generate_refresh_token()
        ctx = context or RequestContext()

        await self._tokens.add(
            RefreshToken(
                user_id=user.id,
                token_hash=digest,
                family_id=family_id,
                expires_at=refresh_token_expiry(),
                user_agent=ctx.user_agent,
                ip_address=ctx.ip_address,
            )
        )
        return TokenPair(
            access_token=access_token,
            refresh_token=plaintext,
            expires_at=expires_at,
        )

    @staticmethod
    def _is_locked(user: User, now: datetime) -> bool:
        if user.locked_until is None:
            return False
        locked_until = user.locked_until
        if locked_until.tzinfo is None:
            locked_until = locked_until.replace(tzinfo=now.tzinfo)
        return locked_until > now

    async def _register_failure(
        self, user: User, now: datetime, context: RequestContext | None
    ) -> None:
        user.failed_login_attempts += 1
        locked = user.failed_login_attempts >= MAX_FAILED_ATTEMPTS
        if locked:
            user.locked_until = now + LOCKOUT_DURATION
            user.failed_login_attempts = 0

        await self._audit.record(
            AuditAction.USER_LOGIN_FAILED,
            actor=user,
            succeeded=False,
            message="Incorrect password.",
            context=context,
            metadata={"locked": locked},
        )
        # Committed explicitly: the caller raises immediately after this, and a
        # rollback would discard the attempt counter. A lockout that forgets
        # previous failures is not a lockout.
        await self._session.commit()


def bootstrap_settings_check() -> None:
    """Fail fast when production is running on a generated secret."""
    if settings.is_production and len(settings.secret_key) < 32:
        raise RuntimeError("OBSIDIAN_SECRET_KEY must be set in production.")
