"""Evidence analysis orchestration."""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.analysis.base import AnalysisResult
from obsidian.analysis.registry import analyzer_for
from obsidian.core.exceptions import ConflictError, NotFoundError, ValidationError
from obsidian.core.logging import get_logger
from obsidian.core.storage import get_storage
from obsidian.db.models.evidence import Evidence
from obsidian.db.models.ioc import IOC
from obsidian.db.models.user import User
from obsidian.domain.enums import AuditAction, EvidenceStatus
from obsidian.repositories.evidence_repository import EvidenceRepository
from obsidian.repositories.ioc_repository import IOCRepository
from obsidian.services.audit_service import AuditService, RequestContext

logger = get_logger(__name__)


class AnalysisService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._evidence = EvidenceRepository(session)
        self._iocs = IOCRepository(session)
        self._audit = AuditService(session)
        self._storage = get_storage()

    async def analyze(
        self,
        *,
        actor: User,
        evidence_id: str,
        context: RequestContext | None = None,
    ) -> Evidence:
        evidence = await self._evidence.get(evidence_id)
        if evidence is None:
            raise NotFoundError("No evidence exists with that identifier.")

        if evidence.status is EvidenceStatus.ANALYZING:
            raise ConflictError("This artefact is already being analysed.")

        analyzer = analyzer_for(evidence.evidence_type)
        if analyzer is None:
            raise ValidationError(
                f"No analysis engine supports '{evidence.evidence_type.value}' yet.",
                details={"evidence_type": evidence.evidence_type.value},
            )

        evidence.status = EvidenceStatus.ANALYZING
        await self._audit.record(
            AuditAction.ANALYSIS_STARTED,
            actor=actor,
            resource_type="evidence",
            resource_id=evidence.id,
            context=context,
            # case_id is recorded on evidence-scoped audit entries so the
            # timeline (and any later correlation) can attribute them to an
            # investigation without a second lookup.
            metadata={"engine": analyzer.name, "case_id": evidence.case_id},
        )
        # Persist ANALYZING before the work begins, so a crash mid-analysis is
        # visible as a stuck job rather than silently looking untouched.
        await self._session.commit()

        try:
            path = self._storage.resolve(evidence.stored_path)
            if not path.exists():
                raise NotFoundError("The stored artefact is missing from disk.")

            # Analysis is CPU-bound and synchronous. It runs inline here; moving
            # it to a worker pool is a Phase-2 follow-up and requires no change
            # above this method because the contract is already a plain result.
            result: AnalysisResult = analyzer.analyze(
                str(path), filename=evidence.original_filename
            )
        except Exception as exc:  # noqa: BLE001 - failure must be recorded, not raised away
            evidence.status = EvidenceStatus.FAILED
            evidence.analysis_summary = {"error": str(exc)[:500]}
            await self._session.commit()
            logger.exception("analysis.failed", evidence_id=evidence.id)
            raise

        await self._persist_iocs(evidence, result)

        evidence.status = EvidenceStatus.ANALYZED
        evidence.analysis_summary = result.to_dict()

        await self._audit.record(
            AuditAction.ANALYSIS_COMPLETED,
            actor=actor,
            resource_type="evidence",
            resource_id=evidence.id,
            context=context,
            metadata={
                "engine": result.engine,
                "case_id": evidence.case_id,
                "findings": len(result.findings),
                "iocs": len(result.iocs),
                "risk_score": result.risk_score,
            },
        )
        logger.info(
            "analysis.completed",
            evidence_id=evidence.id,
            engine=result.engine,
            findings=len(result.findings),
            risk=result.risk_score,
        )
        return evidence

    async def _persist_iocs(self, evidence: Evidence, result: AnalysisResult) -> None:
        """Upsert indicators, incrementing sightings for values already known."""
        for extracted in result.iocs:
            existing = await self._iocs.find(
                evidence.case_id, extracted.ioc_type, extracted.value
            )
            if existing is not None:
                existing.sightings += 1
                # Independent observation raises confidence, but never past a
                # ceiling: repetition is corroboration, not proof.
                existing.confidence = min(99, max(existing.confidence, extracted.confidence) + 3)
                if extracted.severity.rank > existing.severity.rank:
                    existing.severity = extracted.severity
                continue

            await self._iocs.add(
                IOC(
                    case_id=evidence.case_id,
                    first_seen_evidence_id=evidence.id,
                    ioc_type=extracted.ioc_type,
                    value=extracted.value,
                    severity=extracted.severity,
                    confidence=extracted.confidence,
                    context=extracted.context,
                    meta={"engine": result.engine},
                )
            )
