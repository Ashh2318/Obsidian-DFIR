"""AI assistant conversation handling."""

from __future__ import annotations

from collections.abc import AsyncIterator

from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.ai.base import CompletionRequest, Message as AIMessage, MessageRole as AIRole
from obsidian.ai.registry import get_provider
from obsidian.core.config import settings
from obsidian.core.exceptions import NotFoundError, PermissionDeniedError
from obsidian.core.logging import get_logger
from obsidian.db.models.conversation import Conversation, Message
from obsidian.db.models.user import User
from obsidian.domain.enums import AuditAction, MessageRole, Role
from obsidian.repositories.conversation_repository import (
    ConversationRepository,
    MessageRepository,
)
from obsidian.services.audit_service import AuditService, RequestContext
from obsidian.services.context_builder import build_case_context, build_system_prompt

logger = get_logger(__name__)

# Only the tail of a conversation is replayed to the provider. Older turns are
# retained in the database for the analyst's record but dropped from the prompt,
# because a long thread otherwise crowds out the case context that makes the
# answer useful.
MAX_HISTORY_MESSAGES = 20


class ChatService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._conversations = ConversationRepository(session)
        self._messages = MessageRepository(session)
        self._audit = AuditService(session)

    # ── Conversations ────────────────────────────────────────────────────────
    async def get(self, *, actor: User, conversation_id: str) -> Conversation:
        conversation = await self._conversations.get(conversation_id)
        if conversation is None:
            raise NotFoundError("No conversation exists with that identifier.")
        # A conversation is an analyst's working notes. Administrators can audit
        # them; nobody else reads another analyst's reasoning.
        if conversation.owner_id != actor.id and not actor.role.satisfies(Role.ADMIN):
            raise PermissionDeniedError("This conversation belongs to another analyst.")
        return conversation

    async def list(
        self, *, actor: User, limit: int, offset: int, case_id: str | None = None
    ) -> tuple[list[Conversation], int]:
        rows, total = await self._conversations.list_for_owner(
            actor.id, limit=limit, offset=offset, case_id=case_id
        )
        return list(rows), total

    async def create(
        self,
        *,
        actor: User,
        case_id: str | None,
        title: str | None = None,
        context: RequestContext | None = None,
    ) -> Conversation:
        conversation = Conversation(
            case_id=case_id,
            owner_id=actor.id,
            title=(title or "New conversation")[:200],
        )
        await self._conversations.add(conversation)
        await self._audit.record(
            AuditAction.CONVERSATION_STARTED,
            actor=actor,
            resource_type="conversation",
            resource_id=conversation.id,
            context=context,
            metadata={"case_id": case_id},
        )
        return conversation

    async def delete(self, *, actor: User, conversation_id: str) -> None:
        conversation = await self.get(actor=actor, conversation_id=conversation_id)
        await self._conversations.delete(conversation)

    # ── Exchange ─────────────────────────────────────────────────────────────
    async def _prepare(
        self, conversation: Conversation, prompt: str
    ) -> CompletionRequest:
        """Assemble the provider request from case context and recent history."""
        case_context = (
            await build_case_context(self._session, conversation.case_id)
            if conversation.case_id
            else ""
        )

        history = await self._messages.list_for_conversation(conversation.id)
        recent = list(history)[-MAX_HISTORY_MESSAGES:]

        messages = [
            AIMessage(
                role=AIRole.ASSISTANT if m.role is MessageRole.ASSISTANT else AIRole.USER,
                content=m.content,
            )
            for m in recent
            if m.role is not MessageRole.SYSTEM
        ]
        messages.append(AIMessage(role=AIRole.USER, content=prompt))

        return CompletionRequest(
            messages=messages,
            system=build_system_prompt(case_context),
            model=settings.ai_model or None,
            max_tokens=settings.ai_max_tokens,
            temperature=0.2,
        )

    async def send(
        self,
        *,
        actor: User,
        conversation_id: str,
        prompt: str,
        context: RequestContext | None = None,
    ) -> Message:
        """Non-streaming exchange. Returns the persisted assistant message."""
        conversation = await self.get(actor=actor, conversation_id=conversation_id)
        request = await self._prepare(conversation, prompt)

        await self._messages.add(
            Message(conversation_id=conversation.id, role=MessageRole.USER, content=prompt)
        )

        provider = get_provider()
        response = await provider.complete(request)

        assistant = Message(
            conversation_id=conversation.id,
            role=MessageRole.ASSISTANT,
            content=response.content,
            provider=response.provider,
            model=response.model,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            meta={"grounded": bool(conversation.case_id)},
        )
        await self._messages.add(assistant)

        self._retitle(conversation, prompt)
        await self._audit.record(
            AuditAction.ASSISTANT_QUERIED,
            actor=actor,
            resource_type="conversation",
            resource_id=conversation.id,
            context=context,
            metadata={
                "provider": response.provider,
                "model": response.model,
                "grounded": bool(conversation.case_id),
                "output_tokens": response.usage.output_tokens,
            },
        )
        logger.info(
            "assistant.answered",
            conversation_id=conversation.id,
            provider=response.provider,
            grounded=bool(conversation.case_id),
        )
        return assistant

    async def stream(
        self,
        *,
        actor: User,
        conversation_id: str,
        prompt: str,
        context: RequestContext | None = None,
    ) -> AsyncIterator[str]:
        """Stream the answer, persisting the full exchange once it completes.

        The user message is written and committed *before* streaming starts. If
        the connection drops mid-answer the question is still on record, which
        is what an analyst needs when reconstructing what they asked.
        """
        conversation = await self.get(actor=actor, conversation_id=conversation_id)
        request = await self._prepare(conversation, prompt)

        await self._messages.add(
            Message(conversation_id=conversation.id, role=MessageRole.USER, content=prompt)
        )
        self._retitle(conversation, prompt)
        await self._session.commit()

        provider = get_provider()
        chunks: list[str] = []

        async for chunk in provider.stream(request):
            chunks.append(chunk)
            yield chunk

        content = "".join(chunks)
        await self._messages.add(
            Message(
                conversation_id=conversation.id,
                role=MessageRole.ASSISTANT,
                content=content,
                provider=provider.name,
                model=provider.default_model,
                # Streaming responses do not carry usage counts on every
                # provider; an estimate is recorded rather than a false zero.
                output_tokens=len(content) // 4,
                meta={"streamed": True, "grounded": bool(conversation.case_id)},
            )
        )
        await self._audit.record(
            AuditAction.ASSISTANT_QUERIED,
            actor=actor,
            resource_type="conversation",
            resource_id=conversation.id,
            context=context,
            metadata={
                "provider": provider.name,
                "streamed": True,
                "grounded": bool(conversation.case_id),
            },
        )
        await self._session.commit()

    @staticmethod
    def _retitle(conversation: Conversation, prompt: str) -> None:
        """Name an untitled conversation after its opening question."""
        if conversation.title != "New conversation":
            return
        cleaned = " ".join(prompt.split())
        conversation.title = (cleaned[:77] + "...") if len(cleaned) > 80 else cleaned or "New conversation"
