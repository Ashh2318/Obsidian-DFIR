"""User administration."""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.core.exceptions import ConflictError, NotFoundError
from obsidian.core.security import utcnow
from obsidian.db.models.user import User
from obsidian.domain.enums import AuditAction, Role
from obsidian.repositories.refresh_token_repository import RefreshTokenRepository
from obsidian.repositories.user_repository import UserRepository
from obsidian.services.audit_service import AuditService, RequestContext


class UserService:
    def __init__(self, session: AsyncSession) -> None:
        self._users = UserRepository(session)
        self._tokens = RefreshTokenRepository(session)
        self._audit = AuditService(session)

    async def get(self, user_id: str) -> User:
        user = await self._users.get(user_id)
        if user is None:
            raise NotFoundError("No user exists with that identifier.")
        return user

    async def list(
        self, *, limit: int, offset: int, role: Role | None = None
    ) -> tuple[list[User], int]:
        rows, total = await self._users.list_paginated(
            limit=limit, offset=offset, role=role
        )
        return list(rows), total

    async def change_role(
        self,
        *,
        actor: User,
        user_id: str,
        new_role: Role,
        context: RequestContext | None = None,
    ) -> User:
        target = await self.get(user_id)
        previous = target.role

        # Guard against the deployment locking itself out of administration.
        if previous is Role.ADMIN and new_role is not Role.ADMIN:
            if await self._users.count_admins() <= 1:
                raise ConflictError(
                    "Cannot demote the only administrator. Promote another "
                    "account first."
                )

        target.role = new_role
        await self._audit.record(
            AuditAction.USER_ROLE_CHANGED,
            actor=actor,
            resource_type="user",
            resource_id=target.id,
            context=context,
            metadata={"from": previous.value, "to": new_role.value},
        )
        return target

    async def set_active(
        self,
        *,
        actor: User,
        user_id: str,
        is_active: bool,
        context: RequestContext | None = None,
    ) -> User:
        target = await self.get(user_id)

        if not is_active:
            if target.id == actor.id:
                raise ConflictError("You cannot disable your own account.")
            if target.role is Role.ADMIN and await self._users.count_admins() <= 1:
                raise ConflictError("Cannot disable the only administrator.")
            # A disabled account must not be able to mint new access tokens from
            # a refresh token it already holds.
            await self._tokens.revoke_all_for_user(
                target.id, reason="account_disabled", at=utcnow()
            )

        target.is_active = is_active
        await self._audit.record(
            AuditAction.USER_ENABLED if is_active else AuditAction.USER_DISABLED,
            actor=actor,
            resource_type="user",
            resource_id=target.id,
            context=context,
        )
        return target
