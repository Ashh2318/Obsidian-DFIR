"""Case management."""

from __future__ import annotations

from sqlalchemy.exc import IntegrityError

from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.core.exceptions import ConflictError, NotFoundError, PermissionDeniedError
from obsidian.core.logging import get_logger
from obsidian.core.security import utcnow
from obsidian.db.models.case import Case
from obsidian.db.models.user import User
from obsidian.domain.case_rules import CLOSING_STATUSES, allowed_next, can_transition
from obsidian.domain.enums import AuditAction, CaseStatus, Role, Severity
from obsidian.repositories.case_repository import CaseRepository
from obsidian.repositories.evidence_repository import EvidenceRepository
from obsidian.repositories.ioc_repository import IOCRepository
from obsidian.repositories.user_repository import UserRepository
from obsidian.services.audit_service import AuditService, RequestContext

logger = get_logger(__name__)

MAX_REFERENCE_ATTEMPTS = 5


class CaseService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._cases = CaseRepository(session)
        self._users = UserRepository(session)
        self._audit = AuditService(session)

    # ── Reads ────────────────────────────────────────────────────────────────
    async def get(self, case_id: str) -> Case:
        case = await self._cases.get(case_id)
        if case is None:
            raise NotFoundError("No case exists with that identifier.")
        return case

    async def list(
        self,
        *,
        limit: int,
        offset: int,
        query: str | None = None,
        status: CaseStatus | None = None,
        severity: Severity | None = None,
        assignee_id: str | None = None,
    ) -> tuple[list[Case], int]:
        rows, total = await self._cases.search(
            limit=limit,
            offset=offset,
            query=query,
            status=status,
            severity=severity,
            assignee_id=assignee_id,
        )
        return list(rows), total

    async def overview(self, case_id: str) -> dict[str, object]:
        """Counts and the single most severe finding, for a compact header."""
        case = await self.get(case_id)
        artefacts, evidence_count = await EvidenceRepository(
            self._session
        ).list_for_case(case_id, limit=200, offset=0)
        _iocs, ioc_count = await IOCRepository(self._session).search(
            limit=1, offset=0, case_id=case_id
        )

        findings = [
            finding
            for artefact in artefacts
            for finding in (artefact.analysis_summary or {}).get("findings", [])
        ]
        analysed = [a for a in artefacts if a.analysis_summary]
        peak = max(
            (int((a.analysis_summary or {}).get("risk_score", 0)) for a in artefacts),
            default=0,
        )
        worst = (
            max(findings, key=lambda f: Severity(f.get("severity", "info")).rank)
            if findings
            else None
        )

        return {
            "case_id": case.id,
            "reference": case.reference,
            "title": case.title,
            "status": case.status,
            "severity": case.severity,
            "evidence_count": evidence_count,
            "analysed_count": len(analysed),
            "finding_count": len(findings),
            "ioc_count": ioc_count,
            "risk_score": peak,
            "top_finding": worst.get("title") if worst else None,
            "top_finding_severity": (
                Severity(worst.get("severity", "info")) if worst else None
            ),
        }

    async def statistics(self) -> dict[str, dict[str, int]]:
        return {
            "by_status": await self._cases.count_by_status(),
            "by_severity": await self._cases.count_by_severity(),
        }

    # ── Writes ───────────────────────────────────────────────────────────────
    async def create(
        self,
        *,
        actor: User,
        title: str,
        summary: str | None = None,
        severity: Severity = Severity.MEDIUM,
        assignee_id: str | None = None,
        context: RequestContext | None = None,
    ) -> Case:
        if assignee_id and await self._users.get(assignee_id) is None:
            raise NotFoundError("The assigned user does not exist.")

        now = utcnow()
        case = Case(
            reference="",  # replaced below
            title=title.strip(),
            summary=summary,
            severity=severity,
            status=CaseStatus.OPEN,
            owner_id=actor.id,
            assignee_id=assignee_id,
            opened_at=now,
        )

        # Reference allocation races under concurrent creation. The unique
        # constraint is the real guard; this loop turns a rare collision into a
        # retry rather than a 500.
        for attempt in range(MAX_REFERENCE_ATTEMPTS):
            case.reference = await self._cases.next_reference(year=now.year)
            try:
                await self._cases.add(case)
                break
            except IntegrityError:
                await self._session.rollback()
                if attempt == MAX_REFERENCE_ATTEMPTS - 1:
                    raise ConflictError(
                        "Could not allocate a case reference. Please retry."
                    ) from None

        await self._audit.record(
            AuditAction.CASE_CREATED,
            actor=actor,
            resource_type="case",
            resource_id=case.id,
            context=context,
            metadata={"reference": case.reference, "severity": severity.value},
        )
        logger.info("case.created", case_id=case.id, reference=case.reference)
        return case

    async def update(
        self,
        *,
        actor: User,
        case_id: str,
        title: str | None = None,
        summary: str | None = None,
        severity: Severity | None = None,
        assignee_id: str | None = None,
        clear_assignee: bool = False,
        context: RequestContext | None = None,
    ) -> Case:
        case = await self.get(case_id)
        self._assert_can_modify(actor, case)

        changes: dict[str, object] = {}
        if title is not None and title.strip() != case.title:
            changes["title"] = title.strip()
            case.title = title.strip()
        if summary is not None and summary != case.summary:
            changes["summary"] = "updated"
            case.summary = summary
        if severity is not None and severity is not case.severity:
            changes["severity"] = {"from": case.severity.value, "to": severity.value}
            case.severity = severity

        if clear_assignee:
            if case.assignee_id is not None:
                changes["assignee"] = {"from": case.assignee_id, "to": None}
                case.assignee_id = None
        elif assignee_id is not None and assignee_id != case.assignee_id:
            if await self._users.get(assignee_id) is None:
                raise NotFoundError("The assigned user does not exist.")
            changes["assignee"] = {"from": case.assignee_id, "to": assignee_id}
            case.assignee_id = assignee_id

        if changes:
            await self._audit.record(
                AuditAction.CASE_UPDATED,
                actor=actor,
                resource_type="case",
                resource_id=case.id,
                context=context,
                metadata={"changes": changes},
            )
        return case

    async def change_status(
        self,
        *,
        actor: User,
        case_id: str,
        target: CaseStatus,
        context: RequestContext | None = None,
    ) -> Case:
        case = await self.get(case_id)
        self._assert_can_modify(actor, case)

        if not can_transition(case.status, target):
            permitted = sorted(s.value for s in allowed_next(case.status))
            raise ConflictError(
                f"A case that is '{case.status.value}' cannot move to "
                f"'{target.value}'.",
                details={"current": case.status.value, "allowed": permitted},
            )

        previous = case.status
        case.status = target
        # closed_at is a fact about the case, not a display concern, so it is
        # maintained here rather than inferred in the UI.
        case.closed_at = utcnow() if target in CLOSING_STATUSES else None

        await self._audit.record(
            AuditAction.CASE_STATUS_CHANGED,
            actor=actor,
            resource_type="case",
            resource_id=case.id,
            context=context,
            metadata={"from": previous.value, "to": target.value},
        )
        return case

    # ── Authorization ────────────────────────────────────────────────────────
    @staticmethod
    def _assert_can_modify(actor: User, case: Case) -> None:
        """Investigators and above may modify any case; analysts only their own.

        Viewers never reach here — the router requires ANALYST — so this governs
        the analyst tier specifically.
        """
        if actor.role.satisfies(Role.INVESTIGATOR):
            return
        if case.owner_id == actor.id or case.assignee_id == actor.id:
            return
        raise PermissionDeniedError(
            "Analysts may only modify cases they own or are assigned to."
        )
