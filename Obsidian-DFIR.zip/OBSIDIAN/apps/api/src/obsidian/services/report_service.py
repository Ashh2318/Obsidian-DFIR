"""Report generation."""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.core.exceptions import NotFoundError
from obsidian.core.logging import get_logger
from obsidian.core.security import sign_content, verify_content
from obsidian.db.models.report import Report
from obsidian.db.models.user import User
from obsidian.domain.enums import AuditAction
from obsidian.reporting.composer import ReportComposer
from obsidian.reporting.document import ReportFormat, ReportProfile
from obsidian.reporting.registry import EXTENSIONS, render
from obsidian.repositories.case_repository import CaseRepository
from obsidian.repositories.report_repository import ReportRepository
from obsidian.services.audit_service import AuditService, RequestContext

logger = get_logger(__name__)

#: Occupies the signature's position during the first render. Exactly the length
#: of a hex-encoded SHA-256 digest so substituting the real value shifts nothing.
SIGNATURE_PLACEHOLDER = "0" * 64


class ReportService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._reports = ReportRepository(session)
        self._cases = CaseRepository(session)
        self._composer = ReportComposer(session)
        self._audit = AuditService(session)

    async def get(self, report_id: str) -> Report:
        report = await self._reports.get(report_id)
        if report is None:
            raise NotFoundError("No report exists with that identifier.")
        return report

    async def list_for_case(
        self, case_id: str, *, limit: int, offset: int
    ) -> tuple[list[Report], int]:
        rows, total = await self._reports.list_for_case(case_id, limit=limit, offset=offset)
        return list(rows), total

    async def list_all(
        self, *, limit: int, offset: int, profile: ReportProfile | None = None
    ) -> tuple[list[Report], int]:
        rows, total = await self._reports.list_all(limit=limit, offset=offset, profile=profile)
        return list(rows), total

    async def generate(
        self,
        *,
        actor: User,
        case_id: str,
        profile: ReportProfile,
        fmt: ReportFormat,
        context: RequestContext | None = None,
    ) -> Report:
        case = await self._cases.get(case_id)
        if case is None:
            raise NotFoundError("No case exists with that identifier.")

        document = await self._composer.compose(
            case_id=case_id, profile=profile, author=actor.full_name
        )

        # Signed over the *rendered bytes*, so the signature covers exactly what
        # a recipient opens; signing the source data would leave rendering
        # unverified.
        #
        # The signature is also printed inside the document, which is circular:
        # embedding it changes the bytes being signed. Resolved by rendering
        # first with a fixed-length placeholder of identical length. Because
        # SIGNATURE_PLACEHOLDER and a real HMAC-SHA256 hex digest are both
        # exactly 64 characters, the two renders differ in those 64 bytes and
        # nowhere else — no shifted offsets, no altered PDF stream lengths — so
        # verification can substitute the placeholder back and recompute exactly.
        placeholder_render = render(document, fmt, signature=SIGNATURE_PLACEHOLDER)
        signature = sign_content(placeholder_render)
        content = render(document, fmt, signature=signature)

        report = Report(
            case_id=case_id,
            generated_by_id=actor.id,
            title=f"{document.title} — {case.reference}",
            profile=profile,
            fmt=fmt,
            content=content,
            size_bytes=len(content),
            signature=signature,
            summary=document.metadata,
        )
        await self._reports.add(report)

        await self._audit.record(
            AuditAction.REPORT_GENERATED,
            actor=actor,
            resource_type="report",
            resource_id=report.id,
            context=context,
            metadata={
                "case_id": case_id,
                "case_reference": case.reference,
                "profile": profile.value,
                "format": fmt.value,
                "size_bytes": len(content),
            },
        )
        logger.info(
            "report.generated",
            report_id=report.id,
            case=case.reference,
            profile=profile.value,
            format=fmt.value,
            bytes=len(content),
        )
        return report

    async def verify(self, report_id: str) -> dict[str, object]:
        """Confirm stored bytes still match the signature issued at generation."""
        report = await self.get(report_id)
        # The signature was computed over the render *without* it embedded, so
        # verification recomputes against the same input rather than the final
        # bytes, which now contain the signature itself.
        valid = verify_content(_canonical_bytes(report), report.signature)
        return {
            "report_id": report.id,
            "valid": valid,
            "signature": report.signature,
            "algorithm": "HMAC-SHA256",
            "detail": (
                "Content matches the signature issued at generation."
                if valid
                else "Content does NOT match. The report has been altered since generation."
            ),
        }

    async def delete(self, *, report_id: str) -> None:
        await self._reports.delete(await self.get(report_id))

    @staticmethod
    def filename(report: Report) -> str:
        stem = report.title.replace(" ", "_").replace("—", "-").replace("/", "-")
        return f"{stem}.{EXTENSIONS[report.fmt]}"


def _canonical_bytes(report: Report) -> bytes:
    """Reconstruct exactly what was signed.

    Substitutes the embedded signature back to the placeholder it occupied at
    signing time. Both are 64 hex characters, so this is a byte-for-byte
    in-place swap that leaves every offset in the document untouched.
    """
    return report.content.replace(
        report.signature.encode("utf-8"), SIGNATURE_PLACEHOLDER.encode("utf-8")
    )
