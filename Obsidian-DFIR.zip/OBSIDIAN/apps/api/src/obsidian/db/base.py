"""Declarative base, naming conventions and shared column mixins."""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, MetaData, String, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

# Deterministic constraint names. Without this, SQLite and PostgreSQL invent
# different names for the same constraint and an Alembic downgrade that tries to
# drop one by name fails on whichever backend it was not authored against.
NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING_CONVENTION)

    # Fetch server-generated values (created_at, and updated_at's onupdate) as
    # part of the flush itself.
    #
    # Without this, a column carrying a server default is *expired* after an
    # INSERT or UPDATE, and the next attribute read triggers a lazy refresh.
    # Under the async engine that refresh is synchronous I/O on a greenlet that
    # is no longer in an await context, which raises MissingGreenlet — typically
    # surfacing far away, inside response serialisation. Resolving the values
    # eagerly keeps every mapped attribute readable after a write.
    __mapper_args__ = {"eager_defaults": True}


def new_uuid() -> str:
    return str(uuid.uuid4())


class UUIDPrimaryKeyMixin:
    """36-character string UUID primary key.

    Stored as text rather than a native UUID column so the same schema is valid
    on both SQLite and PostgreSQL (see ADR 0001).
    """

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=new_uuid, index=True
    )


class TimestampMixin:
    """Server-side created/updated timestamps."""

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
