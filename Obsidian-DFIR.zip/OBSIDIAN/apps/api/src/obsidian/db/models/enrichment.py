"""Threat-intelligence enrichment cache.

Keyed by the indicator **value**, not by an IOC row.

An IOC row is case-scoped: the same address appearing in three investigations
produces three rows. Its reputation, however, is a property of the indicator
itself and identical for all three. Caching per IOC row would triple the
requests to feeds that meter them aggressively — VirusTotal's free tier allows
four lookups a minute — and could show the same address as malicious on one case
and unknown on another.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (
    DateTime,
    Enum as SAEnum,
    Integer,
    JSON,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from obsidian.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from obsidian.domain.enums import IOCType, ThreatVerdict


class IOCEnrichment(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "ioc_enrichments"
    __table_args__ = (
        UniqueConstraint("ioc_type", "value", name="uq_enrichment_type_value"),
    )

    ioc_type: Mapped[IOCType] = mapped_column(
        SAEnum(IOCType, native_enum=False, length=32), nullable=False, index=True
    )
    value: Mapped[str] = mapped_column(String(512), nullable=False, index=True)

    verdict: Mapped[ThreatVerdict] = mapped_column(
        SAEnum(ThreatVerdict, native_enum=False, length=16),
        default=ThreatVerdict.UNKNOWN,
        nullable=False,
        index=True,
    )
    score: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # Per-provider payloads, retained so an analyst can see *who* said what
    # rather than only the aggregate. A consensus with no attribution is not
    # defensible in a report.
    providers: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)

    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )

    def is_fresh(self, now: datetime) -> bool:
        expires = self.expires_at
        # SQLite returns naive datetimes; normalise before comparing.
        if expires.tzinfo is None and now.tzinfo is not None:
            expires = expires.replace(tzinfo=now.tzinfo)
        return expires > now
