"""Generated reports.

The rendered bytes are stored rather than regenerated on download. A report is
a point-in-time statement about an investigation; regenerating it later would
silently produce a different document as the case evolves, which defeats the
purpose of issuing one.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import (
    Enum as SAEnum,
    ForeignKey,
    Integer,
    JSON,
    LargeBinary,
    String,
)
from sqlalchemy.orm import Mapped, mapped_column

from obsidian.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from obsidian.reporting.document import ReportFormat, ReportProfile


class Report(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "reports"

    case_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("cases.id", ondelete="CASCADE"), nullable=False, index=True
    )
    generated_by_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )

    title: Mapped[str] = mapped_column(String(200), nullable=False)
    profile: Mapped[ReportProfile] = mapped_column(
        SAEnum(ReportProfile, native_enum=False, length=16), nullable=False, index=True
    )
    fmt: Mapped[ReportFormat] = mapped_column(
        "format", SAEnum(ReportFormat, native_enum=False, length=16), nullable=False
    )

    content: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)
    size_bytes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    #: HMAC-SHA256 over the rendered bytes, keyed by the instance secret.
    signature: Mapped[str] = mapped_column(String(64), nullable=False)

    summary: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
