"""Indicators of compromise extracted from evidence.

An IOC is deduplicated per case: the same address observed in five artefacts is
one indicator with five sightings, not five rows. Analysts pivot on indicators,
so a list that repeats the same value is actively harmful.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import (
    Enum as SAEnum,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from obsidian.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from obsidian.domain.enums import IOCType, Severity


class IOC(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "iocs"
    __table_args__ = (
        # One row per (case, type, value). The service increments sightings
        # rather than inserting a duplicate.
        UniqueConstraint("case_id", "ioc_type", "value", name="uq_ioc_case_type_value"),
    )

    case_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("cases.id", ondelete="CASCADE"), nullable=False, index=True
    )
    # Nullable and SET NULL: removing an artefact must not erase the indicator
    # it produced, or deleting evidence would quietly rewrite the findings.
    first_seen_evidence_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("evidence.id", ondelete="SET NULL"), nullable=True, index=True
    )

    ioc_type: Mapped[IOCType] = mapped_column(
        SAEnum(IOCType, native_enum=False, length=32), nullable=False, index=True
    )
    value: Mapped[str] = mapped_column(String(512), nullable=False, index=True)
    severity: Mapped[Severity] = mapped_column(
        SAEnum(Severity, native_enum=False, length=16),
        default=Severity.INFO,
        nullable=False,
        index=True,
    )
    confidence: Mapped[int] = mapped_column(Integer, default=50, nullable=False)
    sightings: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    context: Mapped[str | None] = mapped_column(Text, nullable=True)
    meta: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"<IOC {self.ioc_type.value}={self.value} x{self.sightings}>"
