"""Investigation case aggregate.

Introduced in Phase 0 so the schema, authorization surface and navigation are
settled before Phase 1 adds behaviour on top of it.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from obsidian.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from obsidian.domain.enums import CaseStatus, Severity


class Case(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "cases"

    reference: Mapped[str] = mapped_column(
        String(32), unique=True, index=True, nullable=False
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[CaseStatus] = mapped_column(
        SAEnum(CaseStatus, native_enum=False, length=32),
        default=CaseStatus.OPEN,
        nullable=False,
        index=True,
    )
    severity: Mapped[Severity] = mapped_column(
        SAEnum(Severity, native_enum=False, length=16),
        default=Severity.MEDIUM,
        nullable=False,
        index=True,
    )
    owner_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="RESTRICT"),
        nullable=False, index=True,
    )
    assignee_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True, index=True,
    )
    opened_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    closed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
