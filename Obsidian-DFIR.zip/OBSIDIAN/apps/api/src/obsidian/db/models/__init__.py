"""ORM model registry.

Every model must be imported here. Alembic's autogenerate and
``Base.metadata.create_all`` only see mappers that have actually been imported;
a model omitted from this module silently vanishes from migrations.
"""

from obsidian.db.base import Base
from obsidian.db.models.audit_log import AuditLog
from obsidian.db.models.case import Case
from obsidian.db.models.conversation import Conversation, Message
from obsidian.db.models.enrichment import IOCEnrichment
from obsidian.db.models.evidence import Evidence
from obsidian.db.models.ioc import IOC
from obsidian.db.models.refresh_token import RefreshToken
from obsidian.db.models.report import Report
from obsidian.db.models.user import User

__all__ = [
    "Base",
    "AuditLog",
    "Case",
    "Conversation",
    "Evidence",
    "IOC",
    "IOCEnrichment",
    "Message",
    "RefreshToken",
    "Report",
    "User",
]
