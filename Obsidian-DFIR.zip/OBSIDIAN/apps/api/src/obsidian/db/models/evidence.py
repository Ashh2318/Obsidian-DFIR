"""Evidence item aggregate.

Chain of custody is established at ingest: both SHA-256 and MD5 are recorded.
SHA-256 is the integrity anchor; MD5 exists solely because most threat-intel
feeds and malware corpora are still keyed on it. It is never used for integrity
decisions.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import (
    BigInteger,
    Enum as SAEnum,
    ForeignKey,
    JSON,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column

from obsidian.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from obsidian.domain.enums import EvidenceStatus, EvidenceType


class Evidence(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "evidence"

    case_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("cases.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )
    uploaded_by_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True, index=True,
    )

    original_filename: Mapped[str] = mapped_column(String(512), nullable=False)
    stored_path: Mapped[str] = mapped_column(String(1024), nullable=False)
    media_type: Mapped[str | None] = mapped_column(String(160), nullable=True)
    size_bytes: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)

    evidence_type: Mapped[EvidenceType] = mapped_column(
        SAEnum(EvidenceType, native_enum=False, length=32),
        default=EvidenceType.UNKNOWN,
        nullable=False,
        index=True,
    )
    status: Mapped[EvidenceStatus] = mapped_column(
        SAEnum(EvidenceStatus, native_enum=False, length=32),
        default=EvidenceStatus.UPLOADED,
        nullable=False,
        index=True,
    )

    sha256: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    md5: Mapped[str | None] = mapped_column(String(32), index=True, nullable=True)

    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    analysis_summary: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
