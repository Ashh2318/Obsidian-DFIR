"""Async engine and session management.

Engine construction is dialect-aware: SQLite and PostgreSQL do not accept the
same keyword arguments, so passing pool sizing to an aiosqlite engine raises at
startup. That branching is confined to this module.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from sqlalchemy import event
from sqlalchemy.engine import Engine
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from obsidian.core.config import settings
from obsidian.core.logging import get_logger

logger = get_logger(__name__)


def _engine_kwargs() -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "echo": settings.database_echo,
        "future": True,
        "pool_pre_ping": True,
    }
    if settings.is_sqlite:
        # aiosqlite rejects pool sizing arguments entirely.
        kwargs["connect_args"] = {"check_same_thread": False}
    else:
        kwargs["pool_size"] = settings.database_pool_size
        kwargs["max_overflow"] = settings.database_max_overflow
        kwargs["pool_recycle"] = 1800
    return kwargs


engine: AsyncEngine = create_async_engine(settings.database_url, **_engine_kwargs())

SessionLocal: async_sessionmaker[AsyncSession] = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,  # keep attributes usable after commit in handlers
    autoflush=False,
)


@event.listens_for(Engine, "connect")
def _configure_sqlite(dbapi_connection: Any, _record: Any) -> None:
    """Enable SQLite pragmas that make it behave like a real database.

    SQLite ignores foreign keys unless explicitly told not to, which would let
    referential bugs pass every local test and surface only on PostgreSQL.
    WAL raises concurrent read throughput under the dev server.
    """
    module = type(dbapi_connection).__module__
    if "sqlite" not in module:
        return
    cursor = dbapi_connection.cursor()
    try:
        # Foreign keys are non-negotiable: without this SQLite silently ignores
        # every FK constraint and referential bugs survive until PostgreSQL.
        cursor.execute("PRAGMA foreign_keys=ON")

        # WAL requires shared-memory locking, which is unavailable on network
        # shares, some container bind mounts and many FUSE filesystems. It is a
        # throughput optimisation, not a correctness requirement, so degrade to
        # the default rollback journal instead of failing to start.
        try:
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
        except Exception:  # noqa: BLE001 - dialect-level capability probe
            logger.warning(
                "database.sqlite.wal_unavailable",
                detail="Falling back to the rollback journal.",
            )
    finally:
        cursor.close()


async def get_session() -> AsyncIterator[AsyncSession]:
    """FastAPI dependency yielding a transactional session.

    The session commits on success and rolls back on any exception, so no
    handler or service needs to manage transaction boundaries by hand.
    """
    async with SessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def dispose_engine() -> None:
    await engine.dispose()
    logger.info("database.engine.disposed")
