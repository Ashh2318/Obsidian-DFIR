"""Assistant contracts."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from obsidian.domain.enums import MessageRole
from obsidian.schemas.common import ORMModel


class ConversationCreateRequest(BaseModel):
    case_id: str | None = Field(default=None, max_length=36)
    title: str | None = Field(default=None, max_length=200)


class SendMessageRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=8000)


class MessageResponse(ORMModel):
    id: str
    conversation_id: str
    role: MessageRole
    content: str
    provider: str | None
    model: str | None
    input_tokens: int
    output_tokens: int
    created_at: datetime


class ConversationResponse(ORMModel):
    id: str
    case_id: str | None
    owner_id: str
    title: str
    created_at: datetime
    updated_at: datetime


class ConversationDetailResponse(ConversationResponse):
    messages: list[MessageResponse] = Field(default_factory=list)
