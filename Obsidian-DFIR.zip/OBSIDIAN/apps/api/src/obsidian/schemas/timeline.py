"""Timeline contracts."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel

from obsidian.domain.enums import Severity, TimelineEventKind, TimelineSource


class TimelineEventResponse(BaseModel):
    id: str
    occurred_at: datetime
    kind: TimelineEventKind
    source: TimelineSource
    title: str
    description: str | None = None
    severity: Severity
    case_id: str | None = None
    case_reference: str | None = None
    actor: str | None = None
    evidence_id: str | None = None
    metadata: dict[str, Any] = {}


class TimelineResponse(BaseModel):
    events: list[TimelineEventResponse]
    total: int
    incident_events: int
    investigation_events: int
