"""Case contracts."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field, field_validator

from obsidian.domain.enums import CaseStatus, Severity
from obsidian.schemas.common import ORMModel


class CaseCreateRequest(BaseModel):
    title: str = Field(min_length=4, max_length=200)
    summary: str | None = Field(default=None, max_length=8000)
    severity: Severity = Severity.MEDIUM
    assignee_id: str | None = Field(default=None, max_length=36)

    @field_validator("title")
    @classmethod
    def strip_title(cls, value: str) -> str:
        cleaned = value.strip()
        if len(cleaned) < 4:
            raise ValueError("Title must be at least 4 characters.")
        return cleaned


class CaseUpdateRequest(BaseModel):
    title: str | None = Field(default=None, min_length=4, max_length=200)
    summary: str | None = Field(default=None, max_length=8000)
    severity: Severity | None = None
    assignee_id: str | None = Field(default=None, max_length=36)
    # Distinguishes "leave the assignee alone" from "remove the assignee",
    # which a nullable field alone cannot express.
    clear_assignee: bool = False


class CaseStatusRequest(BaseModel):
    status: CaseStatus


class CaseResponse(ORMModel):
    id: str
    reference: str
    title: str
    summary: str | None
    status: CaseStatus
    severity: Severity
    owner_id: str
    assignee_id: str | None
    opened_at: datetime | None
    closed_at: datetime | None
    created_at: datetime
    updated_at: datetime


class CaseStatisticsResponse(BaseModel):
    by_status: dict[str, int]
    by_severity: dict[str, int]


class CaseOverviewResponse(BaseModel):
    """Compact case telemetry.

    Assembled server-side in one query pass so a client showing live stats — the
    voice HUD in particular — does not need four round trips to render a header.
    """

    case_id: str
    reference: str
    title: str
    status: CaseStatus
    severity: Severity
    evidence_count: int
    analysed_count: int
    finding_count: int
    ioc_count: int
    risk_score: int
    top_finding: str | None = None
    top_finding_severity: Severity | None = None
