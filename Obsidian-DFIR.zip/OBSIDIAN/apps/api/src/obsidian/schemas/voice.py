"""Voice contracts."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from obsidian.domain.enums import IntentAction, IntentConfidence


class VoiceCommandRequest(BaseModel):
    utterance: str = Field(min_length=1, max_length=1000)
    #: The case the analyst is currently viewing, so "this case" resolves.
    current_case_id: str | None = Field(default=None, max_length=36)
    #: The previous turn, so a continuation like "tell me more about that"
    #: resolves against what was just discussed.
    last_action: str | None = Field(default=None, max_length=40)
    last_subject: str | None = Field(default=None, max_length=200)
    #: Parse only, do not execute. Used to read an interpretation back before
    #: performing something that mutates state.
    dry_run: bool = False


class IntentResponse(BaseModel):
    action: IntentAction
    confidence: IntentConfidence
    utterance: str
    entities: dict[str, Any]
    needs_confirmation: bool


class VoiceCommandResponse(BaseModel):
    intent: IntentResponse
    speech: str
    ui_action: dict[str, Any] | None = None
    data: dict[str, Any] = {}
    succeeded: bool


class VoiceCapabilitiesResponse(BaseModel):
    wake_word: str
    actions: list[str]
    examples: list[str]
    help_text: str
