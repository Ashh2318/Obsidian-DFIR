"""Authentication request and response contracts."""

from __future__ import annotations

import re
from datetime import datetime

from pydantic import BaseModel, EmailStr, Field, field_validator

from obsidian.core.config import settings
from obsidian.domain.enums import Role
from obsidian.schemas.common import ORMModel

# Rejected outright regardless of length or composition.
_COMMON_PASSWORDS = {
    "password", "passw0rd", "123456789012", "qwertyuiop123",
    "administrator", "letmein12345", "welcome12345",
}


class PasswordPolicyMixin:
    @classmethod
    def _validate_password(cls, value: str) -> str:
        if len(value) < settings.password_min_length:
            raise ValueError(
                f"Password must be at least {settings.password_min_length} "
                "characters."
            )
        checks = (
            (r"[a-z]", "a lowercase letter"),
            (r"[A-Z]", "an uppercase letter"),
            (r"\d", "a digit"),
            (r"[^A-Za-z0-9]", "a symbol"),
        )
        missing = [label for pattern, label in checks if not re.search(pattern, value)]
        if missing:
            raise ValueError("Password must contain " + ", ".join(missing) + ".")
        if value.lower() in _COMMON_PASSWORDS:
            raise ValueError("This password is too common. Choose another.")
        return value


class RegisterRequest(BaseModel, PasswordPolicyMixin):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    full_name: str = Field(min_length=2, max_length=120)
    organization: str | None = Field(default=None, max_length=160)
    job_title: str | None = Field(default=None, max_length=120)

    @field_validator("password")
    @classmethod
    def check_password(cls, value: str) -> str:
        return cls._validate_password(value)

    @field_validator("full_name")
    @classmethod
    def strip_name(cls, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("Full name cannot be blank.")
        return cleaned


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)


class RefreshRequest(BaseModel):
    refresh_token: str = Field(min_length=16, max_length=512)


class LogoutRequest(BaseModel):
    refresh_token: str | None = Field(default=None, max_length=512)
    all_sessions: bool = False


class UserResponse(ORMModel):
    id: str
    email: EmailStr
    full_name: str
    role: Role
    organization: str | None = None
    job_title: str | None = None
    is_active: bool
    is_verified: bool
    last_login_at: datetime | None = None
    created_at: datetime


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int = Field(description="Access token lifetime in seconds.")


class AuthResponse(BaseModel):
    user: UserResponse
    tokens: TokenResponse
