"""Report contracts."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from obsidian.reporting.document import ReportFormat, ReportProfile
from obsidian.schemas.common import ORMModel


class ReportGenerateRequest(BaseModel):
    profile: ReportProfile = ReportProfile.TECHNICAL
    format: ReportFormat = ReportFormat.PDF


class ReportResponse(ORMModel):
    id: str
    case_id: str
    generated_by_id: str | None
    title: str
    profile: ReportProfile
    fmt: ReportFormat = Field(alias="fmt", serialization_alias="format")
    size_bytes: int
    signature: str
    summary: dict[str, Any] | None
    created_at: datetime


class ReportVerificationResponse(BaseModel):
    report_id: str
    valid: bool
    signature: str
    algorithm: str
    detail: str
