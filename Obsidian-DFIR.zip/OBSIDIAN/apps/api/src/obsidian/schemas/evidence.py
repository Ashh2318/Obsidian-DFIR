"""Evidence contracts."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from obsidian.domain.enums import EvidenceStatus, EvidenceType
from obsidian.schemas.common import ORMModel


class EvidenceResponse(ORMModel):
    id: str
    case_id: str
    uploaded_by_id: str | None
    original_filename: str
    media_type: str | None
    size_bytes: int
    evidence_type: EvidenceType
    status: EvidenceStatus
    sha256: str
    md5: str | None
    notes: str | None
    created_at: datetime
    # Present once the artefact has been analysed. Without this the analyse
    # endpoint returned a body with no results in it, making findings
    # unreachable from any client.
    analysis_summary: dict[str, Any] | None = None


class EvidenceUploadResponse(BaseModel):
    evidence: EvidenceResponse
    duplicate: bool = Field(
        default=False,
        description="True when identical content already existed in storage.",
    )


class EvidenceStatisticsResponse(BaseModel):
    by_type: dict[str, int]
    total_bytes: int
