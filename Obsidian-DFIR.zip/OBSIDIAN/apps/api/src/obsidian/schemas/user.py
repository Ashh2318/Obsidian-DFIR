"""User administration contracts."""

from __future__ import annotations

from pydantic import BaseModel

from obsidian.domain.enums import Role


class RoleUpdateRequest(BaseModel):
    role: Role


class ActiveUpdateRequest(BaseModel):
    is_active: bool
