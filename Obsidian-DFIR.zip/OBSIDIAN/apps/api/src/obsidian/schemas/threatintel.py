"""Threat-intelligence contracts."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, computed_field

from obsidian.domain.enums import IOCType, ThreatVerdict
from obsidian.schemas.common import ORMModel


class EnrichmentResponse(ORMModel):
    id: str
    ioc_type: IOCType
    value: str
    verdict: ThreatVerdict
    score: int
    providers: dict[str, Any] | None
    fetched_at: datetime
    expires_at: datetime

    @computed_field  # type: ignore[prop-decorator]
    @property
    def provider_count(self) -> int:
        return len(self.providers or {})


class ThreatIntelStatusResponse(BaseModel):
    providers: list[str]
    cache_hours: int
    cached_indicators: int
    by_verdict: dict[str, int]
