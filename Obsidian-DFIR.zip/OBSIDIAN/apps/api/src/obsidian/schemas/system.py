"""System, health and AI status contracts."""

from __future__ import annotations

from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: str
    version: str
    environment: str


class ComponentStatus(BaseModel):
    name: str
    healthy: bool
    detail: str = ""
    latency_ms: float | None = None


class ReadinessResponse(BaseModel):
    ready: bool
    components: list[ComponentStatus]


class AIStatusResponse(BaseModel):
    provider: str
    model: str
    available: bool
    detail: str = ""
    latency_ms: float | None = None
    #: Populated when the configured provider could not be built and the mock
    #: was substituted, so the UI can say so instead of implying it is live.
    degraded_reason: str | None = None
