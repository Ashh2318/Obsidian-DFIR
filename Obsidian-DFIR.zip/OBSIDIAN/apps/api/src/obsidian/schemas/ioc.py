"""IOC contracts."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, computed_field

from obsidian.analysis.iocs import defang
from obsidian.domain.enums import IOCType, Severity
from obsidian.schemas.common import ORMModel


class IOCResponse(ORMModel):
    id: str
    case_id: str
    first_seen_evidence_id: str | None
    ioc_type: IOCType
    value: str
    severity: Severity
    confidence: int
    sightings: int
    context: str | None
    created_at: datetime

    @computed_field  # type: ignore[prop-decorator]
    @property
    def defanged(self) -> str:
        """Non-clickable rendering, safe to paste into a ticket or report."""
        return defang(self.value)


class IOCStatisticsResponse(BaseModel):
    by_type: dict[str, int]
    total: int
