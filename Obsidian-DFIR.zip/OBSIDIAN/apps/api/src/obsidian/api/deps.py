"""Dependency injection for the interface layer.

Authorization is expressed as dependencies rather than conditionals inside
handlers, so a route's access requirements are visible in its signature and
cannot be forgotten halfway through a function body.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Annotated

from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.core.exceptions import (
    AccountDisabledError,
    AuthenticationError,
    PermissionDeniedError,
    TokenError,
)
from obsidian.core.security import decode_access_token
from obsidian.db.models.user import User
from obsidian.db.session import get_session
from obsidian.domain.enums import Role
from obsidian.repositories.user_repository import UserRepository
from obsidian.services.audit_service import RequestContext

# auto_error=False so a missing header raises our own domain exception and
# produces the same error envelope as every other failure.
_bearer = HTTPBearer(auto_error=False, description="Bearer access token")

SessionDep = Annotated[AsyncSession, Depends(get_session)]


def get_request_context(request: Request) -> RequestContext:
    return RequestContext(
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
        request_id=getattr(request.state, "request_id", None),
    )


ContextDep = Annotated[RequestContext, Depends(get_request_context)]


async def get_current_user(
    session: SessionDep,
    credentials: Annotated[
        HTTPAuthorizationCredentials | None, Depends(_bearer)
    ] = None,
) -> User:
    """Resolve the authenticated user from a bearer access token."""
    if credentials is None or not credentials.credentials:
        raise AuthenticationError("An access token is required.")

    payload = decode_access_token(credentials.credentials)
    user_id = payload.get("sub")
    if not user_id:
        raise TokenError("The token is missing a subject claim.")

    user = await UserRepository(session).get(user_id)
    if user is None:
        # The token is cryptographically valid but the account is gone.
        raise TokenError("The account for this token no longer exists.")
    if not user.is_active:
        raise AccountDisabledError()

    # Role is re-read from the database rather than trusted from the token, so a
    # demotion takes effect immediately instead of at token expiry.
    return user


CurrentUser = Annotated[User, Depends(get_current_user)]


def require_role(minimum: Role) -> Callable[[User], User]:
    """Dependency factory enforcing a minimum role level."""

    async def _guard(user: CurrentUser) -> User:
        if not user.role.satisfies(minimum):
            raise PermissionDeniedError(
                f"This action requires the '{minimum.value}' role or higher."
            )
        return user

    return _guard


RequireAnalyst = Annotated[User, Depends(require_role(Role.ANALYST))]
RequireInvestigator = Annotated[User, Depends(require_role(Role.INVESTIGATOR))]
RequireAdmin = Annotated[User, Depends(require_role(Role.ADMIN))]
