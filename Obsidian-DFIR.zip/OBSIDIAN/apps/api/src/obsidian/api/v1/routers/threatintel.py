"""Threat-intelligence endpoints."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Query

from obsidian.api.deps import ContextDep, CurrentUser, RequireAnalyst, SessionDep
from obsidian.core.config import settings
from obsidian.domain.enums import ThreatVerdict
from obsidian.repositories.enrichment_repository import EnrichmentRepository
from obsidian.schemas.common import Page
from obsidian.schemas.threatintel import EnrichmentResponse, ThreatIntelStatusResponse
from obsidian.services.enrichment_service import EnrichmentService
from obsidian.threatintel.registry import provider_names

router = APIRouter(prefix="/threat-intel", tags=["Threat Intelligence"])


@router.get(
    "/status",
    response_model=ThreatIntelStatusResponse,
    summary="Configured feeds and cache state",
)
async def status(_user: CurrentUser, session: SessionDep) -> ThreatIntelStatusResponse:
    by_verdict = await EnrichmentService(session).statistics()
    return ThreatIntelStatusResponse(
        providers=provider_names(),
        cache_hours=settings.threatintel_cache_hours,
        cached_indicators=sum(by_verdict.values()),
        by_verdict=by_verdict,
    )


@router.get(
    "/enrichments",
    response_model=Page[EnrichmentResponse],
    summary="Cached reputation verdicts",
)
async def list_enrichments(
    _user: CurrentUser,
    session: SessionDep,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    offset: Annotated[int, Query(ge=0)] = 0,
    verdict: ThreatVerdict | None = None,
) -> Page[EnrichmentResponse]:
    rows, total = await EnrichmentRepository(session).list_recent(
        limit=limit, offset=offset, verdict=verdict
    )
    return Page[EnrichmentResponse](
        items=[EnrichmentResponse.model_validate(r) for r in rows],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.post(
    "/iocs/{ioc_id}/enrich",
    response_model=EnrichmentResponse,
    summary="Enrich a single indicator",
    description=(
        "Returns the cached verdict when it is still fresh. Pass `force=true` to "
        "bypass the cache. A malicious verdict raises the indicator's own "
        "severity, since that is new information about the case."
    ),
)
async def enrich_ioc(
    ioc_id: str,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
    force: bool = False,
) -> EnrichmentResponse:
    enrichment, _ = await EnrichmentService(session).enrich_ioc(
        actor=actor, ioc_id=ioc_id, force=force, context=context
    )
    return EnrichmentResponse.model_validate(enrichment)


@router.post(
    "/cases/{case_id}/enrich",
    response_model=list[EnrichmentResponse],
    summary="Enrich a case's indicators",
)
async def enrich_case(
    case_id: str,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
    limit: Annotated[int, Query(ge=1, le=100)] = 25,
) -> list[EnrichmentResponse]:
    enrichments = await EnrichmentService(session).enrich_case(
        actor=actor, case_id=case_id, limit=limit, context=context
    )
    return [EnrichmentResponse.model_validate(e) for e in enrichments]
