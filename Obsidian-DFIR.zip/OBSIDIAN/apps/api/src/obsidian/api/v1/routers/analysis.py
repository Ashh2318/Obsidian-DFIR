"""Analysis and IOC endpoints."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Query

from obsidian.analysis.registry import supported_types
from obsidian.api.deps import ContextDep, CurrentUser, RequireAnalyst, SessionDep
from obsidian.domain.enums import IOCType, Severity
from obsidian.schemas.common import Page
from obsidian.schemas.evidence import EvidenceResponse
from obsidian.schemas.ioc import IOCResponse, IOCStatisticsResponse
from obsidian.repositories.ioc_repository import IOCRepository
from obsidian.services.analysis_service import AnalysisService

router = APIRouter(tags=["Analysis"])


@router.post(
    "/evidence/{evidence_id}/analyze",
    response_model=EvidenceResponse,
    summary="Analyse an artefact",
    description=(
        "Runs the engine matching the artefact's detected type, storing findings "
        "on the evidence record and upserting extracted indicators against the "
        "case. Re-running refreshes the results and increments IOC sightings."
    ),
)
async def analyze_evidence(
    evidence_id: str,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
) -> EvidenceResponse:
    evidence = await AnalysisService(session).analyze(
        actor=actor, evidence_id=evidence_id, context=context
    )
    return EvidenceResponse.model_validate(evidence)


@router.get(
    "/analysis/engines",
    response_model=list[str],
    summary="Evidence types with an available engine",
)
async def list_engines(_user: CurrentUser) -> list[str]:
    return supported_types()


@router.get("/iocs", response_model=Page[IOCResponse], summary="List indicators")
async def list_iocs(
    _user: CurrentUser,
    session: SessionDep,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    offset: Annotated[int, Query(ge=0)] = 0,
    case_id: Annotated[str | None, Query(max_length=36)] = None,
    ioc_type: IOCType | None = None,
    severity: Severity | None = None,
    q: Annotated[str | None, Query(max_length=200)] = None,
) -> Page[IOCResponse]:
    rows, total = await IOCRepository(session).search(
        limit=limit,
        offset=offset,
        case_id=case_id,
        ioc_type=ioc_type,
        severity=severity,
        query=q,
    )
    return Page[IOCResponse](
        items=[IOCResponse.model_validate(r) for r in rows],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/iocs/statistics",
    response_model=IOCStatisticsResponse,
    summary="Indicator counts by type",
)
async def ioc_statistics(
    _user: CurrentUser,
    session: SessionDep,
    case_id: Annotated[str | None, Query(max_length=36)] = None,
) -> IOCStatisticsResponse:
    by_type = await IOCRepository(session).count_by_type(case_id)
    return IOCStatisticsResponse(by_type=by_type, total=sum(by_type.values()))
