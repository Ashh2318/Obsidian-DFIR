"""Health, readiness and AI provider status."""

from __future__ import annotations

import time

from fastapi import APIRouter
from sqlalchemy import text

from obsidian.ai.registry import degraded_reason, get_provider
from obsidian.api.deps import CurrentUser, SessionDep
from obsidian.core.cache import get_cache
from obsidian.core.config import settings
from obsidian.schemas.system import (
    AIStatusResponse,
    ComponentStatus,
    HealthResponse,
    ReadinessResponse,
)

router = APIRouter(tags=["System"])

VERSION = "0.1.0"


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Liveness probe",
    description="Returns as long as the process is running. Never touches I/O.",
)
async def health() -> HealthResponse:
    return HealthResponse(
        status="ok", version=VERSION, environment=settings.environment
    )


@router.get(
    "/ready",
    response_model=ReadinessResponse,
    summary="Readiness probe",
    description="Verifies every downstream dependency the API needs to serve traffic.",
)
async def ready(session: SessionDep) -> ReadinessResponse:
    components: list[ComponentStatus] = []

    started = time.perf_counter()
    try:
        await session.execute(text("SELECT 1"))
        components.append(
            ComponentStatus(
                name="database",
                healthy=True,
                detail="postgresql" if not settings.is_sqlite else "sqlite",
                latency_ms=round((time.perf_counter() - started) * 1000, 2),
            )
        )
    except Exception as exc:  # noqa: BLE001 - probe must report, not raise
        components.append(
            ComponentStatus(name="database", healthy=False, detail=str(exc)[:200])
        )

    started = time.perf_counter()
    try:
        await get_cache().set("readiness:probe", "1", 5)
        components.append(
            ComponentStatus(
                name="cache",
                healthy=True,
                detail="redis" if settings.redis_url else "in-memory",
                latency_ms=round((time.perf_counter() - started) * 1000, 2),
            )
        )
    except Exception as exc:  # noqa: BLE001
        components.append(
            ComponentStatus(name="cache", healthy=False, detail=str(exc)[:200])
        )

    return ReadinessResponse(
        ready=all(c.healthy for c in components), components=components
    )


@router.get(
    "/ai/status",
    response_model=AIStatusResponse,
    summary="AI provider status",
    description=(
        "Reports which provider is configured and whether it is reachable. "
        "Authenticated because provider identity and model names are "
        "deployment detail."
    ),
)
async def ai_status(_user: CurrentUser) -> AIStatusResponse:
    health_result = await get_provider().health()
    return AIStatusResponse(
        provider=health_result.provider,
        model=health_result.model,
        available=health_result.available,
        detail=health_result.detail,
        latency_ms=health_result.latency_ms,
        degraded_reason=degraded_reason(),
    )
