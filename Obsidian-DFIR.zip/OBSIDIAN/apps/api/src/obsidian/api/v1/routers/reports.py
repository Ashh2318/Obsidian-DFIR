"""Reporting endpoints."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Query, Response, status

from obsidian.api.deps import ContextDep, CurrentUser, RequireAnalyst, SessionDep
from obsidian.reporting.document import ReportProfile
from obsidian.reporting.registry import MEDIA_TYPES
from obsidian.schemas.common import MessageResponse, Page
from obsidian.schemas.report import (
    ReportGenerateRequest,
    ReportResponse,
    ReportVerificationResponse,
)
from obsidian.services.report_service import ReportService

router = APIRouter(tags=["Reports"])


@router.get("/reports", response_model=Page[ReportResponse], summary="List reports")
async def list_reports(
    _user: CurrentUser,
    session: SessionDep,
    limit: Annotated[int, Query(ge=1, le=100)] = 25,
    offset: Annotated[int, Query(ge=0)] = 0,
    profile: ReportProfile | None = None,
) -> Page[ReportResponse]:
    rows, total = await ReportService(session).list_all(
        limit=limit, offset=offset, profile=profile
    )
    return Page[ReportResponse](
        items=[ReportResponse.model_validate(r) for r in rows],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/cases/{case_id}/reports",
    response_model=Page[ReportResponse],
    summary="Reports for a case",
)
async def list_case_reports(
    case_id: str,
    _user: CurrentUser,
    session: SessionDep,
    limit: Annotated[int, Query(ge=1, le=100)] = 25,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> Page[ReportResponse]:
    rows, total = await ReportService(session).list_for_case(
        case_id, limit=limit, offset=offset
    )
    return Page[ReportResponse](
        items=[ReportResponse.model_validate(r) for r in rows],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.post(
    "/cases/{case_id}/reports",
    response_model=ReportResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Generate a report",
    description=(
        "Composes the case into a report and renders it. The rendered bytes are "
        "stored, not regenerated on download: a report is a point-in-time "
        "statement, and regenerating it later would silently produce a different "
        "document as the case evolves."
    ),
)
async def generate_report(
    case_id: str,
    payload: ReportGenerateRequest,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
) -> ReportResponse:
    report = await ReportService(session).generate(
        actor=actor,
        case_id=case_id,
        profile=payload.profile,
        fmt=payload.format,
        context=context,
    )
    return ReportResponse.model_validate(report)


@router.get(
    "/reports/{report_id}/download",
    summary="Download a report",
    response_class=Response,
)
async def download_report(
    report_id: str, _user: CurrentUser, session: SessionDep
) -> Response:
    service = ReportService(session)
    report = await service.get(report_id)
    return Response(
        content=report.content,
        media_type=MEDIA_TYPES[report.fmt],
        headers={
            "Content-Disposition": f'attachment; filename="{service.filename(report)}"',
            "X-Report-Signature": report.signature,
            "X-Content-Type-Options": "nosniff",
        },
    )


@router.post(
    "/reports/{report_id}/verify",
    response_model=ReportVerificationResponse,
    summary="Verify report integrity",
    description=(
        "Recomputes the HMAC over the stored bytes and compares it with the "
        "signature issued at generation. Detects any alteration since."
    ),
)
async def verify_report(
    report_id: str, _user: CurrentUser, session: SessionDep
) -> ReportVerificationResponse:
    result = await ReportService(session).verify(report_id)
    return ReportVerificationResponse(**result)  # type: ignore[arg-type]


@router.delete(
    "/reports/{report_id}", response_model=MessageResponse, summary="Delete a report"
)
async def delete_report(
    report_id: str, _actor: RequireAnalyst, session: SessionDep
) -> MessageResponse:
    await ReportService(session).delete(report_id=report_id)
    return MessageResponse(message="Report deleted.")
