"""Timeline endpoints."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Query

from obsidian.api.deps import CurrentUser, SessionDep
from obsidian.domain.enums import Severity, TimelineSource
from obsidian.schemas.timeline import TimelineEventResponse, TimelineResponse
from obsidian.services.timeline_service import TimelineService

router = APIRouter(tags=["Timeline"])


def _to_response(events: list, source: TimelineSource | None, severity: Severity | None):
    filtered = [
        event
        for event in events
        if (source is None or event.source is source)
        and (severity is None or event.severity.rank >= severity.rank)
    ]
    return TimelineResponse(
        events=[TimelineEventResponse(**event.to_dict()) for event in filtered],
        total=len(filtered),
        incident_events=sum(
            1 for e in filtered if e.source is TimelineSource.INCIDENT
        ),
        investigation_events=sum(
            1 for e in filtered if e.source is TimelineSource.INVESTIGATION
        ),
    )


@router.get(
    "/cases/{case_id}/timeline",
    response_model=TimelineResponse,
    summary="Forensic timeline for a case",
    description=(
        "Merges investigation activity (what the team did, and when) with "
        "incident activity derived from evidence content (when the observed "
        "behaviour actually occurred). Findings are anchored to their capture "
        "window rather than to upload time."
    ),
)
async def case_timeline(
    case_id: str,
    _user: CurrentUser,
    session: SessionDep,
    source: TimelineSource | None = None,
    min_severity: Annotated[Severity | None, Query(alias="min_severity")] = None,
) -> TimelineResponse:
    events = await TimelineService(session).for_case(case_id)
    return _to_response(events, source, min_severity)


@router.get(
    "/timeline",
    response_model=TimelineResponse,
    summary="Recent activity across all cases",
)
async def global_timeline(
    _user: CurrentUser,
    session: SessionDep,
    limit: Annotated[int, Query(ge=1, le=300)] = 100,
    source: TimelineSource | None = None,
    min_severity: Annotated[Severity | None, Query(alias="min_severity")] = None,
) -> TimelineResponse:
    events = await TimelineService(session).recent(limit=limit)
    return _to_response(events, source, min_severity)
