"""Case endpoints."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Query, status

from obsidian.api.deps import ContextDep, CurrentUser, RequireAnalyst, SessionDep
from obsidian.domain.enums import CaseStatus, Severity
from obsidian.schemas.case import (
    CaseCreateRequest,
    CaseOverviewResponse,
    CaseResponse,
    CaseStatisticsResponse,
    CaseStatusRequest,
    CaseUpdateRequest,
)
from obsidian.schemas.common import Page
from obsidian.services.case_service import CaseService

router = APIRouter(prefix="/cases", tags=["Cases"])


@router.get("", response_model=Page[CaseResponse], summary="List cases")
async def list_cases(
    _user: CurrentUser,
    session: SessionDep,
    limit: Annotated[int, Query(ge=1, le=100)] = 25,
    offset: Annotated[int, Query(ge=0)] = 0,
    q: Annotated[str | None, Query(max_length=200, description="Free-text search")] = None,
    status_filter: Annotated[CaseStatus | None, Query(alias="status")] = None,
    severity: Severity | None = None,
    assignee_id: Annotated[str | None, Query(max_length=36)] = None,
) -> Page[CaseResponse]:
    cases, total = await CaseService(session).list(
        limit=limit,
        offset=offset,
        query=q,
        status=status_filter,
        severity=severity,
        assignee_id=assignee_id,
    )
    return Page[CaseResponse](
        items=[CaseResponse.model_validate(c) for c in cases],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/statistics",
    response_model=CaseStatisticsResponse,
    summary="Case counts by status and severity",
)
async def case_statistics(_user: CurrentUser, session: SessionDep) -> CaseStatisticsResponse:
    # Declared before /{case_id} so the literal path is not captured as an id.
    stats = await CaseService(session).statistics()
    return CaseStatisticsResponse(**stats)


@router.post(
    "",
    response_model=CaseResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Open a case",
)
async def create_case(
    payload: CaseCreateRequest,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
) -> CaseResponse:
    case = await CaseService(session).create(
        actor=actor,
        title=payload.title,
        summary=payload.summary,
        severity=payload.severity,
        assignee_id=payload.assignee_id,
        context=context,
    )
    return CaseResponse.model_validate(case)


@router.get(
    "/{case_id}/overview",
    response_model=CaseOverviewResponse,
    summary="Compact case telemetry",
    description="Counts and the most severe finding in a single call.",
)
async def case_overview(
    case_id: str, _user: CurrentUser, session: SessionDep
) -> CaseOverviewResponse:
    return CaseOverviewResponse(**await CaseService(session).overview(case_id))  # type: ignore[arg-type]


@router.get("/{case_id}", response_model=CaseResponse, summary="Fetch a case")
async def get_case(case_id: str, _user: CurrentUser, session: SessionDep) -> CaseResponse:
    return CaseResponse.model_validate(await CaseService(session).get(case_id))


@router.patch("/{case_id}", response_model=CaseResponse, summary="Update a case")
async def update_case(
    case_id: str,
    payload: CaseUpdateRequest,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
) -> CaseResponse:
    case = await CaseService(session).update(
        actor=actor,
        case_id=case_id,
        title=payload.title,
        summary=payload.summary,
        severity=payload.severity,
        assignee_id=payload.assignee_id,
        clear_assignee=payload.clear_assignee,
        context=context,
    )
    return CaseResponse.model_validate(case)


@router.patch(
    "/{case_id}/status",
    response_model=CaseResponse,
    summary="Move a case through its workflow",
    description=(
        "Transitions are validated against the case workflow. An invalid move "
        "returns 409 with the permitted next states."
    ),
)
async def change_case_status(
    case_id: str,
    payload: CaseStatusRequest,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
) -> CaseResponse:
    case = await CaseService(session).change_status(
        actor=actor, case_id=case_id, target=payload.status, context=context
    )
    return CaseResponse.model_validate(case)
