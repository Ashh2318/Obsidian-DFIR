"""User administration endpoints (administrator only)."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Query

from obsidian.api.deps import ContextDep, RequireAdmin, SessionDep
from obsidian.domain.enums import Role
from obsidian.schemas.auth import UserResponse
from obsidian.schemas.common import Page
from obsidian.schemas.user import ActiveUpdateRequest, RoleUpdateRequest
from obsidian.services.user_service import UserService

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("", response_model=Page[UserResponse], summary="List accounts")
async def list_users(
    _admin: RequireAdmin,
    session: SessionDep,
    limit: Annotated[int, Query(ge=1, le=100)] = 25,
    offset: Annotated[int, Query(ge=0)] = 0,
    role: Role | None = None,
) -> Page[UserResponse]:
    users, total = await UserService(session).list(
        limit=limit, offset=offset, role=role
    )
    return Page[UserResponse](
        items=[UserResponse.model_validate(u) for u in users],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get("/{user_id}", response_model=UserResponse, summary="Fetch an account")
async def get_user(
    user_id: str, _admin: RequireAdmin, session: SessionDep
) -> UserResponse:
    return UserResponse.model_validate(await UserService(session).get(user_id))


@router.patch(
    "/{user_id}/role",
    response_model=UserResponse,
    summary="Change an account's role",
    description="Refuses to demote the last remaining administrator.",
)
async def change_role(
    user_id: str,
    payload: RoleUpdateRequest,
    admin: RequireAdmin,
    session: SessionDep,
    context: ContextDep,
) -> UserResponse:
    user = await UserService(session).change_role(
        actor=admin, user_id=user_id, new_role=payload.role, context=context
    )
    return UserResponse.model_validate(user)


@router.patch(
    "/{user_id}/active",
    response_model=UserResponse,
    summary="Enable or disable an account",
    description="Disabling an account immediately revokes all of its sessions.",
)
async def set_active(
    user_id: str,
    payload: ActiveUpdateRequest,
    admin: RequireAdmin,
    session: SessionDep,
    context: ContextDep,
) -> UserResponse:
    user = await UserService(session).set_active(
        actor=admin, user_id=user_id, is_active=payload.is_active, context=context
    )
    return UserResponse.model_validate(user)
