"""Evidence endpoints."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, File, Form, Query, UploadFile, status
from fastapi.responses import FileResponse

from obsidian.api.deps import ContextDep, CurrentUser, RequireAnalyst, SessionDep
from obsidian.core.exceptions import NotFoundError, ValidationError
from obsidian.core.storage import get_storage
from obsidian.schemas.common import MessageResponse, Page
from obsidian.schemas.evidence import EvidenceResponse, EvidenceStatisticsResponse
from obsidian.services.evidence_service import EvidenceService

router = APIRouter(tags=["Evidence"])


@router.get(
    "/cases/{case_id}/evidence",
    response_model=Page[EvidenceResponse],
    summary="List evidence for a case",
)
async def list_evidence(
    case_id: str,
    _user: CurrentUser,
    session: SessionDep,
    limit: Annotated[int, Query(ge=1, le=100)] = 50,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> Page[EvidenceResponse]:
    items, total = await EvidenceService(session).list_for_case(
        case_id, limit=limit, offset=offset
    )
    return Page[EvidenceResponse](
        items=[EvidenceResponse.model_validate(i) for i in items],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.post(
    "/cases/{case_id}/evidence",
    response_model=EvidenceResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Upload evidence",
    description=(
        "Streams the artefact to content-addressed storage, computing SHA-256 "
        "and MD5 in a single pass. The artefact type is detected from magic "
        "bytes, not the filename. Re-uploading identical content to the same "
        "case returns 409."
    ),
)
async def upload_evidence(
    case_id: str,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
    file: Annotated[UploadFile, File(description="The artefact to ingest")],
    notes: Annotated[str | None, Form(max_length=4000)] = None,
) -> EvidenceResponse:
    if not file.filename:
        raise ValidationError("The upload is missing a filename.")

    evidence = await EvidenceService(session).ingest(
        actor=actor,
        case_id=case_id,
        # UploadFile.file is a synchronous SpooledTemporaryFile; the storage
        # backend reads it in chunks so a large artefact is never fully
        # materialised in memory.
        source=file.file,
        filename=file.filename,
        media_type=file.content_type,
        notes=notes,
        context=context,
    )
    return EvidenceResponse.model_validate(evidence)


@router.get(
    "/evidence/statistics",
    response_model=EvidenceStatisticsResponse,
    summary="Evidence counts by type",
)
async def evidence_statistics(
    _user: CurrentUser,
    session: SessionDep,
    case_id: Annotated[str | None, Query(max_length=36)] = None,
) -> EvidenceStatisticsResponse:
    stats = await EvidenceService(session).statistics(case_id)
    return EvidenceStatisticsResponse(**stats)  # type: ignore[arg-type]


@router.get(
    "/evidence/{evidence_id}",
    response_model=EvidenceResponse,
    summary="Fetch evidence metadata",
)
async def get_evidence(
    evidence_id: str, _user: CurrentUser, session: SessionDep
) -> EvidenceResponse:
    return EvidenceResponse.model_validate(await EvidenceService(session).get(evidence_id))


@router.get(
    "/evidence/{evidence_id}/download",
    summary="Download the original artefact",
    description=(
        "Served as an attachment with a generic content type so a browser "
        "never renders potentially malicious evidence inline."
    ),
)
async def download_evidence(
    evidence_id: str, _user: CurrentUser, session: SessionDep
) -> FileResponse:
    evidence = await EvidenceService(session).get(evidence_id)
    path = get_storage().resolve(evidence.stored_path)
    if not path.exists():
        raise NotFoundError("The stored artefact is missing from disk.")

    return FileResponse(
        path,
        filename=evidence.original_filename,
        # Always octet-stream: serving evidence with its real content type
        # invites the browser to execute or render it.
        media_type="application/octet-stream",
        headers={"X-Content-Type-Options": "nosniff"},
    )


@router.delete(
    "/evidence/{evidence_id}",
    response_model=MessageResponse,
    summary="Remove evidence from a case",
)
async def delete_evidence(
    evidence_id: str,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
) -> MessageResponse:
    await EvidenceService(session).delete(
        actor=actor, evidence_id=evidence_id, context=context
    )
    return MessageResponse(message="Evidence removed from the case.")
