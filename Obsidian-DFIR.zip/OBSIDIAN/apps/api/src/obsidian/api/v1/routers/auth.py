"""Authentication endpoints.

Handlers are deliberately thin: validate, delegate to a service, shape a
response. No business rules live here.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, status

from obsidian.api.deps import ContextDep, CurrentUser, SessionDep
from obsidian.core.rate_limit import rate_limit_auth
from obsidian.schemas.auth import (
    AuthResponse,
    LoginRequest,
    LogoutRequest,
    RefreshRequest,
    RegisterRequest,
    TokenResponse,
    UserResponse,
)
from obsidian.schemas.common import MessageResponse
from obsidian.services.auth_service import AuthResult, AuthService

router = APIRouter(prefix="/auth", tags=["Authentication"])

# Every endpoint here is a credential-handling surface, so all of them get the
# strict auth budget rather than the general API budget.
_limited = [Depends(rate_limit_auth())]


def _auth_response(result: AuthResult) -> AuthResponse:
    return AuthResponse(
        user=UserResponse.model_validate(result.user),
        tokens=TokenResponse(
            access_token=result.tokens.access_token,
            refresh_token=result.tokens.refresh_token,
            expires_in=result.tokens.expires_in,
        ),
    )


@router.post(
    "/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=_limited,
    summary="Create an account",
    description=(
        "Registers a new account. The first account created on a deployment is "
        "granted the administrator role so the instance is manageable."
    ),
)
async def register(
    payload: RegisterRequest, session: SessionDep, context: ContextDep
) -> UserResponse:
    user = await AuthService(session).register(
        email=payload.email,
        password=payload.password,
        full_name=payload.full_name,
        organization=payload.organization,
        job_title=payload.job_title,
        context=context,
    )
    return UserResponse.model_validate(user)


@router.post(
    "/login",
    response_model=AuthResponse,
    dependencies=_limited,
    summary="Exchange credentials for tokens",
)
async def login(
    payload: LoginRequest, session: SessionDep, context: ContextDep
) -> AuthResponse:
    result = await AuthService(session).authenticate(
        email=payload.email, password=payload.password, context=context
    )
    return _auth_response(result)


@router.post(
    "/refresh",
    response_model=AuthResponse,
    dependencies=_limited,
    summary="Rotate a refresh token",
    description=(
        "Exchanges a refresh token for a new token pair. The presented token is "
        "revoked on use. Replaying a spent token revokes every session in its "
        "family."
    ),
)
async def refresh(
    payload: RefreshRequest, session: SessionDep, context: ContextDep
) -> AuthResponse:
    result = await AuthService(session).refresh(
        refresh_token=payload.refresh_token, context=context
    )
    return _auth_response(result)


@router.post(
    "/logout",
    response_model=MessageResponse,
    summary="Revoke the current session",
)
async def logout(
    payload: LogoutRequest,
    user: CurrentUser,
    session: SessionDep,
    context: ContextDep,
) -> MessageResponse:
    count = await AuthService(session).logout(
        user=user,
        refresh_token=payload.refresh_token,
        all_sessions=payload.all_sessions,
        context=context,
    )
    return MessageResponse(
        message=f"Signed out. {count} session(s) revoked."
    )


@router.get(
    "/me",
    response_model=UserResponse,
    summary="Current account",
)
async def me(user: CurrentUser) -> UserResponse:
    return UserResponse.model_validate(user)
