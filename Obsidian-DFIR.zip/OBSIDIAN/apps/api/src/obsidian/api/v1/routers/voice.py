"""Voice Command Mode endpoints."""

from __future__ import annotations

from fastapi import APIRouter

from obsidian.api.deps import ContextDep, CurrentUser, RequireAnalyst, SessionDep
from obsidian.domain.enums import IntentAction
from obsidian.schemas.voice import (
    IntentResponse,
    VoiceCapabilitiesResponse,
    VoiceCommandRequest,
    VoiceCommandResponse,
)
from obsidian.voice.intents import parse
from obsidian.voice.resolver import HELP_TEXT, IntentResolver

router = APIRouter(prefix="/voice", tags=["Voice"])

EXAMPLES = [
    "Hey Obsidian, open case O-B-S 2026 1",
    "Show me all critical cases",
    "Summarise this case",
    "Analyse the evidence",
    "What indicators did we find",
    "Check reputation",
    "Mark this case as contained",
    "Generate an executive report",
    "Go to the timeline",
]


@router.get(
    "/capabilities",
    response_model=VoiceCapabilitiesResponse,
    summary="What voice mode understands",
)
async def capabilities(_user: CurrentUser) -> VoiceCapabilitiesResponse:
    return VoiceCapabilitiesResponse(
        wake_word="Hey Obsidian",
        actions=[a.value for a in IntentAction if a is not IntentAction.UNKNOWN],
        examples=EXAMPLES,
        help_text=HELP_TEXT,
    )


@router.post(
    "/command",
    response_model=VoiceCommandResponse,
    summary="Interpret and execute a spoken command",
    description=(
        "Parses an utterance and executes it through the same services the UI "
        "calls. Pass `dry_run` to interpret without acting, which is how a "
        "state-changing command can be read back for confirmation first."
    ),
)
async def command(
    payload: VoiceCommandRequest,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
) -> VoiceCommandResponse:
    intent = parse(
        payload.utterance,
        current_case_id=payload.current_case_id,
        last_action=payload.last_action,
        last_subject=payload.last_subject,
    )

    if payload.dry_run:
        return VoiceCommandResponse(
            intent=IntentResponse(**intent.to_dict()),
            speech=f"I understood that as: {intent.action.value.replace('_', ' ')}.",
            ui_action=None,
            data={},
            succeeded=intent.action is not IntentAction.UNKNOWN,
        )

    result = await IntentResolver(session).resolve(intent, actor=actor, context=context)
    return VoiceCommandResponse(
        intent=IntentResponse(**result.intent.to_dict()),
        speech=result.speech,
        ui_action=result.ui_action,
        data=result.data,
        succeeded=result.succeeded,
    )
