"""AI assistant endpoints."""

from __future__ import annotations

import json
from typing import Annotated

from fastapi import APIRouter, Query, status
from fastapi.responses import StreamingResponse

from obsidian.api.deps import ContextDep, RequireAnalyst, SessionDep
from obsidian.core.exceptions import ObsidianError
from obsidian.core.logging import get_logger
from obsidian.schemas.chat import (
    ConversationCreateRequest,
    ConversationDetailResponse,
    ConversationResponse,
    MessageResponse,
    SendMessageRequest,
)
from obsidian.schemas.common import MessageResponse as SimpleMessage, Page
from obsidian.services.chat_service import ChatService

logger = get_logger(__name__)

router = APIRouter(prefix="/assistant", tags=["AI Assistant"])


@router.get(
    "/conversations",
    response_model=Page[ConversationResponse],
    summary="List your conversations",
)
async def list_conversations(
    actor: RequireAnalyst,
    session: SessionDep,
    limit: Annotated[int, Query(ge=1, le=100)] = 30,
    offset: Annotated[int, Query(ge=0)] = 0,
    case_id: Annotated[str | None, Query(max_length=36)] = None,
) -> Page[ConversationResponse]:
    rows, total = await ChatService(session).list(
        actor=actor, limit=limit, offset=offset, case_id=case_id
    )
    return Page[ConversationResponse](
        items=[ConversationResponse.model_validate(c) for c in rows],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.post(
    "/conversations",
    response_model=ConversationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Start a conversation",
    description=(
        "Attaching a case grounds every answer in that investigation's evidence, "
        "findings and indicators."
    ),
)
async def create_conversation(
    payload: ConversationCreateRequest,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
) -> ConversationResponse:
    conversation = await ChatService(session).create(
        actor=actor, case_id=payload.case_id, title=payload.title, context=context
    )
    return ConversationResponse.model_validate(conversation)


@router.get(
    "/conversations/{conversation_id}",
    response_model=ConversationDetailResponse,
    summary="Fetch a conversation with its messages",
)
async def get_conversation(
    conversation_id: str, actor: RequireAnalyst, session: SessionDep
) -> ConversationDetailResponse:
    conversation = await ChatService(session).get(
        actor=actor, conversation_id=conversation_id
    )
    return ConversationDetailResponse.model_validate(conversation)


@router.delete(
    "/conversations/{conversation_id}",
    response_model=SimpleMessage,
    summary="Delete a conversation",
)
async def delete_conversation(
    conversation_id: str, actor: RequireAnalyst, session: SessionDep
) -> SimpleMessage:
    await ChatService(session).delete(actor=actor, conversation_id=conversation_id)
    return SimpleMessage(message="Conversation deleted.")


@router.post(
    "/conversations/{conversation_id}/messages",
    response_model=MessageResponse,
    summary="Ask a question and wait for the full answer",
)
async def send_message(
    conversation_id: str,
    payload: SendMessageRequest,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
) -> MessageResponse:
    message = await ChatService(session).send(
        actor=actor,
        conversation_id=conversation_id,
        prompt=payload.prompt,
        context=context,
    )
    return MessageResponse.model_validate(message)


@router.post(
    "/conversations/{conversation_id}/stream",
    summary="Ask a question and stream the answer",
    description=(
        "Server-sent events. Each `data:` frame carries a JSON object: "
        "`{\"delta\": \"...\"}` for content, `{\"done\": true}` at completion, "
        "or `{\"error\": \"...\"}` on failure."
    ),
    response_class=StreamingResponse,
)
async def stream_message(
    conversation_id: str,
    payload: SendMessageRequest,
    actor: RequireAnalyst,
    session: SessionDep,
    context: ContextDep,
) -> StreamingResponse:
    service = ChatService(session)

    async def event_stream():
        try:
            async for delta in service.stream(
                actor=actor,
                conversation_id=conversation_id,
                prompt=payload.prompt,
                context=context,
            ):
                yield f"data: {json.dumps({'delta': delta})}\n\n"
            yield f"data: {json.dumps({'done': True})}\n\n"
        except ObsidianError as exc:
            # Headers are already sent by the time streaming starts, so a
            # failure cannot become an HTTP status. It is delivered in-band
            # instead, and the client surfaces it.
            yield f"data: {json.dumps({'error': exc.message})}\n\n"
        except Exception as exc:  # noqa: BLE001 - the stream must always terminate
            logger.exception("assistant.stream.failed", conversation_id=conversation_id)
            yield f"data: {json.dumps({'error': f'The assistant failed: {exc}'})}\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            # Without this, nginx buffers the whole response and the stream
            # arrives as a single lump — defeating the point of streaming.
            "X-Accel-Buffering": "no",
        },
    )
