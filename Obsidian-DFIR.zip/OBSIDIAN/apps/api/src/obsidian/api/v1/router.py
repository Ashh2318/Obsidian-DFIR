"""Aggregate v1 router."""

from __future__ import annotations

from fastapi import APIRouter

from obsidian.api.v1.routers import (
    analysis,
    auth,
    cases,
    chat,
    evidence,
    reports,
    system,
    threatintel,
    timeline,
    users,
    voice,
)

api_router = APIRouter()
api_router.include_router(system.router)
api_router.include_router(auth.router)
api_router.include_router(users.router)
api_router.include_router(cases.router)
api_router.include_router(evidence.router)
api_router.include_router(analysis.router)
api_router.include_router(chat.router)
api_router.include_router(timeline.router)
api_router.include_router(threatintel.router)
api_router.include_router(reports.router)
api_router.include_router(voice.router)
