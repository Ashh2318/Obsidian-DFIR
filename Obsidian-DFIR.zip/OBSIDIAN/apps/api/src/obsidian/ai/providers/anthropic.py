"""Anthropic Claude provider (Messages API over HTTP).

Called through ``httpx`` rather than the vendor SDK so the service has exactly
one HTTP client, one timeout policy and one retry story across all providers.
"""

from __future__ import annotations

import time
from collections.abc import AsyncIterator

import httpx

from obsidian.ai.base import (
    CompletionRequest,
    Message,
    CompletionResponse,
    MessageRole,
    ProviderHealth,
    TokenUsage,
)
from obsidian.core.exceptions import ConfigurationError, ProviderError

API_URL = "https://api.anthropic.com/v1/messages"
API_VERSION = "2023-06-01"


class AnthropicProvider:
    name = "anthropic"

    def __init__(
        self, api_key: str, model: str | None = None, timeout: int = 120
    ) -> None:
        if not api_key:
            raise ConfigurationError(
                "OBSIDIAN_ANTHROPIC_API_KEY is required when "
                "OBSIDIAN_AI_PROVIDER=anthropic."
            )
        self._model = model or "claude-sonnet-5"
        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers={
                "x-api-key": api_key,
                "anthropic-version": API_VERSION,
                "content-type": "application/json",
            },
        )

    @property
    def default_model(self) -> str:
        return self._model

    def _payload(self, request: CompletionRequest, *, stream: bool) -> dict:
        payload: dict = {
            "model": request.model or self._model,
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
            "messages": [
                {"role": m.role.value, "content": m.content}
                for m in request.messages
                if m.role is not MessageRole.SYSTEM
            ],
            "stream": stream,
        }
        # Claude takes the system prompt as a top-level field, not a message.
        system = request.system or next(
            (m.content for m in request.messages if m.role is MessageRole.SYSTEM), None
        )
        if system:
            payload["system"] = system
        return payload

    async def complete(self, request: CompletionRequest) -> CompletionResponse:
        try:
            response = await self._client.post(
                API_URL, json=self._payload(request, stream=False)
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise ProviderError(
                f"Anthropic returned {exc.response.status_code}.",
                details={"body": exc.response.text[:500]},
            ) from exc
        except httpx.HTTPError as exc:
            raise ProviderError(f"Anthropic request failed: {exc}") from exc

        data = response.json()
        text = "".join(
            block.get("text", "")
            for block in data.get("content", [])
            if block.get("type") == "text"
        )
        usage = data.get("usage", {})
        return CompletionResponse(
            content=text,
            model=data.get("model", self._model),
            provider=self.name,
            usage=TokenUsage(
                input_tokens=usage.get("input_tokens", 0),
                output_tokens=usage.get("output_tokens", 0),
            ),
            stop_reason=data.get("stop_reason"),
            raw=data,
        )

    async def stream(self, request: CompletionRequest) -> AsyncIterator[str]:
        import json

        payload = self._payload(request, stream=True)
        async with self._client.stream("POST", API_URL, json=payload) as response:
            if response.status_code >= 400:
                body = (await response.aread()).decode("utf-8", "replace")
                raise ProviderError(
                    f"Anthropic returned {response.status_code}.",
                    details={"body": body[:500]},
                )
            async for line in response.aiter_lines():
                if not line.startswith("data:"):
                    continue
                raw = line[5:].strip()
                if not raw or raw == "[DONE]":
                    continue
                try:
                    event = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                if event.get("type") == "content_block_delta":
                    delta = event.get("delta", {})
                    if delta.get("type") == "text_delta":
                        yield delta.get("text", "")

    async def health(self) -> ProviderHealth:
        started = time.perf_counter()
        try:
            await self.complete(
                CompletionRequest(
                    messages=[Message(MessageRole.USER, "ping")],
                    max_tokens=8,
                )
            )
        except ProviderError as exc:
            return ProviderHealth(self.name, False, self._model, str(exc))
        latency = (time.perf_counter() - started) * 1000
        return ProviderHealth(self.name, True, self._model, "OK", round(latency, 2))

    async def close(self) -> None:
        await self._client.aclose()
