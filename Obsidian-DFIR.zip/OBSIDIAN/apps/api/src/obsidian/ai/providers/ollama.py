"""Ollama provider, local or hosted.

A local Ollama is not merely a cost optimisation. In regulated DFIR work,
evidence often cannot legally leave the analyst's machine, which makes an
offline provider a functional requirement rather than a fallback.

The same wire protocol backs Ollama's hosted service at ollama.com, which
authenticates with a bearer token. Supplying a key selects it; the request and
streaming formats are identical, so only the transport differs.
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator

import httpx

from obsidian.ai.base import (
    CompletionRequest,
    CompletionResponse,
    ProviderHealth,
    TokenUsage,
)
from obsidian.core.exceptions import ProviderError


class OllamaProvider:
    name = "ollama"

    #: Hosted endpoint, used automatically when a key is supplied.
    CLOUD_URL = "https://ollama.com"
    LOCAL_URL = "http://localhost:11434"

    def __init__(
        self,
        base_url: str = LOCAL_URL,
        model: str | None = None,
        timeout: int = 300,
        api_key: str = "",
    ) -> None:
        self._api_key = (api_key or "").strip()

        # A key means the hosted service. Pointing it at the local default would
        # send a cloud credential to a loopback address that is not listening,
        # so the base URL follows the credential unless one was set explicitly.
        resolved = (base_url or "").strip().rstrip("/")
        if self._api_key and (not resolved or resolved == self.LOCAL_URL):
            resolved = self.CLOUD_URL
        self._base_url = resolved or self.LOCAL_URL
        self.is_cloud = bool(self._api_key)

        # Local models are slow; the default timeout is deliberately generous.
        self._model = model or ("gpt-oss:20b" if self._api_key else "llama3.1")
        headers = {"Authorization": f"Bearer {self._api_key}"} if self._api_key else {}
        self._client = httpx.AsyncClient(timeout=timeout, headers=headers)

    @property
    def default_model(self) -> str:
        return self._model

    def _payload(self, request: CompletionRequest, *, stream: bool) -> dict:
        messages: list[dict[str, str]] = []
        if request.system:
            messages.append({"role": "system", "content": request.system})
        messages.extend(
            {"role": m.role.value, "content": m.content} for m in request.messages
        )
        return {
            "model": request.model or self._model,
            "messages": messages,
            "stream": stream,
            "options": {
                "temperature": request.temperature,
                "num_predict": request.max_tokens,
            },
        }

    async def complete(self, request: CompletionRequest) -> CompletionResponse:
        try:
            response = await self._client.post(
                f"{self._base_url}/api/chat", json=self._payload(request, stream=False)
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise ProviderError(
                f"Ollama returned {exc.response.status_code}.",
                details={"body": exc.response.text[:500]},
            ) from exc
        except httpx.HTTPError as exc:
            raise ProviderError(
                f"Could not reach Ollama at {self._base_url}: {exc}"
            ) from exc

        data = response.json()
        return CompletionResponse(
            content=data.get("message", {}).get("content", ""),
            model=data.get("model", self._model),
            provider=self.name,
            usage=TokenUsage(
                input_tokens=data.get("prompt_eval_count", 0),
                output_tokens=data.get("eval_count", 0),
            ),
            stop_reason=data.get("done_reason"),
            raw=data,
        )

    async def stream(self, request: CompletionRequest) -> AsyncIterator[str]:
        payload = self._payload(request, stream=True)
        async with self._client.stream(
            "POST", f"{self._base_url}/api/chat", json=payload
        ) as response:
            if response.status_code >= 400:
                body = (await response.aread()).decode("utf-8", "replace")
                raise ProviderError(
                    f"Ollama returned {response.status_code}.",
                    details={"body": body[:500]},
                )
            # Ollama streams newline-delimited JSON, not SSE.
            async for line in response.aiter_lines():
                if not line.strip():
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if content := event.get("message", {}).get("content"):
                    yield content
                if event.get("done"):
                    break

    async def health(self) -> ProviderHealth:
        started = time.perf_counter()
        try:
            response = await self._client.get(f"{self._base_url}/api/tags", timeout=10)
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code in (401, 403):
                # Distinguished deliberately: "your key was rejected" and "this
                # endpoint needs a key you have not set" call for different
                # actions, and reporting the first for the second sends the
                # analyst looking for a fault in a key that does not exist.
                detail = (
                    "Ollama rejected the API key. Create a new one at "
                    "ollama.com/settings/keys and run configure.bat."
                    if self.is_cloud
                    else f"{self._base_url} requires an API key, but none is set. "
                    "Run configure.bat and choose Ollama Cloud."
                )
                return ProviderHealth(self.name, False, self._model, detail)
            return ProviderHealth(
                self.name,
                False,
                self._model,
                f"Ollama returned {exc.response.status_code} from {self._base_url}.",
            )
        except httpx.HTTPError as exc:
            where = "ollama.com" if self.is_cloud else self._base_url
            return ProviderHealth(
                self.name, False, self._model, f"Ollama is not reachable at {where}: {exc}"
            )

        latency = round((time.perf_counter() - started) * 1000, 2)
        models = [m.get("name", "") for m in response.json().get("models", [])]

        # The hosted service does not report a local inventory, so an empty list
        # there means "nothing pulled locally", not "model missing". Demanding a
        # match would mark a perfectly working cloud provider unavailable.
        if self.is_cloud and not models:
            return ProviderHealth(
                self.name, True, self._model, "OK (Ollama Cloud)", latency
            )

        # Match on the family name so "llama3.1:8b" satisfies "llama3.1".
        installed = any(name.split(":")[0] == self._model.split(":")[0] for name in models)
        return ProviderHealth(
            self.name,
            installed,
            self._model,
            "OK" if installed else f"Model '{self._model}' is not pulled. "
                                   f"Run: ollama pull {self._model}",
            latency,
        )

    async def close(self) -> None:
        await self._client.aclose()
