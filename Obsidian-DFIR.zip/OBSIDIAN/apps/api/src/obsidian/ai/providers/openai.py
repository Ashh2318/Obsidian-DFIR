"""OpenAI Chat Completions provider.

The base URL is configurable because the Chat Completions shape is a de-facto
standard. Groq, Together, OpenRouter, LM Studio and vLLM all speak it, so one
adapter reaches every OpenAI-compatible gateway — including the free tiers —
rather than needing a new provider class per vendor.
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator

import httpx

from obsidian.ai.base import (
    CompletionRequest,
    CompletionResponse,
    Message,
    MessageRole,
    ProviderHealth,
    TokenUsage,
)
from obsidian.core.exceptions import ConfigurationError, ProviderError

DEFAULT_BASE_URL = "https://api.openai.com/v1"


class OpenAIProvider:
    name = "openai"

    def __init__(
        self,
        api_key: str,
        model: str | None = None,
        timeout: int = 120,
        base_url: str | None = None,
    ) -> None:
        if not api_key:
            raise ConfigurationError(
                "OBSIDIAN_OPENAI_API_KEY is required when "
                "OBSIDIAN_AI_PROVIDER=openai."
            )
        self._model = model or "gpt-4o"
        self._url = f"{(base_url or DEFAULT_BASE_URL).rstrip('/')}/chat/completions"
        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
        )

    @property
    def default_model(self) -> str:
        return self._model

    def _payload(self, request: CompletionRequest, *, stream: bool) -> dict:
        messages: list[dict[str, str]] = []
        if request.system:
            messages.append({"role": "system", "content": request.system})
        messages.extend(
            {"role": m.role.value, "content": m.content} for m in request.messages
        )
        return {
            "model": request.model or self._model,
            "messages": messages,
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
            "stream": stream,
        }

    async def complete(self, request: CompletionRequest) -> CompletionResponse:
        try:
            response = await self._client.post(
                self._url, json=self._payload(request, stream=False)
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise ProviderError(
                f"OpenAI returned {exc.response.status_code}.",
                details={"body": exc.response.text[:500]},
            ) from exc
        except httpx.HTTPError as exc:
            raise ProviderError(f"OpenAI request failed: {exc}") from exc

        data = response.json()
        choice = (data.get("choices") or [{}])[0]
        usage = data.get("usage", {})
        return CompletionResponse(
            content=choice.get("message", {}).get("content", ""),
            model=data.get("model", self._model),
            provider=self.name,
            usage=TokenUsage(
                input_tokens=usage.get("prompt_tokens", 0),
                output_tokens=usage.get("completion_tokens", 0),
            ),
            stop_reason=choice.get("finish_reason"),
            raw=data,
        )

    async def stream(self, request: CompletionRequest) -> AsyncIterator[str]:
        payload = self._payload(request, stream=True)
        async with self._client.stream("POST", self._url, json=payload) as response:
            if response.status_code >= 400:
                body = (await response.aread()).decode("utf-8", "replace")
                raise ProviderError(
                    f"OpenAI returned {response.status_code}.",
                    details={"body": body[:500]},
                )
            async for line in response.aiter_lines():
                if not line.startswith("data:"):
                    continue
                raw = line[5:].strip()
                if not raw or raw == "[DONE]":
                    continue
                try:
                    event = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                delta = (event.get("choices") or [{}])[0].get("delta", {})
                if content := delta.get("content"):
                    yield content

    async def health(self) -> ProviderHealth:
        started = time.perf_counter()
        try:
            await self.complete(
                CompletionRequest(
                    messages=[Message(MessageRole.USER, "ping")], max_tokens=8
                )
            )
        except ProviderError as exc:
            return ProviderHealth(self.name, False, self._model, str(exc))
        latency = (time.perf_counter() - started) * 1000
        return ProviderHealth(self.name, True, self._model, "OK", round(latency, 2))

    async def close(self) -> None:
        await self._client.aclose()
