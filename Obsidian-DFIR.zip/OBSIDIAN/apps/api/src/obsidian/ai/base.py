"""AI provider contract (ADR 0002).

Services depend on :class:`AIProvider` and never on a vendor SDK. Adding a
provider means adding one module and one registry entry.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol, runtime_checkable


class MessageRole(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


@dataclass(slots=True)
class Message:
    role: MessageRole
    content: str


@dataclass(slots=True)
class CompletionRequest:
    """Provider-neutral generation request."""

    messages: list[Message]
    system: str | None = None
    model: str | None = None
    max_tokens: int = 4096
    temperature: float = 0.2
    metadata: dict[str, Any] = field(default_factory=dict)

    def user_text(self) -> str:
        return "\n".join(
            m.content for m in self.messages if m.role is MessageRole.USER
        )


@dataclass(slots=True)
class TokenUsage:
    input_tokens: int = 0
    output_tokens: int = 0

    @property
    def total(self) -> int:
        return self.input_tokens + self.output_tokens


@dataclass(slots=True)
class CompletionResponse:
    content: str
    model: str
    provider: str
    usage: TokenUsage = field(default_factory=TokenUsage)
    stop_reason: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ProviderHealth:
    provider: str
    available: bool
    model: str
    detail: str = ""
    latency_ms: float | None = None


@runtime_checkable
class AIProvider(Protocol):
    """The surface every provider must implement."""

    name: str

    @property
    def default_model(self) -> str: ...

    async def complete(self, request: CompletionRequest) -> CompletionResponse: ...

    def stream(self, request: CompletionRequest) -> AsyncIterator[str]: ...

    async def health(self) -> ProviderHealth: ...

    async def close(self) -> None: ...
