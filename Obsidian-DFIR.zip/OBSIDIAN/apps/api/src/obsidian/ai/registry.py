"""Provider resolution.

The concrete provider is chosen once, at first use, from configuration. Adding a
provider means adding one file and one branch — no service or router changes.
"""

from __future__ import annotations

import re

from obsidian.ai.base import AIProvider
from obsidian.ai.providers.anthropic import AnthropicProvider
from obsidian.ai.providers.mock import MockProvider
from obsidian.ai.providers.ollama import OllamaProvider
from obsidian.ai.providers.openai import OpenAIProvider
from obsidian.core.config import settings
from obsidian.core.exceptions import ConfigurationError
from obsidian.core.logging import get_logger

logger = get_logger(__name__)

_provider: AIProvider | None = None
#: Set when the configured provider could not be built and the mock was
#: substituted. Surfaced through /ai/status so the degradation is visible in the
#: UI rather than silently pretending everything is configured.
_degraded_reason: str | None = None


def _construct(name: str) -> AIProvider:
    model = settings.ai_model or None
    if name == "mock":
        return MockProvider(model)
    if name == "anthropic":
        return AnthropicProvider(
            settings.anthropic_api_key, model, settings.ai_timeout_seconds
        )
    if name == "openai":
        return OpenAIProvider(
            settings.openai_api_key,
            model,
            settings.ai_timeout_seconds,
            base_url=settings.openai_base_url or None,
        )
    if name == "ollama":
        return OllamaProvider(
            settings.ollama_base_url,
            model,
            settings.ai_timeout_seconds,
            api_key=settings.ollama_api_key,
        )
    raise ConfigurationError(f"Unknown AI provider: {name!r}")


def _misconfiguration() -> str | None:
    """Describe a credential that has been put in the wrong setting.

    The model prompt accepts free text, so a pasted API key is stored verbatim
    and then sent as a model name. Every request fails against a model that
    cannot exist, and the status badge reports the provider as configured —
    which is true, and useless. Naming the mistake is the difference between a
    five-minute fix and an afternoon.
    """
    base_url = (settings.openai_base_url or "").strip()
    if base_url and not base_url.lower().startswith(("http://", "https://")):
        return (
            "OBSIDIAN_OPENAI_BASE_URL is not a URL (it looks like an API key was "
            "pasted into it). Put the key in OBSIDIAN_OPENAI_API_KEY and leave the "
            "base URL blank, or set it to an http(s) endpoint."
        )

    model = (settings.ai_model or "").strip()
    if not model or len(model) <= 40:
        return None
    looks_like_model = bool(re.fullmatch(r"[a-z0-9][a-z0-9._/-]*(:[a-z0-9._-]+)?", model))
    if looks_like_model:
        return None
    return (
        "OBSIDIAN_AI_MODEL holds what appears to be an API key rather than a "
        "model name. Run configure.bat to store it correctly."
    )


def _build() -> AIProvider:
    """Build the configured provider, degrading to the mock if it cannot be.

    A missing API key must not stop the application from starting. The AI
    assistant is one feature among many — authentication, cases, evidence,
    analysis and reporting are all unaffected by it — and taking the entire
    service down over an optional credential is a failure of proportion.

    The same reasoning already governs threat-intelligence feeds: a provider
    that cannot be built is skipped with a warning, not raised.
    """
    global _degraded_reason

    try:
        provider = _construct(settings.ai_provider)
    except ConfigurationError as exc:
        _degraded_reason = str(exc.message)
        logger.warning(
            "ai.provider.degraded",
            configured=settings.ai_provider,
            fallback="mock",
            reason=_degraded_reason,
            action="Run configure.bat to supply a key, or select ollama/mock.",
        )
        return MockProvider(None)

    _degraded_reason = _misconfiguration()
    if _degraded_reason:
        logger.warning(
            "ai.provider.misconfigured",
            configured=settings.ai_provider,
            reason=_degraded_reason,
        )
    logger.info(
        "ai.provider.selected", provider=provider.name, model=provider.default_model
    )
    return provider


def get_provider() -> AIProvider:
    """Return the configured provider, constructing it on first use."""
    global _provider
    if _provider is None:
        _provider = _build()
    return _provider


def degraded_reason() -> str | None:
    """Why the mock is in use despite another provider being configured."""
    # Ensure the provider has been resolved, or this reports None before the
    # first request simply because nothing has tried to build it yet.
    get_provider()
    return _degraded_reason


async def close_provider() -> None:
    global _provider, _degraded_reason
    if _provider is not None:
        await _provider.close()
        _provider = None
        _degraded_reason = None
