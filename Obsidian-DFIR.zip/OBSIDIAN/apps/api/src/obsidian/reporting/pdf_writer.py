"""Minimal PDF writer.

Written directly against the PDF specification rather than pulled from a
library. reportlab requires Pillow, which drags in a 7 MB binary wheel;
WeasyPrint needs cairo and pango system libraries. Neither is acceptable for an
application that must install cleanly in an air-gapped environment, and reports
here are text, tables and rules — none of the raster or CSS machinery those
libraries exist to provide.

Only the base-14 fonts are used, so nothing has to be embedded.

Reference: PDF 1.7 (ISO 32000-1), sections 7.5 (file structure) and 9 (text).
"""

from __future__ import annotations

from dataclasses import dataclass, field

# Widths for Helvetica, in 1/1000 em, indexed by codepoint 32..126. Needed to
# wrap text: without real metrics, lines either overflow the margin or stop far
# short of it.
_HELVETICA_WIDTHS = (
    278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
    556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
    1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
    667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
    333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556,
    556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,
)
_BOLD_EXTRA = 1.05  # Helvetica-Bold runs marginally wider; close enough for wrapping.

PAGE_WIDTH = 595.28   # A4 in points
PAGE_HEIGHT = 841.89
MARGIN = 56.7         # 20 mm


def text_width(text: str, size: float, bold: bool = False) -> float:
    """Width of ``text`` in points at ``size``."""
    total = 0
    for char in text:
        code = ord(char)
        index = code - 32
        width = _HELVETICA_WIDTHS[index] if 0 <= index < len(_HELVETICA_WIDTHS) else 556
        total += width
    scaled = total * size / 1000.0
    return scaled * _BOLD_EXTRA if bold else scaled


def wrap_text(text: str, size: float, max_width: float, bold: bool = False) -> list[str]:
    """Greedy word wrap using real font metrics."""
    if not text:
        return [""]

    lines: list[str] = []
    for paragraph in text.split("\n"):
        words = paragraph.split()
        if not words:
            lines.append("")
            continue
        current = words[0]
        for word in words[1:]:
            candidate = f"{current} {word}"
            if text_width(candidate, size, bold) <= max_width:
                current = candidate
            else:
                lines.append(current)
                current = word
        lines.append(current)
    return lines


def escape_pdf_text(text: str) -> str:
    """Escape a string for a PDF literal, mapping what WinAnsi cannot encode.

    Only the backslash and the two parentheses are special inside a PDF
    string literal (ISO 32000-1 section 7.3.4.2). Everything printable is
    passed through; the rest is either a WinAnsi octal escape or a sensible
    ASCII substitution, because a glyph that silently becomes "?" in a
    forensic report is a defect an analyst will notice before we do.
    """
    specials = {'\\', "(", ")"}

    # Characters WinAnsiEncoding does have, addressed by octal code. These
    # are the ones that actually appear in reports: bullets in lists and
    # typographic punctuation pasted in from tickets and email.
    winansi = {
        "\u2022": r"\225",  # bullet
        "\u2018": r"\221",
        "\u2019": r"\222",
        "\u201c": r"\223",
        "\u201d": r"\224",
        "\u2013": r"\226",  # en dash
        "\u2014": r"\227",  # em dash
        "\u2026": r"\205",  # ellipsis
        "\u2020": r"\206",
        "\u00b0": r"\260",
        "\u00a3": r"\243",
        "\u20ac": r"\200",
    }

    out: list[str] = []
    for char in text:
        if char in specials:
            out.append('\\' + char)
        elif 32 <= ord(char) <= 126:
            out.append(char)
        elif char in winansi:
            out.append(winansi[char])
        elif char == "\u00a0":
            out.append(" ")
        elif 160 <= ord(char) <= 255:
            # Latin-1 agrees with WinAnsi over this range.
            out.append(f"\\{ord(char):03o}")
        else:
            out.append("?")
    return "".join(out)


@dataclass
class _Page:
    operations: list[str] = field(default_factory=list)


class PDFCanvas:
    """Accumulates drawing operations and serialises a PDF document."""

    def __init__(self, title: str = "OBSIDIAN Report") -> None:
        self._title = title
        self._pages: list[_Page] = []
        self._page: _Page | None = None
        self._patterns: list[tuple[str, str]] = []
        self._y = 0.0
        self.new_page()

    def _emit(self, *operations: str) -> None:
        """Append raw content-stream operators to the current page."""
        assert self._page is not None
        self._page.operations.extend(operations)

    # ── Page management ──────────────────────────────────────────────────────
    def new_page(self) -> None:
        self._page = _Page()
        self._pages.append(self._page)
        self._y = PAGE_HEIGHT - MARGIN

    @property
    def y(self) -> float:
        return self._y

    @property
    def page_count(self) -> int:
        return len(self._pages)

    def content_width(self) -> float:
        return PAGE_WIDTH - 2 * MARGIN

    def ensure_space(self, needed: float) -> None:
        """Start a new page when ``needed`` points will not fit."""
        if self._y - needed < MARGIN + 28:  # leave room for the footer
            self.new_page()

    # ── Brand mark ───────────────────────────────────────────────────────────
    def _gradient(
        self,
        box: tuple[float, float, float, float],
        start: tuple[float, float, float],
        end: tuple[float, float, float],
    ) -> str:
        """Register an axial shading pattern and return its resource name.

        Pattern space defaults to the page's own coordinate system, so the
        gradient axis is given in absolute points and no pattern matrix is
        needed. Registering per call keeps the gradient tied to the box it was
        measured against instead of a position baked into a shared resource.
        """
        x0, y0, x1, y1 = box
        name = f"P{len(self._patterns)}"
        c0 = " ".join(f"{value:.4f}" for value in start)
        c1 = " ".join(f"{value:.4f}" for value in end)
        self._patterns.append(
            (
                name,
                f"<< /Type /Pattern /PatternType 2 /Shading << /ShadingType 2 "
                f"/ColorSpace /DeviceRGB /Coords [{x0:.2f} {y0:.2f} {x1:.2f} {y1:.2f}] "
                f"/Extend [true true] /Function << /FunctionType 2 /Domain [0 1] "
                f"/C0 [{c0}] /C1 [{c1}] /N 1 >> >> >>",
            )
        )
        return name

    def logo(self, x: float, y: float, size: float = 26.0) -> None:
        """Draw the OBSIDIAN faceted-crystal mark at ``(x, y)``.

        The same geometry as the web mark, converted from its 32-unit SVG
        viewBox to PDF user space — which means it is real vector art at any
        zoom, with no image XObject and therefore no imaging dependency. ``y``
        is the baseline of the mark box; the crystal is drawn upward from it.
        """
        s = size / 32.0

        def pt(sx: float, sy: float) -> str:
            # SVG's y axis points down, the PDF's points up.
            return f"{x + sx * s:.2f} {y + (32 - sy) * s:.2f}"

        outline = (
            f"{pt(16, 2)} m {pt(4, 11)} l {pt(8, 28)} l "
            f"{pt(24, 28)} l {pt(28, 11)} l h"
        )
        box = (x, y + size, x + size, y)  # top-left to bottom-right, as the SVG
        # An 18% tint of the brand gradient composited over white, computed
        # rather than requested: a real alpha fill needs a transparency group,
        # and over a white page the arithmetic is exact.
        fill = self._gradient(box, (0.8687, 0.9802, 0.9946), (0.9478, 0.8866, 0.9910))
        stroke = self._gradient(box, (0.2704, 0.8881, 0.9696), (0.7082, 0.3710, 0.9490))

        cx, cy, r = x + 16 * s, y + (32 - 15) * s, 2.5 * s
        k = 0.5523 * r  # cubic control offset for a circular quadrant

        self._emit(
            "q",
            f"/Pattern cs /{fill} scn {outline} f",
            f"/Pattern CS /{stroke} SCN {size / 21:.2f} w 1 j 1 J {outline} S",
            # Facet lines: lighter, so the crystal reads as faceted rather than
            # as an outlined pentagon.
            f"{size / 32:.2f} w 0.6 0.78 0.92 RG "
            f"{pt(16, 2)} m {pt(16, 28)} l S {pt(4, 11)} m {pt(28, 11)} l S",
            f"0.2704 0.8881 0.9696 rg "
            f"{cx + r:.2f} {cy:.2f} m "
            f"{cx + r:.2f} {cy + k:.2f} {cx + k:.2f} {cy + r:.2f} {cx:.2f} {cy + r:.2f} c "
            f"{cx - k:.2f} {cy + r:.2f} {cx - r:.2f} {cy + k:.2f} {cx - r:.2f} {cy:.2f} c "
            f"{cx - r:.2f} {cy - k:.2f} {cx - k:.2f} {cy - r:.2f} {cx:.2f} {cy - r:.2f} c "
            f"{cx + k:.2f} {cy - r:.2f} {cx + r:.2f} {cy - k:.2f} {cx + r:.2f} {cy:.2f} c f",
            "Q",
        )

    def masthead(self, subtitle: str = "Cybersecurity Investigation Platform") -> None:
        """Brand header: the mark, the wordmark, and a rule beneath both."""
        top = self._y
        self.logo(MARGIN, top - 26)
        text_x = MARGIN + 36
        self._emit(
            f"BT /F2 15 Tf 0.09 0.10 0.16 rg 1 0 0 1 {text_x} {top - 10} Tm "
            f"[({escape_pdf_text('OBSIDIAN')}) 120 ] TJ ET",
            f"BT /F1 7.5 Tf 0.42 0.44 0.5 rg 1 0 0 1 {text_x} {top - 22} Tm "
            f"({escape_pdf_text(subtitle)}) Tj ET",
        )
        self._y = top - 34
        self.rule(colour=(0.03, 0.57, 0.70))

    # ── Drawing ──────────────────────────────────────────────────────────────
    def draw_text(
        self,
        text: str,
        *,
        size: float = 10,
        bold: bool = False,
        mono: bool = False,
        indent: float = 0,
        colour: tuple[float, float, float] = (0.1, 0.1, 0.12),
    ) -> None:
        assert self._page is not None
        font = "F3" if mono else ("F2" if bold else "F1")
        red, green, blue = colour
        self._page.operations.append(
            f"BT /{font} {size} Tf {red} {green} {blue} rg "
            f"1 0 0 1 {MARGIN + indent} {self._y} Tm "
            f"({escape_pdf_text(text)}) Tj ET"
        )

    def paragraph(
        self,
        text: str,
        *,
        size: float = 10,
        bold: bool = False,
        mono: bool = False,
        indent: float = 0,
        leading: float | None = None,
        colour: tuple[float, float, float] = (0.1, 0.1, 0.12),
        space_after: float = 6,
    ) -> None:
        line_height = leading or size * 1.45
        for line in wrap_text(text, size, self.content_width() - indent, bold):
            self.ensure_space(line_height)
            self.draw_text(line, size=size, bold=bold, mono=mono, indent=indent, colour=colour)
            self._y -= line_height
        self._y -= space_after

    def heading(self, text: str, *, level: int = 1) -> None:
        size = {1: 17.0, 2: 13.0, 3: 11.0}.get(level, 11.0)
        self.ensure_space(size * 2.4)
        self._y -= size * 0.5
        self.paragraph(text, size=size, bold=True, space_after=size * 0.35)
        if level == 1:
            self.rule()

    def rule(self, *, colour: tuple[float, float, float] = (0.8, 0.8, 0.84)) -> None:
        assert self._page is not None
        self.ensure_space(10)
        red, green, blue = colour
        self._page.operations.append(
            f"{red} {green} {blue} RG 0.6 w "
            f"{MARGIN} {self._y} m {PAGE_WIDTH - MARGIN} {self._y} l S"
        )
        self._y -= 10

    def spacer(self, height: float = 8) -> None:
        self._y -= height

    def key_value(self, key: str, value: str) -> None:
        """Two-column label/value row, used for case metadata."""
        self.ensure_space(15)
        self.draw_text(key, size=9, colour=(0.42, 0.44, 0.5))
        assert self._page is not None
        self._page.operations.append(
            f"BT /F1 9.5 Tf 0.1 0.1 0.12 rg "
            f"1 0 0 1 {MARGIN + 150} {self._y} Tm ({escape_pdf_text(value)}) Tj ET"
        )
        self._y -= 15

    def table(
        self,
        headers: list[str],
        rows: list[list[str]],
        *,
        widths: list[float] | None = None,
        size: float = 8.5,
    ) -> None:
        """Fixed-column table. Cell text is truncated to its column width."""
        assert self._page is not None
        available = self.content_width()
        if widths is None:
            widths = [available / len(headers)] * len(headers)
        else:
            total = sum(widths)
            widths = [w / total * available for w in widths]

        row_height = size * 2.0

        def draw_row(cells: list[str], bold: bool, background: bool) -> None:
            assert self._page is not None
            self.ensure_space(row_height + 4)
            if background:
                self._page.operations.append(
                    f"0.93 0.94 0.96 rg {MARGIN} {self._y - row_height + 10} "
                    f"{available} {row_height} re f"
                )
            offset = 0.0
            for cell, width in zip(cells, widths):
                text = cell
                while text and text_width(text, size, bold) > width - 8:
                    text = text[:-1]
                if text != cell and len(text) > 1:
                    text = text[:-1] + "…"
                self._page.operations.append(
                    f"BT /{'F2' if bold else 'F1'} {size} Tf 0.1 0.1 0.12 rg "
                    f"1 0 0 1 {MARGIN + offset + 3} {self._y} Tm "
                    f"({escape_pdf_text(text)}) Tj ET"
                )
                offset += width
            self._y -= row_height

        draw_row(headers, True, True)
        for row in rows:
            draw_row([str(cell) for cell in row], False, False)
        self._y -= 6

    # ── Serialisation ────────────────────────────────────────────────────────
    def _footer_operations(self, index: int) -> list[str]:
        label = f"Page {index + 1} of {len(self._pages)}"
        width = text_width(label, 8)
        return [
            f"0.55 0.56 0.6 rg 0.4 w {MARGIN} {MARGIN - 12} m "
            f"{PAGE_WIDTH - MARGIN} {MARGIN - 12} l S",
            f"BT /F1 8 Tf 0.45 0.46 0.5 rg "
            f"1 0 0 1 {PAGE_WIDTH - MARGIN - width} {MARGIN - 24} Tm "
            f"({escape_pdf_text(label)}) Tj ET",
            f"BT /F1 8 Tf 0.45 0.46 0.5 rg 1 0 0 1 {MARGIN} {MARGIN - 24} Tm "
            f"({escape_pdf_text('OBSIDIAN - ' + self._title)}) Tj ET",
        ]

    def build(self) -> bytes:
        """Serialise to PDF bytes with a correct cross-reference table."""
        objects: list[bytes] = []

        def add(body: str | bytes) -> int:
            objects.append(body.encode("latin-1") if isinstance(body, str) else body)
            return len(objects)  # object numbers are 1-based

        font_regular = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica "
                           "/Encoding /WinAnsiEncoding >>")
        font_bold = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold "
                        "/Encoding /WinAnsiEncoding >>")
        font_mono = add("<< /Type /Font /Subtype /Type1 /BaseFont /Courier "
                        "/Encoding /WinAnsiEncoding >>")

        # Shading patterns are shared by every page: the resource dictionary is
        # identical across pages, and a gradient is a document-level asset.
        pattern_refs: list[str] = []
        for name, definition in self._patterns:
            pattern_refs.append(f"/{name} {add(definition)} 0 R")
        pattern_resource = (
            f"/Pattern << {' '.join(pattern_refs)} >> " if pattern_refs else ""
        )

        # The pages object number is reserved now and written last, because each
        # page has to name its parent before that parent exists.
        pages_number = len(objects) + 1
        objects.append(b"")  # placeholder

        page_numbers: list[int] = []
        for index, page in enumerate(self._pages):
            stream = "\n".join(page.operations + self._footer_operations(index))
            data = stream.encode("latin-1", errors="replace")
            content_number = add(
                b"<< /Length " + str(len(data)).encode() + b" >>\nstream\n" + data + b"\nendstream"
            )
            page_numbers.append(
                add(
                    f"<< /Type /Page /Parent {pages_number} 0 R "
                    f"/MediaBox [0 0 {PAGE_WIDTH} {PAGE_HEIGHT}] "
                    f"/Resources << /Font << /F1 {font_regular} 0 R /F2 {font_bold} 0 R "
                    f"/F3 {font_mono} 0 R >> {pattern_resource}>> "
                    f"/Contents {content_number} 0 R >>"
                )
            )

        kids = " ".join(f"{n} 0 R" for n in page_numbers)
        objects[pages_number - 1] = (
            f"<< /Type /Pages /Kids [{kids}] /Count {len(page_numbers)} >>"
        ).encode("latin-1")

        info_number = add(
            f"<< /Title ({escape_pdf_text(self._title)}) /Producer (OBSIDIAN) "
            f"/Creator (OBSIDIAN Reporting Engine) >>"
        )
        catalog_number = add(f"<< /Type /Catalog /Pages {pages_number} 0 R >>")

        out = bytearray(b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n")
        offsets: list[int] = []
        for number, body in enumerate(objects, start=1):
            offsets.append(len(out))
            out += f"{number} 0 obj\n".encode("latin-1") + body + b"\nendobj\n"

        xref_offset = len(out)
        out += f"xref\n0 {len(objects) + 1}\n".encode("latin-1")
        out += b"0000000000 65535 f \n"
        for offset in offsets:
            out += f"{offset:010d} 00000 n \n".encode("latin-1")
        out += (
            f"trailer\n<< /Size {len(objects) + 1} /Root {catalog_number} 0 R "
            f"/Info {info_number} 0 R >>\nstartxref\n{xref_offset}\n%%EOF\n"
        ).encode("latin-1")
        return bytes(out)
