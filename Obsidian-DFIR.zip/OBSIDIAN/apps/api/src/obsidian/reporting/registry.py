"""Render a composed document to the requested format."""

from __future__ import annotations

from obsidian.reporting.document import ReportDocument, ReportFormat
from obsidian.reporting.renderers.html import render_html
from obsidian.reporting.renderers.markdown import render_markdown
from obsidian.reporting.renderers.pdf import render_pdf

MEDIA_TYPES = {
    ReportFormat.MARKDOWN: "text/markdown; charset=utf-8",
    ReportFormat.HTML: "text/html; charset=utf-8",
    ReportFormat.PDF: "application/pdf",
}

EXTENSIONS = {
    ReportFormat.MARKDOWN: "md",
    ReportFormat.HTML: "html",
    ReportFormat.PDF: "pdf",
}


def render(
    document: ReportDocument,
    fmt: ReportFormat,
    *,
    signature: str | None = None,
) -> bytes:
    """Render to bytes. Text formats are encoded UTF-8."""
    if fmt is ReportFormat.MARKDOWN:
        return render_markdown(document).encode("utf-8")
    if fmt is ReportFormat.HTML:
        return render_html(document, signature=signature).encode("utf-8")
    if fmt is ReportFormat.PDF:
        return render_pdf(document, signature=signature)
    raise ValueError(f"Unsupported report format: {fmt}")
