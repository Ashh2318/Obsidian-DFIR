"""Structured report document.

A report is composed once into these blocks, then rendered to Markdown, HTML or
PDF. Keeping composition separate from rendering means the *content* of a
report — what an executive sees versus what a technical reader sees — is defined
in exactly one place. Three renderers each deciding what to include is how three
formats end up disagreeing about the same investigation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class ReportFormat(str, Enum):
    MARKDOWN = "markdown"
    HTML = "html"
    PDF = "pdf"


class ReportProfile(str, Enum):
    """Audience. These differ in content, not only in styling."""

    EXECUTIVE = "executive"
    TECHNICAL = "technical"


class BlockType(str, Enum):
    HEADING = "heading"
    PARAGRAPH = "paragraph"
    KEY_VALUES = "key_values"
    TABLE = "table"
    BULLETS = "bullets"
    CALLOUT = "callout"
    CODE = "code"
    DIVIDER = "divider"


@dataclass(slots=True)
class Block:
    type: BlockType
    text: str = ""
    level: int = 2
    items: list[str] = field(default_factory=list)
    pairs: list[tuple[str, str]] = field(default_factory=list)
    headers: list[str] = field(default_factory=list)
    rows: list[list[str]] = field(default_factory=list)
    widths: list[float] | None = None
    tone: str = "info"


@dataclass(slots=True)
class ReportDocument:
    title: str
    subtitle: str
    profile: ReportProfile
    generated_at: datetime
    generated_by: str
    case_reference: str
    blocks: list[Block] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    # ── Fluent builders ──────────────────────────────────────────────────────
    def heading(self, text: str, level: int = 2) -> "ReportDocument":
        self.blocks.append(Block(BlockType.HEADING, text=text, level=level))
        return self

    def paragraph(self, text: str) -> "ReportDocument":
        self.blocks.append(Block(BlockType.PARAGRAPH, text=text))
        return self

    def key_values(self, pairs: list[tuple[str, str]]) -> "ReportDocument":
        self.blocks.append(Block(BlockType.KEY_VALUES, pairs=pairs))
        return self

    def table(
        self, headers: list[str], rows: list[list[str]], widths: list[float] | None = None
    ) -> "ReportDocument":
        self.blocks.append(
            Block(BlockType.TABLE, headers=headers, rows=rows, widths=widths)
        )
        return self

    def bullets(self, items: list[str]) -> "ReportDocument":
        self.blocks.append(Block(BlockType.BULLETS, items=items))
        return self

    def callout(self, text: str, tone: str = "info") -> "ReportDocument":
        self.blocks.append(Block(BlockType.CALLOUT, text=text, tone=tone))
        return self

    def code(self, text: str) -> "ReportDocument":
        self.blocks.append(Block(BlockType.CODE, text=text))
        return self

    def divider(self) -> "ReportDocument":
        self.blocks.append(Block(BlockType.DIVIDER))
        return self
