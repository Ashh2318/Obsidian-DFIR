"""PDF renderer, built on the dependency-free writer."""

from __future__ import annotations

from obsidian.reporting.document import BlockType, ReportDocument
from obsidian.reporting.pdf_writer import PDFCanvas

TONE_COLOURS = {
    "info": (0.03, 0.57, 0.70),
    "warning": (0.85, 0.47, 0.02),
    "critical": (0.86, 0.15, 0.15),
}


def render_pdf(document: ReportDocument, *, signature: str | None = None) -> bytes:
    canvas = PDFCanvas(title=f"{document.title} - {document.case_reference}")

    # Cover block, led by the brand mark drawn as vector art.
    canvas.masthead()
    canvas.spacer(18)
    canvas.paragraph(document.title, size=20, bold=True, space_after=2)
    canvas.paragraph(document.subtitle, size=12, colour=(0.29, 0.33, 0.39), space_after=10)
    canvas.rule(colour=(0.03, 0.57, 0.70))
    canvas.key_value("Case reference", document.case_reference)
    canvas.key_value("Report profile", document.profile.value.title())
    canvas.key_value("Generated", document.generated_at.strftime("%d %b %Y %H:%M UTC"))
    canvas.key_value("Author", document.generated_by)
    canvas.spacer(10)

    for block in document.blocks:
        if block.type is BlockType.HEADING:
            canvas.heading(block.text, level=block.level)
        elif block.type is BlockType.PARAGRAPH:
            canvas.paragraph(block.text, size=9.5)
        elif block.type is BlockType.KEY_VALUES:
            for key, value in block.pairs:
                canvas.key_value(key, value)
            canvas.spacer(6)
        elif block.type is BlockType.TABLE:
            canvas.table(block.headers, block.rows, widths=block.widths)
        elif block.type is BlockType.BULLETS:
            for item in block.items:
                # The bullet is drawn separately so wrapped continuation lines
                # align with the text, not under the marker.
                canvas.ensure_space(14)
                canvas.draw_text("\u2022", size=9.5, colour=(0.03, 0.57, 0.70))
                canvas.paragraph(item, size=9.5, indent=14, space_after=2)
            canvas.spacer(6)
        elif block.type is BlockType.CALLOUT:
            colour = TONE_COLOURS.get(block.tone, TONE_COLOURS["info"])
            canvas.paragraph(block.text, size=9.5, bold=True, colour=colour)
        elif block.type is BlockType.CODE:
            canvas.paragraph(block.text, size=8.5, mono=True)
        elif block.type is BlockType.DIVIDER:
            canvas.rule()

    if signature:
        canvas.spacer(14)
        canvas.rule()
        canvas.paragraph(
            "Integrity signature (HMAC-SHA256)",
            size=8,
            bold=True,
            colour=(0.42, 0.44, 0.5),
            space_after=2,
        )
        canvas.paragraph(signature, size=7.5, mono=True, colour=(0.42, 0.44, 0.5), space_after=4)
        canvas.paragraph(
            "Attests that this report was produced by this OBSIDIAN instance and "
            "has not been altered. Verify via POST /api/v1/reports/{id}/verify.",
            size=7.5,
            colour=(0.42, 0.44, 0.5),
        )

    return canvas.build()
