"""Markdown renderer."""

from __future__ import annotations

from obsidian.reporting.document import BlockType, ReportDocument


def render_markdown(document: ReportDocument) -> str:
    lines: list[str] = [
        f"# {document.title}",
        "",
        f"**{document.subtitle}**",
        "",
        f"| | |",
        f"|---|---|",
        f"| Case | `{document.case_reference}` |",
        f"| Profile | {document.profile.value.title()} |",
        f"| Generated | {document.generated_at.strftime('%d %b %Y %H:%M UTC')} |",
        f"| Author | {document.generated_by} |",
        "",
        "---",
        "",
    ]

    for block in document.blocks:
        if block.type is BlockType.HEADING:
            lines += ["", "#" * min(6, block.level + 1) + f" {block.text}", ""]
        elif block.type is BlockType.PARAGRAPH:
            lines += [block.text, ""]
        elif block.type is BlockType.KEY_VALUES:
            lines += ["| Field | Value |", "|---|---|"]
            lines += [f"| {k} | {v} |" for k, v in block.pairs]
            lines.append("")
        elif block.type is BlockType.TABLE:
            lines.append("| " + " | ".join(block.headers) + " |")
            lines.append("|" + "|".join(["---"] * len(block.headers)) + "|")
            for row in block.rows:
                # Escape pipes, or a value containing one silently breaks the
                # table for every row after it.
                lines.append("| " + " | ".join(str(c).replace("|", "\\|") for c in row) + " |")
            lines.append("")
        elif block.type is BlockType.BULLETS:
            lines += [f"- {item}" for item in block.items] + [""]
        elif block.type is BlockType.CALLOUT:
            lines += [f"> **{block.tone.title()}** — {block.text}", ""]
        elif block.type is BlockType.CODE:
            lines += ["```", block.text, "```", ""]
        elif block.type is BlockType.DIVIDER:
            lines += ["---", ""]

    return "\n".join(lines).rstrip() + "\n"
