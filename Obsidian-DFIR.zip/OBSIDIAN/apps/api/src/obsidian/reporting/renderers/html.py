"""HTML renderer.

Self-contained: styles are inlined so a saved report opens correctly with no
network access and no adjacent asset directory. A report that only renders while
the application is running is not an archival artefact.
"""

from __future__ import annotations

from html import escape

from obsidian.reporting.document import BlockType, ReportDocument

_STYLES = """
:root { color-scheme: light; }
* { box-sizing: border-box; }
body {
  margin: 0; padding: 48px 56px; background: #fff; color: #14161c;
  font: 14px/1.6 ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
}
.wrap { max-width: 940px; margin: 0 auto; }
header { border-bottom: 3px solid #0891b2; padding-bottom: 20px; margin-bottom: 28px; }
.brand { font: 600 11px/1 ui-monospace, monospace; letter-spacing: .22em; color: #0891b2; }
h1 { font-size: 26px; margin: 10px 0 4px; letter-spacing: -.01em; }
.subtitle { color: #4b5563; font-size: 15px; margin: 0; }
.meta { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 10px; margin-top: 18px; }
.meta div { background: #f6f8fa; border: 1px solid #e5e9ef; border-radius: 6px; padding: 8px 10px; }
.meta dt { font-size: 10px; text-transform: uppercase; letter-spacing: .1em; color: #6b7280; }
.meta dd { margin: 3px 0 0; font-size: 13px; font-weight: 500; }
h2 { font-size: 18px; margin: 32px 0 10px; padding-bottom: 6px; border-bottom: 1px solid #e5e9ef; }
h3 { font-size: 15px; margin: 22px 0 6px; }
h4 { font-size: 13px; margin: 18px 0 6px; color: #374151; }
p { margin: 0 0 12px; }
table { width: 100%; border-collapse: collapse; margin: 12px 0 18px; font-size: 12.5px; }
th { text-align: left; background: #f6f8fa; font-weight: 600; font-size: 11px;
     text-transform: uppercase; letter-spacing: .06em; color: #4b5563; }
th, td { border: 1px solid #e5e9ef; padding: 7px 9px; vertical-align: top; word-break: break-word; }
tbody tr:nth-child(even) { background: #fbfcfd; }
ul { margin: 0 0 14px; padding-left: 20px; }
li { margin-bottom: 5px; }
.callout { border-left: 4px solid; border-radius: 4px; padding: 11px 14px; margin: 14px 0; font-size: 13px; }
.callout.info { border-color: #0891b2; background: #ecfeff; }
.callout.warning { border-color: #d97706; background: #fffbeb; }
.callout.critical { border-color: #dc2626; background: #fef2f2; }
code, pre { font-family: ui-monospace, 'SF Mono', Menlo, monospace; font-size: 12px; }
pre { background: #f6f8fa; border: 1px solid #e5e9ef; border-radius: 6px; padding: 12px; overflow-x: auto; }
footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #e5e9ef;
         font-size: 11px; color: #6b7280; }
.sig { font-family: ui-monospace, monospace; word-break: break-all; }
@media print {
  body { padding: 0; }
  h2, h3 { break-after: avoid; }
  table, .callout { break-inside: avoid; }
  @page { size: A4; margin: 18mm; }
}
"""


def render_html(document: ReportDocument, *, signature: str | None = None) -> str:
    parts: list[str] = []

    for block in document.blocks:
        if block.type is BlockType.HEADING:
            tag = f"h{min(4, block.level + 1)}"
            parts.append(f"<{tag}>{escape(block.text)}</{tag}>")
        elif block.type is BlockType.PARAGRAPH:
            parts.append(f"<p>{escape(block.text)}</p>")
        elif block.type is BlockType.KEY_VALUES:
            rows = "".join(
                f"<tr><th>{escape(k)}</th><td>{escape(v)}</td></tr>" for k, v in block.pairs
            )
            parts.append(f"<table><tbody>{rows}</tbody></table>")
        elif block.type is BlockType.TABLE:
            head = "".join(f"<th>{escape(h)}</th>" for h in block.headers)
            body = "".join(
                "<tr>" + "".join(f"<td>{escape(str(c))}</td>" for c in row) + "</tr>"
                for row in block.rows
            )
            parts.append(f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>")
        elif block.type is BlockType.BULLETS:
            items = "".join(f"<li>{escape(i)}</li>" for i in block.items)
            parts.append(f"<ul>{items}</ul>")
        elif block.type is BlockType.CALLOUT:
            parts.append(f'<div class="callout {escape(block.tone)}">{escape(block.text)}</div>')
        elif block.type is BlockType.CODE:
            parts.append(f"<pre>{escape(block.text)}</pre>")
        elif block.type is BlockType.DIVIDER:
            parts.append("<hr>")

    signature_html = (
        f'<p>Integrity signature (HMAC-SHA256): <span class="sig">{escape(signature)}</span><br>'
        "Verify at <code>POST /api/v1/reports/{id}/verify</code>. This attests that the "
        "report was produced by this OBSIDIAN instance and has not been altered since.</p>"
        if signature
        else ""
    )

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{escape(document.title)} — {escape(document.case_reference)}</title>
<style>{_STYLES}</style>
</head>
<body>
<div class="wrap">
<header>
  <div class="brand">OBSIDIAN</div>
  <h1>{escape(document.title)}</h1>
  <p class="subtitle">{escape(document.subtitle)}</p>
  <dl class="meta">
    <div><dt>Case</dt><dd>{escape(document.case_reference)}</dd></div>
    <div><dt>Profile</dt><dd>{escape(document.profile.value.title())}</dd></div>
    <div><dt>Generated</dt><dd>{document.generated_at.strftime('%d %b %Y %H:%M UTC')}</dd></div>
    <div><dt>Author</dt><dd>{escape(document.generated_by)}</dd></div>
  </dl>
</header>
{''.join(parts)}
<footer>
  <p>Generated by OBSIDIAN — Observe. Analyze. Defend.</p>
  {signature_html}
</footer>
</div>
</body>
</html>
"""
