"""Report composition.

Turns an investigation into a :class:`ReportDocument`. The two profiles differ
in *content*, not styling: an executive report that is the technical report with
a different cover page is not an executive report, it is a technical report
nobody senior will read.
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.core.exceptions import NotFoundError
from obsidian.core.security import utcnow
from obsidian.db.models.case import Case
from obsidian.db.models.enrichment import IOCEnrichment
from obsidian.db.models.evidence import Evidence
from obsidian.domain.enums import Severity
from obsidian.reporting.document import ReportDocument, ReportProfile
from obsidian.repositories.case_repository import CaseRepository
from obsidian.repositories.ioc_repository import IOCRepository

SEVERITY_ORDER = [
    Severity.CRITICAL,
    Severity.HIGH,
    Severity.MEDIUM,
    Severity.LOW,
    Severity.INFO,
]


def _risk_band(score: int) -> tuple[str, str]:
    if score >= 75:
        return "Critical", "critical"
    if score >= 50:
        return "High", "warning"
    if score >= 25:
        return "Moderate", "info"
    if score > 0:
        return "Low", "info"
    return "None assessed", "info"


class ReportComposer:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._cases = CaseRepository(session)
        self._iocs = IOCRepository(session)

    async def compose(
        self, *, case_id: str, profile: ReportProfile, author: str
    ) -> ReportDocument:
        case = await self._cases.get(case_id)
        if case is None:
            raise NotFoundError("No case exists with that identifier.")

        artefacts = (
            await self._session.execute(
                select(Evidence).where(Evidence.case_id == case_id).order_by(Evidence.created_at)
            )
        ).scalars().all()

        iocs, ioc_total = await self._iocs.search(limit=200, offset=0, case_id=case_id)

        enrichments: dict[str, IOCEnrichment] = {}
        if iocs:
            rows = (
                await self._session.execute(
                    select(IOCEnrichment).where(
                        IOCEnrichment.value.in_([i.value for i in iocs])
                    )
                )
            ).scalars().all()
            enrichments = {row.value: row for row in rows}

        findings: list[dict] = []
        for artefact in artefacts:
            for finding in (artefact.analysis_summary or {}).get("findings", []):
                findings.append({**finding, "artefact": artefact.original_filename})
        findings.sort(
            key=lambda f: (
                Severity(f.get("severity", "info")).rank,
                f.get("confidence", 0),
            ),
            reverse=True,
        )

        peak_risk = max(
            (int((a.analysis_summary or {}).get("risk_score", 0)) for a in artefacts),
            default=0,
        )

        document = ReportDocument(
            title=(
                "Incident Summary" if profile is ReportProfile.EXECUTIVE
                else "Technical Investigation Report"
            ),
            subtitle=case.title,
            profile=profile,
            generated_at=utcnow(),
            generated_by=author,
            case_reference=case.reference,
            metadata={
                "case_id": case.id,
                "evidence_count": len(artefacts),
                "finding_count": len(findings),
                "ioc_count": ioc_total,
                "risk_score": peak_risk,
            },
        )

        if profile is ReportProfile.EXECUTIVE:
            self._compose_executive(document, case, artefacts, findings, iocs, enrichments, peak_risk)
        else:
            self._compose_technical(document, case, artefacts, findings, iocs, enrichments, peak_risk)

        return document

    # ── Executive ────────────────────────────────────────────────────────────
    def _compose_executive(
        self, doc, case, artefacts, findings, iocs, enrichments, peak_risk
    ) -> None:
        band, tone = _risk_band(peak_risk)
        critical = [f for f in findings if f.get("severity") in ("critical", "high")]

        doc.heading("Assessment", 1)
        doc.callout(
            f"Assessed risk: {band} ({peak_risk}/100). "
            f"{len(critical)} finding(s) of high or critical severity across "
            f"{len(artefacts)} artefact(s).",
            tone=tone,
        )

        # Stated in business terms. An executive summary that opens with packet
        # counts has already lost its audience.
        if critical:
            lead = critical[0]
            doc.paragraph(
                f"The investigation identified activity consistent with "
                f"{lead.get('title', 'a security concern').lower()}. "
                f"This was assessed at {lead.get('confidence', 0)}% confidence "
                f"from analysis of collected evidence."
            )
        elif findings:
            doc.paragraph(
                "Analysis completed. No high or critical severity activity was "
                "identified, though lower-severity observations were recorded and "
                "are detailed in the technical report."
            )
        else:
            doc.paragraph(
                "No detections were raised by automated analysis of the evidence "
                "collected so far. This is not a statement that no compromise "
                "occurred — only that the evidence examined does not show one."
            )

        doc.heading("Case status", 2)
        doc.key_values([
            ("Reference", case.reference),
            ("Status", case.status.value.replace("_", " ").title()),
            ("Severity", case.severity.value.title()),
            ("Opened", (case.opened_at or case.created_at).strftime("%d %b %Y %H:%M UTC")),
            ("Closed", case.closed_at.strftime("%d %b %Y %H:%M UTC") if case.closed_at else "Open"),
            ("Evidence items", str(len(artefacts))),
            ("Indicators extracted", str(len(iocs))),
        ])

        if critical:
            doc.heading("Principal findings", 2)
            doc.table(
                ["Severity", "Finding", "Confidence"],
                [
                    [f.get("severity", "").upper(), f.get("title", ""), f"{f.get('confidence', 0)}%"]
                    for f in critical[:8]
                ],
                widths=[1, 4, 1],
            )

        malicious = [
            i for i in iocs
            if (e := enrichments.get(i.value)) is not None and e.verdict.value == "malicious"
        ]
        if malicious:
            doc.heading("Confirmed malicious infrastructure", 2)
            doc.paragraph(
                f"{len(malicious)} indicator(s) were confirmed malicious by "
                "external threat intelligence."
            )
            doc.bullets([f"{i.ioc_type.value}: {i.value}" for i in malicious[:10]])

        doc.heading("Recommended actions", 2)
        doc.bullets(self._recommendations(findings, malicious))

    # ── Technical ────────────────────────────────────────────────────────────
    def _compose_technical(
        self, doc, case, artefacts, findings, iocs, enrichments, peak_risk
    ) -> None:
        band, tone = _risk_band(peak_risk)

        doc.heading("Case detail", 1)
        doc.key_values([
            ("Reference", case.reference),
            ("Title", case.title),
            ("Status", case.status.value.replace("_", " ").title()),
            ("Severity", case.severity.value.title()),
            ("Opened", (case.opened_at or case.created_at).strftime("%d %b %Y %H:%M UTC")),
            ("Peak risk score", f"{peak_risk}/100 ({band})"),
        ])
        if case.summary:
            doc.paragraph(case.summary)

        doc.heading("Evidence inventory", 1)
        if not artefacts:
            doc.paragraph("No evidence has been collected against this case.")
        else:
            doc.paragraph(
                "Chain of custody is established by SHA-256 recorded at ingest. "
                "MD5 is retained only for correlation against threat-intelligence "
                "corpora and is not relied upon for integrity."
            )
            doc.table(
                ["Artefact", "Type", "Size", "SHA-256", "Status"],
                [
                    [
                        a.original_filename,
                        a.evidence_type.value,
                        f"{a.size_bytes:,} B",
                        a.sha256,
                        a.status.value,
                    ]
                    for a in artefacts
                ],
                widths=[2.2, 1, 1.1, 3.4, 1.1],
            )

        doc.heading("Findings", 1)
        if not findings:
            doc.paragraph("Automated analysis raised no detections.")
        else:
            for finding in findings:
                doc.heading(
                    f"[{finding.get('severity', 'info').upper()}] {finding.get('title', '')}", 3
                )
                doc.paragraph(finding.get("description", ""))
                doc.key_values([
                    ("Artefact", finding.get("artefact", "")),
                    ("Confidence", f"{finding.get('confidence', 0)}%"),
                    ("Category", str(finding.get("category", ""))),
                    ("ATT&CK", ", ".join(finding.get("mitre_techniques", [])) or "Not mapped"),
                ])

        doc.heading("Indicators of compromise", 1)
        if not iocs:
            doc.paragraph("No indicators were extracted.")
        else:
            doc.paragraph(
                "Values are defanged. Private, loopback and documentation address "
                "ranges are excluded by the extractor."
            )
            rows = []
            for ioc in iocs[:80]:
                enrichment = enrichments.get(ioc.value)
                rows.append([
                    ioc.ioc_type.value,
                    _defang(ioc.value),
                    f"{ioc.confidence}%",
                    str(ioc.sightings),
                    enrichment.verdict.value if enrichment else "not checked",
                ])
            doc.table(
                ["Type", "Indicator", "Conf.", "Seen", "Reputation"],
                rows,
                widths=[1, 3.4, 0.8, 0.7, 1.3],
            )

        doc.heading("Methodology", 1)
        doc.paragraph(
            "Artefacts were classified by content inspection rather than filename. "
            "Packet captures were parsed to conversation level; beaconing was "
            "assessed from the regularity of inter-arrival times, port scanning "
            "from distinct-port fan-out, and DNS tunnelling from combined query "
            "volume and payload length. Indicator reputation, where shown, was "
            "obtained from configured threat-intelligence feeds and cached."
        )
        doc.callout(
            "Automated findings are investigative leads, not conclusions. Each "
            "should be corroborated before it informs a containment decision.",
            tone="warning",
        )

    @staticmethod
    def _recommendations(findings: list[dict], malicious: list) -> list[str]:
        """Recommendations derived from what was actually found."""
        actions: list[str] = []
        categories = {f.get("category") for f in findings}

        if "beaconing" in categories:
            actions.append(
                "Isolate hosts observed beaconing and capture volatile memory "
                "before any power state change."
            )
        if "port_scan" in categories:
            actions.append(
                "Review the scanning host for compromise and confirm whether the "
                "activity was authorised."
            )
        if "brute_force" in categories:
            actions.append(
                "Force credential rotation for targeted accounts and confirm "
                "multi-factor authentication is enforced."
            )
        if "dns_tunneling" in categories:
            actions.append(
                "Inspect DNS egress and consider forcing resolution through "
                "monitored resolvers."
            )
        if "plaintext_credentials" in categories:
            actions.append(
                "Retire cleartext protocols on affected segments; treat any "
                "credentials transmitted over them as exposed."
            )
        if malicious:
            actions.append(
                f"Block the {len(malicious)} confirmed malicious indicator(s) at "
                "the perimeter and hunt for them across historical telemetry."
            )
        if not actions:
            actions.append(
                "Continue evidence collection. Current artefacts do not support a "
                "containment decision either way."
            )
        actions.append("Preserve all evidence for the retention period defined by policy.")
        return actions


def _defang(value: str) -> str:
    return value.replace("http", "hxxp").replace(".", "[.]").replace("@", "[at]")
