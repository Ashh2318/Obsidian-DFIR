"""Log, JSON, CSV and plain-text analysis."""

from __future__ import annotations

import re
from collections import Counter

from obsidian.analysis.base import AnalysisResult, Finding
from obsidian.analysis.iocs import extract_from_text
from obsidian.domain.enums import EvidenceType, FindingCategory, Severity

MAX_BYTES = 16 * 1024 * 1024  # cap: indicators cluster early in a log

FAILED_AUTH_RE = re.compile(
    r"(failed password|authentication failure|invalid user|login failed|"
    r"access denied|failed login|auth(?:entication)? failed)",
    re.IGNORECASE,
)
PRIVILEGE_RE = re.compile(
    r"(sudo:|su:|runas|privilege escalation|elevated|administrator|root access)",
    re.IGNORECASE,
)
POWERSHELL_RE = re.compile(
    r"(powershell(?:\.exe)?|-enc(?:odedcommand)?\b|invoke-expression|iex\s|"
    r"downloadstring|frombase64string|-nop\b|-noprofile\b|bypass)",
    re.IGNORECASE,
)
PERSISTENCE_RE = re.compile(
    r"(schtasks|at\.exe|new-scheduledtask|currentversion\\\\run|"
    r"services\\\\.*\\\\imagepath|crontab|systemd.*enable)",
    re.IGNORECASE,
)
SOURCE_IP_RE = re.compile(r"(?:from|src|source|rhost=)\s*[:=]?\s*((?:\d{1,3}\.){3}\d{1,3})", re.I)


class TextAnalyzer:
    """Heuristic analysis for line-oriented evidence."""

    name = "text"

    SUPPORTED = frozenset(
        {
            EvidenceType.LOG,
            EvidenceType.TEXT,
            EvidenceType.CSV,
            EvidenceType.JSON,
            EvidenceType.YARA,
            EvidenceType.SIGMA,
        }
    )

    def supports(self, evidence_type: EvidenceType) -> bool:
        return evidence_type in self.SUPPORTED

    def analyze(self, path: str, *, filename: str) -> AnalysisResult:
        with open(path, "rb") as handle:
            raw = handle.read(MAX_BYTES)

        # Evidence is not guaranteed to be valid UTF-8, and a decode error must
        # never abort an investigation.
        text = raw.decode("utf-8", errors="replace")
        lines = text.splitlines()

        result = AnalysisResult(
            engine=self.name,
            evidence_type=EvidenceType.LOG,
            summary="",
        )

        failed_auth = [line for line in lines if FAILED_AUTH_RE.search(line)]
        privilege = [line for line in lines if PRIVILEGE_RE.search(line)]
        powershell = [line for line in lines if POWERSHELL_RE.search(line)]
        persistence = [line for line in lines if PERSISTENCE_RE.search(line)]

        if len(failed_auth) >= 10:
            sources: Counter[str] = Counter()
            for line in failed_auth:
                match = SOURCE_IP_RE.search(line)
                if match:
                    sources[match.group(1)] += 1
            top = sources.most_common(3)
            result.findings.append(
                Finding(
                    category=FindingCategory.BRUTE_FORCE,
                    title=f"{len(failed_auth)} failed authentication attempts",
                    description=(
                        f"The log contains {len(failed_auth)} failed authentication "
                        "events"
                        + (
                            f", concentrated on {', '.join(f'{ip} ({n})' for ip, n in top)}. "
                            if top
                            else ". "
                        )
                        + "Volume at this level is consistent with credential "
                        "guessing rather than user error."
                    ),
                    severity=Severity.HIGH if len(failed_auth) >= 50 else Severity.MEDIUM,
                    confidence=min(92, 55 + len(failed_auth) // 4),
                    mitre_techniques=["T1110"],
                    evidence_refs=[ip for ip, _ in top],
                    metadata={
                        "failed_attempts": len(failed_auth),
                        "top_sources": [{"ip": ip, "count": n} for ip, n in top],
                    },
                )
            )

        if powershell:
            encoded = [line for line in powershell if re.search(r"-enc|frombase64", line, re.I)]
            result.findings.append(
                Finding(
                    category=FindingCategory.SUSPICIOUS_PROTOCOL,
                    title="Suspicious PowerShell activity",
                    description=(
                        f"{len(powershell)} line(s) reference PowerShell, of which "
                        f"{len(encoded)} use encoded or base64 arguments. Encoding "
                        "a command is a common way to defeat log inspection."
                    ),
                    severity=Severity.HIGH if encoded else Severity.MEDIUM,
                    confidence=80 if encoded else 60,
                    mitre_techniques=["T1059.001", "T1027"],
                    metadata={"matches": len(powershell), "encoded": len(encoded)},
                )
            )

        if persistence:
            result.findings.append(
                Finding(
                    category=FindingCategory.ANOMALY,
                    title="Possible persistence mechanism",
                    description=(
                        f"{len(persistence)} line(s) reference scheduled tasks, "
                        "run keys, services or cron entries — the usual places an "
                        "intruder establishes persistence."
                    ),
                    severity=Severity.MEDIUM,
                    confidence=65,
                    mitre_techniques=["T1053", "T1547.001"],
                    metadata={"matches": len(persistence)},
                )
            )

        if len(privilege) >= 5:
            result.findings.append(
                Finding(
                    category=FindingCategory.ANOMALY,
                    title="Privilege-related activity",
                    description=(
                        f"{len(privilege)} line(s) reference elevation or "
                        "administrative access. Correlate against expected "
                        "administrative windows."
                    ),
                    severity=Severity.LOW,
                    confidence=50,
                    mitre_techniques=["T1548"],
                    metadata={"matches": len(privilege)},
                )
            )

        result.iocs = extract_from_text(text, context=f"Extracted from {filename}")
        result.statistics = {
            "lines": len(lines),
            "bytes_analysed": len(raw),
            "truncated": len(raw) >= MAX_BYTES,
            "failed_auth_events": len(failed_auth),
            "powershell_references": len(powershell),
            "persistence_references": len(persistence),
            "privilege_references": len(privilege),
            "ioc_breakdown": dict(Counter(i.ioc_type.value for i in result.iocs)),
        }
        result.summary = (
            f"Analysed {len(lines):,} lines. {len(result.findings)} finding(s) and "
            f"{len(result.iocs)} indicator(s) extracted."
        )
        return result
