"""Analysis contracts.

Every engine — PCAP, EVTX, document, APK — returns the same
:class:`AnalysisResult`. One shape means one renderer in the UI and one
persistence path, so adding an engine never touches the transport or frontend.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from obsidian.domain.enums import EvidenceType, FindingCategory, IOCType, Severity


@dataclass(slots=True)
class ExtractedIOC:
    """An indicator observed in evidence, before persistence and deduplication."""

    ioc_type: IOCType
    value: str
    severity: Severity = Severity.INFO
    confidence: int = 50
    context: str | None = None

    def key(self) -> tuple[str, str]:
        return (self.ioc_type.value, self.value)


@dataclass(slots=True)
class Finding:
    """A detection with enough context for an analyst to act or dismiss it."""

    category: FindingCategory
    title: str
    description: str
    severity: Severity
    confidence: int = 50
    mitre_techniques: list[str] = field(default_factory=list)
    evidence_refs: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class AnalysisResult:
    """Uniform output of every analysis engine."""

    engine: str
    evidence_type: EvidenceType
    summary: str
    statistics: dict[str, Any] = field(default_factory=dict)
    findings: list[Finding] = field(default_factory=list)
    iocs: list[ExtractedIOC] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def risk_score(self) -> int:
        """0–100 risk, driven by the highest-severity findings.

        Weighted by severity and damped by count so that one critical finding
        outranks a dozen informational ones — the opposite of a naive sum, which
        would let noise outweigh a genuine detection.
        """
        if not self.findings:
            return 0
        weights = {
            Severity.INFO: 5,
            Severity.LOW: 15,
            Severity.MEDIUM: 35,
            Severity.HIGH: 65,
            Severity.CRITICAL: 90,
        }
        ranked = sorted(
            (weights[f.severity] for f in self.findings), reverse=True
        )
        score = ranked[0]
        # Each additional finding contributes a rapidly diminishing amount.
        for index, value in enumerate(ranked[1:], start=1):
            score += value / (2 ** index)
        return min(100, round(score))

    @property
    def highest_severity(self) -> Severity:
        if not self.findings:
            return Severity.INFO
        return max((f.severity for f in self.findings), key=lambda s: s.rank)

    def to_dict(self) -> dict[str, Any]:
        return {
            "engine": self.engine,
            "evidence_type": self.evidence_type.value,
            "summary": self.summary,
            "risk_score": self.risk_score,
            "highest_severity": self.highest_severity.value,
            "statistics": self.statistics,
            "findings": [
                {
                    "category": f.category.value,
                    "title": f.title,
                    "description": f.description,
                    "severity": f.severity.value,
                    "confidence": f.confidence,
                    "mitre_techniques": f.mitre_techniques,
                    "evidence_refs": f.evidence_refs,
                    "metadata": f.metadata,
                }
                for f in self.findings
            ],
            "ioc_count": len(self.iocs),
            "errors": self.errors,
        }


@runtime_checkable
class Analyzer(Protocol):
    """Contract every analysis engine implements."""

    name: str

    def supports(self, evidence_type: EvidenceType) -> bool: ...

    def analyze(self, path: str, *, filename: str) -> AnalysisResult: ...
