"""Indicator extraction.

Shared by every engine so the definition of "what counts as an IOC" exists
once. The filtering matters as much as the matching: an indicator list padded
with RFC 1918 addresses and the analyst's own infrastructure is noise, and
analysts stop reading lists that waste their time.
"""

from __future__ import annotations

import ipaddress
import re
from collections import Counter
from typing import TYPE_CHECKING, Iterable

from obsidian.analysis.base import ExtractedIOC
from obsidian.domain.enums import IOCType, Severity

if TYPE_CHECKING:  # pragma: no cover - import cycle guard
    from obsidian.analysis.pcap import Packet

# Deliberately anchored on word boundaries: unanchored patterns match fragments
# of longer tokens and produce indicators that do not exist in the source.
IPV4_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
IPV6_RE = re.compile(r"\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b")
URL_RE = re.compile(r"\bhttps?://[^\s<>\"'\)\]]{4,400}", re.IGNORECASE)
EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,63}\b")
MD5_RE = re.compile(r"\b[a-fA-F0-9]{32}\b")
SHA1_RE = re.compile(r"\b[a-fA-F0-9]{40}\b")
SHA256_RE = re.compile(r"\b[a-fA-F0-9]{64}\b")
DOMAIN_RE = re.compile(
    r"\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+"
    r"(?:com|net|org|io|co|ru|cn|info|biz|xyz|top|tk|pw|cc|de|uk|fr|nl|br|in|"
    r"online|site|club|shop|live|icu|gq|ml|ga|cf|link|host|space|website|tech)\b",
    re.IGNORECASE,
)

# Extensions that are noise in a hostname context, e.g. "config.info".
FILE_EXTENSION_NOISE = re.compile(
    r"\.(?:png|jpe?g|gif|svg|css|js|json|xml|html?|txt|log|md)$", re.IGNORECASE
)

# Domains that appear in almost every capture and tell an analyst nothing.
BENIGN_DOMAINS = frozenset(
    {
        "microsoft.com", "windows.com", "windowsupdate.com", "msftncsi.com",
        "google.com", "gstatic.com", "googleapis.com", "apple.com",
        "icloud.com", "mozilla.org", "ubuntu.com", "debian.org",
        "cloudflare.com", "akamai.net", "amazonaws.com", "example.com",
    }
)


def is_routable_ip(value: str) -> bool:
    """True only for addresses that could plausibly be an external indicator."""
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        return False
    return not (
        address.is_private
        or address.is_loopback
        or address.is_multicast
        or address.is_reserved
        or address.is_link_local
        or address.is_unspecified
    )


def _registrable(domain: str) -> str:
    """Reduce a hostname to its registrable portion for allow-list comparison."""
    parts = domain.lower().rstrip(".").split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else domain.lower()


def is_interesting_domain(domain: str) -> bool:
    lowered = domain.lower().rstrip(".")
    if FILE_EXTENSION_NOISE.search(lowered):
        return False
    return _registrable(lowered) not in BENIGN_DOMAINS


def defang(value: str) -> str:
    """Render an indicator non-clickable for reports and copy-paste safety."""
    return value.replace("http", "hxxp").replace(".", "[.]").replace("@", "[at]")


def extract_from_text(text: str, *, context: str | None = None) -> list[ExtractedIOC]:
    """Pull indicators out of arbitrary text, deduplicated with sighting counts."""
    found: dict[tuple[str, str], ExtractedIOC] = {}
    counts: Counter[tuple[str, str]] = Counter()

    def add(
        ioc_type: IOCType, value: str, severity: Severity, confidence: int
    ) -> None:
        key = (ioc_type.value, value)
        counts[key] += 1
        if key not in found:
            found[key] = ExtractedIOC(
                ioc_type=ioc_type,
                value=value,
                severity=severity,
                confidence=confidence,
                context=context,
            )

    # Hashes first and longest-first: a SHA-256 string contains valid MD5 and
    # SHA-1 substrings, so matching the short patterns first mints indicators
    # that were never actually present.
    consumed: set[str] = set()
    for pattern, ioc_type in (
        (SHA256_RE, IOCType.SHA256),
        (SHA1_RE, IOCType.SHA1),
        (MD5_RE, IOCType.MD5),
    ):
        for match in pattern.findall(text):
            lowered = match.lower()
            if any(lowered in seen for seen in consumed):
                continue
            consumed.add(lowered)
            add(ioc_type, lowered, Severity.MEDIUM, 70)

    for match in URL_RE.findall(text):
        add(IOCType.URL, match.rstrip(".,;)"), Severity.MEDIUM, 75)

    for match in EMAIL_RE.findall(text):
        add(IOCType.EMAIL, match.lower(), Severity.LOW, 60)

    for match in IPV4_RE.findall(text):
        if is_routable_ip(match):
            add(IOCType.IPV4, match, Severity.MEDIUM, 65)

    for match in IPV6_RE.findall(text):
        if is_routable_ip(match):
            add(IOCType.IPV6, match.lower(), Severity.MEDIUM, 65)

    for match in DOMAIN_RE.findall(text):
        if is_interesting_domain(match):
            add(IOCType.DOMAIN, match.lower().rstrip("."), Severity.LOW, 55)

    # Repetition raises confidence: an indicator seen many times is unlikely to
    # be an incidental string.
    for key, ioc in found.items():
        sightings = counts[key]
        if sightings > 1:
            ioc.confidence = min(95, ioc.confidence + min(20, sightings * 2))

    return list(found.values())


def extract_network_iocs(packets: Iterable["Packet"]) -> list[ExtractedIOC]:
    """Derive indicators from decoded packets.

    External endpoints are indicators; internal ones are the estate being
    defended and would drown the list.
    """
    external: Counter[str] = Counter()
    payload_text: list[str] = []

    for packet in packets:
        for address in (packet.src_ip, packet.dst_ip):
            if is_routable_ip(address):
                external[address] += 1
        if packet.payload:
            payload_text.append(
                packet.payload.decode("utf-8", errors="ignore")
            )

    iocs = [
        ExtractedIOC(
            ioc_type=IOCType.IPV6 if ":" in address else IOCType.IPV4,
            value=address,
            severity=Severity.MEDIUM,
            confidence=min(92, 55 + min(35, count)),
            context=f"Observed in {count} packet(s)",
        )
        for address, count in external.most_common(100)
    ]

    # Payload strings surface domains, URLs and hostnames that never appear in
    # the IP headers, e.g. an HTTP Host or an SNI value.
    if payload_text:
        seen = {(i.ioc_type.value, i.value) for i in iocs}
        for ioc in extract_from_text(
            "\n".join(payload_text[:2000]), context="Extracted from packet payloads"
        ):
            if ioc.key() not in seen:
                iocs.append(ioc)
                seen.add(ioc.key())

    return iocs
