"""Analyzer resolution.

Adding an engine is one import and one list entry. Nothing above this module
knows which engines exist.
"""

from __future__ import annotations

from obsidian.analysis.base import Analyzer
from obsidian.analysis.pcap import PcapAnalyzer
from obsidian.analysis.text import TextAnalyzer
from obsidian.domain.enums import EvidenceType

_ANALYZERS: tuple[Analyzer, ...] = (PcapAnalyzer(), TextAnalyzer())


def analyzer_for(evidence_type: EvidenceType) -> Analyzer | None:
    """Return the engine that handles ``evidence_type``, or None."""
    for analyzer in _ANALYZERS:
        if analyzer.supports(evidence_type):
            return analyzer
    return None


def supported_types() -> list[str]:
    return sorted(
        {
            evidence_type.value
            for evidence_type in EvidenceType
            if analyzer_for(evidence_type) is not None
        }
    )
