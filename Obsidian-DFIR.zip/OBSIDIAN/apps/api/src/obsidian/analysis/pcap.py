"""Packet capture analysis.

Implemented directly against the file format rather than through Scapy or
tshark. Those are heavy dependencies, and Scapy in particular is slow enough on
large captures to be unusable inside a request. The formats needed here —
libpcap and pcapng — are simple, and parsing them explicitly keeps the analysis
path dependency-free and predictable.

Reference: libpcap file format, and PCAP Next Generation (pcapng) block layout.
"""

from __future__ import annotations

import struct
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from statistics import mean, pstdev

from obsidian.analysis.base import AnalysisResult, Finding
from obsidian.analysis.iocs import extract_network_iocs
from obsidian.domain.enums import EvidenceType, FindingCategory, Severity

# libpcap global-header magics. The "us"/"ns" pairs differ only in timestamp
# resolution; endianness is what determines how every subsequent field is read.
PCAP_MAGIC_LE_US = 0xA1B2C3D4
PCAP_MAGIC_BE_US = 0xD4C3B2A1
PCAP_MAGIC_LE_NS = 0xA1B23C4D
PCAP_MAGIC_BE_NS = 0x4D3CB2A1
PCAPNG_MAGIC = 0x0A0D0D0A

LINKTYPE_ETHERNET = 1
LINKTYPE_RAW = 101
LINKTYPE_LINUX_SLL = 113

MAX_PACKETS = 250_000  # bounded so a hostile capture cannot exhaust memory

PROTOCOL_NAMES = {1: "ICMP", 6: "TCP", 17: "UDP", 58: "ICMPv6"}

WELL_KNOWN_PORTS = {
    20: "FTP-DATA", 21: "FTP", 22: "SSH", 23: "TELNET", 25: "SMTP",
    53: "DNS", 67: "DHCP", 68: "DHCP", 80: "HTTP", 110: "POP3",
    123: "NTP", 135: "MSRPC", 139: "NETBIOS", 143: "IMAP", 389: "LDAP",
    443: "HTTPS", 445: "SMB", 993: "IMAPS", 995: "POP3S",
    1433: "MSSQL", 3306: "MYSQL", 3389: "RDP", 5432: "POSTGRES",
    5985: "WINRM", 8080: "HTTP-ALT", 8443: "HTTPS-ALT",
}

CLEARTEXT_PROTOCOL_PORTS = {21: "FTP", 23: "Telnet", 110: "POP3", 143: "IMAP"}


@dataclass(slots=True)
class Packet:
    timestamp: float
    src_ip: str
    dst_ip: str
    protocol: int
    src_port: int | None
    dst_port: int | None
    length: int
    payload: bytes = b""


@dataclass(slots=True)
class Conversation:
    src: str
    dst: str
    dst_port: int | None
    protocol: str
    packets: int = 0
    bytes: int = 0
    timestamps: list[float] = field(default_factory=list)


# ── Byte-level decoding ──────────────────────────────────────────────────────
def _ipv4(raw: bytes) -> str:
    return ".".join(str(b) for b in raw)


def _ipv6(raw: bytes) -> str:
    parts = [f"{raw[i] << 8 | raw[i + 1]:x}" for i in range(0, 16, 2)]
    return ":".join(parts)


def _parse_ip_packet(data: bytes, timestamp: float) -> Packet | None:
    """Decode an IPv4 or IPv6 packet, plus TCP/UDP ports where present."""
    if len(data) < 20:
        return None

    version = data[0] >> 4
    if version == 4:
        ihl = (data[0] & 0x0F) * 4
        if ihl < 20 or len(data) < ihl:
            return None
        total_length = struct.unpack("!H", data[2:4])[0]
        protocol = data[9]
        src, dst = _ipv4(data[12:16]), _ipv4(data[16:20])
        transport = data[ihl:]
    elif version == 6:
        if len(data) < 40:
            return None
        total_length = struct.unpack("!H", data[4:6])[0] + 40
        protocol = data[6]
        src, dst = _ipv6(data[8:24]), _ipv6(data[24:40])
        transport = data[40:]
    else:
        return None

    src_port = dst_port = None
    payload = b""
    if protocol in (6, 17) and len(transport) >= 8:
        src_port, dst_port = struct.unpack("!HH", transport[:4])
        if protocol == 6:
            offset = (transport[12] >> 4) * 4 if len(transport) > 12 else 20
            payload = transport[offset:] if len(transport) > offset else b""
        else:
            payload = transport[8:]

    return Packet(
        timestamp=timestamp,
        src_ip=src,
        dst_ip=dst,
        protocol=protocol,
        src_port=src_port,
        dst_port=dst_port,
        length=total_length or len(data),
        payload=payload[:512],  # enough for DNS and HTTP headers
    )


def _parse_link_frame(frame: bytes, linktype: int, timestamp: float) -> Packet | None:
    if linktype == LINKTYPE_ETHERNET:
        if len(frame) < 14:
            return None
        ethertype = struct.unpack("!H", frame[12:14])[0]
        offset = 14
        # 802.1Q VLAN tag shifts the real ethertype four bytes along.
        if ethertype == 0x8100 and len(frame) >= 18:
            ethertype = struct.unpack("!H", frame[16:18])[0]
            offset = 18
        if ethertype not in (0x0800, 0x86DD):
            return None
        return _parse_ip_packet(frame[offset:], timestamp)

    if linktype == LINKTYPE_RAW:
        return _parse_ip_packet(frame, timestamp)

    if linktype == LINKTYPE_LINUX_SLL:
        if len(frame) < 16:
            return None
        return _parse_ip_packet(frame[16:], timestamp)

    return None


def _read_pcap(data: bytes) -> tuple[list[Packet], list[str]]:
    """Parse a classic libpcap file."""
    errors: list[str] = []
    if len(data) < 24:
        return [], ["File is too short to contain a pcap header."]

    magic = struct.unpack("<I", data[:4])[0]
    if magic in (PCAP_MAGIC_LE_US, PCAP_MAGIC_LE_NS):
        endian = "<"
    elif magic in (PCAP_MAGIC_BE_US, PCAP_MAGIC_BE_NS):
        endian = ">"
    else:
        return [], [f"Unrecognised pcap magic: 0x{magic:08x}"]

    nanosecond = magic in (PCAP_MAGIC_LE_NS, PCAP_MAGIC_BE_NS)
    linktype = struct.unpack(f"{endian}I", data[20:24])[0]

    packets: list[Packet] = []
    offset = 24
    while offset + 16 <= len(data) and len(packets) < MAX_PACKETS:
        seconds, fraction, captured, original = struct.unpack(
            f"{endian}IIII", data[offset : offset + 16]
        )
        offset += 16
        if captured > len(data) - offset:
            errors.append("Truncated packet record; stopping.")
            break

        timestamp = seconds + (fraction / 1e9 if nanosecond else fraction / 1e6)
        packet = _parse_link_frame(data[offset : offset + captured], linktype, timestamp)
        if packet is not None:
            # Prefer the on-wire length so byte totals reflect reality even when
            # the capture was truncated by a snaplen.
            packet.length = original or packet.length
            packets.append(packet)
        offset += captured

    return packets, errors


def _read_pcapng(data: bytes) -> tuple[list[Packet], list[str]]:
    """Parse a pcapng file, reading only the blocks that carry packets."""
    errors: list[str] = []
    packets: list[Packet] = []
    offset = 0
    endian = "<"
    linktypes: dict[int, int] = {}
    interface_index = 0

    while offset + 12 <= len(data) and len(packets) < MAX_PACKETS:
        block_type = struct.unpack(f"{endian}I", data[offset : offset + 4])[0]

        if block_type == PCAPNG_MAGIC:
            # Section Header Block: byte-order magic decides endianness.
            if data[offset + 8 : offset + 12] == b"\x1a\x2b\x3c\x4d":
                endian = "<"
            else:
                endian = ">"
            interface_index = 0

        block_length = struct.unpack(f"{endian}I", data[offset + 4 : offset + 8])[0]
        if block_length < 12 or offset + block_length > len(data):
            errors.append("Malformed pcapng block length; stopping.")
            break

        body = data[offset + 8 : offset + block_length - 4]

        if block_type == 0x00000001 and len(body) >= 4:  # Interface Description
            linktypes[interface_index] = struct.unpack(f"{endian}H", body[:2])[0]
            interface_index += 1
        elif block_type == 0x00000006 and len(body) >= 20:  # Enhanced Packet
            iface, ts_high, ts_low, captured, _original = struct.unpack(
                f"{endian}IIIII", body[:20]
            )
            timestamp = ((ts_high << 32) | ts_low) / 1e6
            frame = body[20 : 20 + captured]
            packet = _parse_link_frame(
                frame, linktypes.get(iface, LINKTYPE_ETHERNET), timestamp
            )
            if packet is not None:
                packets.append(packet)

        offset += block_length

    return packets, errors


# ── Detections ───────────────────────────────────────────────────────────────
def _detect_beaconing(conversations: list[Conversation]) -> list[Finding]:
    """Flag conversations whose inter-arrival times are suspiciously regular.

    Command-and-control channels usually check in on a timer. Human and
    application traffic is bursty, so a low coefficient of variation across many
    intervals is a strong signal. The threshold is deliberately conservative —
    a false positive costs an analyst minutes, and the confidence score is
    surfaced so triage can be prioritised.
    """
    findings: list[Finding] = []

    for conversation in conversations:
        if conversation.packets < 8 or len(conversation.timestamps) < 8:
            continue

        ordered = sorted(conversation.timestamps)
        intervals = [b - a for a, b in zip(ordered, ordered[1:]) if b - a > 0]
        if len(intervals) < 6:
            continue

        average = mean(intervals)
        if average < 0.5:  # sub-second chatter is a stream, not a beacon
            continue

        deviation = pstdev(intervals) if len(intervals) > 1 else 0.0
        coefficient = deviation / average if average else 1.0
        if coefficient >= 0.22:
            continue

        # Regularity maps to confidence: perfectly periodic is near-certain.
        confidence = min(96, int((1 - coefficient / 0.22) * 55) + 42)
        severity = Severity.HIGH if coefficient < 0.10 else Severity.MEDIUM

        findings.append(
            Finding(
                category=FindingCategory.BEACONING,
                title=f"Periodic beaconing to {conversation.dst}",
                description=(
                    f"{conversation.src} contacted {conversation.dst}"
                    f"{f':{conversation.dst_port}' if conversation.dst_port else ''} "
                    f"{conversation.packets} times at a mean interval of "
                    f"{average:.1f}s with only {coefficient * 100:.1f}% variation. "
                    "Regular timing of this kind is characteristic of an "
                    "automated command-and-control check-in."
                ),
                severity=severity,
                confidence=confidence,
                mitre_techniques=["T1071.001", "T1571"],
                evidence_refs=[conversation.dst],
                metadata={
                    "source": conversation.src,
                    "destination": conversation.dst,
                    "port": conversation.dst_port,
                    "mean_interval_seconds": round(average, 2),
                    "jitter_ratio": round(coefficient, 4),
                    "packets": conversation.packets,
                },
            )
        )

    return sorted(findings, key=lambda f: f.confidence, reverse=True)[:10]


def _detect_port_scan(packets: list[Packet]) -> list[Finding]:
    """Flag a host touching many distinct ports on a single target."""
    probes: dict[tuple[str, str], set[int]] = defaultdict(set)
    for packet in packets:
        if packet.protocol == 6 and packet.dst_port is not None:
            probes[(packet.src_ip, packet.dst_ip)].add(packet.dst_port)

    findings: list[Finding] = []
    for (src, dst), ports in probes.items():
        if len(ports) < 20:
            continue
        severity = Severity.HIGH if len(ports) >= 100 else Severity.MEDIUM
        findings.append(
            Finding(
                category=FindingCategory.PORT_SCAN,
                title=f"Port scan from {src} against {dst}",
                description=(
                    f"{src} contacted {len(ports)} distinct TCP ports on {dst}. "
                    "Fan-out of this breadth from one source is characteristic "
                    "of service enumeration rather than normal client traffic."
                ),
                severity=severity,
                confidence=min(95, 55 + len(ports) // 8),
                mitre_techniques=["T1046"],
                evidence_refs=[src, dst],
                metadata={
                    "source": src,
                    "target": dst,
                    "distinct_ports": len(ports),
                    "sample_ports": sorted(ports)[:25],
                },
            )
        )
    return sorted(findings, key=lambda f: f.confidence, reverse=True)[:5]


def _detect_dns_tunneling(packets: list[Packet]) -> list[Finding]:
    """Flag DNS traffic whose volume or query length suggests a covert channel."""
    dns_packets = [p for p in packets if p.dst_port == 53 or p.src_port == 53]
    if len(dns_packets) < 30:
        return []

    lengths = [len(p.payload) for p in dns_packets if p.payload]
    if not lengths:
        return []

    average_length = mean(lengths)
    per_source: Counter[str] = Counter(p.src_ip for p in dns_packets if p.dst_port == 53)
    if not per_source:
        return []

    top_source, query_count = per_source.most_common(1)[0]
    # Two independent signals; either alone is weak, together they are strong.
    if average_length < 90 and query_count < 200:
        return []

    return [
        Finding(
            category=FindingCategory.DNS_TUNNELING,
            title=f"Possible DNS tunneling from {top_source}",
            description=(
                f"{top_source} issued {query_count} DNS queries with a mean "
                f"payload of {average_length:.0f} bytes. High query volume "
                "combined with unusually long payloads is consistent with data "
                "being encoded into DNS rather than resolved through it."
            ),
            severity=Severity.HIGH if average_length > 140 else Severity.MEDIUM,
            confidence=min(90, 45 + int(average_length / 4)),
            mitre_techniques=["T1071.004", "T1048.003"],
            evidence_refs=[top_source],
            metadata={
                "source": top_source,
                "query_count": query_count,
                "mean_payload_bytes": round(average_length, 1),
            },
        )
    ]


def _detect_cleartext_protocols(conversations: list[Conversation]) -> list[Finding]:
    seen: dict[str, Conversation] = {}
    for conversation in conversations:
        name = CLEARTEXT_PROTOCOL_PORTS.get(conversation.dst_port or 0)
        if name and name not in seen:
            seen[name] = conversation

    return [
        Finding(
            category=FindingCategory.PLAINTEXT_CREDENTIALS,
            title=f"Cleartext {name} in use",
            description=(
                f"{conversation.src} communicated with {conversation.dst} over "
                f"{name}, which transmits credentials without encryption. Any "
                "party on the path can read them."
            ),
            severity=Severity.MEDIUM,
            confidence=88,
            mitre_techniques=["T1040"],
            evidence_refs=[conversation.dst],
            metadata={"protocol": name, "destination": conversation.dst},
        )
        for name, conversation in seen.items()
    ]


# ── Engine ───────────────────────────────────────────────────────────────────
class PcapAnalyzer:
    """Network capture analysis engine."""

    name = "pcap"

    def supports(self, evidence_type: EvidenceType) -> bool:
        return evidence_type is EvidenceType.PCAP

    def analyze(self, path: str, *, filename: str) -> AnalysisResult:
        with open(path, "rb") as handle:
            data = handle.read()

        if len(data) >= 4 and struct.unpack("<I", data[:4])[0] == PCAPNG_MAGIC:
            packets, errors = _read_pcapng(data)
        else:
            packets, errors = _read_pcap(data)

        result = AnalysisResult(
            engine=self.name,
            evidence_type=EvidenceType.PCAP,
            summary="",
            errors=errors,
        )

        if not packets:
            result.summary = "No decodable IP packets were found in this capture."
            result.statistics = {"packets": 0}
            return result

        conversations: dict[tuple[str, str, int | None, str], Conversation] = {}
        protocols: Counter[str] = Counter()
        talkers: Counter[str] = Counter()
        ports: Counter[int] = Counter()
        total_bytes = 0

        for packet in packets:
            protocol = PROTOCOL_NAMES.get(packet.protocol, f"IP/{packet.protocol}")
            protocols[protocol] += 1
            talkers[packet.src_ip] += 1
            total_bytes += packet.length
            if packet.dst_port is not None:
                ports[packet.dst_port] += 1

            key = (packet.src_ip, packet.dst_ip, packet.dst_port, protocol)
            conversation = conversations.get(key)
            if conversation is None:
                conversation = Conversation(
                    src=packet.src_ip,
                    dst=packet.dst_ip,
                    dst_port=packet.dst_port,
                    protocol=protocol,
                )
                conversations[key] = conversation
            conversation.packets += 1
            conversation.bytes += packet.length
            conversation.timestamps.append(packet.timestamp)

        conversation_list = sorted(
            conversations.values(), key=lambda c: c.packets, reverse=True
        )

        result.findings.extend(_detect_beaconing(conversation_list))
        result.findings.extend(_detect_port_scan(packets))
        result.findings.extend(_detect_dns_tunneling(packets))
        result.findings.extend(_detect_cleartext_protocols(conversation_list))

        result.iocs = extract_network_iocs(packets)

        times = [p.timestamp for p in packets]
        first_seen, last_seen = min(times), max(times)
        duration = last_seen - first_seen if len(times) > 1 else 0.0

        result.statistics = {
            "packets": len(packets),
            "total_bytes": total_bytes,
            "duration_seconds": round(duration, 2),
            # Absolute capture bounds, not just a duration. A forensic timeline
            # has to place when the traffic actually occurred, which is rarely
            # when the analyst got around to uploading it.
            "first_packet_epoch": round(first_seen, 3),
            "last_packet_epoch": round(last_seen, 3),
            "unique_hosts": len({p.src_ip for p in packets} | {p.dst_ip for p in packets}),
            "conversations": len(conversation_list),
            "protocol_distribution": dict(protocols.most_common()),
            "top_talkers": [
                {"host": host, "packets": count} for host, count in talkers.most_common(10)
            ],
            "top_ports": [
                {
                    "port": port,
                    "service": WELL_KNOWN_PORTS.get(port, "unknown"),
                    "packets": count,
                }
                for port, count in ports.most_common(10)
            ],
            "top_conversations": [
                {
                    "source": c.src,
                    "destination": c.dst,
                    "port": c.dst_port,
                    "protocol": c.protocol,
                    "packets": c.packets,
                    "bytes": c.bytes,
                }
                for c in conversation_list[:15]
            ],
        }

        result.summary = (
            f"Parsed {len(packets):,} packets across {len(conversation_list):,} "
            f"conversations between {result.statistics['unique_hosts']} hosts over "
            f"{duration:.0f}s. {len(result.findings)} finding(s) raised."
        )
        return result
