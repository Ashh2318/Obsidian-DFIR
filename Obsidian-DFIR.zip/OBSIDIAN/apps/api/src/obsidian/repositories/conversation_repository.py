"""Conversation persistence."""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import func, select

from obsidian.db.models.conversation import Conversation, Message
from obsidian.repositories.base import BaseRepository


class ConversationRepository(BaseRepository[Conversation]):
    model = Conversation

    async def list_for_owner(
        self, owner_id: str, *, limit: int, offset: int, case_id: str | None = None
    ) -> tuple[Sequence[Conversation], int]:
        stmt = select(Conversation).where(Conversation.owner_id == owner_id)
        count_stmt = (
            select(func.count())
            .select_from(Conversation)
            .where(Conversation.owner_id == owner_id)
        )
        if case_id:
            stmt = stmt.where(Conversation.case_id == case_id)
            count_stmt = count_stmt.where(Conversation.case_id == case_id)

        rows = await self.session.execute(
            stmt.order_by(Conversation.updated_at.desc()).limit(limit).offset(offset)
        )
        total = await self.session.execute(count_stmt)
        return rows.scalars().all(), int(total.scalar_one())


class MessageRepository(BaseRepository[Message]):
    model = Message

    async def list_for_conversation(self, conversation_id: str) -> Sequence[Message]:
        stmt = (
            select(Message)
            .where(Message.conversation_id == conversation_id)
            .order_by(Message.created_at)
        )
        result = await self.session.execute(stmt)
        return result.scalars().all()
