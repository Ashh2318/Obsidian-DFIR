"""IOC persistence with per-case deduplication."""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import func, or_, select

from obsidian.db.models.ioc import IOC
from obsidian.domain.enums import IOCType, Severity
from obsidian.repositories.base import BaseRepository


class IOCRepository(BaseRepository[IOC]):
    model = IOC

    async def find(self, case_id: str, ioc_type: IOCType, value: str) -> IOC | None:
        stmt = select(IOC).where(
            IOC.case_id == case_id, IOC.ioc_type == ioc_type, IOC.value == value
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def search(
        self,
        *,
        limit: int,
        offset: int,
        case_id: str | None = None,
        ioc_type: IOCType | None = None,
        severity: Severity | None = None,
        query: str | None = None,
    ) -> tuple[Sequence[IOC], int]:
        stmt = select(IOC)
        count_stmt = select(func.count()).select_from(IOC)

        conditions = []
        if case_id:
            conditions.append(IOC.case_id == case_id)
        if ioc_type is not None:
            conditions.append(IOC.ioc_type == ioc_type)
        if severity is not None:
            conditions.append(IOC.severity == severity)
        if query:
            pattern = f"%{query.strip().lower()}%"
            conditions.append(
                or_(
                    func.lower(IOC.value).like(pattern),
                    func.lower(func.coalesce(IOC.context, "")).like(pattern),
                )
            )

        for condition in conditions:
            stmt = stmt.where(condition)
            count_stmt = count_stmt.where(condition)

        rows = await self.session.execute(
            stmt.order_by(IOC.sightings.desc(), IOC.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        total = await self.session.execute(count_stmt)
        return rows.scalars().all(), int(total.scalar_one())

    async def count_by_type(self, case_id: str | None = None) -> dict[str, int]:
        stmt = select(IOC.ioc_type, func.count()).group_by(IOC.ioc_type)
        if case_id:
            stmt = stmt.where(IOC.case_id == case_id)
        result = await self.session.execute(stmt)
        return {t.value: c for t, c in result.all()}
