"""Evidence persistence."""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import func, select

from obsidian.db.models.evidence import Evidence
from obsidian.domain.enums import EvidenceType
from obsidian.repositories.base import BaseRepository


class EvidenceRepository(BaseRepository[Evidence]):
    model = Evidence

    async def list_for_case(
        self, case_id: str, *, limit: int, offset: int
    ) -> tuple[Sequence[Evidence], int]:
        stmt = (
            select(Evidence)
            .where(Evidence.case_id == case_id)
            .order_by(Evidence.created_at.desc())
        )
        count_stmt = (
            select(func.count()).select_from(Evidence).where(Evidence.case_id == case_id)
        )
        rows = await self.session.execute(stmt.limit(limit).offset(offset))
        total = await self.session.execute(count_stmt)
        return rows.scalars().all(), int(total.scalar_one())

    async def find_by_sha256(self, case_id: str, sha256: str) -> Evidence | None:
        """Detect a duplicate artefact already held against this case."""
        stmt = select(Evidence).where(
            Evidence.case_id == case_id, Evidence.sha256 == sha256
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def count_by_type(self, case_id: str | None = None) -> dict[str, int]:
        stmt = select(Evidence.evidence_type, func.count()).group_by(Evidence.evidence_type)
        if case_id:
            stmt = stmt.where(Evidence.case_id == case_id)
        result = await self.session.execute(stmt)
        return {t.value if isinstance(t, EvidenceType) else str(t): c for t, c in result.all()}

    async def total_bytes(self, case_id: str | None = None) -> int:
        stmt = select(func.coalesce(func.sum(Evidence.size_bytes), 0))
        if case_id:
            stmt = stmt.where(Evidence.case_id == case_id)
        result = await self.session.execute(stmt)
        return int(result.scalar_one())
