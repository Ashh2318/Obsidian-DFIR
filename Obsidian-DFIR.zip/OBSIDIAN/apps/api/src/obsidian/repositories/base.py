"""Generic typed repository.

Repositories are the only place SQLAlchemy query construction is permitted.
Services speak in domain terms; nothing above this layer knows what `select()`
is. That boundary is what allows the persistence backend to change without
rewriting business logic.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Generic, TypeVar

from sqlalchemy import Select, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.db.base import Base

ModelT = TypeVar("ModelT", bound=Base)


class BaseRepository(Generic[ModelT]):
    """CRUD and pagination shared by every aggregate repository."""

    model: type[ModelT]

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    # ── Reads ────────────────────────────────────────────────────────────────
    async def get(self, entity_id: str) -> ModelT | None:
        return await self.session.get(self.model, entity_id)

    async def find_one_by(self, **filters: Any) -> ModelT | None:
        result = await self.session.execute(self._filtered(**filters).limit(1))
        return result.scalar_one_or_none()

    async def list(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        order_by: Any | None = None,
        **filters: Any,
    ) -> Sequence[ModelT]:
        stmt = self._filtered(**filters)
        if order_by is not None:
            stmt = stmt.order_by(order_by)
        result = await self.session.execute(stmt.limit(limit).offset(offset))
        return result.scalars().all()

    async def count(self, **filters: Any) -> int:
        stmt = select(func.count()).select_from(self.model)
        for field, value in filters.items():
            stmt = stmt.where(getattr(self.model, field) == value)
        result = await self.session.execute(stmt)
        return int(result.scalar_one())

    async def exists(self, **filters: Any) -> bool:
        return await self.count(**filters) > 0

    # ── Writes ───────────────────────────────────────────────────────────────
    async def add(self, entity: ModelT) -> ModelT:
        self.session.add(entity)
        # Flush, not commit: the transaction boundary belongs to the session
        # dependency. Flushing here makes server defaults and the primary key
        # available to the caller without ending the unit of work.
        await self.session.flush()
        return entity

    async def delete(self, entity: ModelT) -> None:
        await self.session.delete(entity)
        await self.session.flush()

    async def flush(self) -> None:
        await self.session.flush()

    # ── Internals ────────────────────────────────────────────────────────────
    def _filtered(self, **filters: Any) -> Select[tuple[ModelT]]:
        stmt = select(self.model)
        for field, value in filters.items():
            stmt = stmt.where(getattr(self.model, field) == value)
        return stmt
