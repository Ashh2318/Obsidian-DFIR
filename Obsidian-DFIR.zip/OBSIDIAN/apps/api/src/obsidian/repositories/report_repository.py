"""Report persistence."""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import func, select

from obsidian.db.models.report import Report
from obsidian.reporting.document import ReportProfile
from obsidian.repositories.base import BaseRepository


class ReportRepository(BaseRepository[Report]):
    model = Report

    async def list_for_case(
        self, case_id: str, *, limit: int, offset: int
    ) -> tuple[Sequence[Report], int]:
        stmt = (
            select(Report)
            .where(Report.case_id == case_id)
            .order_by(Report.created_at.desc())
        )
        count_stmt = select(func.count()).select_from(Report).where(Report.case_id == case_id)
        rows = await self.session.execute(stmt.limit(limit).offset(offset))
        total = await self.session.execute(count_stmt)
        return rows.scalars().all(), int(total.scalar_one())

    async def list_all(
        self, *, limit: int, offset: int, profile: ReportProfile | None = None
    ) -> tuple[Sequence[Report], int]:
        stmt = select(Report)
        count_stmt = select(func.count()).select_from(Report)
        if profile is not None:
            stmt = stmt.where(Report.profile == profile)
            count_stmt = count_stmt.where(Report.profile == profile)
        rows = await self.session.execute(
            stmt.order_by(Report.created_at.desc()).limit(limit).offset(offset)
        )
        total = await self.session.execute(count_stmt)
        return rows.scalars().all(), int(total.scalar_one())
