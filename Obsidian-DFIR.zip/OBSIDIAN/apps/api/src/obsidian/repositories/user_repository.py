"""User persistence."""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import func, select

from obsidian.db.models.user import User
from obsidian.domain.enums import Role
from obsidian.repositories.base import BaseRepository


class UserRepository(BaseRepository[User]):
    model = User

    async def get_by_email(self, email: str) -> User | None:
        """Case-insensitive lookup.

        Email addresses are stored normalised to lowercase, but comparing with
        ``lower()`` on both sides keeps the query correct even for rows written
        before normalisation, and matches user expectations.
        """
        stmt = select(User).where(func.lower(User.email) == email.strip().lower())
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def email_exists(self, email: str) -> bool:
        return await self.get_by_email(email) is not None

    async def list_paginated(
        self, *, limit: int, offset: int, role: Role | None = None
    ) -> tuple[Sequence[User], int]:
        stmt = select(User)
        count_stmt = select(func.count()).select_from(User)
        if role is not None:
            stmt = stmt.where(User.role == role)
            count_stmt = count_stmt.where(User.role == role)

        rows = await self.session.execute(
            stmt.order_by(User.created_at.desc()).limit(limit).offset(offset)
        )
        total = await self.session.execute(count_stmt)
        return rows.scalars().all(), int(total.scalar_one())

    async def count_admins(self) -> int:
        return await self.count(role=Role.ADMIN)
