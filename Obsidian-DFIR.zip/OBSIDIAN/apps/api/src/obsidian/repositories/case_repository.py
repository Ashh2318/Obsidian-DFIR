"""Case persistence."""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import func, or_, select

from obsidian.db.models.case import Case
from obsidian.domain.enums import CaseStatus, Severity
from obsidian.repositories.base import BaseRepository

#: Words that carry no signal in a case title.
_SEARCH_STOPWORDS = frozenset(
    {
        "the", "a", "an", "case", "cases", "investigation", "investigations",
        "one", "that", "this", "for", "and", "with", "about", "open", "show",
        "me", "my", "our", "please",
    }
)


class CaseRepository(BaseRepository[Case]):
    model = Case

    async def get_by_reference(self, reference: str) -> Case | None:
        stmt = select(Case).where(Case.reference == reference)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def next_reference(self, *, year: int) -> str:
        """Allocate the next human-facing reference, e.g. ``OBS-2026-0042``.

        Counting existing rows for the year is adequate at this scale and keeps
        the schema simple. It is not safe under concurrent creation — two
        simultaneous inserts can compute the same number — so the column carries
        a unique constraint and the service retries on collision.
        """
        prefix = f"OBS-{year}-"
        stmt = select(func.count()).select_from(Case).where(Case.reference.startswith(prefix))
        result = await self.session.execute(stmt)
        return f"{prefix}{int(result.scalar_one()) + 1:04d}"

    async def latest(self) -> Case | None:
        """The most recently updated case.

        Backs "the recent case" / "the last one" in speech. Ordering is by
        update rather than creation because the case an analyst means by
        "recent" is the one they last touched, not the one filed last.
        """
        result = await self.session.execute(
            select(Case).order_by(Case.updated_at.desc(), Case.created_at.desc()).limit(1)
        )
        return result.scalar_one_or_none()

    async def find_by_spoken_reference(self, spoken: str) -> list[Case]:
        """Resolve a case from however an analyst said it aloud.

        Speech gives you "case two", "OBS twenty twenty six oh two", or just a
        few words of the title. Requiring the full canonical reference makes the
        feature unusable by voice, so several strategies are tried in order of
        precision and the caller decides what to do when more than one matches.
        """
        needle = spoken.strip().lower()
        if not needle:
            return []

        # 1. Exact reference.
        exact = await self.get_by_reference(needle.upper())
        if exact is not None:
            return [exact]

        # 2. Trailing digits — "case 2", "case 0002", "the last one, 12".
        digits = "".join(ch for ch in needle if ch.isdigit())
        if digits:
            suffix = f"-{int(digits):04d}"
            stmt = select(Case).where(Case.reference.endswith(suffix))
            rows = (await self.session.execute(stmt)).scalars().all()
            if rows:
                return list(rows)

        # 3. Title words. Every remaining word must appear, so "beaconing
        #    finance" narrows the result rather than widening it.
        #
        #    Grammar and framing words are removed first: an analyst says "open
        #    the beaconing case", but no case title contains "the" or "case",
        #    so keeping them guarantees zero matches.
        words = [
            w for w in needle.split() if len(w) > 2 and w not in _SEARCH_STOPWORDS
        ]
        if words:
            stmt = select(Case)
            for word in words[:5]:
                stmt = stmt.where(func.lower(Case.title).like(f"%{word}%"))
            rows = (await self.session.execute(stmt.limit(10))).scalars().all()
            if rows:
                return list(rows)

        return []

    async def search(
        self,
        *,
        limit: int,
        offset: int,
        query: str | None = None,
        status: CaseStatus | None = None,
        severity: Severity | None = None,
        assignee_id: str | None = None,
        owner_id: str | None = None,
    ) -> tuple[Sequence[Case], int]:
        stmt = select(Case)
        count_stmt = select(func.count()).select_from(Case)

        conditions = []
        if query:
            # ILIKE is PostgreSQL-only; lower() + LIKE behaves the same on both
            # dialects (see ADR 0001).
            pattern = f"%{query.strip().lower()}%"
            conditions.append(
                or_(
                    func.lower(Case.title).like(pattern),
                    func.lower(Case.reference).like(pattern),
                    func.lower(func.coalesce(Case.summary, "")).like(pattern),
                )
            )
        if status is not None:
            conditions.append(Case.status == status)
        if severity is not None:
            conditions.append(Case.severity == severity)
        if assignee_id:
            conditions.append(Case.assignee_id == assignee_id)
        if owner_id:
            conditions.append(Case.owner_id == owner_id)

        for condition in conditions:
            stmt = stmt.where(condition)
            count_stmt = count_stmt.where(condition)

        rows = await self.session.execute(
            stmt.order_by(Case.created_at.desc()).limit(limit).offset(offset)
        )
        total = await self.session.execute(count_stmt)
        return rows.scalars().all(), int(total.scalar_one())

    async def count_by_status(self) -> dict[str, int]:
        stmt = select(Case.status, func.count()).group_by(Case.status)
        result = await self.session.execute(stmt)
        return {status.value: count for status, count in result.all()}

    async def count_by_severity(self) -> dict[str, int]:
        stmt = select(Case.severity, func.count()).group_by(Case.severity)
        result = await self.session.execute(stmt)
        return {severity.value: count for severity, count in result.all()}
