"""Enrichment cache persistence."""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import func, select

from obsidian.db.models.enrichment import IOCEnrichment
from obsidian.domain.enums import IOCType, ThreatVerdict
from obsidian.repositories.base import BaseRepository


class EnrichmentRepository(BaseRepository[IOCEnrichment]):
    model = IOCEnrichment

    async def find(self, ioc_type: IOCType, value: str) -> IOCEnrichment | None:
        stmt = select(IOCEnrichment).where(
            IOCEnrichment.ioc_type == ioc_type, IOCEnrichment.value == value
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def find_many(
        self, pairs: list[tuple[IOCType, str]]
    ) -> dict[tuple[str, str], IOCEnrichment]:
        """Fetch several cached verdicts in one round trip.

        Enriching a page of indicators one query at a time is the classic N+1;
        the list view needs them all at once.
        """
        if not pairs:
            return {}
        values = list({value for _, value in pairs})
        stmt = select(IOCEnrichment).where(IOCEnrichment.value.in_(values))
        rows = (await self.session.execute(stmt)).scalars().all()
        return {(row.ioc_type.value, row.value): row for row in rows}

    async def list_recent(
        self, *, limit: int, offset: int, verdict: ThreatVerdict | None = None
    ) -> tuple[Sequence[IOCEnrichment], int]:
        stmt = select(IOCEnrichment)
        count_stmt = select(func.count()).select_from(IOCEnrichment)
        if verdict is not None:
            stmt = stmt.where(IOCEnrichment.verdict == verdict)
            count_stmt = count_stmt.where(IOCEnrichment.verdict == verdict)

        rows = await self.session.execute(
            stmt.order_by(IOCEnrichment.score.desc(), IOCEnrichment.fetched_at.desc())
            .limit(limit)
            .offset(offset)
        )
        total = await self.session.execute(count_stmt)
        return rows.scalars().all(), int(total.scalar_one())

    async def count_by_verdict(self) -> dict[str, int]:
        stmt = select(IOCEnrichment.verdict, func.count()).group_by(IOCEnrichment.verdict)
        result = await self.session.execute(stmt)
        return {verdict.value: count for verdict, count in result.all()}
