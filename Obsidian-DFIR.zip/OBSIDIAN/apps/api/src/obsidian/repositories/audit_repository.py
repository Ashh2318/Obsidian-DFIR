"""Audit trail persistence — append and read only, by design."""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import func, select

from obsidian.db.models.audit_log import AuditLog
from obsidian.domain.enums import AuditAction
from obsidian.repositories.base import BaseRepository


class AuditRepository(BaseRepository[AuditLog]):
    model = AuditLog

    # Deliberately no update() and no delete(): the base class provides
    # delete(), and it must never be called for this aggregate. Any future
    # retention policy belongs in an out-of-band archival job, not here.

    async def list_paginated(
        self,
        *,
        limit: int,
        offset: int,
        actor_id: str | None = None,
        action: AuditAction | None = None,
    ) -> tuple[Sequence[AuditLog], int]:
        stmt = select(AuditLog)
        count_stmt = select(func.count()).select_from(AuditLog)
        if actor_id:
            stmt = stmt.where(AuditLog.actor_id == actor_id)
            count_stmt = count_stmt.where(AuditLog.actor_id == actor_id)
        if action:
            stmt = stmt.where(AuditLog.action == action)
            count_stmt = count_stmt.where(AuditLog.action == action)

        rows = await self.session.execute(
            stmt.order_by(AuditLog.created_at.desc()).limit(limit).offset(offset)
        )
        total = await self.session.execute(count_stmt)
        return rows.scalars().all(), int(total.scalar_one())
