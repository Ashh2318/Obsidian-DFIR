"""Refresh token persistence, including family-wide revocation."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import delete, select, update

from obsidian.db.models.refresh_token import RefreshToken
from obsidian.repositories.base import BaseRepository


class RefreshTokenRepository(BaseRepository[RefreshToken]):
    model = RefreshToken

    async def get_by_hash(self, token_hash: str) -> RefreshToken | None:
        stmt = select(RefreshToken).where(RefreshToken.token_hash == token_hash)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def revoke(
        self, token: RefreshToken, *, reason: str, at: datetime
    ) -> None:
        token.revoked_at = at
        token.revoked_reason = reason
        await self.session.flush()

    async def revoke_family(
        self, family_id: str, *, reason: str, at: datetime
    ) -> int:
        """Revoke every live token descended from one login.

        Invoked when a spent token is replayed: reuse implies the token was
        copied, so every session in that lineage is treated as compromised.
        """
        stmt = (
            update(RefreshToken)
            .where(
                RefreshToken.family_id == family_id,
                RefreshToken.revoked_at.is_(None),
            )
            .values(revoked_at=at, revoked_reason=reason)
        )
        result = await self.session.execute(stmt)
        await self.session.flush()
        return int(result.rowcount or 0)

    async def revoke_all_for_user(
        self, user_id: str, *, reason: str, at: datetime
    ) -> int:
        stmt = (
            update(RefreshToken)
            .where(
                RefreshToken.user_id == user_id,
                RefreshToken.revoked_at.is_(None),
            )
            .values(revoked_at=at, revoked_reason=reason)
        )
        result = await self.session.execute(stmt)
        await self.session.flush()
        return int(result.rowcount or 0)

    async def purge_expired(self, *, before: datetime) -> int:
        """Delete tokens that expired before ``before``.

        Without periodic pruning this table grows without bound; it is the one
        place in the schema with guaranteed unbounded insert volume.
        """
        stmt = delete(RefreshToken).where(RefreshToken.expires_at < before)
        result = await self.session.execute(stmt)
        await self.session.flush()
        return int(result.rowcount or 0)
