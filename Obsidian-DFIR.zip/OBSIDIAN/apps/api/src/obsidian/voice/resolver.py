"""Intent execution.

Every branch below calls the *same service* the UI calls. That is the seam
reserved in ADR 0004: voice is a second entry point to existing behaviour, never
a parallel implementation of it. If voice could do something the UI could not,
the two would drift and only one would be tested.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from obsidian.core.exceptions import ObsidianError
from obsidian.core.logging import get_logger
from obsidian.db.models.user import User
from obsidian.domain.enums import (
    CaseStatus,
    IntentAction,
    Severity,
)
from obsidian.reporting.document import ReportFormat, ReportProfile
from obsidian.repositories.case_repository import CaseRepository
from obsidian.repositories.evidence_repository import EvidenceRepository
from obsidian.repositories.ioc_repository import IOCRepository
from obsidian.services.analysis_service import AnalysisService
from obsidian.services.audit_service import RequestContext
from obsidian.services.case_service import CaseService
from obsidian.services.enrichment_service import EnrichmentService
from obsidian.services.report_service import ReportService
from obsidian.voice.intents import Intent

logger = get_logger(__name__)

HELP_TEXT = (
    "You can ask me to open a case by reference, list cases by severity or "
    "status, summarise the current case, change its status, analyse its "
    "evidence, list or enrich indicators, generate a report, or navigate to any "
    "module. You can also ask what the findings are, say upload evidence to "
    "open the uploader, or ask a question about the case and I will answer from "
    "its evidence."
)


@dataclass(slots=True)
class IntentResult:
    """Outcome of executing an intent.

    ``speech`` is written to be *heard*: short sentences, no markdown, numbers
    spoken naturally. ``ui_action`` lets the client navigate or refresh in step
    with what was said, so the screen and the voice never disagree.
    """

    intent: Intent
    speech: str
    ui_action: dict[str, Any] | None = None
    data: dict[str, Any] = field(default_factory=dict)
    succeeded: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "intent": self.intent.to_dict(),
            "speech": self.speech,
            "ui_action": self.ui_action,
            "data": self.data,
            "succeeded": self.succeeded,
        }


def _plural(count: int, singular: str, plural: str | None = None) -> str:
    return f"{count} {singular if count == 1 else (plural or singular + 's')}"


class IntentResolver:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._cases = CaseRepository(session)
        self._evidence = EvidenceRepository(session)
        self._iocs = IOCRepository(session)

    async def resolve(
        self,
        intent: Intent,
        *,
        actor: User,
        context: RequestContext | None = None,
    ) -> IntentResult:
        try:
            return await self._dispatch(intent, actor=actor, context=context)
        except ObsidianError as exc:
            # Spoken back rather than raised: a voice interface that returns an
            # HTTP status to a person is not a voice interface.
            logger.info("voice.intent.refused", action=intent.action.value, error=exc.error_code)
            return IntentResult(intent, exc.message, succeeded=False)

    async def _dispatch(
        self, intent: Intent, *, actor: User, context: RequestContext | None
    ) -> IntentResult:
        action = intent.action

        if action is IntentAction.HELP:
            return IntentResult(intent, HELP_TEXT)

        if action is IntentAction.NAVIGATE:
            route = intent.entities.get("route", "/dashboard")
            name = route.strip("/").replace("-", " ") or "dashboard"
            return IntentResult(
                intent, f"Opening {name}.", ui_action={"type": "navigate", "route": route}
            )

        if action is IntentAction.LIST_CASES:
            return await self._list_cases(intent)

        if action is IntentAction.OPEN_CASE:
            return await self._open_case(intent)

        if action is IntentAction.CASE_SUMMARY:
            return await self._case_summary(intent)

        if action is IntentAction.CHANGE_STATUS:
            return await self._change_status(intent, actor=actor, context=context)

        if action is IntentAction.ANALYZE_EVIDENCE:
            return await self._analyze(intent, actor=actor, context=context)

        if action is IntentAction.LIST_IOCS:
            return await self._list_iocs(intent)

        if action is IntentAction.LIST_FINDINGS:
            return await self._list_findings(intent)

        if action is IntentAction.UPLOAD_EVIDENCE:
            return await self._upload_evidence(intent)

        if action is IntentAction.ENRICH_IOCS:
            return await self._enrich(intent, actor=actor, context=context)

        if action is IntentAction.GENERATE_REPORT:
            return await self._generate_report(intent, actor=actor, context=context)

        if action is IntentAction.OFF_TOPIC:
            return IntentResult(
                intent,
                "Sorry, I cannot help with that. I only work with security "
                "investigations in OBSIDIAN — cases, evidence, findings, "
                "indicators and reports.",
                succeeded=False,
            )

        if action is IntentAction.FOLLOW_UP:
            return await self._follow_up(intent)

        if action is IntentAction.ASK_ASSISTANT:
            question = intent.entities.get("question", intent.utterance)
            return IntentResult(
                intent,
                "Let me look at the case evidence.",
                ui_action={"type": "ask_assistant", "question": question,
                           "case_id": intent.entities.get("case_id")},
            )

        # Reached only for an empty or unparseable utterance; everything else
        # is now routed to the assistant.
        return IntentResult(
            intent,
            "I did not catch that. Could you say it again?",
            succeeded=False,
        )

    @staticmethod
    def _ambiguous(intent: Intent, candidates: list) -> IntentResult:
        """Ask which case, rather than picking one."""
        listed = ", ".join(f"{c.reference}, {c.title}" for c in candidates[:4])
        return IntentResult(
            intent,
            f"I found {len(candidates)} matching cases: {listed}. "
            "Which one do you mean? Give me the full reference.",
            data={"candidates": [{"id": c.id, "reference": c.reference} for c in candidates]},
            succeeded=False,
        )

    async def _follow_up(self, intent: Intent) -> IntentResult:
        """Continue the previous exchange.

        Open-ended continuations are routed to the assistant, which is already
        grounded in the case evidence. Re-implementing "explain that" in the
        rule engine would be a worse copy of something that already exists.
        """
        case, _ = await self._resolve_case(intent)
        previous = intent.entities.get("previous_subject")
        question = intent.entities.get("question", intent.utterance)

        if case is None:
            return IntentResult(
                intent,
                "I have lost track of which case we were discussing. "
                "Open one, or tell me its reference.",
                succeeded=False,
            )

        # The previous subject is prepended so the assistant knows what "that"
        # referred to; the pronoun alone carries no meaning across a turn.
        grounded = (
            f"Regarding {previous}: {question}" if previous else question
        )
        return IntentResult(
            intent,
            "Let me expand on that.",
            ui_action={
                "type": "ask_assistant",
                "question": grounded,
                "case_id": case.id,
            },
            data={"case_id": case.id, "question": grounded},
        )

    # ── Case resolution ──────────────────────────────────────────────────────
    async def _resolve_case(self, intent: Intent):
        """Find the case an utterance refers to.

        Returns ``(case, candidates)``. When several cases match a partial
        spoken reference the caller is given all of them, so it can ask which
        one rather than silently acting on the wrong investigation — the worst
        possible outcome for a command that changes state.
        """
        reference = intent.entities.get("case_reference")
        if reference:
            return await self._cases.get_by_reference(reference), []

        spoken = intent.entities.get("spoken_reference")
        if spoken:
            matches = await self._cases.find_by_spoken_reference(spoken)
            if len(matches) == 1:
                return matches[0], []
            if len(matches) > 1:
                return None, matches

        case_id = intent.entities.get("case_id")
        if case_id:
            return await self._cases.get(case_id), []

        # "the recent case", "the latest one". Deliberately last: an explicit
        # reference always wins, and this only fires when the analyst gave no
        # other way to identify the case.
        if intent.entities.get("relative"):
            latest = await self._cases.latest()
            if latest is not None:
                return latest, []
        return None, []

    async def _list_cases(self, intent: Intent) -> IntentResult:
        severity = intent.entities.get("severity")
        status = intent.entities.get("status")
        cases, total = await self._cases.search(
            limit=10,
            offset=0,
            severity=Severity(severity) if severity else None,
            status=CaseStatus(status) if status else None,
        )
        qualifier = " ".join(filter(None, [severity, status])).replace("_", " ")
        if total == 0:
            return IntentResult(
                intent,
                f"There are no {qualifier} cases." if qualifier else "There are no cases.",
                ui_action={"type": "navigate", "route": "/cases"},
            )

        lead = cases[0]
        speech = (
            f"There {'is' if total == 1 else 'are'} {_plural(total, 'case')}"
            f"{' matching ' + qualifier if qualifier else ''}. "
            f"The most recent is {lead.reference}, {lead.title}, "
            f"severity {lead.severity.value}."
        )
        return IntentResult(
            intent,
            speech,
            ui_action={"type": "navigate", "route": "/cases"},
            data={"total": total, "cases": [c.reference for c in cases]},
        )

    async def _open_case(self, intent: Intent) -> IntentResult:
        case, candidates = await self._resolve_case(intent)
        if candidates:
            return self._ambiguous(intent, candidates)
        if case is None:
            # A miss is usually a mis-transcription, not a wrong request: the
            # recogniser hears "3D Intel" for "threat intel" and no amount of
            # matching will recover it. Ending on a flat refusal left the
            # analyst with nothing to act on, so the cases that *do* exist are
            # offered instead — that answers the question they were asking.
            cases, total = await self._cases.search(limit=3, offset=0)
            if total == 0:
                return IntentResult(
                    intent,
                    "There are no cases yet. Say create a case to start one.",
                    ui_action={"type": "navigate", "route": "/cases"},
                    succeeded=False,
                )
            listed = "; ".join(f"{c.reference}, {c.title}" for c in cases)
            return IntentResult(
                intent,
                f"I did not recognise that. {_plural(total, 'case')} open: "
                f"{listed}. Say the reference, or the last digits.",
                ui_action={"type": "navigate", "route": "/cases"},
                data={"cases": [c.reference for c in cases]},
                succeeded=False,
            )
        return IntentResult(
            intent,
            f"Opening {case.reference}. {case.title}. "
            f"Status {case.status.value.replace('_', ' ')}, "
            f"severity {case.severity.value}.",
            ui_action={"type": "navigate", "route": f"/cases/{case.id}"},
            data={"case_id": case.id, "reference": case.reference},
        )

    async def _case_summary(self, intent: Intent) -> IntentResult:
        case, candidates = await self._resolve_case(intent)
        if candidates:
            return self._ambiguous(intent, candidates)
        if case is None:
            return IntentResult(
                intent, "I need to know which case. Open one first, or say its reference.",
                succeeded=False,
            )

        artefacts, evidence_total = await self._evidence.list_for_case(
            case.id, limit=100, offset=0
        )
        findings = [
            finding
            for artefact in artefacts
            for finding in (artefact.analysis_summary or {}).get("findings", [])
        ]
        _iocs, ioc_total = await self._iocs.search(limit=1, offset=0, case_id=case.id)
        peak = max(
            (int((a.analysis_summary or {}).get("risk_score", 0)) for a in artefacts),
            default=0,
        )

        parts = [
            f"{case.reference}. {case.title}.",
            f"Status {case.status.value.replace('_', ' ')}, severity {case.severity.value}.",
            f"{_plural(evidence_total, 'evidence item')}, "
            f"{_plural(len(findings), 'finding')}, "
            f"{_plural(ioc_total, 'indicator')}.",
        ]
        if findings:
            worst = max(findings, key=lambda f: Severity(f.get("severity", "info")).rank)
            parts.append(
                f"Highest risk {peak} out of 100. "
                f"The most severe finding is {worst.get('title', 'unnamed')}, "
                f"at {worst.get('confidence', 0)} percent confidence."
            )
        elif evidence_total:
            parts.append("No detections have been raised yet.")
        else:
            parts.append("No evidence has been collected yet.")

        return IntentResult(
            intent,
            " ".join(parts),
            ui_action={"type": "navigate", "route": f"/cases/{case.id}"},
            data={"case_id": case.id, "risk_score": peak, "findings": len(findings)},
        )

    async def _change_status(
        self, intent: Intent, *, actor: User, context: RequestContext | None
    ) -> IntentResult:
        case, candidates = await self._resolve_case(intent)
        if candidates:
            return self._ambiguous(intent, candidates)
        if case is None:
            return IntentResult(
                intent, "I need to know which case to change.", succeeded=False
            )
        target = intent.entities.get("status")
        if not target:
            return IntentResult(intent, "I did not catch the new status.", succeeded=False)

        previous = case.status.value
        updated = await CaseService(self._session).change_status(
            actor=actor, case_id=case.id, target=CaseStatus(target), context=context
        )
        return IntentResult(
            intent,
            f"{updated.reference} moved from {previous.replace('_', ' ')} to "
            f"{updated.status.value.replace('_', ' ')}.",
            ui_action={"type": "refresh", "route": f"/cases/{case.id}"},
            data={"case_id": case.id, "status": updated.status.value},
        )

    async def _analyze(
        self, intent: Intent, *, actor: User, context: RequestContext | None
    ) -> IntentResult:
        case, candidates = await self._resolve_case(intent)
        if candidates:
            return self._ambiguous(intent, candidates)
        if case is None:
            return IntentResult(intent, "I need to know which case.", succeeded=False)

        artefacts, _ = await self._evidence.list_for_case(case.id, limit=50, offset=0)
        pending = [a for a in artefacts if a.status.value != "analyzed"]
        if not artefacts:
            return IntentResult(
                intent, "That case has no evidence to analyse.", succeeded=False
            )
        if not pending:
            return IntentResult(intent, "All evidence on that case is already analysed.")

        service = AnalysisService(self._session)
        analysed, failed = 0, 0
        findings = 0
        for artefact in pending:
            try:
                result = await service.analyze(
                    actor=actor, evidence_id=artefact.id, context=context
                )
                analysed += 1
                findings += len((result.analysis_summary or {}).get("findings", []))
            except ObsidianError:
                # One unsupported artefact must not abort the batch.
                failed += 1

        speech = f"Analysed {_plural(analysed, 'artefact')}, raising {_plural(findings, 'finding')}."
        if failed:
            speech += f" {_plural(failed, 'artefact')} had no available engine."
        return IntentResult(
            intent,
            speech,
            ui_action={"type": "refresh", "route": f"/cases/{case.id}"},
            data={"analysed": analysed, "failed": failed, "findings": findings},
        )

    async def _list_iocs(self, intent: Intent) -> IntentResult:
        case, candidates = await self._resolve_case(intent)
        if candidates:
            return self._ambiguous(intent, candidates)
        case_id = case.id if case else None
        iocs, total = await self._iocs.search(limit=5, offset=0, case_id=case_id)
        if total == 0:
            return IntentResult(
                intent,
                "No indicators have been extracted yet."
                if case
                else "No indicators have been extracted on any case.",
                ui_action={"type": "navigate", "route": "/iocs"},
            )
        top = ", ".join(i.value for i in iocs[:3])
        return IntentResult(
            intent,
            f"{_plural(total, 'indicator')} extracted. The most frequent are {top}.",
            ui_action={"type": "navigate", "route": "/iocs"},
            data={"total": total},
        )

    async def _list_findings(self, intent: Intent) -> IntentResult:
        """Read stored analysis findings back.

        Answered from the database rather than the model: findings are already
        structured, and reading them verbatim is both faster and more
        trustworthy than asking a model to paraphrase them. The payload carries
        the full set so the client can chart severity alongside the speech.
        """
        case, candidates = await self._resolve_case(intent)
        if candidates:
            return self._ambiguous(intent, candidates)
        if case is None:
            return IntentResult(
                intent,
                "Tell me which case, and I will read back its findings.",
                succeeded=False,
            )

        items, _ = await self._evidence.list_for_case(case.id, limit=100, offset=0)
        analysed = [e for e in items if e.analysis_summary]
        findings: list[dict[str, Any]] = []
        for ev in analysed:
            summary = ev.analysis_summary or {}
            for f in summary.get("findings", []) or []:
                findings.append(
                    {
                        "evidence_id": ev.id,
                        "evidence": ev.original_filename,
                        "title": f.get("title") or "Finding",
                        "severity": (f.get("severity") or "info").lower(),
                        "detail": f.get("description") or "",
                        "category": f.get("category") or "",
                        "confidence": f.get("confidence"),
                        "mitre": f.get("mitre_techniques") or [],
                    }
                )

        route = f"/cases/{case.id}"
        if not items:
            return IntentResult(
                intent,
                f"{case.title} has no evidence attached yet. "
                "Say upload evidence and I will open the uploader.",
                ui_action={"type": "navigate", "route": route},
                data={"case_id": case.id, "findings": []},
            )
        if not analysed:
            return IntentResult(
                intent,
                f"{_plural(len(items), 'artefact')} attached, none analysed yet. "
                "Say analyse the evidence and I will run it.",
                ui_action={"type": "navigate", "route": route},
                data={"case_id": case.id, "findings": []},
            )
        if not findings:
            return IntentResult(
                intent,
                f"Analysis completed on {_plural(len(analysed), 'artefact')} "
                "and raised no findings.",
                ui_action={"type": "findings", "route": route, "case_id": case.id},
                data={"case_id": case.id, "findings": []},
            )

        order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        findings.sort(key=lambda f: order.get(f["severity"], 5))
        counts: dict[str, int] = {}
        for f in findings:
            counts[f["severity"]] = counts.get(f["severity"], 0) + 1

        breakdown = ", ".join(
            f"{count} {sev}" for sev, count in sorted(counts.items(), key=lambda kv: order.get(kv[0], 5))
        )
        headline = findings[0]
        speech = (
            f"{_plural(len(findings), 'finding')} across "
            f"{_plural(len(analysed), 'artefact')}: {breakdown}. "
            f"The most severe is {headline['title']} in {headline['evidence']}."
        )
        return IntentResult(
            intent,
            speech,
            # A dedicated action rather than a bare navigate: the client renders
            # these findings immediately instead of leaving the analyst on a
            # page with no explanation of what was just said.
            ui_action={"type": "findings", "route": route, "case_id": case.id},
            data={
                "case_id": case.id,
                "case_title": case.title,
                "findings": findings,
                "severity_counts": counts,
                "analysed": len(analysed),
                "evidence_total": len(items),
            },
        )

    async def _upload_evidence(self, intent: Intent) -> IntentResult:
        """Open the uploader for a case.

        Voice can carry the analyst all the way to the file dialog but not
        through it: choosing a file requires a real user gesture that no script
        is allowed to synthesise. Saying so plainly is better than implying the
        upload happened.
        """
        case, candidates = await self._resolve_case(intent)
        if candidates:
            return self._ambiguous(intent, candidates)
        if case is None:
            return IntentResult(
                intent,
                "Which case should the evidence go to?",
                succeeded=False,
            )
        return IntentResult(
            intent,
            f"Opening the uploader for {case.title}. Choose the file and I will "
            "hash it, record custody, and analyse it.",
            ui_action={
                "type": "upload_evidence",
                "route": f"/cases/{case.id}",
                "case_id": case.id,
            },
            data={"case_id": case.id},
        )

    async def _enrich(
        self, intent: Intent, *, actor: User, context: RequestContext | None
    ) -> IntentResult:
        case, candidates = await self._resolve_case(intent)
        if candidates:
            return self._ambiguous(intent, candidates)
        if case is None:
            return IntentResult(
                intent, "I need to know which case to enrich.", succeeded=False
            )
        enrichments = await EnrichmentService(self._session).enrich_case(
            actor=actor, case_id=case.id, limit=25, context=context
        )
        if not enrichments:
            return IntentResult(intent, "That case has no indicators to enrich.")

        malicious = sum(1 for e in enrichments if e.verdict.value == "malicious")
        suspicious = sum(1 for e in enrichments if e.verdict.value == "suspicious")
        speech = f"Checked {_plural(len(enrichments), 'indicator')}."
        if malicious:
            speech += f" {_plural(malicious, 'indicator')} confirmed malicious."
        if suspicious:
            speech += f" {_plural(suspicious, 'indicator')} flagged suspicious."
        if not malicious and not suspicious:
            speech += " None were flagged."
        return IntentResult(
            intent,
            speech,
            ui_action={"type": "navigate", "route": "/threat-intel"},
            data={"checked": len(enrichments), "malicious": malicious},
        )

    async def _generate_report(
        self, intent: Intent, *, actor: User, context: RequestContext | None
    ) -> IntentResult:
        case, candidates = await self._resolve_case(intent)
        if candidates:
            return self._ambiguous(intent, candidates)
        if case is None:
            return IntentResult(
                intent, "I need to know which case to report on.", succeeded=False
            )
        profile = ReportProfile(intent.entities.get("profile", "technical"))
        fmt = ReportFormat(intent.entities.get("format", "pdf"))

        report = await ReportService(self._session).generate(
            actor=actor, case_id=case.id, profile=profile, fmt=fmt, context=context
        )
        return IntentResult(
            intent,
            f"{profile.value.title()} report generated for {case.reference} "
            f"as {fmt.value}. It is ready to download.",
            ui_action={"type": "navigate", "route": "/reports"},
            data={"report_id": report.id, "signature": report.signature},
        )
