"""Utterance parsing.

Deterministic patterns are tried before any model. Three reasons:

* **Latency.** A spoken command should act immediately; a round trip to a
  language model makes voice feel slower than the mouse it replaces.
* **Predictability.** "Close this case" must mean the same thing every time. A
  classifier that occasionally decides otherwise is unusable for an action that
  mutates state.
* **Offline.** The platform runs air-gapped, where no model may be available.

The model handles only what the patterns miss, and its results are marked
INFERRED so the caller can require confirmation before acting.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from obsidian.domain.enums import (
    CaseStatus,
    IntentAction,
    IntentConfidence,
    Severity,
)

CASE_REFERENCE_RE = re.compile(r"\b(obs)[\s\-]?(\d{4})[\s\-]?(\d{1,4})\b", re.IGNORECASE)

#: Spoken references to whatever the analyst is currently looking at.
DEICTIC_TERMS = ("this", "that", "current", "the current", "it", "here")

ROUTE_KEYWORDS: dict[str, str] = {
    "dashboard": "/dashboard",
    "home": "/dashboard",
    "cases": "/cases",
    "case list": "/cases",
    "evidence": "/evidence",
    "timeline": "/timeline",
    "assistant": "/assistant",
    "ai": "/assistant",
    "threat intel": "/threat-intel",
    "threat intelligence": "/threat-intel",
    "reputation": "/threat-intel",
    "ioc": "/iocs",
    "iocs": "/iocs",
    "indicators": "/iocs",
    "reports": "/reports",
    "users": "/users",
    "settings": "/settings",
}

STATUS_TERMS: dict[str, CaseStatus] = {
    "open": CaseStatus.OPEN,
    "reopen": CaseStatus.OPEN,
    "in progress": CaseStatus.IN_PROGRESS,
    "progress": CaseStatus.IN_PROGRESS,
    "investigating": CaseStatus.IN_PROGRESS,
    "contained": CaseStatus.CONTAINED,
    "contain": CaseStatus.CONTAINED,
    "closed": CaseStatus.CLOSED,
    "close": CaseStatus.CLOSED,
    "archived": CaseStatus.ARCHIVED,
    "archive": CaseStatus.ARCHIVED,
}

SEVERITY_TERMS: dict[str, Severity] = {
    "info": Severity.INFO,
    "informational": Severity.INFO,
    "low": Severity.LOW,
    "medium": Severity.MEDIUM,
    "high": Severity.HIGH,
    "critical": Severity.CRITICAL,
}


@dataclass(slots=True)
class Intent:
    """A parsed command, before execution."""

    action: IntentAction
    confidence: IntentConfidence
    utterance: str
    entities: dict[str, Any] = field(default_factory=dict)
    #: True when the action mutates state and was only inferred, so the caller
    #: should read the interpretation back and wait rather than acting.
    needs_confirmation: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action.value,
            "confidence": self.confidence.value,
            "utterance": self.utterance,
            "entities": self.entities,
            "needs_confirmation": self.needs_confirmation,
        }


#: Actions that only make sense against a specific case. When the analyst is
#: viewing one and does not name another, that case is what they mean — saying
#: "analyse the evidence" while looking at a case should not require the word
#: "this" to be understood.
CASE_SCOPED_ACTIONS = frozenset(
    {
        IntentAction.OPEN_CASE,
        IntentAction.CASE_SUMMARY,
        IntentAction.CHANGE_STATUS,
        IntentAction.ANALYZE_EVIDENCE,
        IntentAction.ENRICH_IOCS,
        IntentAction.GENERATE_REPORT,
        IntentAction.LIST_IOCS,
        IntentAction.LIST_FINDINGS,
        IntentAction.UPLOAD_EVIDENCE,
        IntentAction.ASK_ASSISTANT,
        IntentAction.FOLLOW_UP,
    }
)

MUTATING_ACTIONS = frozenset(
    {
        IntentAction.CHANGE_STATUS,
        IntentAction.ANALYZE_EVIDENCE,
        IntentAction.ENRICH_IOCS,
        IntentAction.GENERATE_REPORT,
    }
)


def normalise(utterance: str) -> str:
    """Lowercase, strip the wake word, and collapse whitespace.

    Speech recognisers punctuate inconsistently, so punctuation is dropped
    except within case references.
    """
    text = utterance.strip().lower()
    text = re.sub(r"^(hey |ok |okay |hi )?obsidian[,.\s]*", "", text)
    text = re.sub(r"[^\w\s\-]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def extract_case_reference(text: str) -> str | None:
    """Recover a case reference, tolerating how speech engines render it.

    "OBS 2026 1" and "obs-2026-0001" are the same case; the recogniser decides
    which one you get.
    """
    match = CASE_REFERENCE_RE.search(text)
    if match is None:
        return None
    return f"OBS-{match.group(2)}-{int(match.group(3)):04d}"


def refers_to_current(text: str) -> bool:
    return any(re.search(rf"\b{term}\b", text) for term in DEICTIC_TERMS)


def _extract_status(text: str) -> CaseStatus | None:
    # Longest first, so "in progress" is not shadowed by "progress".
    for term in sorted(STATUS_TERMS, key=len, reverse=True):
        if re.search(rf"\b{re.escape(term)}\b", text):
            return STATUS_TERMS[term]
    return None


def _extract_severity(text: str) -> Severity | None:
    for term, severity in SEVERITY_TERMS.items():
        if re.search(rf"\b{term}\b", text):
            return severity
    return None


def _extract_route(text: str) -> str | None:
    for keyword in sorted(ROUTE_KEYWORDS, key=len, reverse=True):
        if re.search(rf"\b{re.escape(keyword)}\b", text):
            return ROUTE_KEYWORDS[keyword]
    return None


#: Phrases that continue the previous exchange rather than starting a new one.
#: Without these, "tell me more about that" is parsed as gibberish and the
#: conversation dead-ends after a single turn — which is not a conversation.
FOLLOW_UP_PATTERNS = (
    r"\b(tell me more|more about|go on|continue|elaborate|expand)\b",
    r"\b(what about|how about)\b",
    r"\b(why (is|was|did|does)|explain)\b.*\b(that|it|this)\b",
    r"^\s*(and|so|but)\b",
    r"\b(say (that )?again|repeat)\b",
)


def is_follow_up(text: str) -> bool:
    return any(re.search(pattern, text) for pattern in FOLLOW_UP_PATTERNS)


#: Subjects plainly outside an investigation platform. Kept deliberately narrow:
#: the cost of wrongly refusing a real security question is far higher than the
#: cost of politely answering an odd one, so only unambiguous signals appear
#: here. Anything not matched falls through to the case-grounded assistant.
OFF_TOPIC_PATTERNS = (
    r"\b(weather|forecast|temperature outside|raining)\b",
    r"\b(joke|funny|meme|riddle|poem|song lyrics|sing)\b",
    r"\b(recipe|cook|cooking|restaurant|pizza|food delivery)\b",
    r"\b(football|cricket|basketball|match score|world cup|olympics)\b",
    r"\b(movie|netflix|tv show|celebrity|actor|actress)\b",
    r"\b(stock price|bitcoin price|crypto price|invest in)\b",
    r"\b(who is the (president|prime minister|king|queen))\b",
    r"\b(translate .* (to|into) (spanish|french|german|hindi|chinese))\b",
    r"\b(capital of|population of|how tall is|how far is)\b",
    r"\b(dating|relationship advice|horoscope|astrology)\b",
)


def is_off_topic(text: str) -> bool:
    """True only for subjects unmistakably outside the platform's remit."""
    return any(re.search(pattern, text) for pattern in OFF_TOPIC_PATTERNS)


def parse(
    utterance: str,
    *,
    current_case_id: str | None = None,
    last_action: str | None = None,
    last_subject: str | None = None,
) -> Intent:
    """Match an utterance against known command shapes.

    ``last_action`` and ``last_subject`` carry the previous turn, so a
    continuation like "tell me more about that" resolves against what was just
    discussed instead of being treated as a fresh, meaningless command.
    """
    text = normalise(utterance)
    if not text:
        return Intent(IntentAction.UNKNOWN, IntentConfidence.NONE, utterance)

    entities: dict[str, Any] = {}
    reference = extract_case_reference(text)
    if reference:
        entities["case_reference"] = reference
    elif current_case_id and refers_to_current(text):
        entities["case_id"] = current_case_id

    # Whatever followed "case"/"open" is kept verbatim so the resolver can match
    # it against a partial reference or a title — "case two", "the beaconing
    # one". Losing this text here is what forced full references before.
    #
    # A module name is excluded: "open timeline" is navigation, and capturing
    # "timeline" as a case reference sent it to a case lookup that could only
    # ever fail.
    spoken = re.search(
        r"\b(?:case|investigation|open|show|pull up|switch to)\s+(.{2,60})$", text
    )
    if spoken and "case_reference" not in entities:
        candidate = spoken.group(1).strip()
        if _extract_route(candidate) is None:
            entities["spoken_reference"] = candidate

    # "the recent case", "the latest one" — resolved against creation order by
    # the resolver rather than requiring a reference nobody remembers.
    if re.search(r"\b(recent|latest|last|newest|current)\b", text):
        entities["relative"] = "latest"

    def intent(action: IntentAction, **extra: Any) -> Intent:
        entities.update(extra)
        # Fall back to the case in view for anything case-scoped that did not
        # name one explicitly.
        if (
            action in CASE_SCOPED_ACTIONS
            and current_case_id
            and "case_reference" not in entities
            and "case_id" not in entities
        ):
            entities["case_id"] = current_case_id
        return Intent(
            action=action,
            confidence=IntentConfidence.EXACT,
            utterance=utterance,
            entities=entities,
            needs_confirmation=False,
        )

    # Capability enquiries only. A bare \bhelp\b also captured "help me
    # understand this attack", which is a question for the assistant, not a
    # request for the command list.
    if re.search(
        r"(what can you do|what are your (commands|capabilities)"
        r"|^help$|^help me$|list (of )?commands|^commands$"
        r"|how do i use (this|you|obsidian))",
        text,
    ):
        return intent(IntentAction.HELP)

    # A continuation is checked early: "tell me more about that beaconing"
    # contains command-shaped words that would otherwise capture it.
    if is_follow_up(text):
        return intent(
            IntentAction.FOLLOW_UP,
            question=utterance,
            previous_action=last_action,
            previous_subject=last_subject,
        )

    # Report generation before the generic "report" navigation keyword.
    if re.search(r"\b(generate|create|produce|write|make)\b.*\breport\b", text):
        profile = "executive" if "executive" in text or "summary" in text else "technical"
        fmt = "pdf"
        if "markdown" in text or "mark down" in text:
            fmt = "markdown"
        elif "html" in text or "web" in text:
            fmt = "html"
        return intent(IntentAction.GENERATE_REPORT, profile=profile, format=fmt)

    if re.search(r"\b(analyse|analyze|scan|process|examine)\b", text) and re.search(
        r"\b(evidence|pcap|capture|log|artefact|artifact|file|it)\b", text
    ):
        return intent(IntentAction.ANALYZE_EVIDENCE)

    if re.search(r"\b(enrich|reputation|check.*(virustotal|abuse)|look up)\b", text):
        return intent(IntentAction.ENRICH_IOCS)

    # Findings answered from stored analysis rather than handed to the model:
    # they are structured data, and reading them back exactly is both faster
    # and more trustworthy than paraphrasing them.
    if re.search(r"\b(finding|findings|detection|detections|what did you find)\b", text):
        return intent(IntentAction.LIST_FINDINGS)

    if re.search(r"\b(upload|add|attach|ingest|import)\b.*\b(evidence|file|pcap|log|artefact|artifact|capture)\b", text):
        return intent(IntentAction.UPLOAD_EVIDENCE)

    # Stems are left open-ended: "indicator" must also match "indicators",
    # which a trailing \b would prevent.
    if re.search(r"\b(indicators?|iocs?)\b", text) and not re.search(
        r"\b(go to|open|show me the) (ioc|iocs|indicators) (page|screen|module)\b", text
    ):
        return intent(IntentAction.LIST_IOCS)

    if re.search(r"\b(mark|set|move|change|make|close|reopen|contain|archive)\b", text):
        status = _extract_status(text)
        if status is not None:
            return intent(IntentAction.CHANGE_STATUS, status=status.value)

    if re.search(
        r"\b(summar\w*|brief\w*|overview|tell me about|what happened|status of)\b", text
    ):
        return intent(IntentAction.CASE_SUMMARY)

    # Listing is checked before opening, because "show me all critical cases"
    # and "show me case 2" share a verb and only the object distinguishes them.
    # A plural noun or a filter word means the analyst wants the list.
    wants_list = re.search(r"\bcases\b", text) or re.search(
        r"\b(all|every|any)\b.*\bcases?\b", text
    )
    if wants_list and re.search(r"\b(list|show|what|which|find|search|display)\b", text):
        severity = _extract_severity(text)
        status = _extract_status(text)
        extra: dict[str, Any] = {}
        if severity:
            extra["severity"] = severity.value
        if status:
            extra["status"] = status.value
        entities.pop("spoken_reference", None)
        return intent(IntentAction.LIST_CASES, **extra)

    # Navigation is resolved before case opening. Both share the verb "open",
    # and a module name is unambiguous where a case reference is not — so the
    # specific match wins. "Open timeline" previously reached the case lookup
    # and failed with a message about references.
    # The navigation verb is still required. Matching on the module name alone
    # swallowed ordinary sentences that merely mentioned one — "can you get me
    # through the cases" is a question, not a request to open /cases.
    route = _extract_route(text)
    if (
        route
        and not reference
        and re.search(r"\b(go to|open|show|navigate|take me|switch to|jump to|bring up)\b", text)
    ):
        entities.pop("spoken_reference", None)
        return intent(IntentAction.NAVIGATE, route=route)

    # Opening accepts a partial spoken reference, not only a canonical one:
    # "open case two" and "pull up the beaconing case" both have to work, or
    # the feature is unusable by voice.
    if re.search(r"\b(open|show|display|pull up|switch to|go to)\b", text) and (
        reference or entities.get("case_id") or entities.get("spoken_reference")
    ):
        return intent(IntentAction.OPEN_CASE)

    if is_off_topic(text):
        return intent(IntentAction.OFF_TOPIC, question=utterance)

    # Anything left is treated as a question for the assistant, which is already
    # grounded in the case. Refusing to answer because an utterance did not
    # match a command pattern made the system feel broken — "can you get me
    # through the cases" is a perfectly reasonable request, and a rule engine
    # cannot enumerate every phrasing a person will use.
    return intent(IntentAction.ASK_ASSISTANT, question=utterance)
