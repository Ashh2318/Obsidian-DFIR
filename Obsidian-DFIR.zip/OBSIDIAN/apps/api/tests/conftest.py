"""Test fixtures.

Each test runs against a fresh in-memory database. Using ``StaticPool`` with a
shared in-memory URL is what makes that work: without it every connection would
get its own private database and nothing written in a fixture would be visible
to the request under test.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator

os.environ.setdefault("OBSIDIAN_SECRET_KEY", "test-secret-key-at-least-32-characters-long")
os.environ.setdefault("OBSIDIAN_ENVIRONMENT", "test")
os.environ.setdefault("OBSIDIAN_RATE_LIMIT_ENABLED", "false")
os.environ.setdefault("OBSIDIAN_AI_PROVIDER", "mock")
# Forced, not defaulted: a developer with real feed keys in .env would otherwise
# have the suite query live rate-limited APIs and fail on assertions about the
# offline provider. Tests must not depend on local configuration.
os.environ["OBSIDIAN_THREATINTEL_PROVIDERS"] = "mock"
os.environ["OBSIDIAN_VIRUSTOTAL_API_KEY"] = ""
os.environ["OBSIDIAN_ABUSEIPDB_API_KEY"] = ""

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import StaticPool

from obsidian.db.models import Base
from obsidian.db.session import get_session
from obsidian.main import create_app

TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"


@pytest_asyncio.fixture
async def engine():
    eng = create_async_engine(
        TEST_DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    async with eng.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield eng
    await eng.dispose()


@pytest_asyncio.fixture
async def session(engine) -> AsyncIterator[AsyncSession]:
    maker = async_sessionmaker(bind=engine, expire_on_commit=False, autoflush=False)
    async with maker() as s:
        yield s


@pytest_asyncio.fixture
async def client(engine) -> AsyncIterator[AsyncClient]:
    app = create_app()
    maker = async_sessionmaker(bind=engine, expire_on_commit=False, autoflush=False)

    async def _override() -> AsyncIterator[AsyncSession]:
        async with maker() as s:
            try:
                yield s
                await s.commit()
            except Exception:
                await s.rollback()
                raise

    app.dependency_overrides[get_session] = _override
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture
def credentials() -> dict[str, str]:
    return {
        "email": "analyst@obsidian.io",
        "password": "Investigate!2026",
        "full_name": "Test Analyst",
    }


@pytest_asyncio.fixture
async def registered(client: AsyncClient, credentials: dict[str, str]) -> dict:
    response = await client.post("/api/v1/auth/register", json=credentials)
    assert response.status_code == 201, response.text
    return response.json()


@pytest_asyncio.fixture
async def auth(client: AsyncClient, registered: dict, credentials: dict) -> dict:
    response = await client.post(
        "/api/v1/auth/login",
        json={"email": credentials["email"], "password": credentials["password"]},
    )
    assert response.status_code == 200, response.text
    return response.json()


@pytest.fixture
def bearer(auth: dict) -> dict[str, str]:
    return {"Authorization": f"Bearer {auth['tokens']['access_token']}"}
