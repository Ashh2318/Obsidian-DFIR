"""AI assistant tests, with emphasis on case grounding."""

from __future__ import annotations

import io
import json

import pytest
from httpx import AsyncClient

from obsidian.services.context_builder import build_case_context, build_system_prompt
from tests.pcap_builder import build_pcap, build_tcp_packet


@pytest.fixture
async def case(client: AsyncClient, bearer: dict) -> dict:
    response = await client.post(
        "/api/v1/cases",
        json={"title": "Assistant grounding case", "severity": "critical"},
        headers=bearer,
    )
    return response.json()


@pytest.fixture
async def analysed_case(client: AsyncClient, bearer: dict, case: dict) -> dict:
    """A case with a genuinely analysed capture, so context has real findings."""
    frames = [
        (i * 60.0, build_tcp_packet("10.0.0.5", "185.243.115.84", 51000, 443))
        for i in range(15)
    ]
    upload = await client.post(
        f"/api/v1/cases/{case['id']}/evidence",
        files={"file": ("c2.pcap", io.BytesIO(build_pcap(frames)), "application/octet-stream")},
        headers=bearer,
    )
    await client.post(
        f"/api/v1/evidence/{upload.json()['id']}/analyze", headers=bearer
    )
    return case


class TestContextBuilder:
    async def test_context_includes_case_identity(self, session, analysed_case) -> None:
        context = await build_case_context(session, analysed_case["id"])
        assert analysed_case["reference"] in context
        assert "Assistant grounding case" in context
        assert "critical" in context

    async def test_context_includes_findings_and_indicators(
        self, session, analysed_case
    ) -> None:
        context = await build_case_context(session, analysed_case["id"])
        assert "## FINDINGS" in context
        assert "beaconing" in context.lower()
        assert "185.243.115.84" in context
        assert "T1071.001" in context

    async def test_context_states_absence_explicitly(self, session, case) -> None:
        """A model told nothing about evidence will invent some."""
        context = await build_case_context(session, case["id"])
        assert "No evidence has been uploaded" in context
        assert "Do not infer findings that are not listed here." in context

    async def test_unknown_case_yields_empty_context(self, session) -> None:
        assert await build_case_context(session, "does-not-exist") == ""

    def test_system_prompt_says_when_ungrounded(self) -> None:
        prompt = build_system_prompt(None)
        assert "No case is currently attached" in prompt

    def test_system_prompt_forbids_speculation(self) -> None:
        prompt = build_system_prompt("# CASE CONTEXT\nReference: OBS-2026-0001")
        assert "do not invent" in prompt.lower()
        assert "OBS-2026-0001" in prompt


class TestConversations:
    async def test_create_and_fetch(self, client: AsyncClient, bearer: dict, case: dict) -> None:
        created = await client.post(
            "/api/v1/assistant/conversations",
            json={"case_id": case["id"]},
            headers=bearer,
        )
        assert created.status_code == 201
        assert created.json()["case_id"] == case["id"]

        fetched = await client.get(
            f"/api/v1/assistant/conversations/{created.json()['id']}", headers=bearer
        )
        assert fetched.status_code == 200
        assert fetched.json()["messages"] == []

    async def test_conversation_without_a_case_is_allowed(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.post(
            "/api/v1/assistant/conversations", json={}, headers=bearer
        )
        assert response.status_code == 201
        assert response.json()["case_id"] is None

    async def test_another_analyst_cannot_read_your_conversation(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        created = await client.post(
            "/api/v1/assistant/conversations", json={}, headers=bearer
        )
        conversation_id = created.json()["id"]

        await client.post(
            "/api/v1/auth/register",
            json={
                "email": "other@obsidian.io",
                "password": "Investigate!2026",
                "full_name": "Other Analyst",
            },
        )
        login = await client.post(
            "/api/v1/auth/login",
            json={"email": "other@obsidian.io", "password": "Investigate!2026"},
        )
        other = {"Authorization": f"Bearer {login.json()['tokens']['access_token']}"}

        response = await client.get(
            f"/api/v1/assistant/conversations/{conversation_id}", headers=other
        )
        assert response.status_code == 403

    async def test_requires_authentication(self, client: AsyncClient) -> None:
        assert (
            await client.get("/api/v1/assistant/conversations")
        ).status_code == 401


class TestExchange:
    async def test_message_is_persisted_with_provenance(
        self, client: AsyncClient, bearer: dict, analysed_case: dict
    ) -> None:
        conversation = (
            await client.post(
                "/api/v1/assistant/conversations",
                json={"case_id": analysed_case["id"]},
                headers=bearer,
            )
        ).json()

        response = await client.post(
            f"/api/v1/assistant/conversations/{conversation['id']}/messages",
            json={"prompt": "What is the most severe finding on this case?"},
            headers=bearer,
        )
        assert response.status_code == 200
        body = response.json()
        assert body["role"] == "assistant"
        assert body["content"]
        # Provenance matters: a reviewer must be able to tell whether an answer
        # came from a frontier model or the offline stub.
        assert body["provider"] == "mock"
        assert body["model"]

    async def test_history_is_retained(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        conversation = (
            await client.post(
                "/api/v1/assistant/conversations",
                json={"case_id": case["id"]},
                headers=bearer,
            )
        ).json()

        for prompt in ("First question", "Second question"):
            await client.post(
                f"/api/v1/assistant/conversations/{conversation['id']}/messages",
                json={"prompt": prompt},
                headers=bearer,
            )

        detail = await client.get(
            f"/api/v1/assistant/conversations/{conversation['id']}", headers=bearer
        )
        messages = detail.json()["messages"]
        assert len(messages) == 4  # two user turns, two assistant turns
        assert [m["role"] for m in messages] == [
            "user", "assistant", "user", "assistant",
        ]

    async def test_conversation_is_titled_from_the_first_question(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        conversation = (
            await client.post(
                "/api/v1/assistant/conversations",
                json={"case_id": case["id"]},
                headers=bearer,
            )
        ).json()
        assert conversation["title"] == "New conversation"

        await client.post(
            f"/api/v1/assistant/conversations/{conversation['id']}/messages",
            json={"prompt": "Summarise the beaconing activity"},
            headers=bearer,
        )
        detail = await client.get(
            f"/api/v1/assistant/conversations/{conversation['id']}", headers=bearer
        )
        assert detail.json()["title"] == "Summarise the beaconing activity"

    async def test_empty_prompt_is_rejected(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        conversation = (
            await client.post(
                "/api/v1/assistant/conversations", json={}, headers=bearer
            )
        ).json()
        response = await client.post(
            f"/api/v1/assistant/conversations/{conversation['id']}/messages",
            json={"prompt": ""},
            headers=bearer,
        )
        assert response.status_code == 422


class TestStreaming:
    async def test_stream_emits_deltas_then_done(
        self, client: AsyncClient, bearer: dict, analysed_case: dict
    ) -> None:
        conversation = (
            await client.post(
                "/api/v1/assistant/conversations",
                json={"case_id": analysed_case["id"]},
                headers=bearer,
            )
        ).json()

        response = await client.post(
            f"/api/v1/assistant/conversations/{conversation['id']}/stream",
            json={"prompt": "Assess this case"},
            headers=bearer,
        )
        assert response.status_code == 200
        assert response.headers["content-type"].startswith("text/event-stream")

        frames = [
            json.loads(line[5:])
            for line in response.text.splitlines()
            if line.startswith("data:")
        ]
        deltas = [f["delta"] for f in frames if "delta" in f]
        assert deltas, "stream should emit content"
        assert frames[-1].get("done") is True

    async def test_streamed_answer_is_persisted(
        self, client: AsyncClient, bearer: dict, analysed_case: dict
    ) -> None:
        conversation = (
            await client.post(
                "/api/v1/assistant/conversations",
                json={"case_id": analysed_case["id"]},
                headers=bearer,
            )
        ).json()

        response = await client.post(
            f"/api/v1/assistant/conversations/{conversation['id']}/stream",
            json={"prompt": "Assess this case"},
            headers=bearer,
        )
        streamed = "".join(
            json.loads(line[5:])["delta"]
            for line in response.text.splitlines()
            if line.startswith("data:") and "delta" in json.loads(line[5:])
        )

        detail = await client.get(
            f"/api/v1/assistant/conversations/{conversation['id']}", headers=bearer
        )
        messages = detail.json()["messages"]
        assistant = [m for m in messages if m["role"] == "assistant"]
        assert assistant, "the streamed answer must be persisted"
        assert assistant[-1]["content"].split() == streamed.split()
