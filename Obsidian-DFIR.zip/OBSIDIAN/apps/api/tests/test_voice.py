"""Voice Command Mode tests."""

from __future__ import annotations

import io

import pytest
from httpx import AsyncClient
from tests.pcap_builder import build_pcap, build_tcp_packet

from obsidian.domain.enums import IntentAction
from obsidian.voice.intents import (
    extract_case_reference,
    normalise,
    parse,
    refers_to_current,
)


@pytest.fixture
async def rich_case(client: AsyncClient, bearer: dict) -> dict:
    case = (
        await client.post(
            "/api/v1/cases",
            json={"title": "Voice command case", "severity": "high"},
            headers=bearer,
        )
    ).json()
    frames = [
        (i * 60.0, build_tcp_packet("10.0.0.5", "185.243.115.84", 51000, 443))
        for i in range(15)
    ]
    await client.post(
        f"/api/v1/cases/{case['id']}/evidence",
        files={"file": ("c2.pcap", io.BytesIO(build_pcap(frames)), "application/octet-stream")},
        headers=bearer,
    )
    return case


class TestNormalisation:
    @pytest.mark.parametrize(
        "raw",
        [
            "Hey Obsidian, open cases",
            "hey obsidian open cases",
            "Obsidian: open cases",
            "OK Obsidian, open cases",
            "obsidian. open cases",
        ],
    )
    def test_wake_word_is_stripped(self, raw: str) -> None:
        assert normalise(raw) == "open cases"

    def test_punctuation_is_dropped(self) -> None:
        """Speech recognisers punctuate inconsistently."""
        assert normalise("Open cases, please!") == "open cases please"


class TestCaseReferenceExtraction:
    @pytest.mark.parametrize(
        "spoken",
        ["OBS-2026-0001", "obs 2026 0001", "OBS 2026 1", "obs-2026-1"],
    )
    def test_recogniser_variants_resolve_to_one_reference(self, spoken: str) -> None:
        """A recogniser may render the same reference several ways."""
        assert extract_case_reference(spoken.lower()) == "OBS-2026-0001"

    def test_absent_reference_returns_none(self) -> None:
        assert extract_case_reference("summarise this case") is None

    def test_deictic_terms_detected(self) -> None:
        assert refers_to_current("summarise this case")
        assert refers_to_current("close the current case")
        assert not refers_to_current("open case obs 2026 1")


class TestParsing:
    @pytest.mark.parametrize(
        ("utterance", "expected"),
        [
            ("open case obs 2026 1", IntentAction.OPEN_CASE),
            ("show me all critical cases", IntentAction.LIST_CASES),
            ("summarise this case", IntentAction.CASE_SUMMARY),
            ("summarize the current case", IntentAction.CASE_SUMMARY),
            ("give me a brief on this", IntentAction.CASE_SUMMARY),
            ("mark this case as contained", IntentAction.CHANGE_STATUS),
            ("close this case", IntentAction.CHANGE_STATUS),
            ("analyse the pcap", IntentAction.ANALYZE_EVIDENCE),
            ("analyze the evidence", IntentAction.ANALYZE_EVIDENCE),
            ("what indicators did we find", IntentAction.LIST_IOCS),
            ("list the iocs", IntentAction.LIST_IOCS),
            ("check reputation", IntentAction.ENRICH_IOCS),
            ("generate an executive report", IntentAction.GENERATE_REPORT),
            ("go to the timeline", IntentAction.NAVIGATE),
            ("what can you do", IntentAction.HELP),
            # Contains "this", so it continues the previous turn. Both this
            # and ASK_ASSISTANT reach the assistant; FOLLOW_UP additionally
            # grounds the pronoun against what was just discussed.
            ("why is this beaconing suspicious", IntentAction.FOLLOW_UP),
            ("what is a beacon", IntentAction.ASK_ASSISTANT),
        ],
    )
    def test_utterances_map_to_intents(self, utterance: str, expected: IntentAction) -> None:
        assert parse(utterance, current_case_id="c1").action is expected

    def test_status_entity_extracted(self) -> None:
        intent = parse("mark this as in progress", current_case_id="c1")
        assert intent.entities["status"] == "in_progress"

    def test_longest_status_term_wins(self) -> None:
        """'in progress' must not be shadowed by 'progress'."""
        assert parse("move this to in progress", current_case_id="c1").entities["status"] == "in_progress"

    def test_report_profile_and_format_extracted(self) -> None:
        intent = parse("generate an executive report as markdown")
        assert intent.entities["profile"] == "executive"
        assert intent.entities["format"] == "markdown"

    def test_report_defaults_to_technical_pdf(self) -> None:
        intent = parse("generate a report")
        assert intent.entities["profile"] == "technical"
        assert intent.entities["format"] == "pdf"

    def test_context_supplies_the_case(self) -> None:
        intent = parse("summarise this case", current_case_id="case-abc")
        assert intent.entities["case_id"] == "case-abc"

    def test_no_context_leaves_the_case_unresolved(self) -> None:
        assert "case_id" not in parse("summarise this case").entities

    def test_unmatched_phrasing_reaches_the_assistant(self) -> None:
        """A rule engine cannot enumerate every phrasing a person will use.

        Refusing anything that did not match a command pattern made the system
        feel broken — "can you get me through the cases" is a reasonable
        request. Unmatched input is now answered from case context instead.
        """
        for utterance in (
            "can you get me through the cases",
            "banana turnip velocity",
            "what should I look at first",
        ):
            assert parse(utterance).action is IntentAction.ASK_ASSISTANT

    @pytest.mark.parametrize(
        "utterance",
        [
            "what is the weather today",
            "tell me a joke",
            "who is the prime minister of India",
            "give me a pizza recipe",
        ],
    )
    def test_off_topic_is_identified(self, utterance: str) -> None:
        assert parse(utterance).action is IntentAction.OFF_TOPIC

    def test_security_questions_are_not_off_topic(self) -> None:
        """Wrongly refusing a real question costs far more than answering an odd one."""
        for utterance in (
            "what is a beacon",
            "help me understand this attack",
            "why does dns tunnelling matter",
            "explain lateral movement",
        ):
            assert parse(utterance).action is not IntentAction.OFF_TOPIC

    def test_empty_utterance_is_unknown(self) -> None:
        assert parse("   ").action is IntentAction.UNKNOWN


class TestVoiceAPI:
    async def test_capabilities_are_listed(self, client: AsyncClient, bearer: dict) -> None:
        response = await client.get("/api/v1/voice/capabilities", headers=bearer)
        assert response.status_code == 200
        body = response.json()
        assert body["wake_word"] == "Hey Obsidian"
        assert "open_case" in body["actions"]
        assert body["examples"]

    async def test_dry_run_interprets_without_acting(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={
                "utterance": "close this case",
                "current_case_id": rich_case["id"],
                "dry_run": True,
            },
            headers=bearer,
        )
        assert response.json()["intent"]["action"] == "change_status"

        # The case must be untouched.
        case = await client.get(f"/api/v1/cases/{rich_case['id']}", headers=bearer)
        assert case.json()["status"] == "open"

    async def test_command_executes_the_real_service(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        """Voice must go through the same path as the UI, not a parallel one."""
        response = await client.post(
            "/api/v1/voice/command",
            json={
                "utterance": "mark this case as in progress",
                "current_case_id": rich_case["id"],
            },
            headers=bearer,
        )
        assert response.json()["succeeded"] is True

        case = await client.get(f"/api/v1/cases/{rich_case['id']}", headers=bearer)
        assert case.json()["status"] == "in_progress"

    async def test_invalid_transition_is_spoken_not_raised(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        """A voice interface returning an HTTP error to a person is not one."""
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "mark this contained", "current_case_id": rich_case["id"]},
            headers=bearer,
        )
        assert response.status_code == 200
        body = response.json()
        assert body["succeeded"] is False
        assert "cannot move" in body["speech"].lower()

    async def test_analysis_runs_through_voice(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "analyse the evidence", "current_case_id": rich_case["id"]},
            headers=bearer,
        )
        body = response.json()
        assert body["succeeded"] is True
        assert body["data"]["analysed"] >= 1

        evidence = await client.get(
            f"/api/v1/cases/{rich_case['id']}/evidence", headers=bearer
        )
        assert evidence.json()["items"][0]["status"] == "analyzed"

    async def test_report_generation_through_voice(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={
                "utterance": "generate an executive report",
                "current_case_id": rich_case["id"],
            },
            headers=bearer,
        )
        assert response.json()["succeeded"] is True

        reports = await client.get(
            f"/api/v1/cases/{rich_case['id']}/reports", headers=bearer
        )
        assert reports.json()["total"] == 1
        assert reports.json()["items"][0]["profile"] == "executive"

    async def test_summary_is_spoken_not_formatted(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        """Speech is heard, so it must carry no markdown."""
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "summarise this case", "current_case_id": rich_case["id"]},
            headers=bearer,
        )
        speech = response.json()["speech"]
        assert rich_case["reference"] in speech
        for marker in ("**", "##", "|", "`"):
            assert marker not in speech

    async def test_navigation_returns_a_ui_action(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command", json={"utterance": "go to the timeline"}, headers=bearer
        )
        assert response.json()["ui_action"] == {"type": "navigate", "route": "/timeline"}

    async def test_conversational_phrasing_is_answered(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={
                "utterance": "can you get me through the cases",
                "current_case_id": rich_case["id"],
            },
            headers=bearer,
        )
        body = response.json()
        assert body["intent"]["action"] == "ask_assistant"
        assert body["succeeded"] is True

    async def test_off_topic_is_declined_clearly(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "what is the weather in Mumbai"},
            headers=bearer,
        )
        body = response.json()
        assert body["succeeded"] is False
        assert "cannot help with that" in body["speech"].lower()
        assert "obsidian" in body["speech"].lower()

    async def test_capability_enquiry_still_lists_commands(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command", json={"utterance": "what can you do"}, headers=bearer
        )
        assert response.json()["intent"]["action"] == "help"

    async def test_missing_case_context_is_explained(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command", json={"utterance": "summarise this case"}, headers=bearer
        )
        assert response.json()["succeeded"] is False
        assert "which case" in response.json()["speech"].lower()

    async def test_requires_authentication(self, client: AsyncClient) -> None:
        response = await client.post(
            "/api/v1/voice/command", json={"utterance": "open cases"}
        )
        assert response.status_code == 401


class TestFuzzyCaseLookup:
    """Speech gives partial references; requiring canonical ones breaks voice."""

    @pytest.fixture
    async def cases(self, client: AsyncClient, bearer: dict) -> list[dict]:
        made = []
        for title in ("C2 beaconing on finance VLAN", "Phishing campaign review"):
            made.append(
                (
                    await client.post(
                        "/api/v1/cases", json={"title": title}, headers=bearer
                    )
                ).json()
            )
        return made

    async def test_opens_by_trailing_digits(
        self, client: AsyncClient, bearer: dict, cases: list[dict]
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command", json={"utterance": "open case 2"}, headers=bearer
        )
        body = response.json()
        assert body["succeeded"] is True
        assert cases[1]["reference"] in body["speech"]

    async def test_opens_by_title_words(
        self, client: AsyncClient, bearer: dict, cases: list[dict]
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "open the beaconing case"},
            headers=bearer,
        )
        body = response.json()
        assert body["succeeded"] is True
        assert cases[0]["reference"] in body["speech"]

    async def test_full_reference_still_works(
        self, client: AsyncClient, bearer: dict, cases: list[dict]
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": f"open case {cases[0]['reference']}"},
            headers=bearer,
        )
        assert response.json()["succeeded"] is True

    async def test_ambiguity_asks_rather_than_guessing(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        """Acting on the wrong investigation is the worst possible outcome."""
        for _ in range(2):
            await client.post(
                "/api/v1/cases",
                json={"title": "Ransomware containment effort"},
                headers=bearer,
            )
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "open the ransomware case"},
            headers=bearer,
        )
        body = response.json()
        assert body["succeeded"] is False
        assert "which one" in body["speech"].lower()
        assert len(body["data"]["candidates"]) >= 2

    async def test_unknown_case_is_refused(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "open the nonexistent zebra case"},
            headers=bearer,
        )
        assert response.json()["succeeded"] is False


class TestFollowUps:
    @pytest.fixture
    async def case(self, client: AsyncClient, bearer: dict) -> dict:
        return (
            await client.post(
                "/api/v1/cases", json={"title": "Follow-up case"}, headers=bearer
            )
        ).json()

    @pytest.mark.parametrize(
        "utterance",
        [
            "tell me more about that",
            "go on",
            "elaborate",
            "why is that suspicious",
            "say that again",
        ],
    )
    async def test_continuations_are_recognised(
        self, client: AsyncClient, bearer: dict, case: dict, utterance: str
    ) -> None:
        """Previously these were parsed as gibberish and the conversation died."""
        response = await client.post(
            "/api/v1/voice/command",
            json={
                "utterance": utterance,
                "current_case_id": case["id"],
                "last_action": "case_summary",
                "last_subject": case["reference"],
            },
            headers=bearer,
        )
        body = response.json()
        assert body["intent"]["action"] == "follow_up"
        assert body["succeeded"] is True

    async def test_previous_subject_grounds_the_pronoun(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={
                "utterance": "tell me more about that",
                "current_case_id": case["id"],
                "last_action": "case_summary",
                "last_subject": "the beaconing finding",
            },
            headers=bearer,
        )
        question = response.json()["data"]["question"]
        assert "the beaconing finding" in question, "'that' must be resolved"

    async def test_follow_up_without_context_says_so(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "tell me more about that"},
            headers=bearer,
        )
        body = response.json()
        assert body["succeeded"] is False
        assert "lost track" in body["speech"].lower()


class TestCaseOverview:
    async def test_returns_counts_in_one_call(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        case = (
            await client.post(
                "/api/v1/cases",
                json={"title": "Overview case", "severity": "high"},
                headers=bearer,
            )
        ).json()
        frames = [
            (i * 60.0, build_tcp_packet("10.0.0.5", "185.243.115.84", 51000, 443))
            for i in range(15)
        ]
        upload = await client.post(
            f"/api/v1/cases/{case['id']}/evidence",
            files={"file": ("c.pcap", io.BytesIO(build_pcap(frames)), "application/octet-stream")},
            headers=bearer,
        )
        await client.post(f"/api/v1/evidence/{upload.json()['id']}/analyze", headers=bearer)

        response = await client.get(
            f"/api/v1/cases/{case['id']}/overview", headers=bearer
        )
        assert response.status_code == 200
        body = response.json()
        assert body["reference"] == case["reference"]
        assert body["evidence_count"] == 1
        assert body["analysed_count"] == 1
        assert body["finding_count"] >= 1
        assert body["ioc_count"] >= 1
        assert body["risk_score"] > 0
        assert body["top_finding"]

    async def test_empty_case_reports_zeros(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        case = (
            await client.post(
                "/api/v1/cases", json={"title": "Empty overview"}, headers=bearer
            )
        ).json()
        body = (
            await client.get(f"/api/v1/cases/{case['id']}/overview", headers=bearer)
        ).json()
        assert body["evidence_count"] == 0
        assert body["finding_count"] == 0
        assert body["risk_score"] == 0
        assert body["top_finding"] is None

    async def test_unknown_case_is_404(self, client: AsyncClient, bearer: dict) -> None:
        response = await client.get("/api/v1/cases/nope/overview", headers=bearer)
        assert response.status_code == 404


class TestNavigationVersusCaseLookup:
    """Module names must never be mistaken for case references.

    Every one of these utterances was reported failing with "I could not find
    that case": the spoken-reference capture took whatever followed "open", and
    the case branch was evaluated before navigation, so a module name could only
    ever reach a lookup that was guaranteed to miss.
    """

    @pytest.mark.parametrize(
        "utterance,route",
        [
            ("open timeline", "/timeline"),
            ("open timeline module", "/timeline"),
            ("I need you to open threat Intel", "/threat-intel"),
            ("show me the threat intelligence page", "/threat-intel"),
            ("take me to reports", "/reports"),
        ],
    )
    def test_module_names_navigate(self, utterance: str, route: str) -> None:
        result = parse(utterance)
        assert result.action is IntentAction.NAVIGATE
        assert result.entities["route"] == route
        # The module name must not survive as a case reference.
        assert "spoken_reference" not in result.entities

    @pytest.mark.parametrize(
        "utterance",
        ["open case 2", "open the beaconing case", "pull up OBS-2026-0001"],
    )
    def test_case_references_still_open_cases(self, utterance: str) -> None:
        assert parse(utterance).action is IntentAction.OPEN_CASE

    def test_a_module_name_without_a_verb_is_not_navigation(self) -> None:
        """Matching the module name alone swallowed ordinary questions.

        "Can you get me through the cases" mentions a module but asks a
        question; routing it to /cases instead of the assistant was a regression
        introduced while fixing the one above.
        """
        assert parse("can you get me through the cases").action is IntentAction.ASK_ASSISTANT


class TestRelativeCaseReference:
    @pytest.mark.parametrize(
        "utterance",
        [
            "generate me report on recent case",
            "summarise the latest case",
            "what is the status of the last case",
        ],
    )
    def test_recency_words_are_captured(self, utterance: str) -> None:
        assert parse(utterance).entities.get("relative") == "latest"


class TestFindingsAndUploadIntents:
    @pytest.mark.parametrize(
        "utterance",
        ["what are the findings", "what did you find", "list the detections"],
    )
    def test_findings_are_their_own_intent(self, utterance: str) -> None:
        """Findings are structured data and are read back, not paraphrased.

        Routing these to the assistant produced "let me look at the case
        evidence" followed by nothing at all.
        """
        assert parse(utterance).action is IntentAction.LIST_FINDINGS

    @pytest.mark.parametrize(
        "utterance",
        ["upload evidence", "add a pcap file", "attach this log file"],
    )
    def test_upload_is_recognised(self, utterance: str) -> None:
        assert parse(utterance).action is IntentAction.UPLOAD_EVIDENCE


class TestVoiceEndToEnd:
    """The reported failures, exercised through the API rather than the parser."""

    async def test_open_timeline_navigates_instead_of_failing(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "open timeline", "current_case_id": rich_case["id"]},
            headers=bearer,
        )
        body = response.json()
        assert body["intent"]["action"] == "navigate"
        assert body["ui_action"]["route"] == "/timeline"
        assert body["succeeded"] is True

    async def test_report_on_the_recent_case_resolves_without_a_reference(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        """No case in context, no reference spoken — recency has to carry it."""
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "generate me a report on the recent case"},
            headers=bearer,
        )
        body = response.json()
        assert body["succeeded"] is True, body["speech"]
        assert "which case" not in body["speech"].lower()

    async def test_findings_return_data_not_just_speech(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        """The complaint was speech with an unchanged screen.

        The payload has to carry the findings themselves, or the client has
        nothing to render and the analyst is told something was found while
        being shown nothing.
        """
        listed = await client.get(
            f"/api/v1/cases/{rich_case['id']}/evidence", headers=bearer
        )
        for item in listed.json()["items"]:
            await client.post(f"/api/v1/evidence/{item['id']}/analyze", headers=bearer)
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "what are the findings", "current_case_id": rich_case["id"]},
            headers=bearer,
        )
        body = response.json()
        assert body["intent"]["action"] == "list_findings"
        assert body["ui_action"]["type"] == "findings"

        # Non-empty, and shaped the way the client renders it. Asserting only
        # that the key exists would pass on an empty list — exactly the failure
        # being fixed, where something was said and nothing could be shown.
        findings = body["data"]["findings"]
        assert findings, body["speech"]
        first = findings[0]
        assert {"title", "severity", "detail", "evidence", "evidence_id"} <= set(first)
        assert first["severity"] in {"critical", "high", "medium", "low", "info"}
        assert body["data"]["severity_counts"]

    async def test_unrecognised_case_offers_the_real_ones(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        """A mis-transcription must not dead-end.

        "Open 3D Intel" is what the recogniser heard for "threat intel". No
        matching can recover that, so the reply lists the cases that do exist
        rather than refusing and stopping.
        """
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "open 3D Intel"},
            headers=bearer,
        )
        body = response.json()
        assert rich_case["reference"] in body["speech"]

    async def test_upload_by_voice_opens_the_uploader(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        response = await client.post(
            "/api/v1/voice/command",
            json={"utterance": "upload evidence", "current_case_id": rich_case["id"]},
            headers=bearer,
        )
        body = response.json()
        assert body["ui_action"]["type"] == "upload_evidence"
        assert body["ui_action"]["case_id"] == rich_case["id"]
