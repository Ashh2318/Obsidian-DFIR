"""Construct valid libpcap bytes for tests.

Building real captures rather than mocking the parser means the tests exercise
the actual byte-level decoding — which is the part most likely to be wrong.
"""

from __future__ import annotations

import struct


def ipv4_bytes(address: str) -> bytes:
    return bytes(int(part) for part in address.split("."))


def build_tcp_packet(
    src_ip: str, dst_ip: str, src_port: int, dst_port: int, payload: bytes = b""
) -> bytes:
    """Ethernet II + IPv4 + TCP frame."""
    tcp = struct.pack(
        "!HHIIBBHHH",
        src_port, dst_port,
        0, 0,            # sequence, acknowledgement
        5 << 4,          # data offset 5 words, no flags set
        0x18,            # PSH+ACK
        8192, 0, 0,      # window, checksum, urgent pointer
    ) + payload

    total_length = 20 + len(tcp)
    ip = struct.pack(
        "!BBHHHBBH4s4s",
        0x45, 0, total_length,
        0, 0,            # identification, flags/fragment
        64, 6, 0,        # ttl, protocol=TCP, checksum
        ipv4_bytes(src_ip), ipv4_bytes(dst_ip),
    ) + tcp

    ethernet = b"\xaa\xbb\xcc\xdd\xee\xff" + b"\x11\x22\x33\x44\x55\x66" + b"\x08\x00"
    return ethernet + ip


def build_udp_packet(
    src_ip: str, dst_ip: str, src_port: int, dst_port: int, payload: bytes = b""
) -> bytes:
    udp = struct.pack("!HHHH", src_port, dst_port, 8 + len(payload), 0) + payload
    total_length = 20 + len(udp)
    ip = struct.pack(
        "!BBHHHBBH4s4s",
        0x45, 0, total_length, 0, 0, 64, 17, 0,
        ipv4_bytes(src_ip), ipv4_bytes(dst_ip),
    ) + udp
    ethernet = b"\xaa\xbb\xcc\xdd\xee\xff" + b"\x11\x22\x33\x44\x55\x66" + b"\x08\x00"
    return ethernet + ip


def build_pcap(frames: list[tuple[float, bytes]]) -> bytes:
    """Wrap frames in a little-endian libpcap file with an Ethernet linktype."""
    out = struct.pack(
        "<IHHiIII",
        0xA1B2C3D4,  # magic, microsecond resolution
        2, 4,        # version major/minor
        0, 0,        # timezone, sigfigs
        65535,       # snaplen
        1,           # LINKTYPE_ETHERNET
    )
    for timestamp, frame in frames:
        seconds = int(timestamp)
        microseconds = int(round((timestamp - seconds) * 1_000_000))
        out += struct.pack("<IIII", seconds, microseconds, len(frame), len(frame))
        out += frame
    return out
