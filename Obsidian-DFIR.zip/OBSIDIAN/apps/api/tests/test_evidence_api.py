"""Evidence ingestion, chain of custody and classification tests."""

from __future__ import annotations

import hashlib
import io

import pytest
from httpx import AsyncClient

from obsidian.domain.enums import EvidenceType
from obsidian.domain.evidence_rules import detect_type, sanitize_filename

PCAP_HEADER = b"\xd4\xc3\xb2\xa1\x02\x00\x04\x00" + b"\x00" * 16
EVTX_HEADER = b"ElfFile\x00" + b"\x00" * 24


@pytest.fixture
async def case(client: AsyncClient, bearer: dict) -> dict:
    response = await client.post(
        "/api/v1/cases", json={"title": "Evidence handling case"}, headers=bearer
    )
    return response.json()


async def upload(
    client: AsyncClient, bearer: dict, case_id: str, name: str, payload: bytes
):
    return await client.post(
        f"/api/v1/cases/{case_id}/evidence",
        files={"file": (name, io.BytesIO(payload), "application/octet-stream")},
        headers=bearer,
    )


class TestChainOfCustody:
    async def test_hashes_match_the_uploaded_bytes(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        payload = PCAP_HEADER + b"synthetic capture payload"
        response = await upload(client, bearer, case["id"], "capture.pcap", payload)

        assert response.status_code == 201, response.text
        body = response.json()
        assert body["sha256"] == hashlib.sha256(payload).hexdigest()
        assert body["md5"] == hashlib.md5(payload).hexdigest()
        assert body["size_bytes"] == len(payload)

    async def test_duplicate_content_is_refused_for_the_same_case(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        payload = PCAP_HEADER + b"identical bytes"
        first = await upload(client, bearer, case["id"], "one.pcap", payload)
        assert first.status_code == 201

        second = await upload(client, bearer, case["id"], "renamed.pcap", payload)
        assert second.status_code == 409
        assert second.json()["details"]["sha256"] == first.json()["sha256"]

    async def test_identical_content_allowed_across_different_cases(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        other = (
            await client.post(
                "/api/v1/cases", json={"title": "A separate investigation"}, headers=bearer
            )
        ).json()

        payload = PCAP_HEADER + b"shared artefact"
        assert (await upload(client, bearer, case["id"], "a.pcap", payload)).status_code == 201
        assert (await upload(client, bearer, other["id"], "a.pcap", payload)).status_code == 201

    async def test_empty_upload_is_rejected(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        response = await upload(client, bearer, case["id"], "empty.log", b"")
        assert response.status_code == 422


class TestClassification:
    async def test_type_detected_from_magic_bytes_not_extension(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        """A PCAP renamed to .txt must still be classified as a PCAP."""
        response = await upload(
            client, bearer, case["id"], "harmless.txt", PCAP_HEADER + b"payload"
        )
        assert response.json()["evidence_type"] == "pcap"

    async def test_evtx_detected(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        response = await upload(
            client, bearer, case["id"], "Security.evtx", EVTX_HEADER + b"records"
        )
        assert response.json()["evidence_type"] == "evtx"

    async def test_extension_used_when_no_signature_matches(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        response = await upload(
            client, bearer, case["id"], "auth.log", b"Jan  1 00:00:00 host sshd[1]: ok"
        )
        assert response.json()["evidence_type"] == "log"

    def test_apk_wins_over_generic_zip_signature(self) -> None:
        zip_header = b"PK\x03\x04" + b"\x00" * 20
        assert detect_type("app.apk", zip_header) is EvidenceType.APK
        assert detect_type("report.docx", zip_header) is EvidenceType.DOCUMENT
        assert detect_type("bundle.zip", zip_header) is EvidenceType.ARCHIVE


class TestFilenameSafety:
    @pytest.mark.parametrize(
        ("supplied", "expected"),
        [
            ("../../etc/passwd", "passwd"),
            ("..\\..\\windows\\system32\\config", "config"),
            ("/absolute/path/eviljpg", "eviljpg"),
            ("normal.pcap", "normal.pcap"),
            ("", "unnamed"),
            ("...", "unnamed"),
        ],
    )
    def test_path_traversal_is_stripped(self, supplied: str, expected: str) -> None:
        assert sanitize_filename(supplied) == expected

    async def test_traversal_filename_is_neutralised_on_upload(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        response = await upload(
            client, bearer, case["id"], "../../../evil.pcap", PCAP_HEADER + b"x"
        )
        assert response.status_code == 201
        assert response.json()["original_filename"] == "evil.pcap"


class TestEvidenceLifecycle:
    async def test_listing_is_scoped_to_the_case(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        await upload(client, bearer, case["id"], "a.log", b"alpha")
        await upload(client, bearer, case["id"], "b.log", b"beta")

        response = await client.get(f"/api/v1/cases/{case['id']}/evidence", headers=bearer)
        assert response.json()["total"] == 2

    async def test_upload_to_unknown_case_is_404(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await upload(client, bearer, "no-such-case", "a.log", b"data")
        assert response.status_code == 404

    async def test_download_returns_the_original_bytes(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        payload = PCAP_HEADER + b"downloadable"
        created = await upload(client, bearer, case["id"], "dl.pcap", payload)

        response = await client.get(
            f"/api/v1/evidence/{created.json()['id']}/download", headers=bearer
        )
        assert response.status_code == 200
        assert response.content == payload
        # Never served with its real type: the browser must not render evidence.
        assert response.headers["content-type"] == "application/octet-stream"

    async def test_delete_removes_the_record(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        created = await upload(client, bearer, case["id"], "gone.log", b"temporary")
        evidence_id = created.json()["id"]

        assert (
            await client.delete(f"/api/v1/evidence/{evidence_id}", headers=bearer)
        ).status_code == 200
        assert (
            await client.get(f"/api/v1/evidence/{evidence_id}", headers=bearer)
        ).status_code == 404

    async def test_upload_requires_authentication(
        self, client: AsyncClient, case: dict
    ) -> None:
        response = await client.post(
            f"/api/v1/cases/{case['id']}/evidence",
            files={"file": ("x.log", io.BytesIO(b"data"), "text/plain")},
        )
        assert response.status_code == 401
