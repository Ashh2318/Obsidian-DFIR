"""Case lifecycle and workflow tests."""

from __future__ import annotations

import pytest
from httpx import AsyncClient

from obsidian.domain.case_rules import can_transition
from obsidian.domain.enums import CaseStatus


@pytest.fixture
async def case(client: AsyncClient, bearer: dict) -> dict:
    response = await client.post(
        "/api/v1/cases",
        json={"title": "Suspected exfiltration on finance VLAN", "severity": "high"},
        headers=bearer,
    )
    assert response.status_code == 201, response.text
    return response.json()


class TestCaseCreation:
    async def test_creates_with_generated_reference(self, case: dict) -> None:
        assert case["reference"].startswith("OBS-")
        assert case["status"] == "open"
        assert case["severity"] == "high"
        assert case["opened_at"] is not None

    async def test_references_are_sequential_and_unique(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        refs = set()
        for index in range(3):
            response = await client.post(
                "/api/v1/cases",
                json={"title": f"Investigation number {index}"},
                headers=bearer,
            )
            refs.add(response.json()["reference"])
        assert len(refs) == 3

    async def test_title_is_required_to_be_meaningful(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.post(
            "/api/v1/cases", json={"title": "ab"}, headers=bearer
        )
        assert response.status_code == 422

    async def test_unknown_assignee_is_rejected(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.post(
            "/api/v1/cases",
            json={"title": "Valid title here", "assignee_id": "does-not-exist"},
            headers=bearer,
        )
        assert response.status_code == 404

    async def test_requires_authentication(self, client: AsyncClient) -> None:
        response = await client.post("/api/v1/cases", json={"title": "Anonymous case"})
        assert response.status_code == 401


class TestCaseWorkflow:
    async def test_valid_transition_is_accepted(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        response = await client.patch(
            f"/api/v1/cases/{case['id']}/status",
            json={"status": "in_progress"},
            headers=bearer,
        )
        assert response.status_code == 200
        assert response.json()["status"] == "in_progress"

    async def test_invalid_transition_is_refused_with_guidance(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        """An OPEN case cannot jump straight to CONTAINED."""
        response = await client.patch(
            f"/api/v1/cases/{case['id']}/status",
            json={"status": "contained"},
            headers=bearer,
        )
        assert response.status_code == 409
        body = response.json()
        assert body["details"]["current"] == "open"
        assert "in_progress" in body["details"]["allowed"]

    async def test_closing_records_closed_at(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        response = await client.patch(
            f"/api/v1/cases/{case['id']}/status",
            json={"status": "closed"},
            headers=bearer,
        )
        assert response.json()["closed_at"] is not None

    async def test_reopening_clears_closed_at(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        await client.patch(
            f"/api/v1/cases/{case['id']}/status",
            json={"status": "closed"},
            headers=bearer,
        )
        response = await client.patch(
            f"/api/v1/cases/{case['id']}/status",
            json={"status": "in_progress"},
            headers=bearer,
        )
        assert response.json()["closed_at"] is None

    async def test_archived_is_terminal(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        for target in ("closed", "archived"):
            await client.patch(
                f"/api/v1/cases/{case['id']}/status",
                json={"status": target},
                headers=bearer,
            )
        response = await client.patch(
            f"/api/v1/cases/{case['id']}/status",
            json={"status": "in_progress"},
            headers=bearer,
        )
        assert response.status_code == 409


class TestTransitionTable:
    """The rules are pure, so they are asserted directly as well as over HTTP."""

    def test_same_status_is_always_permitted(self) -> None:
        for status in CaseStatus:
            assert can_transition(status, status)

    def test_archived_permits_nothing_further(self) -> None:
        for status in CaseStatus:
            if status is CaseStatus.ARCHIVED:
                continue
            assert not can_transition(CaseStatus.ARCHIVED, status)

    def test_open_cannot_skip_to_contained(self) -> None:
        assert not can_transition(CaseStatus.OPEN, CaseStatus.CONTAINED)


class TestCaseSearch:
    async def test_filters_by_status(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        await client.patch(
            f"/api/v1/cases/{case['id']}/status",
            json={"status": "in_progress"},
            headers=bearer,
        )
        response = await client.get("/api/v1/cases?status=in_progress", headers=bearer)
        assert response.json()["total"] == 1

        empty = await client.get("/api/v1/cases?status=archived", headers=bearer)
        assert empty.json()["total"] == 0

    async def test_free_text_matches_title_and_reference(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        by_title = await client.get("/api/v1/cases?q=exfiltration", headers=bearer)
        assert by_title.json()["total"] == 1

        by_reference = await client.get(
            f"/api/v1/cases?q={case['reference']}", headers=bearer
        )
        assert by_reference.json()["total"] == 1

    async def test_search_is_case_insensitive(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        response = await client.get("/api/v1/cases?q=EXFILTRATION", headers=bearer)
        assert response.json()["total"] == 1

    async def test_statistics_group_correctly(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        response = await client.get("/api/v1/cases/statistics", headers=bearer)
        body = response.json()
        assert body["by_status"]["open"] == 1
        assert body["by_severity"]["high"] == 1
