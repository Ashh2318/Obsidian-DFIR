"""Unit tests for cryptographic primitives."""

from __future__ import annotations

import pytest

from obsidian.core.exceptions import TokenError
from obsidian.core.security import (
    create_access_token,
    decode_access_token,
    generate_refresh_token,
    hash_password,
    hash_refresh_token,
    verify_password,
)
from obsidian.domain.enums import Role


def test_password_hash_is_salted_and_verifiable() -> None:
    password = "Investigate!2026"
    first, second = hash_password(password), hash_password(password)

    assert first != second, "Argon2 must salt each hash independently"
    assert verify_password(password, first)
    assert verify_password(password, second)
    assert not verify_password("wrong-password", first)


def test_password_hash_never_contains_plaintext() -> None:
    password = "Investigate!2026"
    assert password not in hash_password(password)


def test_verify_password_rejects_malformed_hash() -> None:
    assert not verify_password("anything", "not-a-valid-argon2-hash")


def test_access_token_roundtrip() -> None:
    token, expires_at = create_access_token("user-123", role=Role.ANALYST.value)
    payload = decode_access_token(token)

    assert payload["sub"] == "user-123"
    assert payload["role"] == Role.ANALYST.value
    assert payload["typ"] == "access"
    assert "jti" in payload
    assert expires_at is not None


def test_tampered_token_is_rejected() -> None:
    token, _ = create_access_token("user-123", role=Role.ADMIN.value)
    header, payload, signature = token.split(".")
    forged = f"{header}.{payload}.{signature[:-4]}AAAA"

    with pytest.raises(TokenError):
        decode_access_token(forged)


def test_refresh_token_is_opaque_and_digest_is_stable() -> None:
    plaintext, digest = generate_refresh_token()

    assert plaintext != digest
    assert len(digest) == 64, "SHA-256 hex digest"
    assert hash_refresh_token(plaintext) == digest
    # Distinct calls must not collide.
    assert generate_refresh_token()[0] != plaintext


def test_role_ordering() -> None:
    assert Role.ADMIN.satisfies(Role.VIEWER)
    assert Role.INVESTIGATOR.satisfies(Role.ANALYST)
    assert Role.ANALYST.satisfies(Role.ANALYST)
    assert not Role.VIEWER.satisfies(Role.ANALYST)
    assert not Role.ANALYST.satisfies(Role.ADMIN)
