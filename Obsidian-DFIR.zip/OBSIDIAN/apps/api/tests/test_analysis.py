"""Analysis engine tests, run against genuinely valid capture bytes.

Note on addresses: RFC 5737 documentation ranges (192.0.2.0/24,
198.51.100.0/24, 203.0.113.0/24) are reported as private by Python's
``ipaddress`` module, so the IOC extractor correctly discards them. These tests
therefore use genuinely routable addresses where an indicator is expected.
"""

from __future__ import annotations

import io

import pytest
from httpx import AsyncClient

from obsidian.analysis.iocs import defang, extract_from_text, is_routable_ip
from obsidian.analysis.pcap import PcapAnalyzer
from obsidian.analysis.registry import analyzer_for, supported_types
from obsidian.analysis.text import TextAnalyzer
from obsidian.domain.enums import EvidenceType, FindingCategory, IOCType
from tests.pcap_builder import build_pcap, build_tcp_packet, build_udp_packet


def write_pcap(tmp_path, frames) -> str:
    path = tmp_path / "capture.pcap"
    path.write_bytes(build_pcap(frames))
    return str(path)


class TestPcapParsing:
    def test_parses_packets_and_conversations(self, tmp_path) -> None:
        frames = [
            (float(i), build_tcp_packet("192.168.1.10", "93.184.216.34", 50000 + i, 443))
            for i in range(20)
        ]
        result = PcapAnalyzer().analyze(write_pcap(tmp_path, frames), filename="c.pcap")

        assert result.statistics["packets"] == 20
        assert result.statistics["unique_hosts"] == 2
        assert "TCP" in result.statistics["protocol_distribution"]

    def test_reports_no_packets_for_an_empty_capture(self, tmp_path) -> None:
        result = PcapAnalyzer().analyze(write_pcap(tmp_path, []), filename="empty.pcap")
        assert result.statistics["packets"] == 0
        assert "No decodable IP packets" in result.summary

    def test_malformed_file_is_reported_not_raised(self, tmp_path) -> None:
        path = tmp_path / "bad.pcap"
        path.write_bytes(b"this is definitely not a capture file")
        result = PcapAnalyzer().analyze(str(path), filename="bad.pcap")
        assert result.errors
        assert result.statistics["packets"] == 0


class TestBeaconDetection:
    def test_regular_intervals_are_flagged(self, tmp_path) -> None:
        """A perfectly periodic check-in is the canonical C2 signal."""
        frames = [
            (i * 60.0, build_tcp_packet("10.0.0.5", "185.243.115.84", 51000, 443))
            for i in range(15)
        ]
        result = PcapAnalyzer().analyze(write_pcap(tmp_path, frames), filename="c2.pcap")

        beaconing = [f for f in result.findings if f.category is FindingCategory.BEACONING]
        assert beaconing, "periodic traffic should raise a beaconing finding"
        assert "185.243.115.84" in beaconing[0].description
        assert "T1071.001" in beaconing[0].mitre_techniques
        assert beaconing[0].confidence > 60

    def test_irregular_traffic_is_not_flagged(self, tmp_path) -> None:
        """Bursty, human-shaped traffic must not trip the detector."""
        offsets = [0, 0.7, 9.1, 9.4, 31.0, 88.2, 89.0, 91.5, 240.0, 241.1, 402.7, 900.0]
        frames = [
            (t, build_tcp_packet("10.0.0.5", "93.184.216.34", 51000, 443))
            for t in offsets
        ]
        result = PcapAnalyzer().analyze(write_pcap(tmp_path, frames), filename="n.pcap")

        assert not [f for f in result.findings if f.category is FindingCategory.BEACONING]


class TestPortScanDetection:
    def test_wide_port_fanout_is_flagged(self, tmp_path) -> None:
        frames = [
            (i * 0.01, build_tcp_packet("10.0.0.99", "10.0.0.1", 40000, port))
            for i, port in enumerate(range(1, 61))
        ]
        result = PcapAnalyzer().analyze(write_pcap(tmp_path, frames), filename="s.pcap")

        scans = [f for f in result.findings if f.category is FindingCategory.PORT_SCAN]
        assert scans
        assert scans[0].metadata["distinct_ports"] == 60
        assert "T1046" in scans[0].mitre_techniques


class TestCleartextDetection:
    def test_telnet_is_flagged(self, tmp_path) -> None:
        frames = [
            (float(i), build_tcp_packet("10.0.0.5", "10.0.0.9", 50000, 23))
            for i in range(5)
        ]
        result = PcapAnalyzer().analyze(write_pcap(tmp_path, frames), filename="t.pcap")

        cleartext = [
            f for f in result.findings
            if f.category is FindingCategory.PLAINTEXT_CREDENTIALS
        ]
        assert cleartext
        assert "Telnet" in cleartext[0].title


class TestNetworkIOCs:
    def test_only_routable_addresses_become_indicators(self, tmp_path) -> None:
        frames = [
            (float(i), build_tcp_packet("192.168.1.10", "45.83.220.14", 50000, 443))
            for i in range(6)
        ]
        result = PcapAnalyzer().analyze(write_pcap(tmp_path, frames), filename="i.pcap")

        values = {i.value for i in result.iocs}
        assert "45.83.220.14" in values
        assert "192.168.1.10" not in values, "RFC 1918 space is the estate, not an IOC"

    def test_payload_domains_are_extracted(self, tmp_path) -> None:
        payload = b"GET /beacon HTTP/1.1\r\nHost: malicious-c2.xyz\r\n\r\n"
        frames = [
            (float(i), build_tcp_packet("10.0.0.5", "91.219.236.7", 50000, 80, payload))
            for i in range(4)
        ]
        result = PcapAnalyzer().analyze(write_pcap(tmp_path, frames), filename="h.pcap")

        assert "malicious-c2.xyz" in {i.value for i in result.iocs}


class TestIOCExtraction:
    def test_private_and_loopback_addresses_are_excluded(self) -> None:
        assert is_routable_ip("8.8.8.8")
        for address in ("10.0.0.1", "192.168.1.1", "172.16.0.1", "127.0.0.1", "169.254.1.1"):
            assert not is_routable_ip(address)

    def test_longest_hash_wins(self) -> None:
        """A SHA-256 contains valid MD5 and SHA-1 substrings; only one IOC is correct."""
        sha256 = "a" * 64
        iocs = extract_from_text(f"hash observed: {sha256}")
        types = {i.ioc_type for i in iocs}
        assert IOCType.SHA256 in types
        assert IOCType.MD5 not in types
        assert IOCType.SHA1 not in types

    def test_benign_domains_are_filtered(self) -> None:
        iocs = extract_from_text("contacted www.microsoft.com and evil-payload.xyz")
        domains = {i.value for i in iocs if i.ioc_type is IOCType.DOMAIN}
        assert "evil-payload.xyz" in domains
        assert not any("microsoft.com" in d for d in domains)

    def test_repetition_raises_confidence(self) -> None:
        once = extract_from_text("seen at 45.83.220.9")
        many = extract_from_text(" ".join(["45.83.220.9"] * 10))
        assert many[0].confidence > once[0].confidence

    def test_defanging_makes_indicators_unclickable(self) -> None:
        assert defang("http://evil.com") == "hxxp://evil[.]com"
        assert defang("a@b.com") == "a[at]b[.]com"


class TestTextAnalyzer:
    def test_brute_force_is_detected(self, tmp_path) -> None:
        lines = [
            f"Jan  1 00:0{i % 10}:00 host sshd[1]: Failed password for root from 45.83.220.7 port 22"
            for i in range(60)
        ]
        path = tmp_path / "auth.log"
        path.write_text("\n".join(lines))

        result = TextAnalyzer().analyze(str(path), filename="auth.log")
        brute = [f for f in result.findings if f.category is FindingCategory.BRUTE_FORCE]
        assert brute
        assert brute[0].metadata["failed_attempts"] == 60
        assert brute[0].metadata["top_sources"][0]["ip"] == "45.83.220.7"

    def test_encoded_powershell_is_high_severity(self, tmp_path) -> None:
        path = tmp_path / "ps.log"
        path.write_text("powershell.exe -nop -enc SQBFAFgAIAAoAE4A\n")
        result = TextAnalyzer().analyze(str(path), filename="ps.log")

        assert any("PowerShell" in f.title for f in result.findings)

    def test_invalid_utf8_does_not_abort_analysis(self, tmp_path) -> None:
        path = tmp_path / "binary.log"
        path.write_bytes(b"valid text \xff\xfe\x00 more text 45.83.220.99")
        result = TextAnalyzer().analyze(str(path), filename="binary.log")

        assert "45.83.220.99" in {i.value for i in result.iocs}


class TestRiskScore:
    def test_one_critical_outranks_many_informational(self, tmp_path) -> None:
        frames = [
            (i * 60.0, build_tcp_packet("10.0.0.5", "185.243.115.84", 51000, 443))
            for i in range(15)
        ]
        result = PcapAnalyzer().analyze(write_pcap(tmp_path, frames), filename="r.pcap")
        assert 0 < result.risk_score <= 100

    def test_no_findings_scores_zero(self, tmp_path) -> None:
        result = PcapAnalyzer().analyze(write_pcap(tmp_path, []), filename="e.pcap")
        assert result.risk_score == 0


class TestRegistry:
    def test_resolves_the_right_engine(self) -> None:
        assert isinstance(analyzer_for(EvidenceType.PCAP), PcapAnalyzer)
        assert isinstance(analyzer_for(EvidenceType.LOG), TextAnalyzer)
        assert analyzer_for(EvidenceType.APK) is None  # Phase 2 follow-up

    def test_supported_types_are_reported(self) -> None:
        assert "pcap" in supported_types()
        assert "log" in supported_types()


class TestAnalysisAPI:
    @pytest.fixture
    async def case(self, client: AsyncClient, bearer: dict) -> dict:
        response = await client.post(
            "/api/v1/cases", json={"title": "Analysis integration case"}, headers=bearer
        )
        return response.json()

    async def test_full_pipeline_produces_findings_and_iocs(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        frames = [
            (i * 60.0, build_tcp_packet("10.0.0.5", "185.243.115.84", 51000, 443))
            for i in range(15)
        ]
        upload = await client.post(
            f"/api/v1/cases/{case['id']}/evidence",
            files={"file": ("c2.pcap", io.BytesIO(build_pcap(frames)), "application/octet-stream")},
            headers=bearer,
        )
        assert upload.status_code == 201
        evidence_id = upload.json()["id"]

        analysed = await client.post(
            f"/api/v1/evidence/{evidence_id}/analyze", headers=bearer
        )
        assert analysed.status_code == 200, analysed.text
        body = analysed.json()
        assert body["status"] == "analyzed"
        assert body["analysis_summary"]["risk_score"] > 0
        assert body["analysis_summary"]["findings"]

        iocs = await client.get(f"/api/v1/iocs?case_id={case['id']}", headers=bearer)
        assert iocs.json()["total"] > 0
        assert any(i["value"] == "185.243.115.84" for i in iocs.json()["items"])

    async def test_reanalysis_increments_sightings_not_rows(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        frames = [
            (float(i), build_udp_packet("10.0.0.5", "91.219.236.20", 40000, 53))
            for i in range(10)
        ]
        upload = await client.post(
            f"/api/v1/cases/{case['id']}/evidence",
            files={"file": ("d.pcap", io.BytesIO(build_pcap(frames)), "application/octet-stream")},
            headers=bearer,
        )
        evidence_id = upload.json()["id"]

        await client.post(f"/api/v1/evidence/{evidence_id}/analyze", headers=bearer)
        first = (await client.get(f"/api/v1/iocs?case_id={case['id']}", headers=bearer)).json()

        await client.post(f"/api/v1/evidence/{evidence_id}/analyze", headers=bearer)
        second = (await client.get(f"/api/v1/iocs?case_id={case['id']}", headers=bearer)).json()

        assert second["total"] == first["total"], "re-analysis must not duplicate indicators"
        assert max(i["sightings"] for i in second["items"]) > 1

    async def test_unsupported_type_is_refused_clearly(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        upload = await client.post(
            f"/api/v1/cases/{case['id']}/evidence",
            files={"file": ("app.apk", io.BytesIO(b"PK\x03\x04" + b"\x00" * 40), "application/octet-stream")},
            headers=bearer,
        )
        response = await client.post(
            f"/api/v1/evidence/{upload.json()['id']}/analyze", headers=bearer
        )
        assert response.status_code == 422
        assert "apk" in response.json()["details"]["evidence_type"]

    async def test_iocs_are_returned_defanged(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        path_frames = [
            (float(i), build_tcp_packet("10.0.0.5", "45.83.220.77", 50000, 443))
            for i in range(6)
        ]
        upload = await client.post(
            f"/api/v1/cases/{case['id']}/evidence",
            files={"file": ("x.pcap", io.BytesIO(build_pcap(path_frames)), "application/octet-stream")},
            headers=bearer,
        )
        await client.post(f"/api/v1/evidence/{upload.json()['id']}/analyze", headers=bearer)

        iocs = (await client.get(f"/api/v1/iocs?case_id={case['id']}", headers=bearer)).json()
        entry = next(i for i in iocs["items"] if i["value"] == "45.83.220.77")
        assert entry["defanged"] == "45[.]83[.]220[.]77"

    async def test_analysis_requires_authentication(
        self, client: AsyncClient, case: dict
    ) -> None:
        response = await client.post("/api/v1/evidence/some-id/analyze")
        assert response.status_code == 401
