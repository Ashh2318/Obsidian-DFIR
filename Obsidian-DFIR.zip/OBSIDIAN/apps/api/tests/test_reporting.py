"""Reporting tests."""

from __future__ import annotations

import io
import re
from datetime import datetime, timezone

import pytest
from httpx import AsyncClient
from tests.pcap_builder import build_pcap, build_tcp_packet

from obsidian.reporting.document import ReportDocument, ReportFormat, ReportProfile
from obsidian.reporting.pdf_writer import (
    PDFCanvas,
    escape_pdf_text,
    text_width,
    wrap_text,
)
from obsidian.reporting.registry import MEDIA_TYPES, render
from obsidian.reporting.renderers.pdf import render_pdf


@pytest.fixture
async def rich_case(client: AsyncClient, bearer: dict) -> dict:
    """A case with evidence, findings and indicators, so reports have content."""
    case = (
        await client.post(
            "/api/v1/cases",
            json={"title": "Reportable investigation", "severity": "critical"},
            headers=bearer,
        )
    ).json()
    frames = [
        (i * 60.0, build_tcp_packet("10.0.0.5", "185.243.115.84", 51000, 443,
                                    b"Host: evil-c2-panel.xyz\r\n"))
        for i in range(15)
    ]
    upload = await client.post(
        f"/api/v1/cases/{case['id']}/evidence",
        files={"file": ("c2.pcap", io.BytesIO(build_pcap(frames)), "application/octet-stream")},
        headers=bearer,
    )
    await client.post(f"/api/v1/evidence/{upload.json()['id']}/analyze", headers=bearer)
    return case


class TestPDFWriter:
    def test_produces_a_structurally_valid_file(self) -> None:
        canvas = PDFCanvas("Structural test")
        canvas.heading("Heading", level=1)
        canvas.paragraph("Body text " * 60)
        canvas.table(["A", "B"], [["1", "2"], ["3", "4"]])
        data = canvas.build()

        assert data.startswith(b"%PDF-1.7")
        assert data.rstrip().endswith(b"%%EOF")
        assert b"/Type /Catalog" in data
        assert b"/Type /Pages" in data

    def test_every_xref_offset_resolves(self) -> None:
        """A wrong offset yields a file readers reject, with no other symptom."""
        canvas = PDFCanvas("Offsets")
        for index in range(80):
            canvas.paragraph(f"Line {index}")
        data = canvas.build()

        start = int(re.search(rb"startxref\s+(\d+)", data).group(1))
        assert data[start : start + 4] == b"xref"

        entries = re.findall(rb"(\d{10}) (\d{5}) ([nf])", data[start:])
        for number, (offset, _gen, kind) in enumerate(entries):
            if kind == b"f":
                continue
            expected = f"{number} 0 obj".encode()
            assert data[int(offset) : int(offset) + len(expected)] == expected

    def test_paginates_automatically(self) -> None:
        canvas = PDFCanvas("Pagination")
        for index in range(150):
            canvas.paragraph(f"Line {index}")
        assert canvas.page_count > 1

    def test_wrapping_respects_the_measured_width(self) -> None:
        lines = wrap_text("word " * 200, 10, 400)
        assert len(lines) > 1
        for line in lines:
            assert text_width(line, 10) <= 400

    def test_parentheses_are_escaped(self) -> None:
        """Unescaped parentheses terminate a PDF string and corrupt the file."""
        canvas = PDFCanvas("Escaping")
        canvas.paragraph("A value (with parens) and a backslash")
        data = canvas.build()
        assert data.startswith(b"%PDF")
        assert b"\\(" in data or b"\\)" in data


class TestRenderers:
    def _document(self) -> ReportDocument:
        from datetime import datetime, timezone

        doc = ReportDocument(
            title="Technical Investigation Report",
            subtitle="Beaconing on the finance VLAN",
            profile=ReportProfile.TECHNICAL,
            generated_at=datetime(2026, 7, 26, tzinfo=timezone.utc),
            generated_by="IR Lead",
            case_reference="OBS-2026-0001",
        )
        doc.heading("Findings", 1).paragraph("Periodic beaconing observed.")
        doc.table(["Severity", "Finding"], [["HIGH", "Beaconing to 185.243.115.84"]])
        doc.bullets(["Isolate the host", "Capture volatile memory"])
        return doc

    def test_all_formats_render(self) -> None:
        doc = self._document()
        for fmt in ReportFormat:
            output = render(doc, fmt, signature="a" * 64)
            assert output, f"{fmt.value} produced nothing"
            assert fmt in MEDIA_TYPES

    def test_markdown_contains_the_content(self) -> None:
        output = render(self._document(), ReportFormat.MARKDOWN).decode()
        assert "OBS-2026-0001" in output
        assert "185.243.115.84" in output
        assert "| Severity | Finding |" in output

    def test_html_is_self_contained(self) -> None:
        """A report that needs the server running is not an archival artefact."""
        output = render(self._document(), ReportFormat.HTML).decode()
        assert "<style>" in output
        assert "<link" not in output
        assert "<script" not in output

    def test_html_escapes_content(self) -> None:
        doc = self._document()
        doc.paragraph("<script>alert('x')</script>")
        output = render(doc, ReportFormat.HTML).decode()
        assert "<script>alert" not in output
        assert "&lt;script&gt;" in output

    def test_pdf_is_binary_and_valid(self) -> None:
        output = render(self._document(), ReportFormat.PDF)
        assert isinstance(output, bytes)
        assert output.startswith(b"%PDF")


class TestProfiles:
    async def test_profiles_differ_in_content_not_only_styling(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        executive = await client.post(
            f"/api/v1/cases/{rich_case['id']}/reports",
            json={"profile": "executive", "format": "markdown"},
            headers=bearer,
        )
        technical = await client.post(
            f"/api/v1/cases/{rich_case['id']}/reports",
            json={"profile": "technical", "format": "markdown"},
            headers=bearer,
        )
        exec_body = (
            await client.get(
                f"/api/v1/reports/{executive.json()['id']}/download", headers=bearer
            )
        ).text
        tech_body = (
            await client.get(
                f"/api/v1/reports/{technical.json()['id']}/download", headers=bearer
            )
        ).text

        assert exec_body != tech_body
        # The technical report carries the custody detail; the executive one
        # deliberately does not.
        assert "SHA-256" in tech_body
        assert "Methodology" in tech_body
        assert "Recommended actions" in exec_body
        assert len(tech_body) > len(exec_body)

    async def test_executive_report_leads_with_assessment(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        created = await client.post(
            f"/api/v1/cases/{rich_case['id']}/reports",
            json={"profile": "executive", "format": "markdown"},
            headers=bearer,
        )
        body = (
            await client.get(
                f"/api/v1/reports/{created.json()['id']}/download", headers=bearer
            )
        ).text
        assert "Assessment" in body
        assert body.index("Assessment") < body.index("Recommended actions")

    async def test_recommendations_derive_from_findings(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        created = await client.post(
            f"/api/v1/cases/{rich_case['id']}/reports",
            json={"profile": "executive", "format": "markdown"},
            headers=bearer,
        )
        body = (
            await client.get(
                f"/api/v1/reports/{created.json()['id']}/download", headers=bearer
            )
        ).text
        # The case contains beaconing, so the beaconing remediation must appear.
        assert "volatile memory" in body.lower()


class TestSignature:
    async def test_report_is_signed(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        created = await client.post(
            f"/api/v1/cases/{rich_case['id']}/reports",
            json={"profile": "technical", "format": "pdf"},
            headers=bearer,
        )
        assert len(created.json()["signature"]) == 64

    @pytest.mark.parametrize("fmt", ["markdown", "html", "pdf"])
    async def test_signature_verifies_for_every_format(
        self, client: AsyncClient, bearer: dict, rich_case: dict, fmt: str
    ) -> None:
        created = await client.post(
            f"/api/v1/cases/{rich_case['id']}/reports",
            json={"profile": "technical", "format": fmt},
            headers=bearer,
        )
        verification = await client.post(
            f"/api/v1/reports/{created.json()['id']}/verify", headers=bearer
        )
        assert verification.status_code == 200
        assert verification.json()["valid"] is True
        assert verification.json()["algorithm"] == "HMAC-SHA256"

    async def test_tampering_is_detected(
        self, client: AsyncClient, bearer: dict, rich_case: dict, session
    ) -> None:
        from sqlalchemy import select

        from obsidian.db.models.report import Report

        created = await client.post(
            f"/api/v1/cases/{rich_case['id']}/reports",
            json={"profile": "technical", "format": "markdown"},
            headers=bearer,
        )
        report_id = created.json()["id"]

        row = (
            await session.execute(select(Report).where(Report.id == report_id))
        ).scalar_one()
        row.content = row.content.replace(b"Findings", b"Fabricat")
        await session.flush()
        await session.commit()

        verification = await client.post(
            f"/api/v1/reports/{report_id}/verify", headers=bearer
        )
        assert verification.json()["valid"] is False
        assert "altered" in verification.json()["detail"].lower()

    async def test_signature_is_returned_on_download(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        created = await client.post(
            f"/api/v1/cases/{rich_case['id']}/reports",
            json={"profile": "technical", "format": "pdf"},
            headers=bearer,
        )
        response = await client.get(
            f"/api/v1/reports/{created.json()['id']}/download", headers=bearer
        )
        assert response.headers["x-report-signature"] == created.json()["signature"]


class TestReportAPI:
    async def test_download_carries_the_right_media_type(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        for fmt, expected in (
            ("pdf", "application/pdf"),
            ("html", "text/html"),
            ("markdown", "text/markdown"),
        ):
            created = await client.post(
                f"/api/v1/cases/{rich_case['id']}/reports",
                json={"profile": "technical", "format": fmt},
                headers=bearer,
            )
            response = await client.get(
                f"/api/v1/reports/{created.json()['id']}/download", headers=bearer
            )
            assert response.headers["content-type"].startswith(expected)
            assert "attachment" in response.headers["content-disposition"]

    async def test_reports_are_listed_for_a_case(
        self, client: AsyncClient, bearer: dict, rich_case: dict
    ) -> None:
        await client.post(
            f"/api/v1/cases/{rich_case['id']}/reports",
            json={"profile": "technical", "format": "pdf"},
            headers=bearer,
        )
        listed = await client.get(
            f"/api/v1/cases/{rich_case['id']}/reports", headers=bearer
        )
        assert listed.json()["total"] == 1

    async def test_unknown_case_is_404(self, client: AsyncClient, bearer: dict) -> None:
        response = await client.post(
            "/api/v1/cases/nope/reports",
            json={"profile": "technical", "format": "pdf"},
            headers=bearer,
        )
        assert response.status_code == 404

    async def test_requires_authentication(
        self, client: AsyncClient, rich_case: dict
    ) -> None:
        response = await client.post(
            f"/api/v1/cases/{rich_case['id']}/reports",
            json={"profile": "technical", "format": "pdf"},
        )
        assert response.status_code == 401

    async def test_empty_case_still_produces_an_honest_report(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        """No findings must not become 'no compromise'."""
        case = (
            await client.post(
                "/api/v1/cases", json={"title": "Nothing found yet"}, headers=bearer
            )
        ).json()
        created = await client.post(
            f"/api/v1/cases/{case['id']}/reports",
            json={"profile": "executive", "format": "markdown"},
            headers=bearer,
        )
        body = (
            await client.get(
                f"/api/v1/reports/{created.json()['id']}/download", headers=bearer
            )
        ).text
        assert "not a statement that no compromise occurred" in body


class TestPDFTextEscaping:
    """String-literal escaping, which no rendering test could see.

    Every report carried `S. Raybole \\(Lead Analyst\\)` on its cover — the
    escape helper emitted a doubled backslash, so the escape character itself
    was printed. Byte-level output was valid PDF and the suite was green; the
    defect was only visible by rasterising a page and reading it.
    """

    def test_parentheses_take_a_single_escape(self) -> None:
        assert escape_pdf_text("S. Raybole (Lead Analyst)") == r"S. Raybole \(Lead Analyst\)"

    def test_a_backslash_is_doubled_and_nothing_else_is(self) -> None:
        assert escape_pdf_text(r"C:\evidence") == r"C:\\evidence"

    def test_bullets_use_the_winansi_glyph_not_a_question_mark(self) -> None:
        """Bulleted recommendations rendered as "?" on every report."""
        assert escape_pdf_text("\u2022") == r"\225"

    @pytest.mark.parametrize(
        "char,octal",
        [("\u2014", r"\227"), ("\u2013", r"\226"), ("\u201c", r"\223"), ("\u2019", r"\222")],
    )
    def test_typographic_punctuation_survives(self, char: str, octal: str) -> None:
        assert escape_pdf_text(char) == octal

    def test_accented_latin_is_encoded_rather_than_dropped(self) -> None:
        assert escape_pdf_text("caf\u00e9") == r"caf\351"

    def test_undisplayable_characters_degrade_to_a_marker(self) -> None:
        assert escape_pdf_text("\u4e2d") == "?"

    def test_a_rendered_report_contains_no_stray_escape_characters(self) -> None:
        """End-to-end guard on the same bug, through the real renderer."""
        document = ReportDocument(
            title="Escaping (probe)",
            subtitle="Parentheses and bullets",
            profile=ReportProfile.TECHNICAL,
            generated_at=datetime(2026, 7, 26, 12, 0, tzinfo=timezone.utc),
            generated_by="A. Analyst (Lead)",
            case_reference="OBS-2026-0001",
        )
        document.bullets(["First item", "Second item"])
        pdf = render_pdf(document)
        assert pdf.startswith(b"%PDF-")
        # A doubled backslash immediately before a parenthesis is the signature
        # of the bug: it renders the escape character itself.
        assert rb"\\(" not in pdf
        assert rb"\\)" not in pdf
