"""End-to-end tests for the authentication surface."""

from __future__ import annotations

import pytest
from httpx import AsyncClient


class TestRegistration:
    async def test_creates_account_and_never_returns_password(
        self, client: AsyncClient, credentials: dict
    ) -> None:
        response = await client.post("/api/v1/auth/register", json=credentials)

        assert response.status_code == 201
        body = response.json()
        assert body["email"] == credentials["email"]
        assert "password" not in body
        assert "password_hash" not in body

    async def test_first_account_becomes_administrator(
        self, client: AsyncClient, credentials: dict
    ) -> None:
        response = await client.post("/api/v1/auth/register", json=credentials)
        assert response.json()["role"] == "admin"

    async def test_subsequent_accounts_are_analysts(
        self, client: AsyncClient, credentials: dict
    ) -> None:
        await client.post("/api/v1/auth/register", json=credentials)
        second = await client.post(
            "/api/v1/auth/register",
            json={**credentials, "email": "second@obsidian.io"},
        )
        assert second.json()["role"] == "analyst"

    async def test_duplicate_email_conflicts(
        self, client: AsyncClient, credentials: dict
    ) -> None:
        await client.post("/api/v1/auth/register", json=credentials)
        duplicate = await client.post("/api/v1/auth/register", json=credentials)

        assert duplicate.status_code == 409
        assert duplicate.json()["error"] == "email_already_registered"

    async def test_email_is_normalised_to_lowercase(
        self, client: AsyncClient, credentials: dict
    ) -> None:
        response = await client.post(
            "/api/v1/auth/register",
            json={**credentials, "email": "MiXeD@Obsidian.IO"},
        )
        assert response.json()["email"] == "mixed@obsidian.io"

    @pytest.mark.parametrize(
        "password",
        [
            "short1!A",              # below the minimum length
            "alllowercase123!",      # no uppercase
            "ALLUPPERCASE123!",      # no lowercase
            "NoDigitsHereAtAll!",    # no digit
            "NoSymbolsHere12345",    # no symbol
        ],
    )
    async def test_weak_passwords_are_rejected(
        self, client: AsyncClient, credentials: dict, password: str
    ) -> None:
        response = await client.post(
            "/api/v1/auth/register", json={**credentials, "password": password}
        )
        assert response.status_code == 422


class TestLogin:
    async def test_returns_token_pair(self, auth: dict) -> None:
        assert auth["tokens"]["access_token"]
        assert auth["tokens"]["refresh_token"]
        assert auth["tokens"]["token_type"] == "bearer"
        assert auth["tokens"]["expires_in"] > 0

    async def test_wrong_password_is_rejected(
        self, client: AsyncClient, registered: dict, credentials: dict
    ) -> None:
        response = await client.post(
            "/api/v1/auth/login",
            json={"email": credentials["email"], "password": "WrongPassword!1"},
        )
        assert response.status_code == 401
        assert response.json()["error"] == "invalid_credentials"

    async def test_unknown_and_known_emails_are_indistinguishable(
        self, client: AsyncClient, registered: dict, credentials: dict
    ) -> None:
        """The login endpoint must not become an account-enumeration oracle."""
        unknown = await client.post(
            "/api/v1/auth/login",
            json={"email": "nobody@obsidian.io", "password": "WrongPassword!1"},
        )
        known = await client.post(
            "/api/v1/auth/login",
            json={"email": credentials["email"], "password": "WrongPassword!1"},
        )

        assert unknown.status_code == known.status_code == 401
        assert unknown.json()["error"] == known.json()["error"]
        assert unknown.json()["message"] == known.json()["message"]

    async def test_lockout_after_repeated_failures(
        self, client: AsyncClient, registered: dict, credentials: dict
    ) -> None:
        for _ in range(5):
            await client.post(
                "/api/v1/auth/login",
                json={"email": credentials["email"], "password": "WrongPassword!1"},
            )

        # The correct password must now also be refused.
        response = await client.post(
            "/api/v1/auth/login",
            json={"email": credentials["email"], "password": credentials["password"]},
        )
        assert response.status_code == 401


class TestProtectedRoutes:
    async def test_me_requires_a_token(self, client: AsyncClient) -> None:
        assert (await client.get("/api/v1/auth/me")).status_code == 401

    async def test_me_returns_the_caller(
        self, client: AsyncClient, bearer: dict, credentials: dict
    ) -> None:
        response = await client.get("/api/v1/auth/me", headers=bearer)
        assert response.status_code == 200
        assert response.json()["email"] == credentials["email"]

    async def test_garbage_token_is_rejected(self, client: AsyncClient) -> None:
        response = await client.get(
            "/api/v1/auth/me", headers={"Authorization": "Bearer not.a.token"}
        )
        assert response.status_code == 401

    async def test_refresh_token_is_not_accepted_as_a_bearer_token(
        self, client: AsyncClient, auth: dict
    ) -> None:
        """A long-lived credential must not authenticate general API calls."""
        response = await client.get(
            "/api/v1/auth/me",
            headers={"Authorization": f"Bearer {auth['tokens']['refresh_token']}"},
        )
        assert response.status_code == 401


class TestRefreshRotation:
    async def test_refresh_issues_a_new_pair(
        self, client: AsyncClient, auth: dict
    ) -> None:
        original = auth["tokens"]["refresh_token"]
        response = await client.post(
            "/api/v1/auth/refresh", json={"refresh_token": original}
        )

        assert response.status_code == 200
        assert response.json()["tokens"]["refresh_token"] != original

    async def test_spent_token_cannot_be_reused(
        self, client: AsyncClient, auth: dict
    ) -> None:
        original = auth["tokens"]["refresh_token"]
        await client.post("/api/v1/auth/refresh", json={"refresh_token": original})

        replay = await client.post(
            "/api/v1/auth/refresh", json={"refresh_token": original}
        )
        assert replay.status_code == 401
        assert replay.json()["error"] == "token_reuse_detected"

    async def test_reuse_revokes_the_entire_family(
        self, client: AsyncClient, auth: dict
    ) -> None:
        """Reuse implies theft, so every descendant session must die."""
        first = auth["tokens"]["refresh_token"]
        rotated = (
            await client.post("/api/v1/auth/refresh", json={"refresh_token": first})
        ).json()["tokens"]["refresh_token"]

        # Replaying the spent ancestor poisons the family...
        await client.post("/api/v1/auth/refresh", json={"refresh_token": first})

        # ...so the currently-valid descendant is now dead too.
        response = await client.post(
            "/api/v1/auth/refresh", json={"refresh_token": rotated}
        )
        assert response.status_code == 401

    async def test_unknown_refresh_token_is_rejected(
        self, client: AsyncClient
    ) -> None:
        response = await client.post(
            "/api/v1/auth/refresh", json={"refresh_token": "x" * 64}
        )
        assert response.status_code == 401


class TestLogout:
    async def test_logout_revokes_the_presented_token(
        self, client: AsyncClient, auth: dict, bearer: dict
    ) -> None:
        token = auth["tokens"]["refresh_token"]
        response = await client.post(
            "/api/v1/auth/logout", json={"refresh_token": token}, headers=bearer
        )
        assert response.status_code == 200

        reuse = await client.post("/api/v1/auth/refresh", json={"refresh_token": token})
        assert reuse.status_code == 401

    async def test_logout_requires_authentication(self, client: AsyncClient) -> None:
        response = await client.post("/api/v1/auth/logout", json={})
        assert response.status_code == 401
