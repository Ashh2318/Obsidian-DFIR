"""Threat-intelligence enrichment tests."""

from __future__ import annotations

import io

import pytest
from httpx import AsyncClient

from obsidian.domain.enums import IOCType, ThreatVerdict
from obsidian.services.enrichment_service import EnrichmentService
from obsidian.threatintel.base import ProviderResult, ThreatIntelProvider
from obsidian.threatintel.providers.abuseipdb import AbuseIPDBProvider
from obsidian.threatintel.providers.mock import MockThreatIntelProvider
from obsidian.threatintel.providers.virustotal import VirusTotalProvider
from tests.pcap_builder import build_pcap, build_tcp_packet


@pytest.fixture
async def case_with_iocs(client: AsyncClient, bearer: dict) -> dict:
    case = (
        await client.post(
            "/api/v1/cases", json={"title": "Enrichment case"}, headers=bearer
        )
    ).json()
    frames = [
        (i * 60.0, build_tcp_packet("10.0.0.5", "185.243.115.84", 51000, 443))
        for i in range(15)
    ]
    upload = await client.post(
        f"/api/v1/cases/{case['id']}/evidence",
        files={"file": ("c2.pcap", io.BytesIO(build_pcap(frames)), "application/octet-stream")},
        headers=bearer,
    )
    await client.post(f"/api/v1/evidence/{upload.json()['id']}/analyze", headers=bearer)
    return case


class TestAggregation:
    """The rule is asymmetric by design: the worst credible verdict wins."""

    def test_single_malicious_outweighs_several_benign(self) -> None:
        results = [
            ProviderResult("a", ThreatVerdict.BENIGN, 5),
            ProviderResult("b", ThreatVerdict.BENIGN, 2),
            ProviderResult("c", ThreatVerdict.MALICIOUS, 91),
        ]
        verdict, score = EnrichmentService.aggregate(results)
        assert verdict is ThreatVerdict.MALICIOUS
        assert score == 91

    def test_failed_lookups_are_excluded_not_counted_benign(self) -> None:
        """A feed being unreachable says nothing about the indicator."""
        results = [
            ProviderResult("a", ThreatVerdict.UNKNOWN, 0, error="timeout"),
            ProviderResult("b", ThreatVerdict.SUSPICIOUS, 55),
        ]
        verdict, score = EnrichmentService.aggregate(results)
        assert verdict is ThreatVerdict.SUSPICIOUS
        assert score == 55

    def test_all_failures_yield_unknown(self) -> None:
        results = [
            ProviderResult("a", ThreatVerdict.UNKNOWN, 0, error="down"),
            ProviderResult("b", ThreatVerdict.UNKNOWN, 0, error="rate limited"),
        ]
        assert EnrichmentService.aggregate(results) == (ThreatVerdict.UNKNOWN, 0)

    def test_no_providers_yields_unknown(self) -> None:
        assert EnrichmentService.aggregate([]) == (ThreatVerdict.UNKNOWN, 0)

    def test_highest_score_among_the_winning_verdict(self) -> None:
        results = [
            ProviderResult("a", ThreatVerdict.MALICIOUS, 60),
            ProviderResult("b", ThreatVerdict.MALICIOUS, 95),
        ]
        assert EnrichmentService.aggregate(results)[1] == 95


class TestMockProvider:
    async def test_is_deterministic(self) -> None:
        provider = MockThreatIntelProvider()
        first = await provider.lookup(IOCType.IPV4, "185.243.115.84")
        second = await provider.lookup(IOCType.IPV4, "185.243.115.84")
        assert (first.verdict, first.score) == (second.verdict, second.score)

    async def test_different_values_differ(self) -> None:
        provider = MockThreatIntelProvider()
        a = await provider.lookup(IOCType.IPV4, "185.243.115.84")
        b = await provider.lookup(IOCType.IPV4, "8.8.8.8")
        assert (a.verdict, a.score) != (b.verdict, b.score)

    async def test_labels_itself_as_simulated(self) -> None:
        """Nobody should mistake a mock verdict for evidence."""
        result = await MockThreatIntelProvider().lookup(IOCType.IPV4, "1.2.3.4")
        assert result.attributes["simulated"] is True
        assert "offline" in result.detail.lower()

    def test_satisfies_the_protocol(self) -> None:
        assert isinstance(MockThreatIntelProvider(), ThreatIntelProvider)


class TestProviderCapabilities:
    def test_abuseipdb_handles_addresses_only(self) -> None:
        provider = AbuseIPDBProvider("dummy-key")
        assert provider.supports(IOCType.IPV4)
        assert not provider.supports(IOCType.DOMAIN)
        assert not provider.supports(IOCType.SHA256)

    def test_virustotal_handles_hashes_and_domains(self) -> None:
        provider = VirusTotalProvider("dummy-key")
        assert provider.supports(IOCType.SHA256)
        assert provider.supports(IOCType.DOMAIN)
        assert provider.supports(IOCType.IPV4)

    async def test_unsupported_type_returns_an_error_not_a_verdict(self) -> None:
        result = await AbuseIPDBProvider("dummy-key").lookup(IOCType.SHA256, "abc")
        assert result.error is not None
        assert result.verdict is ThreatVerdict.UNKNOWN


class TestCaching:
    async def test_second_call_is_served_from_cache(self, session) -> None:
        service = EnrichmentService(session)
        first = await service.enrich_value(ioc_type=IOCType.IPV4, value="185.243.115.84")
        second = await service.enrich_value(ioc_type=IOCType.IPV4, value="185.243.115.84")
        # Same row, and the timestamp did not move.
        assert first.id == second.id
        assert first.fetched_at == second.fetched_at

    async def test_force_refreshes(self, session) -> None:
        service = EnrichmentService(session)
        first = await service.enrich_value(ioc_type=IOCType.IPV4, value="9.9.9.9")
        refreshed = await service.enrich_value(
            ioc_type=IOCType.IPV4, value="9.9.9.9", force=True
        )
        assert first.id == refreshed.id, "force must update in place, not duplicate"
        assert refreshed.fetched_at >= first.fetched_at

    async def test_expired_entry_is_refetched(self, session) -> None:
        from datetime import timedelta

        from obsidian.core.security import utcnow

        service = EnrichmentService(session)
        entry = await service.enrich_value(ioc_type=IOCType.IPV4, value="1.1.1.1")
        original = entry.fetched_at

        entry.expires_at = utcnow() - timedelta(hours=1)
        await session.flush()

        refreshed = await service.enrich_value(ioc_type=IOCType.IPV4, value="1.1.1.1")
        assert refreshed.fetched_at >= original
        assert refreshed.is_fresh(utcnow())

    async def test_cache_is_shared_across_cases(self, session) -> None:
        """Reputation is a property of the indicator, not of one investigation."""
        service = EnrichmentService(session)
        a = await service.enrich_value(ioc_type=IOCType.IPV4, value="203.0.113.200")
        b = await service.enrich_value(ioc_type=IOCType.IPV4, value="203.0.113.200")
        assert a.id == b.id


class TestEnrichmentAPI:
    async def test_status_reports_configured_feeds(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.get("/api/v1/threat-intel/status", headers=bearer)
        assert response.status_code == 200
        body = response.json()
        assert "mock" in body["providers"]
        assert body["cache_hours"] > 0

    async def test_enrich_an_indicator(
        self, client: AsyncClient, bearer: dict, case_with_iocs: dict
    ) -> None:
        iocs = (
            await client.get(
                f"/api/v1/iocs?case_id={case_with_iocs['id']}", headers=bearer
            )
        ).json()
        assert iocs["total"] > 0
        ioc_id = iocs["items"][0]["id"]

        response = await client.post(
            f"/api/v1/threat-intel/iocs/{ioc_id}/enrich", headers=bearer
        )
        assert response.status_code == 200
        body = response.json()
        assert body["verdict"] in {"unknown", "benign", "suspicious", "malicious"}
        assert body["provider_count"] >= 1

    async def test_enrichments_are_listed(
        self, client: AsyncClient, bearer: dict, case_with_iocs: dict
    ) -> None:
        iocs = (
            await client.get(
                f"/api/v1/iocs?case_id={case_with_iocs['id']}", headers=bearer
            )
        ).json()
        await client.post(
            f"/api/v1/threat-intel/iocs/{iocs['items'][0]['id']}/enrich", headers=bearer
        )

        listed = await client.get("/api/v1/threat-intel/enrichments", headers=bearer)
        assert listed.json()["total"] >= 1

    async def test_case_enrichment_covers_multiple_indicators(
        self, client: AsyncClient, bearer: dict, case_with_iocs: dict
    ) -> None:
        response = await client.post(
            f"/api/v1/threat-intel/cases/{case_with_iocs['id']}/enrich", headers=bearer
        )
        assert response.status_code == 200
        assert len(response.json()) >= 1

    async def test_unknown_indicator_is_404(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.post(
            "/api/v1/threat-intel/iocs/does-not-exist/enrich", headers=bearer
        )
        assert response.status_code == 404

    async def test_requires_authentication(self, client: AsyncClient) -> None:
        assert (await client.get("/api/v1/threat-intel/status")).status_code == 401
