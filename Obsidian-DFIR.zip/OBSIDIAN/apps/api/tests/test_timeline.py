"""Forensic timeline tests.

The property that matters most is the separation of *when it happened* from
*when we noticed*. A capture recorded days before upload must appear at its own
time, not at ingest time.
"""

from __future__ import annotations

import io
from datetime import datetime, timezone

import pytest
from httpx import AsyncClient

from obsidian.domain.enums import Severity, TimelineEventKind, TimelineSource
from obsidian.domain.timeline import TimelineEvent, sort_events
from tests.pcap_builder import build_pcap, build_tcp_packet

# 2025-01-01T00:00:00Z — deliberately far in the past relative to upload time.
CAPTURE_EPOCH = 1735689600.0


def parse_iso(value: str) -> datetime:
    """Parse an API timestamp portably.

    Pydantic serialises UTC with a trailing ``Z``, which
    ``datetime.fromisoformat`` only accepts from Python 3.11 onward. Normalising
    keeps the suite valid on 3.10 as well.
    """
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


@pytest.fixture
async def case(client: AsyncClient, bearer: dict) -> dict:
    response = await client.post(
        "/api/v1/cases",
        json={"title": "Timeline correlation case", "severity": "high"},
        headers=bearer,
    )
    return response.json()


@pytest.fixture
async def analysed_case(client: AsyncClient, bearer: dict, case: dict) -> dict:
    frames = [
        (CAPTURE_EPOCH + i * 60.0, build_tcp_packet("10.0.0.5", "185.243.115.84", 51000, 443))
        for i in range(15)
    ]
    upload = await client.post(
        f"/api/v1/cases/{case['id']}/evidence",
        files={"file": ("c2.pcap", io.BytesIO(build_pcap(frames)), "application/octet-stream")},
        headers=bearer,
    )
    await client.post(f"/api/v1/evidence/{upload.json()['id']}/analyze", headers=bearer)
    return case


class TestOrdering:
    def test_ties_break_deterministically(self) -> None:
        """Events from different sources routinely share a timestamp."""
        moment = datetime(2026, 1, 1, tzinfo=timezone.utc)
        events = [
            TimelineEvent(
                id=f"e{i}",
                occurred_at=moment,
                kind=TimelineEventKind.CASE_OPENED,
                source=TimelineSource.INVESTIGATION,
                title=f"Event {i}",
            )
            for i in (3, 1, 2)
        ]
        first = [e.id for e in sort_events(events)]
        second = [e.id for e in sort_events(list(reversed(events)))]
        assert first == second, "identical timestamps must still order stably"

    def test_newest_first_by_default(self) -> None:
        events = [
            TimelineEvent(
                id="old",
                occurred_at=datetime(2025, 1, 1, tzinfo=timezone.utc),
                kind=TimelineEventKind.CASE_OPENED,
                source=TimelineSource.INVESTIGATION,
                title="Old",
            ),
            TimelineEvent(
                id="new",
                occurred_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
                kind=TimelineEventKind.CASE_OPENED,
                source=TimelineSource.INVESTIGATION,
                title="New",
            ),
        ]
        assert [e.id for e in sort_events(events)] == ["new", "old"]


class TestCaseTimeline:
    async def test_case_creation_appears(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        response = await client.get(f"/api/v1/cases/{case['id']}/timeline", headers=bearer)
        assert response.status_code == 200
        kinds = {e["kind"] for e in response.json()["events"]}
        assert "case.opened" in kinds

    async def test_status_change_appears(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        await client.patch(
            f"/api/v1/cases/{case['id']}/status",
            json={"status": "in_progress"},
            headers=bearer,
        )
        response = await client.get(f"/api/v1/cases/{case['id']}/timeline", headers=bearer)
        events = [e for e in response.json()["events"] if e["kind"] == "case.status_changed"]
        assert events
        assert "in_progress" in events[0]["title"]

    async def test_upload_and_analysis_appear(
        self, client: AsyncClient, bearer: dict, analysed_case: dict
    ) -> None:
        response = await client.get(
            f"/api/v1/cases/{analysed_case['id']}/timeline", headers=bearer
        )
        kinds = {e["kind"] for e in response.json()["events"]}
        assert "evidence.uploaded" in kinds
        assert "analysis.completed" in kinds

    async def test_unknown_case_is_404(self, client: AsyncClient, bearer: dict) -> None:
        response = await client.get("/api/v1/cases/nope/timeline", headers=bearer)
        assert response.status_code == 404

    async def test_requires_authentication(self, client: AsyncClient, case: dict) -> None:
        assert (
            await client.get(f"/api/v1/cases/{case['id']}/timeline")
        ).status_code == 401


class TestIncidentVersusInvestigation:
    async def test_capture_window_is_placed_at_capture_time(
        self, client: AsyncClient, bearer: dict, analysed_case: dict
    ) -> None:
        """The whole point: traffic from 2025 must not appear at upload time."""
        response = await client.get(
            f"/api/v1/cases/{analysed_case['id']}/timeline", headers=bearer
        )
        captures = [
            e for e in response.json()["events"] if e["kind"] == "capture.window"
        ]
        assert captures, "an analysed capture should contribute a window event"

        occurred = parse_iso(captures[0]["occurred_at"])
        assert occurred.year == 2025, "capture must sit at its recorded time, not ingest time"
        assert captures[0]["source"] == "incident"

    async def test_findings_anchor_to_the_capture_not_the_upload(
        self, client: AsyncClient, bearer: dict, analysed_case: dict
    ) -> None:
        response = await client.get(
            f"/api/v1/cases/{analysed_case['id']}/timeline", headers=bearer
        )
        findings = [e for e in response.json()["events"] if e["kind"] == "finding.raised"]
        assert findings

        occurred = parse_iso(findings[0]["occurred_at"])
        assert occurred.year == 2025
        assert findings[0]["source"] == "incident"

    async def test_investigation_events_use_real_time(
        self, client: AsyncClient, bearer: dict, analysed_case: dict
    ) -> None:
        response = await client.get(
            f"/api/v1/cases/{analysed_case['id']}/timeline", headers=bearer
        )
        uploads = [
            e for e in response.json()["events"] if e["kind"] == "evidence.uploaded"
        ]
        assert uploads
        occurred = parse_iso(uploads[0]["occurred_at"])
        assert occurred.year >= 2026, "ingest is an investigation event and happens now"
        assert uploads[0]["source"] == "investigation"

    async def test_counts_split_by_source(
        self, client: AsyncClient, bearer: dict, analysed_case: dict
    ) -> None:
        body = (
            await client.get(
                f"/api/v1/cases/{analysed_case['id']}/timeline", headers=bearer
            )
        ).json()
        assert body["incident_events"] > 0
        assert body["investigation_events"] > 0
        assert body["total"] == body["incident_events"] + body["investigation_events"]


class TestFiltering:
    async def test_source_filter(
        self, client: AsyncClient, bearer: dict, analysed_case: dict
    ) -> None:
        response = await client.get(
            f"/api/v1/cases/{analysed_case['id']}/timeline?source=incident",
            headers=bearer,
        )
        body = response.json()
        assert body["investigation_events"] == 0
        assert all(e["source"] == "incident" for e in body["events"])

    async def test_minimum_severity_filter(
        self, client: AsyncClient, bearer: dict, analysed_case: dict
    ) -> None:
        response = await client.get(
            f"/api/v1/cases/{analysed_case['id']}/timeline?min_severity=high",
            headers=bearer,
        )
        for event in response.json()["events"]:
            assert Severity(event["severity"]).rank >= Severity.HIGH.rank


class TestGlobalTimeline:
    async def test_spans_cases_and_carries_references(
        self, client: AsyncClient, bearer: dict, analysed_case: dict
    ) -> None:
        await client.post(
            "/api/v1/cases", json={"title": "A second investigation"}, headers=bearer
        )
        body = (await client.get("/api/v1/timeline", headers=bearer)).json()

        assert body["total"] >= 2
        opened = [e for e in body["events"] if e["kind"] == "case.opened"]
        assert len(opened) >= 2
        assert any(e["case_reference"] for e in opened), "events should name their case"

    async def test_excludes_authentication_noise(
        self, client: AsyncClient, bearer: dict, case: dict
    ) -> None:
        """Logins are security telemetry, not case chronology."""
        body = (await client.get("/api/v1/timeline", headers=bearer)).json()
        kinds = {e["kind"] for e in body["events"]}
        assert not any("login" in k for k in kinds)
