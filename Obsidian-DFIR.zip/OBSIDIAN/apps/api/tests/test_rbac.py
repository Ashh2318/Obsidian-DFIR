"""Authorization and administration tests."""

from __future__ import annotations

import pytest
from httpx import AsyncClient


@pytest.fixture
async def analyst_bearer(client: AsyncClient, bearer: dict) -> dict[str, str]:
    """A non-admin account. ``bearer`` first-registers the admin."""
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "second@obsidian.io",
            "password": "Investigate!2026",
            "full_name": "Second Analyst",
        },
    )
    login = await client.post(
        "/api/v1/auth/login",
        json={"email": "second@obsidian.io", "password": "Investigate!2026"},
    )
    return {"Authorization": f"Bearer {login.json()['tokens']['access_token']}"}


class TestRoleEnforcement:
    async def test_admin_can_list_users(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.get("/api/v1/users", headers=bearer)
        assert response.status_code == 200
        assert response.json()["total"] >= 1

    async def test_analyst_cannot_list_users(
        self, client: AsyncClient, analyst_bearer: dict
    ) -> None:
        response = await client.get("/api/v1/users", headers=analyst_bearer)
        assert response.status_code == 403
        assert response.json()["error"] == "permission_denied"

    async def test_anonymous_cannot_list_users(self, client: AsyncClient) -> None:
        assert (await client.get("/api/v1/users")).status_code == 401


class TestAdministration:
    async def test_admin_can_promote_an_analyst(
        self, client: AsyncClient, bearer: dict, analyst_bearer: dict
    ) -> None:
        users = (await client.get("/api/v1/users", headers=bearer)).json()["items"]
        target = next(u for u in users if u["email"] == "second@obsidian.io")

        response = await client.patch(
            f"/api/v1/users/{target['id']}/role",
            json={"role": "investigator"},
            headers=bearer,
        )
        assert response.status_code == 200
        assert response.json()["role"] == "investigator"

    async def test_last_administrator_cannot_be_demoted(
        self, client: AsyncClient, bearer: dict, registered: dict
    ) -> None:
        """Guards against the deployment locking itself out of administration."""
        response = await client.patch(
            f"/api/v1/users/{registered['id']}/role",
            json={"role": "analyst"},
            headers=bearer,
        )
        assert response.status_code == 409

    async def test_admin_cannot_disable_their_own_account(
        self, client: AsyncClient, bearer: dict, registered: dict
    ) -> None:
        response = await client.patch(
            f"/api/v1/users/{registered['id']}/active",
            json={"is_active": False},
            headers=bearer,
        )
        assert response.status_code == 409

    async def test_disabling_an_account_revokes_its_sessions(
        self, client: AsyncClient, bearer: dict, analyst_bearer: dict
    ) -> None:
        login = await client.post(
            "/api/v1/auth/login",
            json={"email": "second@obsidian.io", "password": "Investigate!2026"},
        )
        refresh_token = login.json()["tokens"]["refresh_token"]

        users = (await client.get("/api/v1/users", headers=bearer)).json()["items"]
        target = next(u for u in users if u["email"] == "second@obsidian.io")
        await client.patch(
            f"/api/v1/users/{target['id']}/active",
            json={"is_active": False},
            headers=bearer,
        )

        # The disabled account must not be able to mint fresh access tokens.
        response = await client.post(
            "/api/v1/auth/refresh", json={"refresh_token": refresh_token}
        )
        assert response.status_code == 401

    async def test_unknown_user_returns_404(
        self, client: AsyncClient, bearer: dict
    ) -> None:
        response = await client.get("/api/v1/users/does-not-exist", headers=bearer)
        assert response.status_code == 404
