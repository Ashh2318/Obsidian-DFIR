"""AI provider abstraction tests."""

from __future__ import annotations

import httpx
import pytest

from obsidian.ai.base import AIProvider, CompletionRequest, Message, MessageRole
from obsidian.ai.providers.mock import MockProvider
from obsidian.ai.providers.ollama import OllamaProvider
from obsidian.ai.registry import _misconfiguration
from obsidian.core.config import settings


def _request(text: str) -> CompletionRequest:
    return CompletionRequest(messages=[Message(MessageRole.USER, text)])


def test_mock_satisfies_the_provider_protocol() -> None:
    assert isinstance(MockProvider(), AIProvider)


async def test_mock_output_is_deterministic() -> None:
    """Reproducibility is what makes AI-dependent tests assertable at all."""
    provider = MockProvider()
    first = await provider.complete(_request("analyze capture.pcap"))
    second = await provider.complete(_request("analyze capture.pcap"))

    assert first.content == second.content


async def test_different_input_yields_different_output() -> None:
    provider = MockProvider()
    a = await provider.complete(_request("analyze capture.pcap"))
    b = await provider.complete(_request("analyze security.evtx"))

    assert a.content != b.content


async def test_completion_reports_provenance_and_usage() -> None:
    response = await MockProvider().complete(_request("triage this host"))

    assert response.provider == "mock"
    assert response.model
    assert response.usage.total > 0


async def test_streaming_reassembles_to_the_full_completion() -> None:
    provider = MockProvider()
    request = _request("summarise the intrusion")

    streamed = "".join([chunk async for chunk in provider.stream(request)])
    complete = await provider.complete(request)

    assert streamed.split() == complete.content.split()


async def test_mock_reports_healthy_without_credentials() -> None:
    health = await MockProvider().health()
    assert health.available is True
    assert health.provider == "mock"


class TestOllamaCloud:
    """Ollama's hosted service, which needs a bearer token the local one does not.

    A key pasted into the model prompt was stored as OBSIDIAN_AI_MODEL, so the
    provider sent a credential as a model name to a local server that was not
    running. Nothing reported the mistake.
    """

    def test_a_key_selects_the_hosted_endpoint(self) -> None:
        provider = OllamaProvider(api_key="test-key")
        assert provider._base_url == OllamaProvider.CLOUD_URL
        assert provider.is_cloud is True

    def test_a_key_overrides_the_stale_local_default(self) -> None:
        """Switching to cloud must not leave the base URL pointing at loopback.

        Otherwise a cloud credential is sent to 127.0.0.1, which is not
        listening, and the failure looks like a network problem.
        """
        provider = OllamaProvider("http://localhost:11434", api_key="test-key")
        assert provider._base_url == OllamaProvider.CLOUD_URL

    def test_an_explicit_base_url_is_respected(self) -> None:
        provider = OllamaProvider("https://gateway.internal", api_key="test-key")
        assert provider._base_url == "https://gateway.internal"

    def test_no_key_stays_local_and_unauthenticated(self) -> None:
        provider = OllamaProvider()
        assert provider._base_url == OllamaProvider.LOCAL_URL
        assert provider.is_cloud is False
        assert "authorization" not in {k.lower() for k in provider._client.headers}

    def test_the_bearer_token_is_sent(self) -> None:
        provider = OllamaProvider(api_key="test-key")
        assert provider._client.headers["Authorization"] == "Bearer test-key"

    async def test_cloud_is_available_even_though_it_lists_no_local_models(self) -> None:
        """The hosted service reports no local inventory.

        Requiring the configured model to appear in /api/tags marked a working
        cloud provider unavailable, because the list is always empty there.
        """
        provider = OllamaProvider(api_key="test-key")

        async def fake_get(*_args: object, **_kwargs: object) -> httpx.Response:
            return httpx.Response(
                200, json={"models": []}, request=httpx.Request("GET", "https://ollama.com")
            )

        provider._client.get = fake_get  # type: ignore[method-assign]
        health = await provider.health()
        assert health.available is True
        assert "Cloud" in health.detail

    async def test_a_rejected_key_says_so(self) -> None:
        provider = OllamaProvider(api_key="wrong")

        async def fake_get(*_args: object, **_kwargs: object) -> httpx.Response:
            request = httpx.Request("GET", "https://ollama.com")
            raise httpx.HTTPStatusError(
                "401", request=request, response=httpx.Response(401, request=request)
            )

        provider._client.get = fake_get  # type: ignore[method-assign]
        health = await provider.health()
        assert health.available is False
        assert "rejected the API key" in health.detail

    async def test_a_401_without_a_key_asks_for_one(self) -> None:
        """A different fault needs a different instruction."""
        provider = OllamaProvider("https://gateway.internal")

        async def fake_get(*_args: object, **_kwargs: object) -> httpx.Response:
            request = httpx.Request("GET", "https://gateway.internal")
            raise httpx.HTTPStatusError(
                "401", request=request, response=httpx.Response(401, request=request)
            )

        provider._client.get = fake_get  # type: ignore[method-assign]
        health = await provider.health()
        assert "requires an API key" in health.detail


class TestMisconfigurationIsReported:
    def test_a_key_in_the_model_setting_is_named(self, monkeypatch) -> None:
        """The exact mistake the model prompt invites."""
        monkeypatch.setattr(settings, "ai_model", "b574393fb6c043159731ec5ae1ed78fe.D4bfoxC2")
        assert "API key" in (_misconfiguration() or "")

    @pytest.mark.parametrize("model", ["llama3.1", "gpt-oss:120b", "qwen2.5-coder:7b", ""])
    def test_real_model_names_are_not_flagged(self, monkeypatch, model: str) -> None:
        monkeypatch.setattr(settings, "ai_model", model)
        assert _misconfiguration() is None
