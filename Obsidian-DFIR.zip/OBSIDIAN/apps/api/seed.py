"""Bootstrap the database with an administrator account.

Idempotent: running it repeatedly will not create duplicates or reset an
existing password.

    python seed.py            # administrator only
    python seed.py --demo     # administrator + a demo case with sample IOCs
"""

from __future__ import annotations

import asyncio
import sys
from datetime import datetime, timezone

from obsidian.core.config import settings
from obsidian.core.logging import configure_logging
from obsidian.core.security import hash_password
from obsidian.db.models.case import Case
from obsidian.db.models.ioc import IOC
from obsidian.db.models.user import User
from obsidian.db.session import SessionLocal, dispose_engine
from obsidian.domain.enums import CaseStatus, IOCType, Role, Severity
from obsidian.repositories.case_repository import CaseRepository
from obsidian.repositories.user_repository import UserRepository


DEMO_TITLE = "DEMO - Suspicious outbound traffic from workstation WS-0142"

DEMO_IOCS = [
    (IOCType.IPV4, "185.220.101.45", Severity.HIGH, 85, "Repeated beaconing to this address every 60s."),
    (IOCType.DOMAIN, "update-check.example-c2.test", Severity.HIGH, 80, "Resolved by WS-0142 before the first beacon."),
    (IOCType.URL, "http://update-check.example-c2.test/gate.php", Severity.MEDIUM, 70, "Observed in HTTP POST requests."),
    (IOCType.IPV4, "10.0.4.17", Severity.INFO, 40, "Internal host WS-0142 (source of traffic)."),
]


async def seed_demo(session, owner_id: str) -> None:
    """Create one sample case with indicators so the UI has data on first run."""
    from sqlalchemy import select

    exists = (await session.execute(select(Case).where(Case.title == DEMO_TITLE))).scalar_one_or_none()
    if exists is not None:
        print("  Demo case already exists. Nothing to do.")
        return
    now = datetime.now(timezone.utc)
    reference = await CaseRepository(session).next_reference(year=now.year)
    case = Case(
        reference=reference,
        title=DEMO_TITLE,
        summary="Sample case created by seed.py --demo. Safe to delete.",
        status=CaseStatus.IN_PROGRESS,
        severity=Severity.HIGH,
        owner_id=owner_id,
        opened_at=now,
    )
    session.add(case)
    await session.flush()
    for ioc_type, value, severity, confidence, context in DEMO_IOCS:
        session.add(
            IOC(case_id=case.id, ioc_type=ioc_type, value=value, severity=severity,
                confidence=confidence, sightings=1, context=context)
        )
    await session.commit()
    print(f"  Demo case {reference} created with {len(DEMO_IOCS)} indicators.")


async def seed(demo: bool = False) -> int:
    configure_logging()
    email = settings.seed_admin_email.strip().lower()
    password = settings.seed_admin_password

    async with SessionLocal() as session:
        users = UserRepository(session)

        existing = await users.get_by_email(email)
        if existing is not None:
            print(f"  Administrator '{email}' already exists. Nothing to do.")
            if demo:
                await seed_demo(session, existing.id)
            return 0

        admin = User(
            email=email,
            full_name="OBSIDIAN Administrator",
            password_hash=hash_password(password),
            role=Role.ADMIN,
            is_active=True,
            is_verified=True,
        )
        await users.add(admin)
        await session.commit()
        if demo:
            await seed_demo(session, admin.id)

    print("  Administrator created.")
    print(f"    email:    {email}")
    print(f"    password: {password}")
    if password == "ChangeMe!2026":
        print(
            "\n  WARNING: this is the default password from .env.example.\n"
            "  Change OBSIDIAN_SEED_ADMIN_PASSWORD before exposing this "
            "instance to anyone."
        )
    return 0


if __name__ == "__main__":
    try:
        sys.exit(asyncio.run(seed(demo="--demo" in sys.argv[1:])))
    except KeyboardInterrupt:
        sys.exit(130)
    finally:
        asyncio.run(dispose_engine())
