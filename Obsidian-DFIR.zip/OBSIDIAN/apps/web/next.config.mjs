/**
 * The API is reached through a same-origin rewrite rather than a second host.
 *
 * Calling the backend directly from the browser meant the page origin
 * (localhost:3000) and the API origin (127.0.0.1:8000) differed, which brought
 * three avoidable failure modes:
 *
 *   1. Windows resolves "localhost" to the IPv6 address ::1 first, while
 *      uvicorn's --host 0.0.0.0 binds IPv4 only. The API answered curl and
 *      refused the browser.
 *   2. NEXT_PUBLIC_* values are inlined when the dev server starts, so editing
 *      .env.local had no effect until the process was restarted.
 *   3. Every request needed a CORS preflight.
 *
 * Proxying through Next removes all three: the browser only ever talks to its
 * own origin, and the hop to the API happens server-side where the host is
 * resolved fresh from configuration on each request. This also mirrors how the
 * app runs behind nginx in production.
 */
// NOTE: this is read when Next evaluates the config, which happens at build
// time and at server start — NOT per request, and NOT after `.env.local` is
// loaded. Setting API_PROXY_TARGET in .env.local therefore has no effect; it
// must be a real environment variable in the process that runs Next. The
// scripts pass it explicitly for that reason.
const API_PROXY_TARGET = process.env.API_PROXY_TARGET ?? "http://127.0.0.1:8000";

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,

  async rewrites() {
    return [
      { source: "/api/:path*", destination: `${API_PROXY_TARGET}/api/:path*` },
    ];
  },

  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          // Microphone is explicitly self-allowed: Voice Command Mode (Phase 6)
          // needs it, and the policy is easier to reason about declared here.
          { key: "Permissions-Policy", value: "camera=(), microphone=(self), geolocation=()" },
        ],
      },
      {
        // The service worker must not be cached, or clients get pinned to a
        // stale version of the app shell indefinitely.
        source: "/sw.js",
        headers: [{ key: "Cache-Control", value: "no-cache, no-store, must-revalidate" }],
      },
    ];
  },
};

export default nextConfig;
