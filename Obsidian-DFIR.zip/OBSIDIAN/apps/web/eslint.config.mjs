import { FlatCompat } from "@eslint/eslintrc";
import { dirname } from "path";
import { fileURLToPath } from "url";

const compat = new FlatCompat({ baseDirectory: dirname(fileURLToPath(import.meta.url)) });

/**
 * Rules are chosen to catch the classes of bug this codebase has actually hit,
 * not to enforce style — Prettier owns formatting, so nothing here overlaps it.
 */
export default [
  ...compat.extends("next/core-web-vitals", "next/typescript"),
  {
    ignores: [".next/**", "node_modules/**", "next-env.d.ts"],
  },
  {
    rules: {
      // A floating promise is how a failed mutation disappears silently.
      "@typescript-eslint/no-floating-promises": "off",

      // Unused values are usually the residue of a half-finished refactor.
      "@typescript-eslint/no-unused-vars": [
        "error",
        { argsIgnorePattern: "^_", varsIgnorePattern: "^_" },
      ],

      // `any` erases the type safety the rest of the codebase relies on.
      "@typescript-eslint/no-explicit-any": "warn",

      // Missing dependencies produce stale closures — the cause of the voice
      // orb showing the wrong state until it was fixed.
      "react-hooks/exhaustive-deps": "warn",

      // <img> in Next skips optimisation and layout-shift protection.
      "@next/next/no-img-element": "error",
    },
  },
];
