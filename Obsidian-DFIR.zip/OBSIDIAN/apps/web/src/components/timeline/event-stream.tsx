"use client";

import {
  Activity,
  FileUp,
  FolderPlus,
  Radio,
  ShieldAlert,
  Sparkles,
  type LucideIcon,
} from "lucide-react";
import Link from "next/link";
import * as React from "react";

import { Badge } from "@/components/ui/badge";
import { cn, formatDate } from "@/lib/utils";
import {
  SEVERITY_TONES,
  TIMELINE_SOURCE_LABELS,
  type TimelineEvent,
  type TimelineEventKind,
} from "@/types/api";

const ICONS: Record<TimelineEventKind, LucideIcon> = {
  "case.opened": FolderPlus,
  "case.status_changed": Activity,
  "evidence.uploaded": FileUp,
  "analysis.completed": Sparkles,
  "finding.raised": ShieldAlert,
  "capture.window": Radio,
  "indicator.observed": ShieldAlert,
};

const SEVERITY_RING: Record<string, string> = {
  info: "border-border bg-muted/50 text-muted-foreground",
  low: "border-primary/40 bg-primary/15 text-primary",
  medium: "border-accent/40 bg-accent/15 text-accent",
  high: "border-warning/40 bg-warning/15 text-warning",
  critical: "border-destructive/40 bg-destructive/15 text-destructive",
};

/**
 * Chronological event rail.
 *
 * Incident events — derived from what the evidence records — are visually
 * distinguished from investigation events. Conflating "when it happened" with
 * "when we noticed" produces a chronology that reads coherently and is wrong,
 * which is the specific failure mode this view exists to prevent.
 */
export function EventStream({
  events,
  showCase = false,
}: {
  events: TimelineEvent[];
  showCase?: boolean;
}) {
  return (
    <ol className="relative space-y-0">
      {events.map((event, index) => {
        const Icon = ICONS[event.kind] ?? Activity;
        const isLast = index === events.length - 1;
        const incident = event.source === "incident";

        return (
          <li key={event.id} className="relative flex gap-s3 pb-s4 last:pb-0">
            {!isLast ? (
              <span
                className={cn(
                  "absolute left-[15px] top-8 h-[calc(100%-1.5rem)] w-px",
                  incident ? "bg-destructive/25" : "bg-border/70",
                )}
                aria-hidden
              />
            ) : null}

            <span
              className={cn(
                "relative z-10 grid size-8 shrink-0 place-items-center rounded-full border",
                SEVERITY_RING[event.severity] ?? SEVERITY_RING.info,
              )}
              aria-hidden
            >
              <Icon className="size-3.5" />
            </span>

            <div className="min-w-0 flex-1 pt-1">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <p className="text-xs font-medium">{event.title}</p>
                <time
                  dateTime={event.occurred_at}
                  className="shrink-0 font-mono text-2xs tabular-nums text-muted-foreground"
                >
                  {formatDate(event.occurred_at)}
                </time>
              </div>

              {event.description ? (
                <p className="mt-0.5 text-2xs leading-relaxed text-muted-foreground">
                  {event.description}
                </p>
              ) : null}

              <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                <Badge variant={incident ? "destructive" : "neutral"}>
                  {TIMELINE_SOURCE_LABELS[event.source]}
                </Badge>
                {event.severity !== "info" ? (
                  <Badge variant={SEVERITY_TONES[event.severity]}>{event.severity}</Badge>
                ) : null}
                {showCase && event.case_reference && event.case_id ? (
                  <Link
                    href={`/cases/${event.case_id}`}
                    className="font-mono text-2xs text-primary hover:underline"
                  >
                    {event.case_reference}
                  </Link>
                ) : null}
                {event.actor ? (
                  <span className="text-2xs text-muted-foreground/70">{event.actor}</span>
                ) : null}
                {Array.isArray(event.metadata.mitre_techniques)
                  ? (event.metadata.mitre_techniques as string[]).map((t) => (
                      <a
                        key={t}
                        href={`https://attack.mitre.org/techniques/${t.replace(".", "/")}/`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="rounded-full border border-accent/30 bg-accent/10 px-1.5 py-px font-mono text-2xs text-accent"
                      >
                        {t}
                      </a>
                    ))
                  : null}
              </div>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
