"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, FileText, ShieldCheck } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useDownload } from "@/hooks/use-download";
import { ApiError } from "@/lib/api-client";
import { reportsApi } from "@/lib/api/reports";
import { formatBytes, relativeTime, shortHash } from "@/lib/utils";
import {
  REPORT_FORMAT_LABELS,
  REPORT_PROFILE_LABELS,
  type Report,
  type ReportFormat,
  type ReportProfile,
} from "@/types/api";

export function CaseReports({ caseId }: { caseId: string }) {
  const queryClient = useQueryClient();

  const { download: runDownload } = useDownload();
  const download = (report: Report) =>
    runDownload(report.id, report.title, () => reportsApi.download(report));
  const [profile, setProfile] = React.useState<ReportProfile>("technical");
  const [format, setFormat] = React.useState<ReportFormat>("pdf");

  const query = useQuery({
    queryKey: ["reports", caseId],
    queryFn: () => reportsApi.listForCase(caseId),
    enabled: Boolean(caseId),
  });

  const generate = useMutation({
    mutationFn: () => reportsApi.generate(caseId, profile, format),
    onSuccess: (report) => {
      void queryClient.invalidateQueries({ queryKey: ["reports"] });
      toast.success("Report generated", {
        description: `${REPORT_PROFILE_LABELS[report.profile]} · ${formatBytes(report.size_bytes)}`,
      });
    },
    onError: (error) =>
      toast.error("Generation failed", {
        description: error instanceof ApiError ? error.message : "Request failed.",
      }),
  });

  const verify = useMutation({
    mutationFn: (id: string) => reportsApi.verify(id),
    onSuccess: (result) =>
      result.valid
        ? toast.success("Integrity verified", { description: result.detail })
        : toast.error("Integrity check FAILED", { description: result.detail }),
  });

  return (
    <div className="space-y-s4">
      <div className="flex flex-wrap items-end gap-s2">
        <div className="space-y-1">
          <p className="text-2xs uppercase tracking-eyebrow text-muted-foreground">
            Profile
          </p>
          <Select value={profile} onValueChange={(v) => setProfile(v as ReportProfile)}>
            <SelectTrigger className="h-9 w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="executive">Executive</SelectItem>
              <SelectItem value="technical">Technical</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <p className="text-2xs uppercase tracking-eyebrow text-muted-foreground">
            Format
          </p>
          <Select value={format} onValueChange={(v) => setFormat(v as ReportFormat)}>
            <SelectTrigger className="h-9 w-36">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pdf">PDF</SelectItem>
              <SelectItem value="html">HTML</SelectItem>
              <SelectItem value="markdown">Markdown</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button size="sm" loading={generate.isPending} onClick={() => generate.mutate()}>
          <FileText />
          Generate
        </Button>
      </div>

      <p className="text-2xs leading-relaxed text-muted-foreground">
        The executive profile leads with an assessment and recommended actions.
        The technical profile adds the evidence inventory with custody hashes,
        every finding with its ATT&amp;CK mapping, and methodology. Reports are
        stored as generated, not rebuilt on download.
      </p>

      <Separator />

      {(query.data?.items.length ?? 0) === 0 ? (
        <EmptyState
          icon={FileText}
          title="No reports for this case"
          description="Generate one above once the evidence has been analysed."
          className="border-0"
        />
      ) : (
        <ul className="space-y-1.5">
          {(query.data?.items ?? []).map((report) => (
            <li
              key={report.id}
              className="flex flex-wrap items-center gap-s2 rounded-md border border-border/60 bg-white/[0.02] px-s3 py-s2"
            >
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-medium">{report.title}</p>
                <p className="truncate font-mono text-2xs text-muted-foreground">
                  sig {shortHash(report.signature, 20)} · {formatBytes(report.size_bytes)} ·{" "}
                  {relativeTime(report.created_at)}
                </p>
              </div>
              <Badge variant={report.profile === "executive" ? "accent" : "primary"}>
                {REPORT_PROFILE_LABELS[report.profile]}
              </Badge>
              <Badge variant="neutral">{REPORT_FORMAT_LABELS[report.format]}</Badge>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => verify.mutate(report.id)}
                aria-label={`Verify ${report.title}`}
                title="Verify integrity"
              >
                <ShieldCheck />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => download(report)}
                aria-label={`Download ${report.title}`}
                title="Download"
              >
                <Download />
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
