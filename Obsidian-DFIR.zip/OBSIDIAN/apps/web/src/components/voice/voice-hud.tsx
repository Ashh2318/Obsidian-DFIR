"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, Mic, MicOff, Radio, Square, Volume2, X } from "lucide-react";
import { useParams, usePathname, useRouter } from "next/navigation";
import * as React from "react";
import { createPortal } from "react-dom";

import { VoiceOrb, type VoiceState } from "@/components/voice/voice-orb";
import { Alert } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { VoiceFindings, type VoiceFinding } from "@/components/voice/voice-findings";
import { assistantApi, streamAssistant } from "@/lib/api/assistant";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  useAvailableVoices,
  useSpeechRecognition,
  useSpeechSupport,
  useSpeechSynthesis,
} from "@/hooks/use-speech";
import { usePersistedState } from "@/lib/persisted-state";
import { ApiError } from "@/lib/api-client";
import { casesApi } from "@/lib/api/cases";
import { voiceApi } from "@/lib/api/voice";
import { cn } from "@/lib/utils";
import {
  CASE_STATUS_LABELS,
  SEVERITY_TONES,
  type CaseOverview,
} from "@/types/api";

interface Exchange {
  id: string;
  utterance: string;
  speech: string;
  succeeded: boolean;
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-md border border-white/10 bg-white/[0.04] px-s3 py-s2 text-center">
      <p className="font-mono text-lg font-semibold tabular-nums">{value}</p>
      <p className="mt-0.5 text-2xs uppercase tracking-eyebrow text-muted-foreground">
        {label}
      </p>
    </div>
  );
}

/**
 * Voice Command Mode heads-up display.
 *
 * Full-viewport rather than a dialog: this is a mode, not a prompt. The
 * workspace behind it is blurred out so nothing competes with the orb, and live
 * case telemetry is shown because an analyst speaking to the system still needs
 * to see the numbers being discussed.
 *
 * Rendered through a portal to escape the topbar's backdrop-filter containing
 * block — see the note in the previous implementation.
 */
export function VoiceHud({
  onClose,
  wakeWordEnabled,
  onWakeWordChange,
  pendingUtterance,
}: {
  onClose: () => void;
  wakeWordEnabled: boolean;
  onWakeWordChange: (enabled: boolean) => void;
  /** Command captured alongside the wake word, run immediately on open. */
  pendingUtterance?: string | null;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useParams<{ caseId?: string }>();
  const queryClient = useQueryClient();

  const support = useSpeechSupport();
  const [state, setState] = React.useState<VoiceState>("idle");
  const [interim, setInterim] = React.useState("");
  const [error, setError] = React.useState<string | null>(null);
  const [history, setHistory] = React.useState<Exchange[]>([]);

  // The previous turn, so a continuation resolves against it.
  const lastTurn = React.useRef<{ action: string; subject: string } | null>(null);

  const caseId = pathname?.startsWith("/cases/") ? (params?.caseId ?? null) : null;

  const overview = useQuery({
    queryKey: ["case-overview", caseId],
    queryFn: () => casesApi.overview(caseId as string),
    enabled: Boolean(caseId),
    refetchInterval: 15_000,
  });

  const capabilities = useQuery({
    queryKey: ["voice-capabilities"],
    queryFn: () => voiceApi.capabilities(),
  });

  // What the last turn produced, rendered under the orb. Speech on its own
  // left the analyst with a sentence and an unchanged screen.
  const [findings, setFindings] = React.useState<{
    caseTitle?: string;
    items: VoiceFinding[];
  } | null>(null);
  const [answer, setAnswer] = React.useState<{ question: string; text: string } | null>(
    null,
  );

  const voices = useAvailableVoices();

  // Distinguishes "still loading" from "genuinely none", so the warning below
  // does not flash on every open while the platform list is still arriving.
  const [voicesSettled, setVoicesSettled] = React.useState(false);
  React.useEffect(() => {
    const timer = window.setTimeout(() => setVoicesSettled(true), 8_000);
    return () => window.clearTimeout(timer);
  }, []);
  const [voiceName, setVoiceName] = usePersistedState<string | null>(
    "obsidian.voice.name",
    null,
  );

  // Declared before the recogniser so its suspend/resume can be referenced.
  const recogniser = React.useRef<{ suspend: () => void; resume: () => void }>({
    suspend: () => {},
    resume: () => {},
  });

  const { speaking, speak, cancel } = useSpeechSynthesis({
    voiceName,
    // The microphone is closed for the whole duration of playback and reopened
    // afterwards. Without this the assistant transcribes its own reply and
    // submits it as the next command.
    onSpeakingChange: (isSpeaking) => {
      if (isSpeaking) recogniser.current.suspend();
      else recogniser.current.resume();
    },
  });

  const command = useMutation({
    mutationFn: (utterance: string) =>
      voiceApi.command(utterance, {
        currentCaseId: caseId,
        lastAction: lastTurn.current?.action,
        lastSubject: lastTurn.current?.subject,
      }),
    onMutate: () => setState("thinking"),
    onSuccess: (result) => {
      setHistory((current) =>
        [
          {
            id: crypto.randomUUID(),
            utterance: result.intent.utterance,
            speech: result.speech,
            succeeded: result.succeeded,
          },
          ...current,
        ].slice(0, 20),
      );

      // Remember this turn so the next one can say "that".
      if (result.succeeded) {
        lastTurn.current = {
          action: result.intent.action,
          subject:
            (result.data.reference as string) ??
            overview.data?.reference ??
            result.intent.utterance,
        };
      }

      speak(result.speech);
      setState("speaking");

      const action = result.ui_action;
      if (action?.type === "navigate" && action.route) {
        router.push(action.route);
      } else if (action?.type === "refresh") {
        void queryClient.invalidateQueries();
      } else if (action?.type === "findings") {
        // Rendered here rather than navigated to: the analyst asked a question
        // and is owed the answer, not a page that might show it.
        setFindings({
          caseTitle: result.data.case_title as string | undefined,
          items: (result.data.findings as VoiceFinding[]) ?? [],
        });
      } else if (action?.type === "upload_evidence" && action.route) {
        // The file dialog needs a real user gesture, so voice can only carry
        // the analyst to the uploader with it already open.
        router.push(`${action.route}?upload=1`);
      } else if (action?.type === "ask_assistant") {
        // Previously this navigated to /assistant and dropped the question, so
        // the assistant said it would look and then nothing happened at all.
        void ask(
          (action.question as string) ?? result.intent.utterance,
          (action.case_id as string | null) ?? caseId ?? null,
        );
      }
      void overview.refetch();
    },
    onError: (caught) => {
      setError(caught instanceof ApiError ? caught.message : "Could not reach the API.");
      setState("error");
      speak("Sorry, I could not reach the server.");
    },
  });

  // Streams a real answer from the case-grounded assistant and speaks it.
  //
  // The conversation is created on demand and reused for the rest of the
  // session, so follow-up questions keep their thread instead of starting a new
  // one for every utterance.
  const conversationId = React.useRef<string | null>(null);
  const ask = React.useCallback(
    async (question: string, forCaseId: string | null) => {
      setAnswer({ question, text: "" });
      try {
        if (!conversationId.current) {
          const conversation = await assistantApi.create(forCaseId);
          conversationId.current = conversation.id;
        }
        let text = "";
        await streamAssistant(conversationId.current, question, {
          onDelta: (delta) => {
            text += delta;
            setAnswer({ question, text });
          },
          onDone: () => {
            const spoken = text.trim();
            if (spoken) {
              // Spoken in full: the point of asking by voice is to be answered
              // by voice.
              speak(spoken);
              setState("speaking");
            } else {
              speak("I could not find an answer in this case's evidence.");
            }
          },
          onError: (message) => {
            setAnswer({ question, text: message });
            speak("I could not complete that question.");
          },
        });
      } catch (caught) {
        const message =
          caught instanceof ApiError ? caught.message : "The assistant is unavailable.";
        setAnswer({ question, text: message });
        speak("I could not reach the assistant.");
      }
    },
    [speak],
  );

  const { listening, start, stop, suspend, resume } = useSpeechRecognition({
    // Continuous, so consecutive commands need no click between them.
    continuous: true,
    onFinal: (transcript) => {
      setInterim("");
      if (!transcript) return;
      // Speaking over the assistant stops it. The recogniser is suspended
      // during playback, so this lands on the first thing said after it
      // finishes — but it also covers the queued-sentence case, where speech
      // is still draining when the next command arrives.
      cancel();
      command.mutate(transcript);
    },
    onInterim: setInterim,
    onError: (message) => {
      setError(message);
      setState("error");
    },
  });

  React.useEffect(() => {
    recogniser.current = { suspend, resume };
  }, [suspend, resume]);

  // Start listening as soon as the mode opens: opening it is the intent to speak.
  //
  // The guard is only set once recognition support is actually known. Setting
  // it on the first render — before the support probe resolves — meant the
  // effect returned early on the re-run that had support, and listening never
  // started at all.
  const startedRef = React.useRef(false);
  React.useEffect(() => {
    if (startedRef.current || !support.recognition) return;
    startedRef.current = true;
    if (pendingUtterance) command.mutate(pendingUtterance);
    start();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [support.recognition]);

  React.useEffect(() => {
    if (command.isPending) setState("thinking");
    else if (speaking) setState("speaking");
    else if (listening) setState("listening");
    else if (!error) setState("idle");
  }, [command.isPending, speaking, listening, error]);

  const close = React.useCallback(() => {
    cancel();
    stop();
    onClose();
  }, [cancel, stop, onClose]);

  /** Stop talking immediately and go back to listening. */
  const interrupt = React.useCallback(() => {
    cancel();
    setState(listening ? "listening" : "idle");
  }, [cancel, listening]);

  React.useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      // While speaking, Escape stops the speech rather than closing the mode:
      // wanting it to stop talking is far more common than wanting to leave,
      // and closing would discard the answer on screen too.
      if (event.key === "Escape") {
        if (speaking) interrupt();
        else close();
        return;
      }
      if (event.code === "Space" && speaking) {
        const target = event.target as HTMLElement | null;
        // Not while typing, and not when a button has focus — Space activates it.
        if (target && /^(INPUT|TEXTAREA|BUTTON|SELECT)$/.test(target.tagName)) return;
        event.preventDefault();
        interrupt();
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [close, speaking, interrupt]);

  const statusLabel = {
    idle: speaking ? "Microphone paused while speaking" : "Say a command",
    listening: "Listening",
    thinking: "Working",
    speaking: "Speaking",
    error: "Something went wrong",
  }[state];

  const stats: CaseOverview | undefined = overview.data;

  // Portalled to <body>. A `fixed` element under an ancestor with
  // backdrop-filter, filter or transform resolves against that ancestor rather
  // than the viewport — the exact bug that made the first version spill across
  // the header. Portalling makes the mount point irrelevant.
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  return createPortal(
    <div className="fixed inset-0 z-[100] flex flex-col bg-black/85 backdrop-blur-2xl">
      <header className="flex shrink-0 items-center gap-s3 border-b border-white/10 px-s5 py-s3">
        <Radio className={cn("size-4", listening ? "text-primary" : "text-muted-foreground")} />
        <p className="text-sm font-medium">Voice Command Mode</p>
        {caseId ? (
          <Badge variant="primary" className="text-2xs">
            case in context
          </Badge>
        ) : null}

        <div className="ml-auto flex items-center gap-s3">
          {/* Always rendered. Hiding this until getVoices() had populated meant
              the control simply was not present when the analyst went looking
              for it, which reads as a missing feature rather than a pending one. */}
          <label className="flex items-center gap-2 text-2xs text-muted-foreground">
            Voice
            <Select
              value={voiceName ?? "auto"}
              disabled={voices.length === 0}
              onValueChange={(value) => {
                const next = value === "auto" ? null : value;
                setVoiceName(next);
                // Previewed immediately: a voice is chosen by ear, not by name.
                window.setTimeout(() => speak("Voice set. Ready for your command."), 60);
              }}
            >
              <SelectTrigger className="h-8 w-48 text-2xs">
                <SelectValue
                  placeholder={
                    support.synthesis ? "Loading voices…" : "Not supported"
                  }
                />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto">Automatic</SelectItem>
                {voices.map((voice) => (
                  <SelectItem key={voice.name} value={voice.name}>
                    {voice.name}
                    {voice.local ? "" : " (cloud)"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {/* Confirms the chosen voice actually produces audio. Silence has
                several causes — muted tab, no voices installed, wrong output
                device — and they are indistinguishable without a way to test. */}
            <Button
              variant="ghost"
              size="icon"
              className="size-8"
              onClick={() => speak("Obsidian voice check. I am ready.")}
              disabled={!support.synthesis}
              aria-label="Test the selected voice"
              title="Test voice"
            >
              <Volume2 className="size-3.5" />
            </Button>
          </label>

          <label className="flex items-center gap-2 text-2xs text-muted-foreground">
            <Switch
              checked={wakeWordEnabled}
              onCheckedChange={onWakeWordChange}
              aria-label="Always listen for the wake word"
            />
            &ldquo;Hey Obsidian&rdquo; always on
          </label>
          <Button variant="ghost" size="icon" onClick={close} aria-label="Close voice mode">
            <X />
          </Button>
        </div>
      </header>

      <div className="flex min-h-0 flex-1 flex-col items-center justify-center gap-s4 px-s5 py-s4">
        <VoiceOrb
          state={state}
          size={140}
          onClick={() => {
            if (speaking) interrupt();
            else if (listening) stop();
            else start();
          }}
        />

        <p
          className={cn(
            "text-xs uppercase tracking-eyebrow",
            state === "error" ? "text-destructive" : "text-muted-foreground",
          )}
          aria-live="polite"
        >
          {statusLabel}
        </p>

        {interim ? (
          <p className="max-w-2xl text-center text-lg italic text-foreground/80">
            &ldquo;{interim}&rdquo;
          </p>
        ) : null}

        {stats ? (
          <div className="w-full max-w-3xl space-y-s3">
            <div className="flex flex-wrap items-center justify-center gap-2">
              <span className="font-mono text-xs text-primary">{stats.reference}</span>
              <span className="text-sm font-medium">{stats.title}</span>
              <Badge variant={SEVERITY_TONES[stats.severity]}>{stats.severity}</Badge>
              <Badge variant="neutral">{CASE_STATUS_LABELS[stats.status]}</Badge>
            </div>

            <div className="grid grid-cols-2 gap-s2 sm:grid-cols-5">
              <Stat label="Evidence" value={stats.evidence_count} />
              <Stat label="Analysed" value={stats.analysed_count} />
              <Stat label="Findings" value={stats.finding_count} />
              <Stat label="Indicators" value={stats.ioc_count} />
              <Stat label="Risk" value={`${stats.risk_score}`} />
            </div>

            <div className="space-y-1">
              <Progress value={stats.risk_score} />
              {stats.top_finding ? (
                <p className="text-center text-2xs text-muted-foreground">
                  Most severe: {stats.top_finding}
                </p>
              ) : null}
            </div>
          </div>
        ) : null}

        {findings ? (
          <VoiceFindings
            caseTitle={findings.caseTitle}
            findings={findings.items}
            onOpenEvidence={() =>
              router.push(`/cases/${caseId ?? findings.items[0]?.evidence_id}`)
            }
          />
        ) : null}

        {answer ? (
          <div className="w-full max-w-3xl space-y-1 rounded-lg border border-primary/25 bg-primary/[0.06] p-s3">
            <p className="text-2xs uppercase tracking-eyebrow text-primary">
              {answer.question}
            </p>
            <p className="whitespace-pre-wrap text-sm leading-relaxed">
              {answer.text || "Reading the case evidence\u2026"}
            </p>
          </div>
        ) : null}

        {support.synthesis && voices.length === 0 && voicesSettled ? (
          <Alert variant="warning" className="max-w-xl">
            No speech voices are installed, so replies cannot be spoken. On
            Windows, add one under Settings &rsaquo; Time &amp; language &rsaquo;
            Speech, then reload this page. Everything else still works and
            replies remain on screen.
          </Alert>
        ) : null}

        {!support.recognition ? (
          <Alert variant="warning" className="max-w-xl">
            This browser has no speech recognition. Chrome or Edge is required.
          </Alert>
        ) : support.cloudRecognition ? (
          <Alert variant="warning" icon={AlertTriangle} className="max-w-xl">
            This browser&apos;s recogniser streams audio to Google for
            transcription. Avoid speaking case-sensitive detail aloud on
            regulated investigations.
          </Alert>
        ) : null}

        {error ? (
          <Alert variant="destructive" className="max-w-xl">
            {error}
          </Alert>
        ) : null}

        {history.length === 0 && capabilities.data ? (
          <div className="max-w-2xl text-center">
            <p className="mb-2 text-2xs uppercase tracking-eyebrow text-muted-foreground">
              Try saying
            </p>
            <div className="flex flex-wrap justify-center gap-1.5">
              {capabilities.data.examples.slice(0, 6).map((example) => (
                <button
                  key={example}
                  type="button"
                  onClick={() => command.mutate(example)}
                  className="rounded-full border border-white/15 px-2.5 py-1 text-2xs text-muted-foreground transition-colors duration-fast hover:border-primary/50 hover:text-foreground"
                >
                  {example}
                </button>
              ))}
            </div>
          </div>
        ) : null}
      </div>

      {history.length > 0 ? (
        <ScrollArea className="max-h-56 shrink-0 border-t border-white/10">
          <ul className="mx-auto max-w-3xl space-y-1.5 px-s5 py-s3">
            {history.map((exchange) => (
              <li
                key={exchange.id}
                className={cn(
                  "rounded-md border px-s3 py-s2",
                  exchange.succeeded
                    ? "border-white/10 bg-white/[0.04]"
                    : "border-warning/30 bg-warning/10",
                )}
              >
                <p className="text-2xs text-muted-foreground">
                  &ldquo;{exchange.utterance}&rdquo;
                </p>
                <p className="mt-0.5 text-xs leading-relaxed">{exchange.speech}</p>
              </li>
            ))}
          </ul>
        </ScrollArea>
      ) : null}

      <footer className="flex shrink-0 items-center justify-center gap-s3 border-t border-white/10 px-s5 py-s3">
        {speaking ? (
          <Button size="lg" variant="destructive" onClick={interrupt}>
            <Square />
            Stop speaking
          </Button>
        ) : (
          <Button
            size="lg"
            onClick={() => (listening ? stop() : start())}
            disabled={!support.recognition}
          >
            {listening ? <MicOff /> : <Mic />}
            {listening ? "Stop listening" : "Start listening"}
          </Button>
        )}
        <p className="text-2xs text-muted-foreground">
          {speaking
            ? "Space or Esc to stop · click the orb to interrupt"
            : "Listening stays on between commands · Esc to close"}
        </p>
      </footer>
    </div>,
    document.body,
  );
}
