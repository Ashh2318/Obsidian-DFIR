"use client";

import { Bar, BarChart, Cell, XAxis, YAxis } from "recharts";

import {
  CHART_AXIS_PROPS,
  CHART_COLORS,
  ChartContainer,
  ChartTooltip,
} from "@/components/ui/chart";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

export interface VoiceFinding {
  evidence_id: string;
  evidence: string;
  title: string;
  severity: string;
  detail: string;
}

/** Highest severity first, so the chart and the list agree on what matters. */
const SEVERITY_ORDER = ["critical", "high", "medium", "low", "info"] as const;

const SEVERITY_FILL: Record<string, string> = {
  critical: CHART_COLORS.destructive,
  high: "hsl(20 90% 58%)",
  medium: CHART_COLORS.warning,
  low: CHART_COLORS.primary,
  info: CHART_COLORS.muted,
};

const SEVERITY_TONE: Record<string, "destructive" | "warning" | "primary" | "neutral"> = {
  critical: "destructive",
  high: "destructive",
  medium: "warning",
  low: "primary",
  info: "neutral",
};

/**
 * What the assistant just described, shown while it is still speaking.
 *
 * Speech alone left the analyst with a sentence and an unchanged screen — the
 * assistant would say it had found something and nothing would appear. The
 * numbers behind the sentence are rendered here so the two always agree.
 */
export function VoiceFindings({
  caseTitle,
  findings,
  onOpenEvidence,
}: {
  caseTitle?: string;
  findings: VoiceFinding[];
  onOpenEvidence?: (evidenceId: string) => void;
}) {
  if (findings.length === 0) return null;

  const counts = SEVERITY_ORDER.map((severity) => ({
    severity,
    label: severity[0].toUpperCase() + severity.slice(1),
    count: findings.filter((finding) => finding.severity === severity).length,
  })).filter((entry) => entry.count > 0);

  return (
    <div className="w-full max-w-3xl space-y-s3 rounded-lg border border-white/10 bg-white/[0.03] p-s3">
      <div className="flex items-baseline justify-between gap-s3">
        <p className="text-2xs uppercase tracking-eyebrow text-muted-foreground">
          Findings{caseTitle ? ` · ${caseTitle}` : ""}
        </p>
        <p className="text-2xs text-muted-foreground">
          {findings.length} total across {new Set(findings.map((f) => f.evidence_id)).size}{" "}
          artefact(s)
        </p>
      </div>

      <ChartContainer height={112}>
        <BarChart data={counts} layout="vertical" margin={{ left: 4, right: 16 }}>
          <XAxis type="number" {...CHART_AXIS_PROPS} allowDecimals={false} />
          <YAxis type="category" dataKey="label" width={64} {...CHART_AXIS_PROPS} />
          <ChartTooltip />
          <Bar dataKey="count" name="Findings" radius={[0, 3, 3, 0]} barSize={14}>
            {counts.map((entry) => (
              <Cell key={entry.severity} fill={SEVERITY_FILL[entry.severity]} />
            ))}
          </Bar>
        </BarChart>
      </ChartContainer>

      <ScrollArea className="max-h-40">
        <ul className="space-y-1.5 pr-s2">
          {findings.slice(0, 12).map((finding, index) => (
            <li
              key={`${finding.evidence_id}-${index}`}
              className={cn(
                "rounded-md border border-white/10 bg-black/20 px-s3 py-s2",
                onOpenEvidence && "cursor-pointer hover:border-primary/40",
              )}
              onClick={() => onOpenEvidence?.(finding.evidence_id)}
            >
              <div className="flex items-center gap-2">
                <Badge variant={SEVERITY_TONE[finding.severity] ?? "neutral"} className="text-2xs">
                  {finding.severity}
                </Badge>
                <p className="truncate text-xs font-medium">{finding.title}</p>
              </div>
              {finding.detail ? (
                <p className="mt-0.5 line-clamp-2 text-2xs text-muted-foreground">
                  {finding.detail}
                </p>
              ) : null}
              <p className="mt-0.5 truncate font-mono text-2xs text-muted-foreground/70">
                {finding.evidence}
              </p>
            </li>
          ))}
        </ul>
      </ScrollArea>
    </div>
  );
}
