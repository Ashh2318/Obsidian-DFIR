"use client";

import { Mic, Sparkles } from "lucide-react";
import * as React from "react";

import { cn } from "@/lib/utils";

export type VoiceState = "idle" | "listening" | "thinking" | "speaking" | "error";

const STATE_STYLES: Record<VoiceState, { ring: string; glow: string; icon: string }> = {
  idle: {
    ring: "border-border/70",
    glow: "",
    icon: "text-muted-foreground",
  },
  listening: {
    ring: "border-primary",
    glow: "shadow-[0_0_40px_-4px_hsl(var(--primary)/0.8)]",
    icon: "text-primary",
  },
  thinking: {
    ring: "border-accent",
    glow: "shadow-[0_0_40px_-6px_hsl(var(--accent)/0.7)]",
    icon: "text-accent",
  },
  speaking: {
    ring: "border-success",
    glow: "shadow-[0_0_40px_-4px_hsl(var(--success)/0.7)]",
    icon: "text-success",
  },
  error: {
    ring: "border-destructive",
    glow: "shadow-[0_0_36px_-8px_hsl(var(--destructive)/0.7)]",
    icon: "text-destructive",
  },
};

/**
 * The voice orb.
 *
 * Each state is distinguishable by *motion* as well as colour: expanding rings
 * while listening, orbiting dots while thinking, a pulsing bar while speaking.
 * Colour alone would leave the state unreadable to a colour-blind analyst, and
 * the whole point of the orb is telling you at a glance whether it heard you.
 */
export function VoiceOrb({
  state,
  size = 120,
  onClick,
}: {
  state: VoiceState;
  size?: number;
  onClick?: () => void;
}) {
  const styles = STATE_STYLES[state];
  const label = {
    idle: "Voice idle. Click or say the wake word.",
    listening: "Listening",
    thinking: "Thinking",
    speaking: "Speaking",
    error: "Voice error",
  }[state];

  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      className="relative grid place-items-center rounded-full focus-visible:outline-none"
      style={{ width: size, height: size }}
    >
      {/* Expanding rings while listening — the visual analogue of sound. */}
      {state === "listening" ? (
        <>
          <span className="absolute inset-0 animate-pulse-ring rounded-full border-2 border-primary/40" />
          <span
            className="absolute inset-0 animate-pulse-ring rounded-full border-2 border-primary/25"
            style={{ animationDelay: "0.6s" }}
          />
        </>
      ) : null}

      {/* Orbiting dots while thinking. */}
      {state === "thinking" ? (
        <span
          className="absolute inset-0 rounded-full"
          style={{ animation: "spin 1.8s linear infinite" }}
        >
          {[0, 120, 240].map((angle) => (
            <span
              key={angle}
              className="absolute size-2 rounded-full bg-accent"
              style={{
                top: "50%",
                left: "50%",
                transform: `rotate(${angle}deg) translateY(-${size / 2 - 6}px)`,
                transformOrigin: "0 0",
              }}
            />
          ))}
        </span>
      ) : null}

      <span
        className={cn(
          "grid place-items-center rounded-full border-2 bg-[hsl(var(--elevated))]/80 backdrop-blur-xl transition-all duration-normal",
          styles.ring,
          styles.glow,
        )}
        style={{ width: size * 0.72, height: size * 0.72 }}
      >
        {state === "speaking" ? (
          <span className="flex items-end gap-0.5" aria-hidden>
            {[0, 1, 2, 3, 4].map((bar) => (
              <span
                key={bar}
                className="w-1 animate-pulse rounded-full bg-success"
                style={{
                  height: `${8 + ((bar % 3) + 1) * 5}px`,
                  animationDelay: `${bar * 90}ms`,
                }}
              />
            ))}
          </span>
        ) : state === "thinking" ? (
          <Sparkles className={cn("size-6", styles.icon)} aria-hidden />
        ) : (
          <Mic className={cn("size-6 transition-colors duration-normal", styles.icon)} aria-hidden />
        )}
      </span>
    </button>
  );
}
