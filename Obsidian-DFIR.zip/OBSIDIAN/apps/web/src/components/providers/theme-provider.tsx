"use client";

import * as React from "react";

import { usePersistedState } from "@/lib/persisted-state";
import { applyTheme, THEME_PRESETS, type Density } from "@/lib/theme";

interface ThemeState {
  presetId: string;
  setPresetId: (id: string) => void;
  density: Density;
  setDensity: (density: Density) => void;
}

const ThemeContext = React.createContext<ThemeState | null>(null);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [presetId, setPresetId] = usePersistedState("obsidian.theme.preset", "obsidian");
  const [density, setDensity] = usePersistedState<Density>(
    "obsidian.theme.density",
    "comfortable",
  );

  // Applied in an effect rather than during render: this mutates the DOM, which
  // is a side effect and must not run while React is rendering.
  React.useEffect(() => {
    applyTheme(presetId, density);
  }, [presetId, density]);

  const value = React.useMemo(
    () => ({ presetId, setPresetId, density, setDensity }),
    [presetId, setPresetId, density, setDensity],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeState {
  const context = React.useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used within ThemeProvider.");
  return context;
}

export { THEME_PRESETS };
