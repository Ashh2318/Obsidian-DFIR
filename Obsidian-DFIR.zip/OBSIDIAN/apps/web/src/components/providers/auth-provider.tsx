"use client";

import { useRouter } from "next/navigation";
import * as React from "react";

import { api } from "@/lib/api-client";
import { tokenStore } from "@/lib/token-store";
import type { User } from "@/types/api";

interface AuthContextValue {
  user: User | null;
  /** True until the initial silent-refresh attempt resolves. */
  initializing: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: (allSessions?: boolean) => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = React.createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [user, setUser] = React.useState<User | null>(null);
  const [initializing, setInitializing] = React.useState(true);

  // Keep React state in sync with the module-level store, which the API client
  // writes to directly during a silent refresh.
  React.useEffect(() => tokenStore.subscribe(setUser), []);

  // On mount, the access token is gone (it only ever lived in memory). Attempt
  // one silent refresh to rehydrate the session before rendering guarded routes.
  React.useEffect(() => {
    let cancelled = false;
    void (async () => {
      if (tokenStore.getRefreshToken()) {
        await api.restoreSession();
      }
      if (!cancelled) setInitializing(false);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const login = React.useCallback(async (email: string, password: string) => {
    const result = await api.login(email, password);
    tokenStore.setSession(
      result.tokens.access_token,
      result.tokens.refresh_token,
      result.user,
    );
  }, []);

  const logout = React.useCallback(
    async (allSessions = false) => {
      try {
        await api.logout(tokenStore.getRefreshToken(), allSessions);
      } catch {
        // A failed revocation must not trap the user in a signed-in shell;
        // clearing locally is the safer outcome either way.
      } finally {
        tokenStore.clear();
        router.replace("/login");
      }
    },
    [router],
  );

  const refreshUser = React.useCallback(async () => {
    tokenStore.setUser(await api.me());
  }, []);

  const value = React.useMemo(
    () => ({ user, initializing, login, logout, refreshUser }),
    [user, initializing, login, logout, refreshUser],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = React.useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within an AuthProvider.");
  return context;
}
