"use client";

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, FileUp, Upload, XCircle } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { API_URL, ApiError } from "@/lib/api-client";
import { tokenStore } from "@/lib/token-store";
import { cn, formatBytes } from "@/lib/utils";
import type { Evidence } from "@/types/api";

interface QueueItem {
  id: string;
  file: File;
  progress: number;
  state: "pending" | "uploading" | "done" | "error";
  message?: string;
}

/**
 * Drag-and-drop evidence upload with real progress.
 *
 * Uses XMLHttpRequest rather than fetch: fetch still cannot report upload
 * progress in any shipping browser, and a progress bar that jumps 0 → 100 on a
 * multi-gigabyte capture is worse than none. The auth header and error handling
 * mirror the shared client.
 */
function uploadWithProgress(
  caseId: string,
  file: File,
  onProgress: (percent: number) => void,
): Promise<Evidence> {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open("POST", `${API_URL}/api/v1/cases/${caseId}/evidence`);

    const token = tokenStore.getAccessToken();
    if (token) request.setRequestHeader("Authorization", `Bearer ${token}`);

    request.upload.addEventListener("progress", (event) => {
      if (event.lengthComputable) {
        onProgress(Math.round((event.loaded / event.total) * 100));
      }
    });

    request.addEventListener("load", () => {
      let body: unknown = null;
      try {
        body = JSON.parse(request.responseText);
      } catch {
        /* non-JSON response */
      }
      if (request.status >= 200 && request.status < 300) {
        resolve(body as Evidence);
      } else {
        const parsed = body as { error?: string; message?: string } | null;
        reject(
          new ApiError(
            request.status,
            parsed?.error ?? "upload_failed",
            parsed?.message ?? `Upload failed with status ${request.status}.`,
          ),
        );
      }
    });

    request.addEventListener("error", () =>
      reject(new Error("The connection dropped during upload.")),
    );
    request.addEventListener("abort", () => reject(new Error("Upload cancelled.")));

    const form = new FormData();
    form.append("file", file);
    request.send(form);
  });
}

export function EvidenceUploader({
  caseId,
  /** Open the file dialog on mount — used when arriving here by voice. */
  autoOpen = false,
}: {
  caseId: string;
  autoOpen?: boolean;
}) {
  const [queue, setQueue] = React.useState<QueueItem[]>([]);
  const [dragging, setDragging] = React.useState(false);
  const inputRef = React.useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();

  // Choosing a file requires a user gesture the page cannot synthesise, so the
  // most voice can do is put the dropzone in front of the analyst and focus it.
  // Claiming the upload happened would be worse than admitting it cannot.
  const opened = React.useRef(false);
  React.useEffect(() => {
    if (!autoOpen || opened.current) return;
    opened.current = true;
    inputRef.current?.focus();
    inputRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [autoOpen]);

  const update = React.useCallback(
    (id: string, patch: Partial<QueueItem>) =>
      setQueue((current) => current.map((i) => (i.id === id ? { ...i, ...patch } : i))),
    [],
  );

  const mutation = useMutation({
    mutationFn: async (item: QueueItem) => {
      update(item.id, { state: "uploading" });
      return uploadWithProgress(caseId, item.file, (percent) =>
        update(item.id, { progress: percent }),
      );
    },
    onSuccess: (_evidence, item) => {
      update(item.id, { state: "done", progress: 100 });
      void queryClient.invalidateQueries({ queryKey: ["evidence", caseId] });
      toast.success("Evidence ingested", { description: item.file.name });
    },
    onError: (error, item) => {
      const message =
        error instanceof ApiError ? error.message : "The upload failed.";
      update(item.id, { state: "error", message });
      toast.error("Upload failed", { description: `${item.file.name} — ${message}` });
    },
  });

  const enqueue = React.useCallback(
    (files: FileList | null) => {
      if (!files?.length) return;
      const items: QueueItem[] = Array.from(files).map((file) => ({
        id: crypto.randomUUID(),
        file,
        progress: 0,
        state: "pending",
      }));
      setQueue((current) => [...items, ...current]);

      // Sequential rather than parallel: concurrent multi-gigabyte uploads
      // saturate the link and make every individual transfer slower. Each
      // failure is swallowed so one bad artefact does not abort the rest of
      // the queue — per-item state already records it.
      void (async () => {
        for (const item of items) {
          try {
            await mutation.mutateAsync(item);
          } catch {
            /* state and toast are handled in the mutation's onError */
          }
        }
      })();
    },
    [mutation],
  );

  return (
    <div className="space-y-s3">
      <div
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault();
          setDragging(false);
          enqueue(event.dataTransfer.files);
        }}
        className={cn(
          "flex flex-col items-center justify-center gap-2 rounded-lg border border-dashed px-s4 py-s6 text-center transition-colors duration-fast",
          dragging ? "border-primary bg-primary/[0.06]" : "border-border/70",
        )}
      >
        <span className="grid size-10 place-items-center rounded-full bg-white/[0.03] text-muted-foreground">
          <FileUp className="size-4" aria-hidden />
        </span>
        <p className="text-sm font-medium">Drop evidence here</p>
        <p className="max-w-sm text-2xs leading-relaxed text-muted-foreground">
          PCAP, EVTX, logs, documents, APKs and archives. SHA-256 and MD5 are
          recorded at ingest. Type is detected from file content first; the filename is only a fallback.
        </p>
        <Button variant="secondary" size="sm" onClick={() => inputRef.current?.click()}>
          <Upload />
          Choose files
        </Button>
        <input
          ref={inputRef}
          type="file"
          multiple
          className="sr-only"
          onChange={(event) => {
            enqueue(event.target.files);
            // Reset so selecting the same file twice still fires onChange.
            event.target.value = "";
          }}
        />
      </div>

      {queue.length > 0 ? (
        <ul className="space-y-1.5">
          {queue.map((item) => (
            <li
              key={item.id}
              className="rounded-md border border-border/60 bg-white/[0.02] px-s3 py-s2"
            >
              <div className="flex items-center gap-2">
                {item.state === "done" ? (
                  <CheckCircle2 className="size-3.5 shrink-0 text-success" aria-hidden />
                ) : item.state === "error" ? (
                  <XCircle className="size-3.5 shrink-0 text-destructive" aria-hidden />
                ) : (
                  <Upload className="size-3.5 shrink-0 text-muted-foreground" aria-hidden />
                )}
                <span className="min-w-0 flex-1 truncate text-xs">{item.file.name}</span>
                <span className="shrink-0 font-mono text-2xs text-muted-foreground">
                  {formatBytes(item.file.size)}
                </span>
              </div>
              {item.state === "uploading" ? (
                <Progress value={item.progress} className="mt-1.5" />
              ) : null}
              {item.state === "error" ? (
                <p className="mt-1 text-2xs text-destructive">{item.message}</p>
              ) : null}
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}
