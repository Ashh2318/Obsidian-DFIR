"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import * as React from "react";

import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { useQueryClient } from "@tanstack/react-query";

import { labelForRouteWithData } from "@/hooks/use-workspace-tabs";

/** Trail derived from the pathname, so new routes need no registration. */
export function Breadcrumbs() {
  const pathname = usePathname();
  const queryClient = useQueryClient();

  const crumbs = React.useMemo(() => {
    const segments = (pathname ?? "").split("/").filter(Boolean);
    return segments.map((_, index) => {
      const href = "/" + segments.slice(0, index + 1).join("/");
      return { href, label: labelForRouteWithData(href, queryClient) };
    });
  }, [pathname, queryClient]);

  if (crumbs.length === 0) return null;

  return (
    <Breadcrumb className="hidden min-w-0 md:block">
      <BreadcrumbList className="flex-nowrap">
        <BreadcrumbItem>
          <BreadcrumbLink asChild>
            <Link href="/dashboard">OBSIDIAN</Link>
          </BreadcrumbLink>
        </BreadcrumbItem>
        {crumbs.map((crumb, index) => {
          const isLast = index === crumbs.length - 1;
          return (
            <React.Fragment key={crumb.href}>
              <BreadcrumbSeparator />
              <BreadcrumbItem className="min-w-0">
                {isLast ? (
                  <BreadcrumbPage className="truncate">{crumb.label}</BreadcrumbPage>
                ) : (
                  <BreadcrumbLink asChild>
                    <Link href={crumb.href} className="truncate">
                      {crumb.label}
                    </Link>
                  </BreadcrumbLink>
                )}
              </BreadcrumbItem>
            </React.Fragment>
          );
        })}
      </BreadcrumbList>
    </Breadcrumb>
  );
}
