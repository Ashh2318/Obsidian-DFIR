"use client";

import { Moon, PanelLeft, Sparkles } from "lucide-react";
import { useRouter } from "next/navigation";
import * as React from "react";

import { useTheme } from "@/components/providers/theme-provider";
import { useAuth } from "@/components/providers/auth-provider";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandShortcut,
} from "@/components/ui/command";
import { useShell } from "@/hooks/use-shell";
import { canSee, NAV_SECTIONS } from "@/lib/navigation";
import { THEME_PRESETS } from "@/lib/theme";

/**
 * Keyboard-first navigation and actions, opened with Cmd/Ctrl+K.
 *
 * Analysts work at speed; requiring a mouse is the difference between a tool
 * and a website. This is also the surface Voice Command Mode targets in Phase 6
 * — an utterance and a keystroke will resolve to the same action list.
 */
export function CommandPalette() {
  const router = useRouter();
  const { user } = useAuth();
  const { commandOpen, setCommandOpen, toggleSidebar, toggleAiPanel } = useShell();
  const { setPresetId } = useTheme();

  const sections = React.useMemo(
    () =>
      NAV_SECTIONS.map((section) => ({
        heading: section.heading,
        items: section.items.filter((item) => canSee(item, user?.role)),
      })).filter((section) => section.items.length > 0),
    [user?.role],
  );

  function run(action: () => void) {
    setCommandOpen(false);
    action();
  }

  return (
    <CommandDialog open={commandOpen} onOpenChange={setCommandOpen}>
      <CommandInput placeholder="Search modules, actions and settings..." />
      <CommandList>
        <CommandEmpty>No matching commands.</CommandEmpty>

        {sections.map((section) => (
          <CommandGroup key={section.heading} heading={section.heading}>
            {section.items.map((item) => {
              const Icon = item.icon;
              const locked = Boolean(item.phase);
              return (
                <CommandItem
                  key={item.href}
                  value={`${item.label} ${section.heading}`}
                  disabled={locked}
                  onSelect={() => run(() => router.push(item.href))}
                >
                  <Icon aria-hidden />
                  <span className="flex-1">{item.label}</span>
                  {locked ? (
                    <span className="rounded-xs border border-border/70 px-1 py-px text-2xs uppercase text-muted-foreground/70">
                      Phase {item.phase}
                    </span>
                  ) : (
                    <CommandShortcut>↵</CommandShortcut>
                  )}
                </CommandItem>
              );
            })}
          </CommandGroup>
        ))}

        <CommandGroup heading="View">
          <CommandItem value="toggle sidebar" onSelect={() => run(toggleSidebar)}>
            <PanelLeft aria-hidden />
            <span className="flex-1">Toggle sidebar</span>
            <CommandShortcut>⌘B</CommandShortcut>
          </CommandItem>
          <CommandItem value="toggle ai panel assistant" onSelect={() => run(toggleAiPanel)}>
            <Sparkles aria-hidden />
            <span className="flex-1">Toggle AI panel</span>
            <CommandShortcut>⌘J</CommandShortcut>
          </CommandItem>
        </CommandGroup>

        <CommandGroup heading="Theme">
          {THEME_PRESETS.map((preset) => (
            <CommandItem
              key={preset.id}
              value={`theme ${preset.name}`}
              onSelect={() => run(() => setPresetId(preset.id))}
            >
              <Moon aria-hidden />
              <span className="flex-1">{preset.name}</span>
              <span className="flex gap-0.5" aria-hidden>
                {preset.swatch.map((c) => (
                  <span
                    key={c}
                    className="size-2.5 rounded-full ring-1 ring-white/10"
                    style={{ backgroundColor: c }}
                  />
                ))}
              </span>
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
