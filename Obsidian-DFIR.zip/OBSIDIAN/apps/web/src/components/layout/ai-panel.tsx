"use client";

import { PanelRightClose, Sparkles } from "lucide-react";
import { useParams, usePathname } from "next/navigation";
import * as React from "react";

import { AssistantChat } from "@/components/assistant/chat";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useShell } from "@/hooks/use-shell";

/**
 * Docked AI assistant.
 *
 * Picks up the case from the route, so opening the panel while viewing a case
 * grounds the conversation in it without the analyst selecting anything.
 */
export function AiPanel() {
  const { aiPanelOpen, setAiPanelOpen } = useShell();
  const pathname = usePathname();
  const params = useParams<{ caseId?: string }>();

  const caseId = React.useMemo(
    () => (pathname?.startsWith("/cases/") ? (params?.caseId ?? null) : null),
    [pathname, params],
  );

  if (!aiPanelOpen) return null;

  return (
    <TooltipProvider delayDuration={300}>
      <aside
        aria-label="AI assistant"
        className="hidden w-96 shrink-0 flex-col border-l border-border/60 bg-[hsl(var(--surface))]/60 backdrop-blur-xl xl:flex"
      >
        <header className="flex h-12 shrink-0 items-center gap-2 border-b border-border/60 px-s3">
          <Sparkles className="size-4 text-primary" aria-hidden />
          <p className="flex-1 text-sm font-medium">AI Assistant</p>
          {caseId ? (
            <Badge variant="primary" className="text-2xs">
              case
            </Badge>
          ) : null}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setAiPanelOpen(false)}
                aria-label="Close AI panel"
              >
                <PanelRightClose />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">Close (⌘J)</TooltipContent>
          </Tooltip>
        </header>

        <AssistantChat key={caseId ?? "general"} caseId={caseId} dense />
      </aside>
    </TooltipProvider>
  );
}
