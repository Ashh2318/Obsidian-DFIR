"use client";

import { ChevronsLeft, PanelLeft } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import * as React from "react";

import { useAuth } from "@/components/providers/auth-provider";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/ui/logo";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { SIDEBAR_MAX, SIDEBAR_MIN, useShell } from "@/hooks/use-shell";
import { canSee, NAV_SECTIONS, type NavItem } from "@/lib/navigation";
import { cn } from "@/lib/utils";

/** Drag-to-resize edge. Also operable from the keyboard via arrow keys. */
function ResizeHandle() {
  const { sidebarWidth, setSidebarWidth } = useShell();
  const [dragging, setDragging] = React.useState(false);

  React.useEffect(() => {
    if (!dragging) return;

    function onMove(event: PointerEvent) {
      setSidebarWidth(event.clientX);
    }
    function onUp() {
      setDragging(false);
    }

    // Suppress text selection and swap the cursor globally, or the pointer
    // flickers whenever it leaves the 4px handle mid-drag.
    document.body.style.userSelect = "none";
    document.body.style.cursor = "col-resize";
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);

    return () => {
      document.body.style.userSelect = "";
      document.body.style.cursor = "";
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, [dragging, setSidebarWidth]);

  return (
    <div
      role="separator"
      aria-orientation="vertical"
      aria-label="Resize sidebar"
      aria-valuenow={sidebarWidth}
      aria-valuemin={SIDEBAR_MIN}
      aria-valuemax={SIDEBAR_MAX}
      tabIndex={0}
      onPointerDown={(event) => {
        event.preventDefault();
        setDragging(true);
      }}
      onKeyDown={(event) => {
        if (event.key === "ArrowLeft") {
          event.preventDefault();
          setSidebarWidth(sidebarWidth - 16);
        } else if (event.key === "ArrowRight") {
          event.preventDefault();
          setSidebarWidth(sidebarWidth + 16);
        }
      }}
      className={cn(
        "absolute inset-y-0 -right-px z-20 w-1 cursor-col-resize transition-colors duration-fast",
        "hover:bg-primary/60 focus-visible:bg-primary focus-visible:outline-none",
        dragging && "bg-primary",
      )}
    />
  );
}

function NavLink({ item, collapsed }: { item: NavItem; collapsed: boolean }) {
  const pathname = usePathname();
  const active = pathname === item.href;
  const locked = Boolean(item.phase);
  const Icon = item.icon;

  const className = cn(
    "group relative flex items-center gap-3 rounded-md px-2.5 py-2 text-sm transition-colors duration-fast",
    active
      ? "bg-primary/10 font-medium text-primary"
      : "text-muted-foreground hover:bg-white/[0.04] hover:text-foreground",
    locked && "cursor-not-allowed opacity-40 hover:bg-transparent hover:text-muted-foreground",
    collapsed && "justify-center px-0",
  );

  const body = (
    <>
      {active ? (
        <span className="absolute inset-y-1.5 left-0 w-0.5 rounded-full bg-primary" aria-hidden />
      ) : null}
      <Icon className="size-4 shrink-0" aria-hidden />
      {!collapsed ? (
        <>
          <span className="flex-1 truncate">{item.label}</span>
          {locked ? (
            <span className="rounded-xs border border-border/70 px-1 py-px text-2xs font-medium uppercase text-muted-foreground/70">
              P{item.phase}
            </span>
          ) : null}
        </>
      ) : null}
    </>
  );

  const element = locked ? (
    <div className={className} aria-disabled title={collapsed ? undefined : `Phase ${item.phase}`}>
      {body}
    </div>
  ) : (
    <Link href={item.href} className={className} aria-current={active ? "page" : undefined}>
      {body}
    </Link>
  );

  // Collapsed to icons, the label is gone, so a tooltip is the only way to
  // identify the destination.
  if (!collapsed) return element;
  return (
    <Tooltip>
      <TooltipTrigger asChild>{element}</TooltipTrigger>
      <TooltipContent side="right">
        {item.label}
        {locked ? ` — Phase ${item.phase}` : ""}
      </TooltipContent>
    </Tooltip>
  );
}

export function Sidebar() {
  const { user } = useAuth();
  const { sidebarWidth, sidebarCollapsed, toggleSidebar } = useShell();
  const width = sidebarCollapsed ? "var(--shell-sidebar-collapsed)" : `${sidebarWidth}px`;

  return (
    <TooltipProvider delayDuration={300}>
      <aside
        style={{ width }}
        className={cn(
          "relative hidden shrink-0 flex-col border-r border-border/60 bg-[hsl(var(--surface))]/60 backdrop-blur-xl lg:flex",
          // Width animates only when toggling; during a drag it must track the
          // pointer exactly, so no transition is applied there.
          sidebarCollapsed && "transition-[width] duration-normal ease-out",
        )}
      >
        <div
          className={cn(
            "flex h-12 shrink-0 items-center gap-2.5 border-b border-border/60 px-3",
            sidebarCollapsed && "justify-center px-0",
          )}
        >
          <Logo className="size-6 shrink-0" />
          {!sidebarCollapsed ? (
            <div className="min-w-0 flex-1 leading-none">
              <p className="truncate text-sm font-semibold tracking-wide">OBSIDIAN</p>
              <p className="mt-0.5 truncate text-2xs uppercase tracking-eyebrow text-muted-foreground">
                Analyst Mode
              </p>
            </div>
          ) : null}
        </div>

        <nav className="flex-1 space-y-4 overflow-y-auto px-2 py-3" aria-label="Primary">
          {NAV_SECTIONS.map((section) => {
            const visible = section.items.filter((item) => canSee(item, user?.role));
            if (visible.length === 0) return null;
            return (
              <div key={section.heading}>
                {!sidebarCollapsed ? (
                  <p className="px-2.5 pb-1.5 text-2xs font-semibold uppercase tracking-eyebrow text-muted-foreground/70">
                    {section.heading}
                  </p>
                ) : (
                  <div className="mx-auto mb-1.5 h-px w-6 bg-border/60" aria-hidden />
                )}
                <ul className="space-y-0.5">
                  {visible.map((item) => (
                    <li key={item.href}>
                      <NavLink item={item} collapsed={sidebarCollapsed} />
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </nav>

        <div className="shrink-0 border-t border-border/60 p-2">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size={sidebarCollapsed ? "icon" : "sm"}
                onClick={toggleSidebar}
                aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
                className={cn("w-full", sidebarCollapsed && "w-auto")}
              >
                {sidebarCollapsed ? <PanelLeft /> : <ChevronsLeft />}
                {!sidebarCollapsed ? <span className="flex-1 text-left">Collapse</span> : null}
                {!sidebarCollapsed ? (
                  <kbd className="font-mono text-2xs opacity-60">⌘B</kbd>
                ) : null}
              </Button>
            </TooltipTrigger>
            {sidebarCollapsed ? <TooltipContent side="right">Expand sidebar (⌘B)</TooltipContent> : null}
          </Tooltip>
        </div>

        {!sidebarCollapsed ? <ResizeHandle /> : null}
      </aside>
    </TooltipProvider>
  );
}
