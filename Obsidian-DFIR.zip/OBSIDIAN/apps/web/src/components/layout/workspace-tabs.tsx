"use client";

import { X } from "lucide-react";
import Link from "next/link";
import * as React from "react";

import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";
import { useWorkspaceTabs } from "@/hooks/use-workspace-tabs";
import { cn } from "@/lib/utils";

/** Open-route tab strip. Right-click a tab for close actions. */
export function WorkspaceTabs() {
  const { tabs, activeHref, closeTab, closeOthers, closeAll } = useWorkspaceTabs();

  if (tabs.length === 0) return null;

  return (
    <div
      className="flex h-9 shrink-0 items-stretch gap-px overflow-x-auto border-b border-border/60 bg-[hsl(var(--surface))]/40 px-1"
      role="tablist"
      aria-label="Open workspaces"
    >
      {tabs.map((tab) => {
        const active = tab.href === activeHref;
        return (
          <ContextMenu key={tab.href}>
            <ContextMenuTrigger asChild>
              <div
                className={cn(
                  "group relative flex shrink-0 items-center transition-colors duration-fast",
                  active ? "bg-white/[0.05]" : "hover:bg-white/[0.03]",
                )}
              >
                {active ? (
                  <span className="absolute inset-x-0 top-0 h-px bg-primary" aria-hidden />
                ) : null}
                <Link
                  href={tab.href}
                  role="tab"
                  aria-selected={active}
                  className={cn(
                    "flex h-full items-center gap-2 py-0 pl-3 pr-1 text-xs transition-colors duration-fast",
                    active ? "text-foreground" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {tab.label}
                </Link>
                <button
                  type="button"
                  onClick={(event) => {
                    // The close control sits inside the link's row; without
                    // stopping propagation the router would navigate first.
                    event.preventDefault();
                    event.stopPropagation();
                    closeTab(tab.href);
                  }}
                  aria-label={`Close ${tab.label}`}
                  className={cn(
                    "mr-1.5 grid size-4 place-items-center rounded-xs text-muted-foreground transition-all duration-fast",
                    "hover:bg-white/10 hover:text-foreground focus-visible:outline-none",
                    active ? "opacity-100" : "opacity-0 group-hover:opacity-100",
                  )}
                >
                  <X className="size-3" aria-hidden />
                </button>
              </div>
            </ContextMenuTrigger>

            <ContextMenuContent>
              <ContextMenuItem onSelect={() => closeTab(tab.href)}>Close</ContextMenuItem>
              <ContextMenuItem onSelect={() => closeOthers(tab.href)}>Close others</ContextMenuItem>
              <ContextMenuSeparator />
              <ContextMenuItem variant="destructive" onSelect={closeAll}>
                Close all
              </ContextMenuItem>
            </ContextMenuContent>
          </ContextMenu>
        );
      })}
    </div>
  );
}
