"use client";

import { AlertTriangle, Bell, CheckCircle2, Info, ShieldAlert, X } from "lucide-react";
import Link from "next/link";
import * as React from "react";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { EmptyState } from "@/components/ui/empty-state";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  useNotifications,
  type NotificationSeverity,
} from "@/hooks/use-notifications";
import { cn, relativeTime } from "@/lib/utils";

const ICONS: Record<NotificationSeverity, typeof Info> = {
  info: Info,
  success: CheckCircle2,
  warning: AlertTriangle,
  critical: ShieldAlert,
};

const TONES: Record<NotificationSeverity, string> = {
  info: "text-primary",
  success: "text-success",
  warning: "text-warning",
  critical: "text-destructive",
};

export function NotificationCenter() {
  const { notifications, unreadCount, markRead, markAllRead, dismiss, clearAll } =
    useNotifications();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative"
          aria-label={
            unreadCount > 0 ? `Notifications, ${unreadCount} unread` : "Notifications"
          }
        >
          <Bell />
          {unreadCount > 0 ? (
            <span className="absolute right-1 top-1 grid min-w-3.5 place-items-center rounded-full bg-primary px-1 text-2xs font-semibold leading-4 text-primary-foreground">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          ) : null}
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between px-3 py-2">
          <p className="text-xs font-medium">Notifications</p>
          {notifications.length > 0 ? (
            <div className="flex items-center gap-1">
              {unreadCount > 0 ? (
                <button
                  type="button"
                  onClick={markAllRead}
                  className="text-2xs text-muted-foreground transition-colors duration-fast hover:text-primary"
                >
                  Mark all read
                </button>
              ) : null}
              <button
                type="button"
                onClick={clearAll}
                className="text-2xs text-muted-foreground transition-colors duration-fast hover:text-destructive"
              >
                Clear
              </button>
            </div>
          ) : null}
        </div>
        <Separator />

        {notifications.length === 0 ? (
          <EmptyState
            icon={Bell}
            title="No notifications"
            description="Analysis results and system alerts will appear here."
            className="border-0 py-8"
          />
        ) : (
          <ScrollArea className="max-h-80">
            <ul className="p-1">
              {notifications.map((n) => {
                const Icon = ICONS[n.severity];
                const content = (
                  <>
                    <Icon className={cn("mt-0.5 size-3.5 shrink-0", TONES[n.severity])} aria-hidden />
                    <span className="min-w-0 flex-1">
                      <span className="flex items-baseline justify-between gap-2">
                        <span
                          className={cn(
                            "truncate text-xs",
                            n.read ? "text-muted-foreground" : "font-medium text-foreground",
                          )}
                        >
                          {n.title}
                        </span>
                        <time className="shrink-0 font-mono text-2xs text-muted-foreground/70">
                          {relativeTime(new Date(n.createdAt))}
                        </time>
                      </span>
                      {n.body ? (
                        <span className="mt-0.5 block text-2xs leading-relaxed text-muted-foreground">
                          {n.body}
                        </span>
                      ) : null}
                    </span>
                  </>
                );

                return (
                  <li key={n.id} className="group relative">
                    {n.href ? (
                      <Link
                        href={n.href}
                        onClick={() => markRead(n.id)}
                        className="flex gap-2.5 rounded-md p-2 pr-7 transition-colors duration-fast hover:bg-white/[0.04]"
                      >
                        {content}
                      </Link>
                    ) : (
                      <button
                        type="button"
                        onClick={() => markRead(n.id)}
                        className="flex w-full gap-2.5 rounded-md p-2 pr-7 text-left transition-colors duration-fast hover:bg-white/[0.04]"
                      >
                        {content}
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => dismiss(n.id)}
                      aria-label={`Dismiss ${n.title}`}
                      className="absolute right-1.5 top-2 grid size-4 place-items-center rounded-xs text-muted-foreground opacity-0 transition-opacity duration-fast hover:text-destructive focus-visible:opacity-100 group-hover:opacity-100"
                    >
                      <X className="size-3" aria-hidden />
                    </button>
                    {!n.read ? (
                      <span
                        className="pointer-events-none absolute left-0.5 top-1/2 size-1 -translate-y-1/2 rounded-full bg-primary"
                        aria-hidden
                      />
                    ) : null}
                  </li>
                );
              })}
            </ul>
          </ScrollArea>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
