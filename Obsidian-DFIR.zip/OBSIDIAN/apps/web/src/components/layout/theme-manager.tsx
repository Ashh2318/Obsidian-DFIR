"use client";

import { Check, Palette } from "lucide-react";
import * as React from "react";

import { THEME_PRESETS, useTheme } from "@/components/providers/theme-provider";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { Density } from "@/lib/theme";
import { cn } from "@/lib/utils";

export function ThemeManager() {
  const { presetId, setPresetId, density, setDensity } = useTheme();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" aria-label="Appearance">
          <Palette />
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-60">
        <DropdownMenuLabel>Theme</DropdownMenuLabel>
        {THEME_PRESETS.map((preset) => {
          const active = preset.id === presetId;
          return (
            <button
              key={preset.id}
              type="button"
              onClick={() => setPresetId(preset.id)}
              className={cn(
                "flex w-full items-start gap-2.5 rounded-md px-3 py-2 text-left transition-colors duration-fast",
                active ? "bg-primary/10" : "hover:bg-white/[0.05]",
              )}
            >
              <span className="mt-0.5 flex shrink-0 gap-0.5" aria-hidden>
                {preset.swatch.map((colour) => (
                  <span
                    key={colour}
                    className="size-3 rounded-full ring-1 ring-white/10"
                    style={{ backgroundColor: colour }}
                  />
                ))}
              </span>
              <span className="min-w-0 flex-1">
                <span
                  className={cn(
                    "flex items-center gap-1.5 text-xs",
                    active ? "font-medium text-primary" : "text-foreground",
                  )}
                >
                  {preset.name}
                  {active ? <Check className="size-3" aria-hidden /> : null}
                </span>
                <span className="mt-0.5 block text-2xs leading-relaxed text-muted-foreground">
                  {preset.description}
                </span>
              </span>
            </button>
          );
        })}

        <DropdownMenuSeparator />
        <DropdownMenuLabel>Density</DropdownMenuLabel>
        <DropdownMenuRadioGroup
          value={density}
          onValueChange={(value) => setDensity(value as Density)}
        >
          <DropdownMenuRadioItem value="comfortable">Comfortable</DropdownMenuRadioItem>
          <DropdownMenuRadioItem value="compact">Compact</DropdownMenuRadioItem>
        </DropdownMenuRadioGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
