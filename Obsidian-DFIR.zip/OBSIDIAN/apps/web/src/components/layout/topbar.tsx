"use client";

import { useQuery } from "@tanstack/react-query";
import { ChevronDown, LogOut, Mic, PanelLeft, Search, Settings, Sparkles } from "lucide-react";
import { useRouter } from "next/navigation";
import * as React from "react";

import { Breadcrumbs } from "@/components/layout/breadcrumbs";
import { NotificationCenter } from "@/components/layout/notification-center";
import { ThemeManager } from "@/components/layout/theme-manager";
import { useAuth } from "@/components/providers/auth-provider";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useShell } from "@/hooks/use-shell";
import { apiRequest } from "@/lib/api-client";
import { initialsOf } from "@/lib/utils";
import { ROLE_LABELS, type AIStatus } from "@/types/api";

export function Topbar() {
  const router = useRouter();
  const { user, logout } = useAuth();
  const {
    setCommandOpen,
    toggleSidebar,
    toggleAiPanel,
    setVoiceOpen,
    wakeWordArmed,
    wakeWordNeedsGesture,
  } = useShell();

  const { data: ai } = useQuery({
    queryKey: ["ai-status"],
    queryFn: () => apiRequest<AIStatus>("/ai/status"),
    refetchInterval: 60_000,
    retry: false,
  });

  return (
    <header className="flex h-12 shrink-0 items-center gap-2 border-b border-border/60 bg-[hsl(var(--surface))]/50 px-2 backdrop-blur-xl sm:px-3">
      <TooltipProvider delayDuration={300}>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleSidebar}
              aria-label="Toggle sidebar"
              className="lg:hidden"
            >
              <PanelLeft />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom">Toggle sidebar (⌘B)</TooltipContent>
        </Tooltip>

        <Breadcrumbs />

        <div className="flex-1" />

        <button
          type="button"
          onClick={() => setCommandOpen(true)}
          className="flex h-8 items-center gap-2 rounded-md border border-border bg-[hsl(var(--input))]/60 px-2.5 text-left text-xs text-muted-foreground transition-colors duration-fast hover:border-primary/40 sm:w-56"
        >
          <Search className="size-3.5 shrink-0" aria-hidden />
          <span className="hidden flex-1 truncate sm:block">Search...</span>
          <kbd className="hidden rounded-xs border border-border px-1 py-px font-mono text-2xs sm:block">
            ⌘K
          </kbd>
        </button>

        {ai ? (
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge
                variant={ai.available ? "success" : "warning"}
                className="hidden lg:inline-flex"
              >
                <Sparkles className="size-3" aria-hidden />
                {ai.provider}
                {ai.available ? "" : " · unavailable"}
              </Badge>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="max-w-xs">
              {/* The reason comes first when there is one. A badge reading
                  "ollama" while nothing works is technically accurate and
                  entirely unhelpful. */}
              {ai.degraded_reason ? (
                <span className="block font-medium text-warning">
                  {ai.degraded_reason}
                </span>
              ) : null}
              <span className="block">
                {ai.model} — {ai.detail}
              </span>
            </TooltipContent>
          </Tooltip>
        ) : null}

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleAiPanel}
              aria-label="Toggle AI panel"
              className="hidden xl:inline-flex"
            >
              <Sparkles />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom">AI panel (⌘J)</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setVoiceOpen(true)}
              aria-label={
                wakeWordArmed
                  ? "Voice Command Mode. Listening for the wake word."
                  : "Open Voice Command Mode"
              }
              className="relative"
            >
              <Mic
                className={
                  wakeWordArmed
                    ? "text-primary"
                    : wakeWordNeedsGesture
                      ? "text-warning"
                      : undefined
                }
              />
              {wakeWordArmed || wakeWordNeedsGesture ? (
                <span
                  className={
                    wakeWordArmed
                      ? "absolute right-1 top-1 size-1.5 animate-pulse rounded-full bg-primary"
                      : "absolute right-1 top-1 size-1.5 rounded-full bg-warning"
                  }
                  aria-hidden
                />
              ) : null}
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom">
            {wakeWordArmed
              ? 'Listening for "Hey Obsidian"'
              : wakeWordNeedsGesture
                ? "Microphone blocked — click to open voice mode and allow it"
                : "Voice Command Mode"}
          </TooltipContent>
        </Tooltip>

        <NotificationCenter />
        <ThemeManager />
      </TooltipProvider>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            type="button"
            className="group flex items-center gap-2 rounded-md py-1 pl-1 pr-1.5 transition-colors duration-fast hover:bg-white/[0.05] focus-visible:outline-none"
          >
            <Avatar className="size-7">
              <AvatarFallback className="text-2xs">
                {user ? initialsOf(user.full_name) : "··"}
              </AvatarFallback>
            </Avatar>
            <span className="hidden text-left leading-tight md:block">
              <span className="block text-2xs font-medium">{user?.full_name}</span>
              <span className="block text-2xs text-muted-foreground">
                {user ? ROLE_LABELS[user.role] : ""}
              </span>
            </span>
            <ChevronDown
              className="size-3.5 text-muted-foreground transition-transform duration-fast group-data-[state=open]:rotate-180"
              aria-hidden
            />
          </button>
        </DropdownMenuTrigger>

        <DropdownMenuContent align="end">
          <div className="px-3 py-2">
            <p className="truncate text-xs font-medium text-foreground">{user?.full_name}</p>
            <p className="truncate text-2xs text-muted-foreground">{user?.email}</p>
          </div>
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={() => router.push("/settings")}>
            <Settings aria-hidden />
            Settings
          </DropdownMenuItem>
          <DropdownMenuItem variant="destructive" onSelect={() => void logout()}>
            <LogOut aria-hidden />
            Sign out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}
