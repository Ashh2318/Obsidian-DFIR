"use client";

import { Search, X } from "lucide-react";
import * as React from "react";

import { cn } from "@/lib/utils";

export interface SearchInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "value"> {
  value: string;
  onValueChange: (value: string) => void;
  /** Rendered on the right, e.g. a keyboard hint. */
  adornment?: React.ReactNode;
  containerClassName?: string;
}

/**
 * Search field with a clear affordance.
 *
 * Escape clears rather than blurring: in a filtered list the analyst almost
 * always wants the results back, not the focus gone.
 */
export const SearchInput = React.forwardRef<HTMLInputElement, SearchInputProps>(
  ({ className, containerClassName, value, onValueChange, adornment, ...props }, ref) => (
    <div
      className={cn(
        "flex h-9 items-center gap-2 rounded-md border border-border bg-[hsl(var(--input))]/60 px-2.5",
        "transition-colors duration-fast focus-within:border-primary/50",
        containerClassName,
      )}
    >
      <Search className="size-3.5 shrink-0 text-muted-foreground" aria-hidden />
      <input
        ref={ref}
        type="search"
        value={value}
        onChange={(event) => onValueChange(event.target.value)}
        onKeyDown={(event) => {
          if (event.key === "Escape" && value) {
            event.preventDefault();
            event.stopPropagation();
            onValueChange("");
          }
        }}
        className={cn(
          "min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground/70",
          // Chrome renders its own clear button for type=search; ours is styled.
          "[&::-webkit-search-cancel-button]:appearance-none",
          className,
        )}
        {...props}
      />
      {value ? (
        <button
          type="button"
          onClick={() => onValueChange("")}
          aria-label="Clear search"
          className="grid size-4 shrink-0 place-items-center rounded-xs text-muted-foreground transition-colors duration-fast hover:text-foreground focus-visible:outline-none"
        >
          <X className="size-3" aria-hidden />
        </button>
      ) : (
        adornment
      )}
    </div>
  ),
);
SearchInput.displayName = "SearchInput";
