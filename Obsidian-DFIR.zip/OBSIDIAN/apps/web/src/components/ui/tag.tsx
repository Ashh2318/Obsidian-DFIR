"use client";

import { X } from "lucide-react";
import * as React from "react";

import { cn } from "@/lib/utils";

export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Supplying this renders a remove control. */
  onRemove?: () => void;
  removeLabel?: string;
}

/**
 * A compact, optionally dismissible chip. Distinct from Badge: Badge conveys
 * status and is inert, Tag represents a user-managed value such as an IOC or a
 * filter and can be removed.
 */
export function Tag({ className, children, onRemove, removeLabel, ...props }: TagProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-md border border-border bg-white/[0.03] py-0.5 pl-2 text-xs text-foreground",
        onRemove ? "pr-1" : "pr-2",
        className,
      )}
      {...props}
    >
      <span className="truncate font-mono">{children}</span>
      {onRemove ? (
        <button
          type="button"
          onClick={onRemove}
          // Screen readers otherwise announce a row of identical "remove" buttons.
          aria-label={removeLabel ?? `Remove ${typeof children === "string" ? children : "tag"}`}
          className="grid size-4 place-items-center rounded text-muted-foreground transition-colors hover:bg-destructive/15 hover:text-destructive focus-visible:outline-none"
        >
          <X className="size-3" aria-hidden />
        </button>
      ) : null}
    </span>
  );
}
