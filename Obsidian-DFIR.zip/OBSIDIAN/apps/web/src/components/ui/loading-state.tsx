import { Loader2 } from "lucide-react";
import * as React from "react";

import { cn } from "@/lib/utils";

export interface LoadingStateProps extends React.HTMLAttributes<HTMLDivElement> {
  label?: string;
}

/**
 * Indeterminate loading indicator for regions with no predictable shape.
 *
 * Prefer <Skeleton> when the eventual layout is known — it avoids the content
 * shift that a centred spinner causes when real content replaces it.
 */
export function LoadingState({
  label = "Loading",
  className,
  ...props
}: LoadingStateProps) {
  return (
    <div
      // aria-live so assistive tech announces the wait rather than silence.
      role="status"
      aria-live="polite"
      className={cn("flex flex-col items-center justify-center gap-3 py-12", className)}
      {...props}
    >
      <Loader2 className="size-5 animate-spin text-primary" aria-hidden />
      <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{label}</p>
    </div>
  );
}

export function Spinner({ className, ...props }: React.SVGProps<SVGSVGElement>) {
  return (
    <Loader2
      className={cn("size-4 animate-spin", className)}
      role="status"
      aria-label="Loading"
      {...props}
    />
  );
}
