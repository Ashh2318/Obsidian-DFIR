"use client";

import { AlertOctagon, RotateCcw } from "lucide-react";
import * as React from "react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export interface ErrorStateProps extends React.HTMLAttributes<HTMLDivElement> {
  title?: string;
  description?: string;
  /** Correlation id from the API, shown so a user can quote it in a report. */
  requestId?: string;
  onRetry?: () => void;
}

/** Shown when a request failed. Always offers a way forward. */
export function ErrorState({
  title = "Something went wrong",
  description = "The request could not be completed. Retrying often resolves it.",
  requestId,
  onRetry,
  className,
  ...props
}: ErrorStateProps) {
  return (
    <div
      role="alert"
      className={cn(
        "flex flex-col items-center justify-center gap-3 rounded-lg border border-destructive/25 bg-destructive/[0.06] px-6 py-12 text-center",
        className,
      )}
      {...props}
    >
      <span className="grid size-11 place-items-center rounded-full bg-destructive/10 text-destructive">
        <AlertOctagon className="size-5" aria-hidden />
      </span>
      <div className="space-y-1">
        <p className="text-sm font-medium">{title}</p>
        <p className="mx-auto max-w-sm text-xs leading-relaxed text-muted-foreground">
          {description}
        </p>
        {requestId ? (
          <p className="pt-1 font-mono text-[11px] text-muted-foreground/60">
            request id: {requestId}
          </p>
        ) : null}
      </div>
      {onRetry ? (
        <Button variant="secondary" size="sm" onClick={onRetry} className="mt-1">
          <RotateCcw />
          Try again
        </Button>
      ) : null}
    </div>
  );
}
