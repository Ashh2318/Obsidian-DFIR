import * as React from "react";
import type { LucideIcon } from "lucide-react";

import { cn } from "@/lib/utils";

export interface TimelineItemData {
  id: string;
  title: string;
  description?: string;
  timestamp?: string;
  icon?: LucideIcon;
  /** Maps to the severity palette; drives the marker colour. */
  tone?: "neutral" | "primary" | "success" | "warning" | "destructive";
}

const TONE_RING: Record<string, string> = {
  neutral: "border-border bg-muted text-muted-foreground",
  primary: "border-primary/40 bg-primary/15 text-primary",
  success: "border-success/40 bg-success/15 text-success",
  warning: "border-warning/40 bg-warning/15 text-warning",
  destructive: "border-destructive/40 bg-destructive/15 text-destructive",
};

export interface TimelineProps extends React.HTMLAttributes<HTMLOListElement> {
  items: TimelineItemData[];
}

/**
 * Chronological event rail. Rendered as an ordered list so the sequence is
 * conveyed to assistive technology, not only visually by the connecting line.
 */
export function Timeline({ items, className, ...props }: TimelineProps) {
  return (
    <ol className={cn("relative space-y-0", className)} {...props}>
      {items.map((item, index) => {
        const Icon = item.icon;
        const isLast = index === items.length - 1;
        return (
          <li key={item.id} className="relative flex gap-3 pb-5 last:pb-0">
            {!isLast ? (
              <span
                className="absolute left-[13px] top-7 h-[calc(100%-1rem)] w-px bg-border/70"
                aria-hidden
              />
            ) : null}

            <span
              className={cn(
                "relative z-10 grid size-7 shrink-0 place-items-center rounded-full border",
                TONE_RING[item.tone ?? "neutral"],
              )}
              aria-hidden
            >
              {Icon ? <Icon className="size-3.5" /> : <span className="size-1.5 rounded-full bg-current" />}
            </span>

            <div className="min-w-0 flex-1 pt-0.5">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <p className="text-sm font-medium leading-tight">{item.title}</p>
                {item.timestamp ? (
                  <time className="font-mono text-[11px] tabular-nums text-muted-foreground">
                    {item.timestamp}
                  </time>
                ) : null}
              </div>
              {item.description ? (
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  {item.description}
                </p>
              ) : null}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
