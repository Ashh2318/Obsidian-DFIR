"use client";

import * as React from "react";
import { ResponsiveContainer, Tooltip, type TooltipProps } from "recharts";

import { cn } from "@/lib/utils";

/**
 * Recharts wrapper supplying OBSIDIAN theming and a responsive container.
 *
 * Charts are composed by the caller rather than configured through a giant
 * props object: every module needs a different mark, and a "do everything"
 * chart component becomes unmaintainable within three feature requests.
 * This owns sizing, palette and tooltip styling only.
 */

/** Chart palette, resolved from the design tokens. */
export const CHART_COLORS = {
  primary: "hsl(187 92% 52%)",
  accent: "hsl(265 85% 66%)",
  success: "hsl(152 62% 45%)",
  warning: "hsl(38 92% 55%)",
  destructive: "hsl(0 72% 56%)",
  muted: "hsl(220 12% 62%)",
} as const;

/** Severity-aligned ordering for consistent colouring across every module. */
export const SEVERITY_COLORS = [
  CHART_COLORS.muted,
  CHART_COLORS.primary,
  CHART_COLORS.warning,
  "hsl(20 90% 58%)",
  CHART_COLORS.destructive,
] as const;

export const CHART_AXIS_PROPS = {
  stroke: "hsl(220 12% 62%)",
  fontSize: 11,
  tickLine: false,
  axisLine: false,
} as const;

export const CHART_GRID_PROPS = {
  stroke: "hsl(225 20% 16%)",
  strokeDasharray: "3 3",
  vertical: false,
} as const;

export interface ChartContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Fixed pixel height. Recharts cannot size itself from a percentage parent. */
  height?: number;
  children: React.ReactElement;
}

export function ChartContainer({
  height = 240,
  className,
  children,
  ...props
}: ChartContainerProps) {
  return (
    <div className={cn("w-full", className)} style={{ height }} {...props}>
      <ResponsiveContainer width="100%" height="100%">
        {children}
      </ResponsiveContainer>
    </div>
  );
}

/** Tooltip matching the glass surface treatment. */
export function ChartTooltipContent({
  active,
  payload,
  label,
}: TooltipProps<number, string>) {
  if (!active || !payload?.length) return null;

  return (
    <div className="glass-strong rounded-md px-3 py-2 text-xs shadow-xl">
      {label !== undefined ? (
        <p className="mb-1 font-medium text-foreground">{String(label)}</p>
      ) : null}
      <ul className="space-y-0.5">
        {payload.map((entry) => (
          <li key={String(entry.dataKey)} className="flex items-center gap-2">
            <span
              className="size-2 shrink-0 rounded-full"
              style={{ backgroundColor: entry.color }}
              aria-hidden
            />
            <span className="text-muted-foreground">{entry.name}</span>
            <span className="ml-auto font-mono tabular-nums text-foreground">
              {entry.value}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function ChartTooltip(props: React.ComponentProps<typeof Tooltip>) {
  return (
    <Tooltip
      cursor={{ fill: "hsl(187 92% 52% / 0.06)" }}
      content={<ChartTooltipContent />}
      {...props}
    />
  );
}
