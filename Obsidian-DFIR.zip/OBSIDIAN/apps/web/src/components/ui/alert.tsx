import { cva, type VariantProps } from "class-variance-authority";
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  Info,
  type LucideIcon,
} from "lucide-react";
import * as React from "react";

import { cn } from "@/lib/utils";

const alertVariants = cva(
  "relative flex w-full gap-2.5 rounded-md border px-3 py-2.5 text-xs [&>svg]:mt-px [&>svg]:size-4 [&>svg]:shrink-0",
  {
    variants: {
      variant: {
        info: "border-primary/30 bg-primary/10 text-primary",
        success: "border-success/30 bg-success/10 text-success",
        warning: "border-warning/30 bg-warning/10 text-warning",
        destructive: "border-destructive/30 bg-destructive/10 text-destructive",
      },
    },
    defaultVariants: { variant: "info" },
  },
);

const DEFAULT_ICONS: Record<string, LucideIcon> = {
  info: Info,
  success: CheckCircle2,
  warning: AlertTriangle,
  destructive: AlertCircle,
};

export interface AlertProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof alertVariants> {
  /** Pass null to suppress the icon entirely. */
  icon?: LucideIcon | null;
}

export function Alert({ className, variant = "info", icon, children, ...props }: AlertProps) {
  const Icon = icon === null ? null : (icon ?? DEFAULT_ICONS[variant ?? "info"]);
  return (
    // role="alert" makes screen readers announce this the moment it appears,
    // which is the point of an inline validation or connection error.
    <div role="alert" className={cn(alertVariants({ variant }), className)} {...props}>
      {Icon ? <Icon aria-hidden /> : null}
      <div className="flex-1 space-y-1">{children}</div>
    </div>
  );
}

export function AlertTitle({ className, ...props }: React.HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn("font-medium leading-none", className)} {...props} />;
}

export function AlertDescription({
  className,
  ...props
}: React.HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn("leading-relaxed opacity-90", className)} {...props} />;
}
