import { cn } from "@/lib/utils";

/**
 * The OBSIDIAN mark: a faceted crystal rendered as inline SVG so it inherits
 * currentColor and needs no network request.
 */
export function Logo({ className, ...props }: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      className={cn("size-8", className)}
      role="img"
      aria-label="OBSIDIAN"
      {...props}
    >
      <defs>
        <linearGradient id="obsidian-facet" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="hsl(187 92% 62%)" />
          <stop offset="100%" stopColor="hsl(265 85% 66%)" />
        </linearGradient>
      </defs>
      <path d="M16 2 4 11l4 17h16l4-17L16 2Z" fill="url(#obsidian-facet)" fillOpacity="0.18" />
      <path
        d="M16 2 4 11l4 17h16l4-17L16 2Z"
        stroke="url(#obsidian-facet)"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
      <path d="M16 2v26M4 11h24" stroke="url(#obsidian-facet)" strokeWidth="1" strokeOpacity="0.55" />
      <circle cx="16" cy="15" r="2.5" fill="hsl(187 92% 62%)" />
    </svg>
  );
}
