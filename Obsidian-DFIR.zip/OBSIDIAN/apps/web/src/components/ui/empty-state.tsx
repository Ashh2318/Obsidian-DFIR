import { Inbox, type LucideIcon } from "lucide-react";
import * as React from "react";

import { cn } from "@/lib/utils";

export interface EmptyStateProps extends React.HTMLAttributes<HTMLDivElement> {
  icon?: LucideIcon;
  title: string;
  description?: string;
  /** Primary call to action, e.g. a Button that opens a creation dialog. */
  action?: React.ReactNode;
}

/**
 * Shown when a query succeeds but returns nothing.
 *
 * Distinct from ErrorState: an empty result is a normal outcome, so this is
 * calm and offers a next step rather than signalling that something broke.
 */
export function EmptyState({
  icon: Icon = Inbox,
  title,
  description,
  action,
  className,
  ...props
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-border/70 px-6 py-12 text-center",
        className,
      )}
      {...props}
    >
      <span className="grid size-11 place-items-center rounded-full bg-white/[0.03] text-muted-foreground">
        <Icon className="size-5" aria-hidden />
      </span>
      <div className="space-y-1">
        <p className="text-sm font-medium">{title}</p>
        {description ? (
          <p className="mx-auto max-w-sm text-xs leading-relaxed text-muted-foreground">
            {description}
          </p>
        ) : null}
      </div>
      {action ? <div className="pt-1">{action}</div> : null}
    </div>
  );
}
