"use client";

import { Check, Copy } from "lucide-react";
import * as React from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";

function CodeBlock({ children }: { children: React.ReactNode }) {
  const [copied, setCopied] = React.useState(false);
  const ref = React.useRef<HTMLPreElement>(null);

  async function copy() {
    const text = ref.current?.innerText ?? "";
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard unavailable */
    }
  }

  return (
    <div className="group relative">
      <pre
        ref={ref}
        className="overflow-x-auto rounded-md border border-border/60 bg-black/40 p-s3 font-mono text-2xs leading-relaxed"
      >
        {children}
      </pre>
      <button
        type="button"
        onClick={() => void copy()}
        aria-label="Copy code"
        className="absolute right-1.5 top-1.5 grid size-6 place-items-center rounded-xs bg-white/[0.06] text-muted-foreground opacity-0 transition-opacity duration-fast hover:text-foreground focus-visible:opacity-100 group-hover:opacity-100"
      >
        {copied ? <Check className="size-3" /> : <Copy className="size-3" />}
      </button>
    </div>
  );
}

/**
 * Assistant output renderer.
 *
 * Deliberately does NOT enable `rehype-raw` or any HTML passthrough. Model
 * output is untrusted input — it can restate an attacker-controlled string
 * lifted from evidence — and rendering raw HTML from it would be a stored XSS
 * vector straight through the investigation workflow.
 */
export function Markdown({ content }: { content: string }) {
  return (
    <div className="space-y-2 text-xs leading-relaxed">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          p: ({ children }) => <p className="leading-relaxed">{children}</p>,
          h1: ({ children }) => (
            <h1 className="mt-3 text-sm font-semibold tracking-tight">{children}</h1>
          ),
          h2: ({ children }) => (
            <h2 className="mt-3 text-sm font-semibold tracking-tight">{children}</h2>
          ),
          h3: ({ children }) => (
            <h3 className="mt-2 text-xs font-semibold uppercase tracking-eyebrow text-muted-foreground">
              {children}
            </h3>
          ),
          ul: ({ children }) => (
            <ul className="list-disc space-y-0.5 pl-4">{children}</ul>
          ),
          ol: ({ children }) => (
            <ol className="list-decimal space-y-0.5 pl-4">{children}</ol>
          ),
          strong: ({ children }) => (
            <strong className="font-semibold text-foreground">{children}</strong>
          ),
          a: ({ href, children }) => (
            <a
              href={href}
              target="_blank"
              // noreferrer as well as noopener: the destination may have come
              // from evidence, and it should not learn where the click began.
              rel="noopener noreferrer"
              className="text-primary underline underline-offset-2"
            >
              {children}
            </a>
          ),
          code: ({ className, children }) => {
            const inline = !className?.includes("language-");
            if (inline) {
              return (
                <code className="rounded-xs bg-white/[0.07] px-1 py-px font-mono text-2xs text-primary">
                  {children}
                </code>
              );
            }
            return <code className={className}>{children}</code>;
          },
          pre: ({ children }) => <CodeBlock>{children}</CodeBlock>,
          table: ({ children }) => (
            <div className="my-2 overflow-hidden rounded-md border border-border/60">
              <Table>{children}</Table>
            </div>
          ),
          thead: ({ children }) => <TableHeader>{children}</TableHeader>,
          tbody: ({ children }) => <TableBody>{children}</TableBody>,
          tr: ({ children }) => <TableRow>{children}</TableRow>,
          th: ({ children }) => <TableHead>{children}</TableHead>,
          td: ({ children }) => (
            <TableCell className="text-2xs">{children}</TableCell>
          ),
          blockquote: ({ children }) => (
            <blockquote className={cn("border-l-2 border-primary/40 pl-3 text-muted-foreground")}>
              {children}
            </blockquote>
          ),
          hr: () => <hr className="border-border/60" />,
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
