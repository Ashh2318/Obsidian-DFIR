"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Bot, Send, Sparkles, User as UserIcon } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";

import { Markdown } from "@/components/assistant/markdown";
import { Alert } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { LoadingState } from "@/components/ui/loading-state";
import { Textarea } from "@/components/ui/textarea";
import { assistantApi, streamAssistant } from "@/lib/api/assistant";
import { cn } from "@/lib/utils";
import type { ChatMessage } from "@/types/api";

interface ChatProps {
  /** Grounds every answer in this investigation. */
  caseId?: string | null;
  className?: string;
  /** Compact spacing for the docked side panel. */
  dense?: boolean;
}

const SUGGESTIONS = [
  "Summarise this case for an executive audience",
  "What is the most severe finding and why does it matter?",
  "Which indicators should I pivot on first?",
  "What evidence is still missing to reach a conclusion?",
];

function Bubble({
  role,
  children,
  dense,
}: {
  role: "user" | "assistant";
  children: React.ReactNode;
  dense?: boolean;
}) {
  const isUser = role === "user";
  return (
    <div className={cn("flex gap-2.5", isUser && "flex-row-reverse")}>
      <span
        className={cn(
          "grid size-6 shrink-0 place-items-center rounded-md",
          isUser ? "bg-white/[0.06] text-muted-foreground" : "bg-primary/15 text-primary",
        )}
        aria-hidden
      >
        {isUser ? <UserIcon className="size-3" /> : <Bot className="size-3" />}
      </span>
      <div
        className={cn(
          "min-w-0 max-w-[85%] rounded-lg px-s3 py-s2",
          isUser ? "bg-white/[0.05]" : "border border-border/60 bg-white/[0.02]",
          dense && "px-s2 py-1.5",
        )}
      >
        {children}
      </div>
    </div>
  );
}

/** Three-dot indicator shown between sending and the first streamed token. */
function Thinking() {
  return (
    <span className="flex items-center gap-1 py-0.5" aria-label="Assistant is thinking">
      {[0, 1, 2].map((index) => (
        <span
          key={index}
          className="size-1.5 animate-pulse rounded-full bg-primary"
          style={{ animationDelay: `${index * 160}ms` }}
        />
      ))}
    </span>
  );
}

export function AssistantChat({ caseId, className, dense }: ChatProps) {
  const queryClient = useQueryClient();
  const [conversationId, setConversationId] = React.useState<string | null>(null);
  const [draft, setDraft] = React.useState("");
  const [streaming, setStreaming] = React.useState(false);
  const [partial, setPartial] = React.useState("");
  const [error, setError] = React.useState<string | null>(null);
  const abortRef = React.useRef<AbortController | null>(null);
  const bottomRef = React.useRef<HTMLDivElement>(null);

  // A conversation is created lazily on first use, so opening the panel does
  // not litter the database with empty threads.
  const ensureConversation = React.useCallback(async (): Promise<string> => {
    if (conversationId) return conversationId;
    const created = await assistantApi.create(caseId ?? null);
    setConversationId(created.id);
    return created.id;
  }, [conversationId, caseId]);

  const detail = useQuery({
    queryKey: ["conversation", conversationId],
    queryFn: () => assistantApi.get(conversationId as string),
    enabled: Boolean(conversationId),
  });

  const messages: ChatMessage[] = detail.data?.messages ?? [];

  React.useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, partial]);

  // Abort any in-flight stream when the component unmounts, so navigating away
  // does not leave the connection open.
  React.useEffect(() => () => abortRef.current?.abort(), []);

  const send = useMutation({
    mutationFn: async (prompt: string) => {
      const id = await ensureConversation();
      const controller = new AbortController();
      abortRef.current = controller;

      setStreaming(true);
      setPartial("");
      setError(null);

      await streamAssistant(
        id,
        prompt,
        {
          onDelta: (delta) => setPartial((current) => current + delta),
          onDone: () => {
            setStreaming(false);
            setPartial("");
            void queryClient.invalidateQueries({ queryKey: ["conversation", id] });
          },
          onError: (message) => {
            setStreaming(false);
            setPartial("");
            setError(message);
          },
        },
        controller.signal,
      );
    },
  });

  function submit(prompt: string) {
    const trimmed = prompt.trim();
    if (!trimmed || streaming) return;
    setDraft("");
    send.mutate(trimmed, {
      onError: () => toast.error("Could not send the message"),
    });
  }

  const empty = messages.length === 0 && !streaming;

  return (
    <div className={cn("flex min-h-0 flex-1 flex-col", className)}>
      <div className="min-h-0 flex-1 space-y-s3 overflow-y-auto p-s3">
        {detail.isPending && conversationId ? (
          <LoadingState label="Loading conversation" />
        ) : null}

        {empty ? (
          <div className="space-y-s3 py-s4 text-center">
            <span className="mx-auto grid size-10 place-items-center rounded-full bg-primary/10 text-primary">
              <Sparkles className="size-4" aria-hidden />
            </span>
            <div className="space-y-1">
              <p className="text-sm font-medium">
                {caseId ? "Grounded in this case" : "General assistant"}
              </p>
              <p className="mx-auto max-w-sm text-2xs leading-relaxed text-muted-foreground">
                {caseId
                  ? "Answers draw on this investigation's evidence, findings and indicators. The assistant is instructed to say when the evidence does not support a conclusion."
                  : "Attach a case to ground answers in real evidence."}
              </p>
            </div>
            <div className="mx-auto flex max-w-sm flex-col gap-1.5">
              {SUGGESTIONS.map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => submit(suggestion)}
                  className="rounded-md border border-border/60 px-s3 py-1.5 text-left text-2xs text-muted-foreground transition-colors duration-fast hover:border-primary/40 hover:text-foreground"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        ) : null}

        {messages.map((message) => (
          <Bubble
            key={message.id}
            role={message.role === "assistant" ? "assistant" : "user"}
            dense={dense}
          >
            {message.role === "assistant" ? (
              <>
                <Markdown content={message.content} />
                {message.provider ? (
                  <p className="mt-1.5 font-mono text-2xs text-muted-foreground/60">
                    {message.provider} · {message.model}
                  </p>
                ) : null}
              </>
            ) : (
              <p className="whitespace-pre-wrap text-xs">{message.content}</p>
            )}
          </Bubble>
        ))}

        {streaming ? (
          <Bubble role="assistant" dense={dense}>
            {partial ? (
              <>
                <Markdown content={partial} />
                <span className="ml-0.5 inline-block h-3 w-1 animate-pulse bg-primary align-middle" />
              </>
            ) : (
              <Thinking />
            )}
          </Bubble>
        ) : null}

        {error ? <Alert variant="destructive">{error}</Alert> : null}

        <div ref={bottomRef} />
      </div>

      <div className="shrink-0 border-t border-border/60 p-s2">
        <div className="relative">
          <Textarea
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            onKeyDown={(event) => {
              // Enter sends; Shift+Enter is a newline. Matches every chat tool
              // the audience already uses.
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                submit(draft);
              }
            }}
            placeholder={caseId ? "Ask about this case..." : "Ask a question..."}
            rows={dense ? 2 : 3}
            disabled={streaming}
            className="resize-none pr-10 text-xs"
          />
          <Button
            size="icon"
            className="absolute bottom-1.5 right-1.5"
            disabled={!draft.trim() || streaming}
            loading={streaming}
            onClick={() => submit(draft)}
            aria-label="Send message"
          >
            <Send />
          </Button>
        </div>
        <div className="mt-1.5 flex items-center justify-between">
          <p className="text-2xs text-muted-foreground">
            Enter to send · Shift+Enter for a new line
          </p>
          {caseId ? (
            <Badge variant="primary" className="text-2xs">
              case-grounded
            </Badge>
          ) : null}
        </div>
      </div>
    </div>
  );
}
