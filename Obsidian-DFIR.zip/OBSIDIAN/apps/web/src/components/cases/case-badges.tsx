import { Badge } from "@/components/ui/badge";
import {
  CASE_STATUS_LABELS,
  CASE_STATUS_TONES,
  SEVERITY_LABELS,
  SEVERITY_TONES,
  type CaseStatus,
  type Severity,
} from "@/types/api";

/**
 * Status and severity rendering, defined once.
 *
 * Both appear in the list, the detail header and the dashboard. Inlining the
 * colour mapping at each site is how three views drift out of agreement.
 */
export function StatusBadge({ status }: { status: CaseStatus }) {
  return <Badge variant={CASE_STATUS_TONES[status]}>{CASE_STATUS_LABELS[status]}</Badge>;
}

export function SeverityBadge({ severity }: { severity: Severity }) {
  return <Badge variant={SEVERITY_TONES[severity]}>{SEVERITY_LABELS[severity]}</Badge>;
}
