"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { useRouter } from "next/navigation";
import * as React from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";

import { Alert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { casesApi } from "@/lib/api/cases";
import { ApiError } from "@/lib/api-client";
import { SEVERITY_LABELS, type Severity } from "@/types/api";

// Mirrors the server contract (title min length 4) so the user is corrected
// before a round-trip, not after.
const schema = z.object({
  title: z.string().min(4, "Give the case a title of at least 4 characters.").max(200),
  summary: z.string().max(8000).optional(),
  severity: z.enum(["info", "low", "medium", "high", "critical"]),
});

type FormValues = z.infer<typeof schema>;

export function CreateCaseDialog() {
  const [open, setOpen] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const router = useRouter();
  const queryClient = useQueryClient();

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { title: "", summary: "", severity: "medium" },
  });

  const mutation = useMutation({
    mutationFn: (values: FormValues) =>
      casesApi.create({
        title: values.title,
        summary: values.summary || undefined,
        severity: values.severity,
      }),
    onSuccess: (created) => {
      void queryClient.invalidateQueries({ queryKey: ["cases"] });
      void queryClient.invalidateQueries({ queryKey: ["case-statistics"] });
      toast.success("Case opened", { description: created.reference });
      setOpen(false);
      form.reset();
      router.push(`/cases/${created.id}`);
    },
    onError: (caught) => {
      setError(
        caught instanceof ApiError
          ? caught.message
          : "Could not reach the API. Is the backend running?",
      );
    },
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) {
          setError(null);
          form.reset();
        }
      }}
    >
      <DialogTrigger asChild>
        <Button size="sm">
          <Plus />
          New case
        </Button>
      </DialogTrigger>

      <DialogContent>
        <DialogHeader>
          <DialogTitle>Open a case</DialogTitle>
          <DialogDescription>
            A reference is allocated automatically. Severity can be revised as the
            investigation develops.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit((values) => {
              setError(null);
              mutation.mutate(values);
            })}
            className="space-y-4 pt-2"
          >
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Suspected exfiltration, finance VLAN" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="severity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Severity</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {(Object.keys(SEVERITY_LABELS) as Severity[]).map((s) => (
                        <SelectItem key={s} value={s}>
                          {SEVERITY_LABELS[s]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="summary"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Summary</FormLabel>
                  <FormControl>
                    <Textarea
                      rows={3}
                      placeholder="What prompted this investigation?"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>Optional. Appears on generated reports.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {error ? <Alert variant="destructive">{error}</Alert> : null}

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
                disabled={mutation.isPending}
              >
                Cancel
              </Button>
              <Button type="submit" loading={mutation.isPending}>
                Open case
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
