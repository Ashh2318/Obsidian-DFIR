"use client";

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Play, RotateCcw } from "lucide-react";
import * as React from "react";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { toast } from "sonner";

import { FindingList, RiskScore } from "@/components/analysis/finding-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  CHART_AXIS_PROPS,
  CHART_COLORS,
  CHART_GRID_PROPS,
  ChartContainer,
  ChartTooltip,
} from "@/components/ui/chart";
import { Separator } from "@/components/ui/separator";
import { ApiError } from "@/lib/api-client";
import { analysisApi } from "@/lib/api/analysis";
import { formatBytes } from "@/lib/utils";
import type { Evidence } from "@/types/api";

/** Evidence types with no engine yet — the button explains rather than fails. */
const ANALYSABLE = new Set(["pcap", "log", "text", "csv", "json", "yara", "sigma"]);

export function AnalysisPanel({ evidence, caseId }: { evidence: Evidence; caseId: string }) {
  const queryClient = useQueryClient();
  const summary = evidence.analysis_summary;
  const supported = ANALYSABLE.has(evidence.evidence_type);

  const mutation = useMutation({
    mutationFn: () => analysisApi.analyze(evidence.id),
    onSuccess: (updated) => {
      void queryClient.invalidateQueries({ queryKey: ["evidence", caseId] });
      void queryClient.invalidateQueries({ queryKey: ["iocs"] });
      toast.success("Analysis complete", {
        description: `${updated.analysis_summary?.findings.length ?? 0} finding(s), risk ${
          updated.analysis_summary?.risk_score ?? 0
        }/100.`,
      });
    },
    onError: (error) =>
      toast.error("Analysis failed", {
        description: error instanceof ApiError ? error.message : "The request failed.",
      }),
  });

  const protocolData = React.useMemo(() => {
    const distribution = summary?.statistics?.protocol_distribution as
      | Record<string, number>
      | undefined;
    if (!distribution) return [];
    return Object.entries(distribution)
      .map(([name, count]) => ({ name, count }))
      .slice(0, 6);
  }, [summary]);

  return (
    <div className="space-y-s3">
      <div className="flex flex-wrap items-center justify-between gap-s2">
        <div className="flex items-center gap-s3">
          {summary ? <RiskScore score={summary.risk_score} /> : null}
          {summary ? (
            <Badge variant="neutral">engine: {summary.engine}</Badge>
          ) : null}
        </div>

        <Button
          size="sm"
          variant={summary ? "secondary" : "primary"}
          loading={mutation.isPending}
          disabled={!supported}
          onClick={() => mutation.mutate()}
          title={supported ? undefined : `No engine supports ${evidence.evidence_type} yet`}
        >
          {summary ? <RotateCcw /> : <Play />}
          {mutation.isPending
            ? "Analysing"
            : summary
              ? "Re-analyse"
              : supported
                ? "Analyse"
                : "No engine yet"}
        </Button>
      </div>

      {summary ? (
        <>
          <p className="text-xs leading-relaxed text-muted-foreground">{summary.summary}</p>

          {summary.errors.length > 0 ? (
            <ul className="space-y-0.5 rounded-md border border-warning/30 bg-warning/10 p-s2">
              {summary.errors.map((error) => (
                <li key={error} className="text-2xs text-warning">
                  {error}
                </li>
              ))}
            </ul>
          ) : null}

          <div className="grid grid-cols-2 gap-s2 sm:grid-cols-4">
            {[
              ["Packets", summary.statistics.packets],
              ["Conversations", summary.statistics.conversations],
              ["Hosts", summary.statistics.unique_hosts],
              ["Lines", summary.statistics.lines],
              ["Indicators", summary.ioc_count],
              [
                "Volume",
                typeof summary.statistics.total_bytes === "number"
                  ? formatBytes(summary.statistics.total_bytes)
                  : undefined,
              ],
            ]
              .filter(([, value]) => value !== undefined && value !== null)
              .map(([label, value]) => (
                <div
                  key={String(label)}
                  className="rounded-md border border-border/60 bg-white/[0.02] px-s3 py-s2"
                >
                  <p className="text-2xs text-muted-foreground">{String(label)}</p>
                  <p className="mt-0.5 font-mono text-sm tabular-nums">
                    {typeof value === "number" ? value.toLocaleString() : String(value)}
                  </p>
                </div>
              ))}
          </div>

          {protocolData.length > 0 ? (
            <div>
              <p className="mb-1.5 text-2xs uppercase tracking-eyebrow text-muted-foreground">
                Protocol distribution
              </p>
              <ChartContainer height={160}>
                <BarChart data={protocolData}>
                  <CartesianGrid {...CHART_GRID_PROPS} />
                  <XAxis dataKey="name" {...CHART_AXIS_PROPS} />
                  <YAxis {...CHART_AXIS_PROPS} />
                  <ChartTooltip />
                  <Bar dataKey="count" fill={CHART_COLORS.primary} radius={[4, 4, 0, 0]} />
                </BarChart>
              </ChartContainer>
            </div>
          ) : null}

          <Separator />
          <div>
            <p className="mb-1.5 text-2xs uppercase tracking-eyebrow text-muted-foreground">
              Findings ({summary.findings.length})
            </p>
            <FindingList findings={summary.findings} />
          </div>
        </>
      ) : (
        <p className="text-xs text-muted-foreground">
          {supported
            ? "This artefact has not been analysed yet."
            : `No analysis engine supports ${evidence.evidence_type} artefacts yet.`}
        </p>
      )}
    </div>
  );
}
