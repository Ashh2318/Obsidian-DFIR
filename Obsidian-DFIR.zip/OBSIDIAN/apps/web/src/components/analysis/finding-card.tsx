"use client";

import * as React from "react";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  FINDING_CATEGORY_LABELS,
  SEVERITY_LABELS,
  SEVERITY_TONES,
  type Finding,
} from "@/types/api";

/**
 * A detection, rendered so an analyst can triage or dismiss it without opening
 * anything else: what was observed, how confident the engine is, and which
 * ATT&CK techniques it maps to.
 */
export function FindingList({ findings }: { findings: Finding[] }) {
  if (findings.length === 0) {
    return (
      <p className="rounded-md border border-dashed border-border/70 px-s3 py-s4 text-center text-xs text-muted-foreground">
        No detections were raised for this artefact.
      </p>
    );
  }

  return (
    <Accordion type="multiple" className="rounded-md border border-border/60">
      {findings.map((finding, index) => (
        <AccordionItem
          key={`${finding.category}-${index}`}
          value={`${finding.category}-${index}`}
          className="px-s3 last:border-b-0"
        >
          <AccordionTrigger className="gap-s3 hover:no-underline">
            <span className="flex min-w-0 flex-1 items-center gap-2">
              <Badge variant={SEVERITY_TONES[finding.severity]}>
                {SEVERITY_LABELS[finding.severity]}
              </Badge>
              <span className="truncate text-xs font-medium">{finding.title}</span>
            </span>
            <span className="shrink-0 font-mono text-2xs text-muted-foreground">
              {finding.confidence}%
            </span>
          </AccordionTrigger>

          <AccordionContent className="space-y-s3">
            <p className="text-xs leading-relaxed">{finding.description}</p>

            <div className="flex flex-wrap items-center gap-1.5">
              <Badge variant="neutral">
                {FINDING_CATEGORY_LABELS[finding.category] ?? finding.category}
              </Badge>
              {finding.mitre_techniques.map((technique) => (
                <a
                  key={technique}
                  href={`https://attack.mitre.org/techniques/${technique.replace(".", "/")}/`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={cn(
                    "rounded-full border border-accent/30 bg-accent/10 px-2 py-0.5",
                    "font-mono text-2xs text-accent transition-colors duration-fast hover:bg-accent/20",
                  )}
                >
                  {technique}
                </a>
              ))}
            </div>

            {Object.keys(finding.metadata).length > 0 ? (
              <dl className="grid grid-cols-2 gap-x-s3 gap-y-1 rounded-md bg-white/[0.02] p-s2">
                {Object.entries(finding.metadata)
                  .filter(([, value]) => typeof value !== "object")
                  .map(([key, value]) => (
                    <React.Fragment key={key}>
                      <dt className="truncate text-2xs text-muted-foreground">
                        {key.replace(/_/g, " ")}
                      </dt>
                      <dd className="truncate font-mono text-2xs">{String(value)}</dd>
                    </React.Fragment>
                  ))}
              </dl>
            ) : null}
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}

export function RiskScore({ score }: { score: number }) {
  const tone =
    score >= 75
      ? "text-destructive"
      : score >= 45
        ? "text-warning"
        : score > 0
          ? "text-primary"
          : "text-muted-foreground";

  return (
    <div className="flex items-baseline gap-1.5">
      <span className={cn("font-mono text-2xl font-semibold tabular-nums", tone)}>
        {score}
      </span>
      <span className="text-2xs text-muted-foreground">/ 100 risk</span>
    </div>
  );
}
