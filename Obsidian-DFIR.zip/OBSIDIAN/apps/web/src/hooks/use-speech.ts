"use client";

import * as React from "react";

/**
 * Browser speech engines.
 *
 * The Web Speech API is used because it needs no dependency, no model download
 * and no GPU — voice works the moment the app loads.
 *
 * It carries a real caveat for this product: Chrome's recogniser streams audio
 * to Google's servers. For an investigation platform handling regulated
 * evidence that is a genuine disclosure risk, and it is surfaced in the UI
 * rather than buried. The hooks below are deliberately thin so a local Whisper
 * recogniser and a Piper synthesiser can replace them without touching the
 * components that consume them (Phase 7).
 */

interface SpeechResultEvent {
  resultIndex: number;
  results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }>;
}

interface SpeechErrorEvent {
  error: string;
}

// The API is prefixed in Chromium and absent in some browsers entirely.
interface SpeechRecognitionLike extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: ((event: SpeechResultEvent) => void) | null;
  onerror: ((event: SpeechErrorEvent) => void) | null;
  onend: (() => void) | null;
}

function getRecognitionConstructor(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as Record<string, unknown>;
  return (w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null) as
    | (new () => SpeechRecognitionLike)
    | null;
}

export interface SpeechSupport {
  recognition: boolean;
  synthesis: boolean;
  /** True when the recogniser is known to send audio off-device. */
  cloudRecognition: boolean;
}

export function useSpeechSupport(): SpeechSupport {
  const [support, setSupport] = React.useState<SpeechSupport>({
    recognition: false,
    synthesis: false,
    cloudRecognition: false,
  });

  // Probed in an effect: neither API exists during server rendering, and
  // checking during render would produce markup that fails hydration.
  React.useEffect(() => {
    const hasRecognition = getRecognitionConstructor() !== null;
    setSupport({
      recognition: hasRecognition,
      synthesis: typeof window !== "undefined" && "speechSynthesis" in window,
      cloudRecognition:
        hasRecognition && /Chrome|Edg/.test(navigator.userAgent) && !/Firefox/.test(navigator.userAgent),
    });
  }, []);

  return support;
}

export interface UseSpeechRecognitionOptions {
  onFinal: (transcript: string) => void;
  onInterim?: (transcript: string) => void;
  onError?: (message: string) => void;
  lang?: string;
  /**
   * Keep listening across utterances.
   *
   * Chrome ends a recognition session on its own after a pause regardless of
   * `continuous`, so staying live requires restarting on `onend`. Without that
   * the analyst has to click the microphone before every single command, which
   * is the opposite of hands-free.
   */
  continuous?: boolean;
}

export function useSpeechRecognition({
  onFinal,
  onInterim,
  onError,
  lang = "en-GB",
  continuous = false,
}: UseSpeechRecognitionOptions) {
  const [listening, setListening] = React.useState(false);
  const recognitionRef = React.useRef<SpeechRecognitionLike | null>(null);
  //: Distinguishes a session the user stopped from one the browser ended, so
  //: only the latter is restarted.
  const wantsToListen = React.useRef(false);
  //: True while output is playing. Distinct from wantsToListen: the session
  //: is paused, not ended, so it resumes automatically afterwards.
  const suspended = React.useRef(false);
  // Callbacks are held in refs so restarting recognition never rebinds
  // handlers mid-session and drops a result.
  const handlers = React.useRef({ onFinal, onInterim, onError });
  handlers.current = { onFinal, onInterim, onError };

  const stop = React.useCallback(() => {
    wantsToListen.current = false;
    recognitionRef.current?.abort();
    setListening(false);
  }, []);

  /**
   * Stop capturing without forgetting that we want to listen.
   *
   * Used while the assistant speaks. With the microphone live during playback
   * the recogniser transcribes the assistant's own reply and submits it as the
   * next command — the system ends up talking to itself, which is exactly what
   * happened in practice.
   */
  const suspend = React.useCallback(() => {
    suspended.current = true;
    recognitionRef.current?.abort();
    setListening(false);
  }, []);

  const start = React.useCallback(() => {
    const Constructor = getRecognitionConstructor();
    if (!Constructor) {
      handlers.current.onError?.("This browser has no speech recognition.");
      return;
    }
    if (recognitionRef.current) recognitionRef.current.abort();

    const recognition = new Constructor();
    recognition.lang = lang;
    recognition.continuous = continuous;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event: SpeechResultEvent) => {
      let interim = "";
      for (let i = event.resultIndex; i < event.results.length; i += 1) {
        const result = event.results[i];
        const transcript = result[0].transcript as string;
        if (result.isFinal) {
          handlers.current.onFinal(transcript.trim());
        } else {
          interim += transcript;
        }
      }
      if (interim) handlers.current.onInterim?.(interim.trim());
    };

    recognition.onerror = (event: SpeechErrorEvent) => {
      // "no-speech" and "aborted" are routine, not failures worth reporting.
      if (event.error === "no-speech" || event.error === "aborted") return;
      handlers.current.onError?.(
        event.error === "not-allowed"
          ? "Microphone access was denied."
          : `Recognition error: ${event.error}`,
      );
      // A denied microphone is permanent; anything else may recover, so a
      // continuous session is left to restart itself via onend.
      if (event.error === "not-allowed" || event.error === "service-not-allowed") {
        wantsToListen.current = false;
        setListening(false);
      }
    };

    recognition.onend = () => {
      // Never resume while output is playing, or the reply becomes the next
      // command.
      if (suspended.current) {
        setListening(false);
        return;
      }
      // Restart only if the user has not stopped us. A short delay avoids a
      // tight loop when the microphone is unavailable.
      if (continuous && wantsToListen.current) {
        setTimeout(() => {
          if (!wantsToListen.current) return;
          try {
            recognition.start();
          } catch {
            /* already running */
          }
        }, 250);
        return;
      }
      setListening(false);
    };

    recognitionRef.current = recognition;
    wantsToListen.current = true;
    suspended.current = false;
    try {
      recognition.start();
      setListening(true);
    } catch {
      // start() throws if called while already running; harmless.
    }
  }, [lang, continuous]);

  React.useEffect(
    () => () => {
      wantsToListen.current = false;
      recognitionRef.current?.abort();
    },
    [],
  );

  /** Resume after a suspend, if the session was not deliberately stopped. */
  const resume = React.useCallback(() => {
    suspended.current = false;
    if (wantsToListen.current) {
      // A short delay lets the audio device settle after playback; restarting
      // immediately frequently captures the tail of the utterance.
      setTimeout(() => {
        if (suspended.current || !wantsToListen.current) return;
        start();
      }, 400);
    }
  }, [start]);

  return { listening, start, stop, suspend, resume };
}

export interface VoiceOption {
  name: string;
  lang: string;
  /** Runs on-device. Remote voices send the text to the vendor to synthesise. */
  local: boolean;
}

/**
 * Installed synthesis voices.
 *
 * Chrome populates the list asynchronously and returns an empty array on the
 * first call, so `voiceschanged` is awaited rather than assuming the first
 * result is complete.
 */
export function useAvailableVoices(): VoiceOption[] {
  const [voices, setVoices] = React.useState<VoiceOption[]>([]);

  React.useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

    function load() {
      // Every installed voice is offered, English first.
      //
      // Filtering to `en-*` looked reasonable and was wrong: on a machine whose
      // installed voices are all another locale the list came back empty, the
      // picker had nothing to show, and the feature appeared not to exist.
      // Ranking beats excluding.
      const list = window.speechSynthesis
        .getVoices()
        .map((v) => ({ name: v.name, lang: v.lang, local: v.localService }))
        .sort((a, b) => {
          const aEnglish = a.lang.toLowerCase().startsWith("en") ? 0 : 1;
          const bEnglish = b.lang.toLowerCase().startsWith("en") ? 0 : 1;
          return aEnglish - bEnglish || a.name.localeCompare(b.name);
        });
      if (list.length) setVoices(list);
    }

    load();
    window.speechSynthesis.addEventListener("voiceschanged", load);

    // Chrome populates the list asynchronously and does not reliably fire
    // `voiceschanged` — notably when the page loads with the list already warm,
    // and on Windows where the platform voices arrive a second or two after
    // first paint. Polling until something appears is the only dependable way
    // to get them; a one-shot read returns an empty array often enough that the
    // picker looks broken.
    let elapsed = 0;
    const poll = window.setInterval(() => {
      elapsed += 400;
      load();
      if (elapsed >= 8000 || window.speechSynthesis.getVoices().length > 0) {
        window.clearInterval(poll);
      }
    }, 400);

    return () => {
      window.speechSynthesis.removeEventListener("voiceschanged", load);
      window.clearInterval(poll);
    };
  }, []);

  return voices;
}

export interface UseSpeechSynthesisOptions {
  /** Exact voice name from useAvailableVoices. Falls back to a local English voice. */
  voiceName?: string | null;
  rate?: number;
  /** Called around speech so a recogniser can be suspended and resumed. */
  onSpeakingChange?: (speaking: boolean) => void;
}

export function useSpeechSynthesis({
  voiceName,
  rate = 1.05,
  onSpeakingChange,
}: UseSpeechSynthesisOptions = {}) {
  const [speaking, setSpeaking] = React.useState(false);
  const notify = React.useRef(onSpeakingChange);
  notify.current = onSpeakingChange;

  const setState = React.useCallback((value: boolean) => {
    setSpeaking(value);
    notify.current?.(value);
  }, []);

  // Incremented on every cancel. Callbacks belonging to an older generation are
  // ignored, so a late `onend` from a cancelled utterance cannot clear the state
  // of the one that replaced it — or, worse, leave `speaking` stuck true and the
  // recogniser suspended for the rest of the session.
  const generation = React.useRef(0);

  const cancel = React.useCallback(() => {
    generation.current += 1;
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setState(false);
  }, [setState]);

  const speak = React.useCallback(
    (text: string) => {
      if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

      const mine = ++generation.current;
      window.speechSynthesis.cancel();

      const voices = window.speechSynthesis.getVoices();
      const chosen =
        (voiceName && voices.find((v) => v.name === voiceName)) ||
        // Prefer a local voice: lower latency, and it does not send the text
        // off-device — which matters when the text describes evidence.
        voices.find((v) => v.localService && v.lang.startsWith("en")) ||
        voices.find((v) => v.lang.startsWith("en")) ||
        voices[0];

      // Split on sentences and queue them separately. Chrome stops a single
      // long utterance after roughly fifteen seconds, and a queue of short ones
      // also means an interruption takes effect at the current sentence instead
      // of being swallowed by a minute-long block of audio.
      const sentences =
        text.match(/[^.!?]+[.!?]*\s*/g)?.filter((part) => part.trim()) ?? [text];

      // Reported before the first utterance begins, not on its onstart event:
      // there is a gap of tens of milliseconds before audio starts, and a
      // recogniser left live during that window captures the first syllable.
      setState(true);

      sentences.forEach((sentence, index) => {
        const utterance = new SpeechSynthesisUtterance(sentence.trim());
        utterance.rate = rate;
        utterance.pitch = 1.0;
        utterance.lang = "en-GB";
        if (chosen) utterance.voice = chosen;

        const finish = () => {
          if (generation.current !== mine) return; // superseded or cancelled
          if (index === sentences.length - 1) setState(false);
        };
        utterance.onend = finish;
        utterance.onerror = finish;

        window.speechSynthesis.speak(utterance);
      });
    },
    [voiceName, rate, setState],
  );

  React.useEffect(() => cancel, [cancel]);

  return { speaking, speak, cancel };
}


const WAKE_PATTERNS = [
  /\b(hey|ok|okay|hi)\s+obsidian\b/i,
  /\bobsidian\b/i,
];

/**
 * Global wake-word listener.
 *
 * Runs its own recognition session, separate from the command recogniser, and
 * pauses while the HUD is open so the two never compete for the microphone.
 *
 * Chrome will not grant the microphone to a session started without a user
 * gesture, and it fails *silently* — `start()` resolves, no error fires, and no
 * audio ever arrives. That is why arming reports its state back to the caller
 * rather than being assumed to have worked: the UI can then ask for the single
 * click that authorises it.
 */
export function useWakeWord({
  enabled,
  paused,
  onWake,
}: {
  enabled: boolean;
  paused: boolean;
  onWake: (trailing: string) => void;
}) {
  const [armed, setArmed] = React.useState(false);
  const [needsGesture, setNeedsGesture] = React.useState(false);
  const onWakeRef = React.useRef(onWake);
  onWakeRef.current = onWake;

  // Guards against one utterance firing twice, since interim and final results
  // both arrive and both contain the wake word.
  const lastFired = React.useRef(0);

  const handleTranscript = React.useCallback((transcript: string) => {
    const match = WAKE_PATTERNS.find((pattern) => pattern.test(transcript));
    if (!match) return;

    const now = Date.now();
    if (now - lastFired.current < 2500) return;
    lastFired.current = now;

    // Anything after the wake word is the command itself, so
    // "Hey Obsidian, open case two" works in one breath.
    const trailing = transcript.replace(match, "").replace(/^[,.\s]+/, "").trim();
    onWakeRef.current(trailing);
  }, []);

  const { listening, start, stop } = useSpeechRecognition({
    onFinal: handleTranscript,
    onInterim: handleTranscript,
    onError: (message) => {
      // A denied or unavailable microphone is reported rather than retried
      // forever; the user has to grant it once.
      if (/denied|not-allowed/i.test(message)) setNeedsGesture(true);
    },
    continuous: true,
  });

  React.useEffect(() => {
    if (enabled && !paused) {
      start();
      setArmed(true);
    } else {
      stop();
      setArmed(false);
    }
  }, [enabled, paused, start, stop]);

  return {
    armed: armed && listening,
    /** True when the browser refused the microphone and a click is required. */
    needsGesture,
  };
}
