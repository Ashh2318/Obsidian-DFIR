"use client";

import * as React from "react";

import { usePersistedState } from "@/lib/persisted-state";

export type NotificationSeverity = "info" | "success" | "warning" | "critical";

export interface AppNotification {
  id: string;
  title: string;
  body?: string;
  severity: NotificationSeverity;
  /** Epoch milliseconds. Stored as a number so it survives JSON round-tripping. */
  createdAt: number;
  read: boolean;
  href?: string;
}

export interface NotificationsState {
  notifications: AppNotification[];
  unreadCount: number;
  push: (n: Omit<AppNotification, "id" | "createdAt" | "read">) => void;
  markRead: (id: string) => void;
  markAllRead: () => void;
  dismiss: (id: string) => void;
  clearAll: () => void;
}

const NotificationsContext = React.createContext<NotificationsState | null>(null);

/** Cap retention: an unbounded list in localStorage will eventually hit quota. */
const MAX_NOTIFICATIONS = 50;

export function useNotificationsState(): NotificationsState {
  const [notifications, setNotifications] = usePersistedState<AppNotification[]>(
    "obsidian.notifications",
    [],
  );

  const push = React.useCallback(
    (n: Omit<AppNotification, "id" | "createdAt" | "read">) => {
      setNotifications((current) =>
        [
          {
            ...n,
            id: crypto.randomUUID(),
            createdAt: Date.now(),
            read: false,
          },
          ...current,
        ].slice(0, MAX_NOTIFICATIONS),
      );
    },
    [setNotifications],
  );

  const markRead = React.useCallback(
    (id: string) =>
      setNotifications((c) => c.map((n) => (n.id === id ? { ...n, read: true } : n))),
    [setNotifications],
  );

  const markAllRead = React.useCallback(
    () => setNotifications((c) => c.map((n) => ({ ...n, read: true }))),
    [setNotifications],
  );

  const dismiss = React.useCallback(
    (id: string) => setNotifications((c) => c.filter((n) => n.id !== id)),
    [setNotifications],
  );

  const clearAll = React.useCallback(() => setNotifications([]), [setNotifications]);

  const unreadCount = React.useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications],
  );

  return React.useMemo(
    () => ({ notifications, unreadCount, push, markRead, markAllRead, dismiss, clearAll }),
    [notifications, unreadCount, push, markRead, markAllRead, dismiss, clearAll],
  );
}

export const NotificationsProvider = NotificationsContext.Provider;

export function useNotifications(): NotificationsState {
  const context = React.useContext(NotificationsContext);
  if (!context) throw new Error("useNotifications must be used within the app shell.");
  return context;
}
