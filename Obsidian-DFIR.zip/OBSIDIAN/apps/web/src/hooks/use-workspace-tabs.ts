"use client";

import { useQueryClient, type QueryClient } from "@tanstack/react-query";
import { usePathname, useRouter } from "next/navigation";
import * as React from "react";

import { NAV_SECTIONS } from "@/lib/navigation";
import { usePersistedState } from "@/lib/persisted-state";

export interface WorkspaceTab {
  href: string;
  label: string;
}

/** Route metadata, so a tab can be labelled without the route being open. */
const ROUTE_LABELS: Record<string, string> = Object.fromEntries(
  NAV_SECTIONS.flatMap((s) => s.items).map((i) => [i.href, i.label]),
);

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Human label for a route. */
export function labelForRoute(href: string): string {
  if (ROUTE_LABELS[href]) return ROUTE_LABELS[href];

  const segments = href.split("/").filter(Boolean);
  const last = segments[segments.length - 1] ?? "Workspace";

  // Detail routes end in an identifier. Titlecasing a UUID produces a tab
  // labelled "112ba1b7 05cb 4982 8b63 Cf0bece1e665", which is worse than
  // useless — it is unreadable and pushes every other tab off screen.
  // The parent segment names what is being viewed instead.
  if (UUID_RE.test(last)) {
    const parent = segments[segments.length - 2];
    if (parent === "cases") return "Case";
    if (parent === "evidence") return "Evidence item";
    if (parent === "reports") return "Report";
    return "Detail";
  }

  return last
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

/**
 * Label a route using loaded data when it is available.
 *
 * A case tab should read "OBS-2026-0001", not "Case". The reference is already
 * in the query cache once the detail page has loaded, so this reads it rather
 * than issuing another request; it degrades to the generic label until then.
 */
export function labelForRouteWithData(
  href: string,
  queryClient: QueryClient,
): string {
  const segments = href.split("/").filter(Boolean);
  const last = segments[segments.length - 1];

  if (segments[0] === "cases" && last && UUID_RE.test(last)) {
    const record = queryClient.getQueryData<{ reference?: string }>(["case", last]);
    if (record?.reference) return record.reference;
  }
  return labelForRoute(href);
}

export interface WorkspaceTabsState {
  tabs: WorkspaceTab[];
  activeHref: string;
  closeTab: (href: string) => void;
  closeOthers: (href: string) => void;
  closeAll: () => void;
}

/**
 * VS Code style route tabs.
 *
 * Navigating opens a tab; tabs persist across reloads. Closing the active tab
 * moves to its neighbour rather than leaving the workspace on a dead route.
 */
export function useWorkspaceTabs(): WorkspaceTabsState {
  const pathname = usePathname();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [tabs, setTabs] = usePersistedState<WorkspaceTab[]>("obsidian.shell.tabs", []);

  // Cached case data may arrive after the tab is created, so labels are
  // recomputed rather than frozen at open time.
  const caseRecord = queryClient.getQueryData(["case", pathname?.split("/")[2] ?? ""]);

  React.useEffect(() => {
    if (!pathname) return;
    const label = labelForRouteWithData(pathname, queryClient);
    setTabs((current) => {
      const existing = current.find((t) => t.href === pathname);
      if (!existing) return [...current, { href: pathname, label }];
      if (existing.label === label) return current;
      return current.map((t) => (t.href === pathname ? { ...t, label } : t));
    });
  }, [pathname, setTabs, queryClient, caseRecord]);

  const closeTab = React.useCallback(
    (href: string) => {
      setTabs((current) => {
        const index = current.findIndex((t) => t.href === href);
        if (index === -1) return current;
        const next = current.filter((t) => t.href !== href);

        // Only redirect when closing the tab the user is looking at.
        if (href === pathname) {
          const fallback = next[index] ?? next[index - 1] ?? next[0];
          router.push(fallback ? fallback.href : "/dashboard");
        }
        return next;
      });
    },
    [pathname, router, setTabs],
  );

  const closeOthers = React.useCallback(
    (href: string) => {
      setTabs((current) => current.filter((t) => t.href === href));
      if (href !== pathname) router.push(href);
    },
    [pathname, router, setTabs],
  );

  const closeAll = React.useCallback(() => {
    setTabs([]);
    router.push("/dashboard");
  }, [router, setTabs]);

  return React.useMemo(
    () => ({ tabs, activeHref: pathname ?? "", closeTab, closeOthers, closeAll }),
    [tabs, pathname, closeTab, closeOthers, closeAll],
  );
}
