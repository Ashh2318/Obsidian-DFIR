"use client";

import * as React from "react";
import { toast } from "sonner";

import { ApiError } from "@/lib/api-client";

/**
 * Run an authenticated download with visible failure.
 *
 * Downloads used to be plain anchors, which cannot send the bearer token: the
 * API answered 401 and the browser silently saved the error body as
 * `download.json`. Nothing in the UI said anything had gone wrong. Fetching the
 * bytes ourselves means failures are ordinary promise rejections, so they can be
 * reported instead of written to disk.
 */
export function useDownload() {
  const [pending, setPending] = React.useState<string | null>(null);

  const download = React.useCallback(
    async (key: string, label: string, run: () => Promise<void>) => {
      setPending(key);
      try {
        await run();
      } catch (error) {
        const message =
          error instanceof ApiError
            ? error.message
            : "The download could not be completed.";
        toast.error(`Could not download ${label}`, { description: message });
      } finally {
        setPending(null);
      }
    },
    [],
  );

  return { download, pending };
}
