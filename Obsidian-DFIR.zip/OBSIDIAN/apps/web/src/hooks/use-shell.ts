"use client";

import * as React from "react";

import { usePersistedState } from "@/lib/persisted-state";

export const SIDEBAR_MIN = 192;
export const SIDEBAR_MAX = 384;
export const SIDEBAR_DEFAULT = 256;
export const SIDEBAR_COLLAPSED = 52;

export interface ShellState {
  sidebarWidth: number;
  setSidebarWidth: (width: number) => void;
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  setSidebarCollapsed: (collapsed: boolean) => void;

  aiPanelOpen: boolean;
  toggleAiPanel: () => void;
  setAiPanelOpen: (open: boolean) => void;

  commandOpen: boolean;
  setCommandOpen: (open: boolean) => void;

  voiceOpen: boolean;
  setVoiceOpen: (open: boolean) => void;
  /** True while the wake-word recogniser holds the microphone. */
  wakeWordArmed: boolean;
  setWakeWordArmed: (armed: boolean) => void;
  /** True when the browser refused the microphone until a user gesture. */
  wakeWordNeedsGesture: boolean;
  setWakeWordNeedsGesture: (needs: boolean) => void;
  /** Always-on wake word. Opt-in: a permanently open microphone is the
   *  analyst's decision, not a default. */
  wakeWordEnabled: boolean;
  setWakeWordEnabled: React.Dispatch<React.SetStateAction<boolean>>;
  /** Command captured in the same breath as the wake word. */
  pendingUtterance: string | null;
  setPendingUtterance: (utterance: string | null) => void;

  /** False until persisted values have been read, so the shell can avoid animating in. */
  hydrated: boolean;
}

const ShellContext = React.createContext<ShellState | null>(null);

export function useShellState(): ShellState {
  const [sidebarWidth, setWidth, widthHydrated] = usePersistedState(
    "obsidian.shell.sidebarWidth",
    SIDEBAR_DEFAULT,
  );
  const [sidebarCollapsed, setSidebarCollapsed] = usePersistedState(
    "obsidian.shell.sidebarCollapsed",
    false,
  );
  const [aiPanelOpen, setAiPanelOpen] = usePersistedState(
    "obsidian.shell.aiPanelOpen",
    false,
  );
  const [commandOpen, setCommandOpen] = React.useState(false);
  const [voiceOpen, setVoiceOpen] = React.useState(false);
  const [pendingUtterance, setPendingUtterance] = React.useState<string | null>(null);
  const [wakeWordArmed, setWakeWordArmed] = React.useState(false);
  const [wakeWordNeedsGesture, setWakeWordNeedsGesture] = React.useState(false);
  // On by default: hands-free is the point of the feature, and shipping it
  // off meant saying "Hey Obsidian" did nothing at all. The trade-off is not
  // hidden — the topbar shows a live indicator whenever the microphone is
  // armed, and one click disables it.
  const [wakeWordEnabled, setWakeWordEnabled] = usePersistedState(
    "obsidian.shell.wakeWord",
    true,
  );

  const setSidebarWidth = React.useCallback(
    (width: number) => setWidth(Math.min(SIDEBAR_MAX, Math.max(SIDEBAR_MIN, width))),
    [setWidth],
  );

  const toggleSidebar = React.useCallback(
    () => setSidebarCollapsed((c) => !c),
    [setSidebarCollapsed],
  );
  const toggleAiPanel = React.useCallback(
    () => setAiPanelOpen((o) => !o),
    [setAiPanelOpen],
  );

  // Global shortcuts. Ctrl/Cmd+B and Ctrl/Cmd+J mirror VS Code deliberately —
  // the muscle memory is already there for the audience this targets.
  React.useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      const mod = event.metaKey || event.ctrlKey;
      if (!mod) return;
      const key = event.key.toLowerCase();
      if (key === "b") {
        event.preventDefault();
        toggleSidebar();
      } else if (key === "j") {
        event.preventDefault();
        toggleAiPanel();
      } else if (key === "k") {
        event.preventDefault();
        setCommandOpen((open) => !open);
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [toggleSidebar, toggleAiPanel]);

  return React.useMemo(
    () => ({
      sidebarWidth,
      setSidebarWidth,
      sidebarCollapsed,
      toggleSidebar,
      setSidebarCollapsed,
      aiPanelOpen,
      toggleAiPanel,
      setAiPanelOpen,
      commandOpen,
      setCommandOpen,
      voiceOpen,
      setVoiceOpen,
      wakeWordArmed,
      setWakeWordArmed,
      wakeWordNeedsGesture,
      setWakeWordNeedsGesture,
      wakeWordEnabled,
      setWakeWordEnabled,
      pendingUtterance,
      setPendingUtterance,
      hydrated: widthHydrated,
    }),
    [
      sidebarWidth, setSidebarWidth, sidebarCollapsed, toggleSidebar, setSidebarCollapsed,
      aiPanelOpen, toggleAiPanel, setAiPanelOpen, commandOpen, widthHydrated,
      voiceOpen, wakeWordEnabled, setWakeWordEnabled, pendingUtterance,
      wakeWordArmed, wakeWordNeedsGesture,
    ],
  );
}

export const ShellProvider = ShellContext.Provider;

export function useShell(): ShellState {
  const context = React.useContext(ShellContext);
  if (!context) throw new Error("useShell must be used within the app shell.");
  return context;
}
