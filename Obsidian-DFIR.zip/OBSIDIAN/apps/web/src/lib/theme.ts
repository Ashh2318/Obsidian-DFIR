/**
 * Theme presets.
 *
 * OBSIDIAN is dark-only by design — a SOC runs in low light and a light theme
 * would be a liability, not a feature. What varies is the accent pair and the
 * canvas temperature, expressed purely as HSL channel overrides so every
 * component re-themes without a single class change.
 */

export interface ThemePreset {
  id: string;
  name: string;
  description: string;
  /** CSS custom property overrides applied to :root. */
  tokens: Record<string, string>;
  /** Swatch shown in the picker. */
  swatch: [string, string];
}

export const THEME_PRESETS: ThemePreset[] = [
  {
    id: "obsidian",
    name: "Obsidian",
    description: "Cyan and violet on near-black. The default.",
    swatch: ["hsl(187 92% 52%)", "hsl(265 85% 66%)"],
    tokens: {
      "--background": "225 30% 4%",
      "--surface": "225 26% 7%",
      "--elevated": "225 24% 10%",
      "--primary": "187 92% 52%",
      "--accent": "265 85% 66%",
      "--ring": "187 92% 52%",
    },
  },
  {
    id: "midnight",
    name: "Midnight",
    description: "Cooler blue canvas with an indigo accent.",
    swatch: ["hsl(212 96% 60%)", "hsl(244 84% 68%)"],
    tokens: {
      "--background": "222 40% 4%",
      "--surface": "222 34% 8%",
      "--elevated": "222 30% 11%",
      "--primary": "212 96% 60%",
      "--accent": "244 84% 68%",
      "--ring": "212 96% 60%",
    },
  },
  {
    id: "carbon",
    name: "Carbon",
    description: "Neutral greyscale. Lowest chroma, longest sessions.",
    swatch: ["hsl(160 84% 45%)", "hsl(200 18% 60%)"],
    tokens: {
      "--background": "220 12% 5%",
      "--surface": "220 10% 8%",
      "--elevated": "220 9% 12%",
      "--primary": "160 84% 45%",
      "--accent": "200 18% 60%",
      "--ring": "160 84% 45%",
    },
  },
  {
    id: "amber",
    name: "Amber Alert",
    description: "High-contrast warm accent for incident bridges.",
    swatch: ["hsl(38 96% 56%)", "hsl(14 90% 60%)"],
    tokens: {
      "--background": "230 26% 4%",
      "--surface": "230 22% 7%",
      "--elevated": "230 20% 10%",
      "--primary": "38 96% 56%",
      "--accent": "14 90% 60%",
      "--ring": "38 96% 56%",
    },
  },
];

export type Density = "comfortable" | "compact";

export function applyTheme(presetId: string, density: Density): void {
  const preset = THEME_PRESETS.find((p) => p.id === presetId) ?? THEME_PRESETS[0];
  const root = document.documentElement;

  for (const [token, value] of Object.entries(preset.tokens)) {
    root.style.setProperty(token, value);
  }
  // Density is a data attribute rather than inline styles: globals.css already
  // redefines the spacing scale under [data-density="compact"].
  root.dataset.density = density;
  root.dataset.theme = preset.id;
}
