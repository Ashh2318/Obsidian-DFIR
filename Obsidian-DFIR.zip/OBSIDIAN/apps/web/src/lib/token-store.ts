import type { User } from "@/types/api";

/**
 * Access tokens are held in module memory and never in localStorage.
 *
 * localStorage is readable by any script executing on the origin, which makes
 * it the standard exfiltration target for an XSS payload. A token in a closure
 * is not reachable that way.
 *
 * The refresh token is the deliberate exception: something must survive a page
 * reload or the user is signed out on every refresh. It is the *only* value
 * persisted, it is single-use, and replaying a spent one revokes the entire
 * session family server-side (see ADR 0003). In production this moves to an
 * httpOnly cookie, at which point this file is the only thing that changes.
 */

const REFRESH_STORAGE_KEY = "obsidian.rt";

let accessToken: string | null = null;
let currentUser: User | null = null;

type Listener = (user: User | null) => void;
const listeners = new Set<Listener>();

function emit(): void {
  for (const listener of listeners) listener(currentUser);
}

export const tokenStore = {
  getAccessToken(): string | null {
    return accessToken;
  },

  getUser(): User | null {
    return currentUser;
  },

  getRefreshToken(): string | null {
    if (typeof window === "undefined") return null;
    try {
      return window.localStorage.getItem(REFRESH_STORAGE_KEY);
    } catch {
      // Storage can throw in private browsing modes or when disabled entirely.
      return null;
    }
  },

  setSession(access: string, refresh: string, user: User): void {
    accessToken = access;
    currentUser = user;
    if (typeof window !== "undefined") {
      try {
        window.localStorage.setItem(REFRESH_STORAGE_KEY, refresh);
      } catch {
        /* non-fatal: the session simply will not survive a reload */
      }
    }
    emit();
  },

  setUser(user: User | null): void {
    currentUser = user;
    emit();
  },

  clear(): void {
    accessToken = null;
    currentUser = null;
    if (typeof window !== "undefined") {
      try {
        window.localStorage.removeItem(REFRESH_STORAGE_KEY);
      } catch {
        /* ignore */
      }
    }
    emit();
  },

  subscribe(listener: Listener): () => void {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },
};
