"use client";

import * as React from "react";

/**
 * State mirrored into localStorage.
 *
 * Reads lazily on mount rather than during the initial render: the server has
 * no localStorage, so reading it while rendering produces markup that differs
 * from the client's first paint and React discards the tree with a hydration
 * error. Starting from the default and applying the stored value in an effect
 * costs one extra frame and is correct.
 */
export function usePersistedState<T>(
  key: string,
  defaultValue: T,
): [T, React.Dispatch<React.SetStateAction<T>>, boolean] {
  const [value, setValue] = React.useState<T>(defaultValue);
  const [hydrated, setHydrated] = React.useState(false);

  React.useEffect(() => {
    try {
      const stored = window.localStorage.getItem(key);
      if (stored !== null) setValue(JSON.parse(stored) as T);
    } catch {
      // Corrupt entry or storage disabled — the default is a fine outcome.
    }
    setHydrated(true);
  }, [key]);

  React.useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Quota exceeded or private mode; losing persistence is not fatal.
    }
  }, [key, value, hydrated]);

  return [value, setValue, hydrated];
}
