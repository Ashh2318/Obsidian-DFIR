import { tokenStore } from "@/lib/token-store";
import type { ApiErrorBody, AuthResponse, User } from "@/types/api";

/**
 * Base URL for API calls.
 *
 * Empty by default, which makes every request same-origin: the browser calls
 * `/api/v1/...` on the page's own host and `next.config.mjs` rewrites it to the
 * backend server-side. That removes the cross-origin hop entirely — no CORS
 * preflight, no second hostname for the browser to resolve, and no build-time
 * URL baked into the bundle.
 *
 * Set NEXT_PUBLIC_API_URL only when the frontend must call an API on a genuinely
 * different origin, e.g. a separately hosted deployment.
 */
export const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "";

/** What to show a user when a request never reached a server. */
export const API_DISPLAY_URL = API_URL || "this application's own origin";
const API_PREFIX = "/api/v1";

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
    readonly details?: Record<string, unknown>,
    readonly requestId?: string,
  ) {
    super(message);
    this.name = "ApiError";
  }

  /** Field-level messages from a 422, keyed by field name. */
  get fieldErrors(): Record<string, string> {
    const fields = this.details?.fields;
    if (!Array.isArray(fields)) return {};
    const result: Record<string, string> = {};
    for (const entry of fields) {
      if (entry && typeof entry === "object" && "field" in entry && "message" in entry) {
        const { field, message } = entry as { field: string; message: string };
        result[field] ??= message;
      }
    }
    return result;
  }
}

interface RequestOptions extends Omit<RequestInit, "body"> {
  body?: unknown;
  /** Skip the Authorization header and the refresh-on-401 path. */
  anonymous?: boolean;
  /** Internal: prevents a refresh attempt from recursing. */
  _retried?: boolean;
}

/**
 * In-flight refresh, shared by every caller.
 *
 * When an access token expires, several queries typically 401 at the same
 * moment. Without this single-flight guard each one would independently POST to
 * /auth/refresh; the first would rotate the token and the rest would present a
 * now-spent token, which the server correctly interprets as reuse and answers
 * by revoking the whole session family. The user would be logged out precisely
 * because the client was working correctly. This promise is the fix.
 */
let refreshInFlight: Promise<boolean> | null = null;

async function parseError(response: Response): Promise<ApiError> {
  let body: Partial<ApiErrorBody> = {};
  try {
    body = (await response.json()) as ApiErrorBody;
  } catch {
    /* non-JSON error body (proxy failure, timeout page, ...) */
  }
  return new ApiError(
    response.status,
    body.error ?? "http_error",
    body.message ?? `Request failed with status ${response.status}.`,
    body.details as Record<string, unknown> | undefined,
    body.request_id,
  );
}

async function performRefresh(): Promise<boolean> {
  const refreshToken = tokenStore.getRefreshToken();
  if (!refreshToken) return false;

  try {
    const response = await fetch(`${API_URL}${API_PREFIX}/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
    if (!response.ok) {
      tokenStore.clear();
      return false;
    }
    const data = (await response.json()) as AuthResponse;
    tokenStore.setSession(data.tokens.access_token, data.tokens.refresh_token, data.user);
    return true;
  } catch {
    tokenStore.clear();
    return false;
  }
}

function refreshSession(): Promise<boolean> {
  refreshInFlight ??= performRefresh().finally(() => {
    refreshInFlight = null;
  });
  return refreshInFlight;
}

export async function apiRequest<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { body, anonymous, _retried, headers, ...init } = options;

  const requestHeaders = new Headers(headers);
  if (body !== undefined) requestHeaders.set("Content-Type", "application/json");

  if (!anonymous) {
    const token = tokenStore.getAccessToken();
    if (token) requestHeaders.set("Authorization", `Bearer ${token}`);
  }

  const response = await fetch(`${API_URL}${API_PREFIX}${path}`, {
    ...init,
    headers: requestHeaders,
    body: body === undefined ? undefined : JSON.stringify(body),
  });

  // A 401 on an authenticated call means the access token aged out. Refresh
  // once, then replay. _retried stops this from becoming a loop.
  if (response.status === 401 && !anonymous && !_retried) {
    if (await refreshSession()) {
      return apiRequest<T>(path, { ...options, _retried: true });
    }
  }

  if (!response.ok) throw await parseError(response);
  if (response.status === 204) return undefined as T;
  return (await response.json()) as T;
}

/** Filename the server asked us to save under, if it named one. */
function filenameFromDisposition(header: string | null): string | null {
  if (!header) return null;
  // RFC 6266 filename* wins over the plain form when both are present.
  const encoded = /filename\*=UTF-8''([^;]+)/i.exec(header);
  if (encoded) {
    try {
      return decodeURIComponent(encoded[1]);
    } catch {
      /* malformed percent-encoding — fall through to the plain form */
    }
  }
  const plain = /filename="?([^";]+)"?/i.exec(header);
  return plain ? plain[1] : null;
}

/**
 * Download a protected file.
 *
 * A plain `<a href download>` cannot carry the Authorization header: it is a
 * browser navigation, not a fetch. Every such link therefore arrived at the API
 * unauthenticated, got a 401, and the browser dutifully saved the JSON error
 * envelope — which is why downloads landed as `download.json` and Chrome
 * reported the file "wasn't available". Fetching the bytes ourselves is the only
 * way to present the token, so the download goes through a blob URL instead.
 */
export async function downloadFile(
  path: string,
  fallbackName: string,
  _retried = false,
): Promise<void> {
  const headers = new Headers();
  const token = tokenStore.getAccessToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);

  const response = await fetch(`${API_URL}${API_PREFIX}${path}`, { headers });

  if (response.status === 401 && !_retried) {
    if (await refreshSession()) return downloadFile(path, fallbackName, true);
  }
  if (!response.ok) throw await parseError(response);

  const blob = await response.blob();
  const name =
    filenameFromDisposition(response.headers.get("Content-Disposition")) ?? fallbackName;

  const url = URL.createObjectURL(blob);
  try {
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = name;
    anchor.rel = "noopener";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
  } finally {
    // Revoked on a turn of the event loop: revoking synchronously can race the
    // browser's own read of the blob and produce an empty file.
    setTimeout(() => URL.revokeObjectURL(url), 10_000);
  }
}

export const api = {
  login: (email: string, password: string) =>
    apiRequest<AuthResponse>("/auth/login", {
      method: "POST",
      body: { email, password },
      anonymous: true,
    }),

  register: (payload: {
    email: string;
    password: string;
    full_name: string;
    organization?: string;
    job_title?: string;
  }) =>
    apiRequest<User>("/auth/register", {
      method: "POST",
      body: payload,
      anonymous: true,
    }),

  logout: (refreshToken: string | null, allSessions = false) =>
    apiRequest<{ message: string }>("/auth/logout", {
      method: "POST",
      body: { refresh_token: refreshToken, all_sessions: allSessions },
    }),

  me: () => apiRequest<User>("/auth/me"),

  restoreSession: refreshSession,
};
