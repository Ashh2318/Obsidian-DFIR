import {
  Activity,
  Bot,
  FileSearch,
  FileText,
  FolderKanban,
  LayoutDashboard,
  Palette,
  Radar,
  Settings,
  ShieldAlert,
  Users,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

import type { Role } from "@/types/api";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  /** Minimum role required to see this item. */
  minRole?: Role;
  /** Rendered but disabled, with a "Phase N" hint. */
  phase?: number;
}

export interface NavSection {
  heading: string;
  items: NavItem[];
}

export const NAV_SECTIONS: NavSection[] = [
  {
    heading: "Investigate",
    items: [
      { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
      { label: "Cases", href: "/cases", icon: FolderKanban },
      { label: "Evidence", href: "/evidence", icon: FileSearch },
      { label: "Timeline", href: "/timeline", icon: Activity },
    ],
  },
  {
    heading: "Intelligence",
    items: [
      { label: "AI Assistant", href: "/assistant", icon: Bot },
      { label: "Threat Intel", href: "/threat-intel", icon: Radar },
      { label: "IOC Engine", href: "/iocs", icon: ShieldAlert },
      { label: "Reports", href: "/reports", icon: FileText },
    ],
  },
  {
    heading: "Administration",
    items: [
      { label: "Users", href: "/users", icon: Users, minRole: "admin" },
      { label: "Settings", href: "/settings", icon: Settings },
      { label: "Design System", href: "/design-system", icon: Palette },
    ],
  },
];

const ROLE_LEVEL: Record<Role, number> = {
  viewer: 10,
  analyst: 20,
  investigator: 30,
  admin: 40,
};

export function canSee(item: NavItem, role: Role | undefined): boolean {
  if (!item.minRole) return true;
  if (!role) return false;
  return ROLE_LEVEL[role] >= ROLE_LEVEL[item.minRole];
}
