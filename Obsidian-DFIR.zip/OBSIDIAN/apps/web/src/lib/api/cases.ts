import { apiRequest, downloadFile } from "@/lib/api-client";
import type {
  Case,
  CaseOverview,
  CaseStatistics,
  CaseStatus,
  Evidence,
  Page,
  Severity,
} from "@/types/api";

export interface CaseFilters {
  q?: string;
  status?: CaseStatus | "";
  severity?: Severity | "";
  limit?: number;
  offset?: number;
}

/** Drops blank filters so the URL never carries `?status=` with no value. */
function toQuery(filters: CaseFilters): string {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(filters)) {
    if (value !== undefined && value !== null && value !== "") {
      params.set(key, String(value));
    }
  }
  const query = params.toString();
  return query ? `?${query}` : "";
}

export const casesApi = {
  list: (filters: CaseFilters = {}) => apiRequest<Page<Case>>(`/cases${toQuery(filters)}`),

  statistics: () => apiRequest<CaseStatistics>("/cases/statistics"),

  get: (id: string) => apiRequest<Case>(`/cases/${id}`),

  overview: (id: string) => apiRequest<CaseOverview>(`/cases/${id}/overview`),

  create: (payload: { title: string; summary?: string; severity: Severity }) =>
    apiRequest<Case>("/cases", { method: "POST", body: payload }),

  update: (id: string, payload: { title?: string; summary?: string; severity?: Severity }) =>
    apiRequest<Case>(`/cases/${id}`, { method: "PATCH", body: payload }),

  changeStatus: (id: string, status: CaseStatus) =>
    apiRequest<Case>(`/cases/${id}/status`, { method: "PATCH", body: { status } }),

  listEvidence: (caseId: string) => apiRequest<Page<Evidence>>(`/cases/${caseId}/evidence`),

  // Fetched with the bearer token rather than linked: an <a download> is a
  // navigation and cannot authenticate, so it saved a 401 body instead.
  downloadEvidence: (evidenceId: string, filename: string) =>
    downloadFile(`/evidence/${evidenceId}/download`, filename),

  deleteEvidence: (evidenceId: string) =>
    apiRequest<{ message: string }>(`/evidence/${evidenceId}`, { method: "DELETE" }),
};
