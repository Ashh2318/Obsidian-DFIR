import { apiRequest } from "@/lib/api-client";
import type { Severity, TimelineResponse, TimelineSource } from "@/types/api";

interface TimelineFilters {
  source?: TimelineSource | "";
  min_severity?: Severity | "";
  limit?: number;
}

function toQuery(filters: object): string {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(filters)) {
    if (value !== undefined && value !== null && value !== "") {
      params.set(key, String(value));
    }
  }
  const query = params.toString();
  return query ? `?${query}` : "";
}

export const timelineApi = {
  forCase: (caseId: string, filters: TimelineFilters = {}) =>
    apiRequest<TimelineResponse>(`/cases/${caseId}/timeline${toQuery(filters)}`),

  recent: (filters: TimelineFilters = {}) =>
    apiRequest<TimelineResponse>(`/timeline${toQuery(filters)}`),
};
