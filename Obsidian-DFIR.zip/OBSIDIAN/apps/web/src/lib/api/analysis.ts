import { apiRequest } from "@/lib/api-client";
import type { Evidence, IOC, IOCType, Page, Severity } from "@/types/api";

export interface IOCFilters {
  case_id?: string;
  ioc_type?: IOCType | "";
  severity?: Severity | "";
  q?: string;
  limit?: number;
  offset?: number;
}

// An interface has no index signature, so the parameter is typed as a
// record of unknown values rather than requiring callers to widen theirs.
function toQuery(filters: object): string {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(filters)) {
    if (value !== undefined && value !== null && value !== "") {
      params.set(key, String(value));
    }
  }
  const query = params.toString();
  return query ? `?${query}` : "";
}

export const analysisApi = {
  analyze: (evidenceId: string) =>
    apiRequest<Evidence>(`/evidence/${evidenceId}/analyze`, { method: "POST" }),

  engines: () => apiRequest<string[]>("/analysis/engines"),

  listIocs: (filters: IOCFilters = {}) =>
    apiRequest<Page<IOC>>(`/iocs${toQuery(filters)}`),

  iocStatistics: (caseId?: string) =>
    apiRequest<{ by_type: Record<string, number>; total: number }>(
      `/iocs/statistics${caseId ? `?case_id=${caseId}` : ""}`,
    ),
};
