import { apiRequest, downloadFile } from "@/lib/api-client";
import type { Page, Report, ReportFormat, ReportProfile, ReportVerification } from "@/types/api";

export const reportsApi = {
  list: (params: { profile?: ReportProfile | ""; limit?: number } = {}) => {
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== "") search.set(key, String(value));
    }
    const query = search.toString();
    return apiRequest<Page<Report>>(`/reports${query ? `?${query}` : ""}`);
  },

  listForCase: (caseId: string) =>
    apiRequest<Page<Report>>(`/cases/${caseId}/reports`),

  generate: (caseId: string, profile: ReportProfile, format: ReportFormat) =>
    apiRequest<Report>(`/cases/${caseId}/reports`, {
      method: "POST",
      body: { profile, format },
    }),

  verify: (reportId: string) =>
    apiRequest<ReportVerification>(`/reports/${reportId}/verify`, { method: "POST" }),

  remove: (reportId: string) =>
    apiRequest<{ message: string }>(`/reports/${reportId}`, { method: "DELETE" }),

  // Fetched with the bearer token rather than linked: see downloadFile.
  download: (report: { id: string; title: string; format: ReportFormat }) =>
    downloadFile(
      `/reports/${report.id}/download`,
      // Only a fallback: the server sends Content-Disposition, and that name wins.
      `${report.title.replace(/[^\w.-]+/g, "_")}.${report.format}`,
    ),
};
