import { apiRequest } from "@/lib/api-client";
import type { Page, Role, User } from "@/types/api";

export const usersApi = {
  list: (params: { limit?: number; offset?: number; role?: Role | "" } = {}) => {
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== "") search.set(key, String(value));
    }
    const query = search.toString();
    return apiRequest<Page<User>>(`/users${query ? `?${query}` : ""}`);
  },

  changeRole: (id: string, role: Role) =>
    apiRequest<User>(`/users/${id}/role`, { method: "PATCH", body: { role } }),

  setActive: (id: string, isActive: boolean) =>
    apiRequest<User>(`/users/${id}/active`, {
      method: "PATCH",
      body: { is_active: isActive },
    }),
};
