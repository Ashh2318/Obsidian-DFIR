import { apiRequest } from "@/lib/api-client";
import type { Enrichment, Page, ThreatIntelStatus, ThreatVerdict } from "@/types/api";

export const threatIntelApi = {
  status: () => apiRequest<ThreatIntelStatus>("/threat-intel/status"),

  listEnrichments: (params: { verdict?: ThreatVerdict | ""; limit?: number } = {}) => {
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== "") search.set(key, String(value));
    }
    const query = search.toString();
    return apiRequest<Page<Enrichment>>(
      `/threat-intel/enrichments${query ? `?${query}` : ""}`,
    );
  },

  enrichIoc: (iocId: string, force = false) =>
    apiRequest<Enrichment>(
      `/threat-intel/iocs/${iocId}/enrich${force ? "?force=true" : ""}`,
      { method: "POST" },
    ),

  enrichCase: (caseId: string) =>
    apiRequest<Enrichment[]>(`/threat-intel/cases/${caseId}/enrich`, {
      method: "POST",
    }),
};
