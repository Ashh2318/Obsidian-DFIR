import { API_URL, apiRequest, ApiError } from "@/lib/api-client";
import { tokenStore } from "@/lib/token-store";
import type { ChatMessage, Conversation, ConversationDetail, Page } from "@/types/api";

export const assistantApi = {
  listConversations: (caseId?: string) =>
    apiRequest<Page<Conversation>>(
      `/assistant/conversations${caseId ? `?case_id=${caseId}` : ""}`,
    ),

  create: (caseId?: string | null) =>
    apiRequest<Conversation>("/assistant/conversations", {
      method: "POST",
      body: { case_id: caseId ?? null },
    }),

  get: (id: string) => apiRequest<ConversationDetail>(`/assistant/conversations/${id}`),

  remove: (id: string) =>
    apiRequest<{ message: string }>(`/assistant/conversations/${id}`, {
      method: "DELETE",
    }),

  send: (id: string, prompt: string) =>
    apiRequest<ChatMessage>(`/assistant/conversations/${id}/messages`, {
      method: "POST",
      body: { prompt },
    }),
};

/**
 * Stream an answer over server-sent events.
 *
 * Uses fetch with a ReadableStream rather than EventSource, because EventSource
 * cannot set an Authorization header — it would force the access token into the
 * query string, where it lands in server logs and browser history.
 *
 * The reader is cancelled on abort so a navigation away does not leave the
 * connection open.
 */
export async function streamAssistant(
  conversationId: string,
  prompt: string,
  handlers: {
    onDelta: (delta: string) => void;
    onDone: () => void;
    onError: (message: string) => void;
  },
  signal?: AbortSignal,
): Promise<void> {
  const token = tokenStore.getAccessToken();

  let response: Response;
  try {
    response = await fetch(
      `${API_URL}/api/v1/assistant/conversations/${conversationId}/stream`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ prompt }),
        signal,
      },
    );
  } catch {
    handlers.onError("Could not reach the OBSIDIAN API.");
    return;
  }

  if (!response.ok) {
    let message = `The assistant returned ${response.status}.`;
    try {
      const body = (await response.json()) as { message?: string };
      if (body.message) message = body.message;
    } catch {
      /* non-JSON error body */
    }
    handlers.onError(message);
    return;
  }

  if (!response.body) {
    handlers.onError("The response carried no stream.");
    return;
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      // SSE frames are separated by a blank line. A chunk can split a frame,
      // so only whole frames are consumed and the remainder is carried over.
      const frames = buffer.split("\n\n");
      buffer = frames.pop() ?? "";

      for (const frame of frames) {
        const line = frame.split("\n").find((l) => l.startsWith("data:"));
        if (!line) continue;
        try {
          const payload = JSON.parse(line.slice(5).trim()) as {
            delta?: string;
            done?: boolean;
            error?: string;
          };
          if (payload.error) {
            handlers.onError(payload.error);
            return;
          }
          if (payload.delta) handlers.onDelta(payload.delta);
          if (payload.done) {
            handlers.onDone();
            return;
          }
        } catch {
          /* ignore a malformed frame rather than aborting the stream */
        }
      }
    }
    handlers.onDone();
  } catch (error) {
    if ((error as Error).name !== "AbortError") {
      handlers.onError(
        error instanceof ApiError ? error.message : "The stream was interrupted.",
      );
    }
  } finally {
    await reader.cancel().catch(() => undefined);
  }
}
