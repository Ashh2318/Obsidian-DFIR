import { apiRequest } from "@/lib/api-client";
import type { VoiceCapabilities, VoiceCommandResult } from "@/types/api";

export const voiceApi = {
  capabilities: () => apiRequest<VoiceCapabilities>("/voice/capabilities"),

  command: (
    utterance: string,
    options: {
      currentCaseId?: string | null;
      /** The previous turn, so "tell me more about that" resolves. */
      lastAction?: string | null;
      lastSubject?: string | null;
      dryRun?: boolean;
    } = {},
  ) =>
    apiRequest<VoiceCommandResult>("/voice/command", {
      method: "POST",
      body: {
        utterance,
        current_case_id: options.currentCaseId ?? null,
        last_action: options.lastAction ?? null,
        last_subject: options.lastSubject ?? null,
        dry_run: options.dryRun ?? false,
      },
    }),
};
