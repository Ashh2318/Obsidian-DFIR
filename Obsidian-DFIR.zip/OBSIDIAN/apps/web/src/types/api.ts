/** Contracts mirrored from the FastAPI OpenAPI schema. */

export type Role = "viewer" | "analyst" | "investigator" | "admin";

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: Role;
  organization: string | null;
  job_title: string | null;
  is_active: boolean;
  is_verified: boolean;
  last_login_at: string | null;
  created_at: string;
}

export interface TokenPair {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
}

export interface AuthResponse {
  user: User;
  tokens: TokenPair;
}

export interface Page<T> {
  items: T[];
  total: number;
  limit: number;
  offset: number;
}

export interface ApiErrorBody {
  error: string;
  message: string;
  details?: Record<string, unknown>;
  request_id?: string;
}

export interface AIStatus {
  provider: string;
  model: string;
  available: boolean;
  detail: string;
  latency_ms: number | null;
  /** Set when the configured provider could not be used as configured. */
  degraded_reason: string | null;
}

export interface ComponentStatus {
  name: string;
  healthy: boolean;
  detail: string;
  latency_ms: number | null;
}

export interface ReadinessResponse {
  ready: boolean;
  components: ComponentStatus[];
}

export const ROLE_LABELS: Record<Role, string> = {
  viewer: "Viewer",
  analyst: "Analyst",
  investigator: "Investigator",
  admin: "Administrator",
};


// ── Cases ────────────────────────────────────────────────────────────────────
export type CaseStatus = "open" | "in_progress" | "contained" | "closed" | "archived";
export type Severity = "info" | "low" | "medium" | "high" | "critical";

export interface Case {
  id: string;
  reference: string;
  title: string;
  summary: string | null;
  status: CaseStatus;
  severity: Severity;
  owner_id: string;
  assignee_id: string | null;
  opened_at: string | null;
  closed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface CaseStatistics {
  by_status: Record<string, number>;
  by_severity: Record<string, number>;
}

export const CASE_STATUS_LABELS: Record<CaseStatus, string> = {
  open: "Open",
  in_progress: "In progress",
  contained: "Contained",
  closed: "Closed",
  archived: "Archived",
};

/**
 * Mirrors the server's transition table so the UI can disable impossible moves
 * rather than offering them and rendering a 409. The server remains the
 * authority; this is a usability affordance, never a security control.
 */
export const ALLOWED_TRANSITIONS: Record<CaseStatus, CaseStatus[]> = {
  open: ["in_progress", "closed"],
  in_progress: ["contained", "closed", "open"],
  contained: ["closed", "in_progress"],
  closed: ["archived", "in_progress"],
  archived: [],
};

export const SEVERITY_LABELS: Record<Severity, string> = {
  info: "Info",
  low: "Low",
  medium: "Medium",
  high: "High",
  critical: "Critical",
};

export type BadgeTone = "neutral" | "primary" | "accent" | "success" | "warning" | "destructive";

export const SEVERITY_TONES: Record<Severity, BadgeTone> = {
  info: "neutral",
  low: "primary",
  medium: "accent",
  high: "warning",
  critical: "destructive",
};

export const CASE_STATUS_TONES: Record<CaseStatus, BadgeTone> = {
  open: "primary",
  in_progress: "accent",
  contained: "warning",
  closed: "success",
  archived: "neutral",
};

// ── Evidence ─────────────────────────────────────────────────────────────────
export type EvidenceType =
  | "pcap" | "evtx" | "log" | "csv" | "json" | "text" | "document"
  | "pdf" | "apk" | "archive" | "hash" | "url" | "yara" | "sigma" | "unknown";

export type EvidenceStatus =
  | "uploaded" | "queued" | "analyzing" | "analyzed" | "failed" | "quarantined";

export interface Evidence {
  id: string;
  case_id: string;
  uploaded_by_id: string | null;
  original_filename: string;
  media_type: string | null;
  size_bytes: number;
  evidence_type: EvidenceType;
  status: EvidenceStatus;
  sha256: string;
  md5: string | null;
  notes: string | null;
  created_at: string;
  analysis_summary: AnalysisSummary | null;
}

export const EVIDENCE_TYPE_LABELS: Record<EvidenceType, string> = {
  pcap: "PCAP", evtx: "EVTX", log: "Log", csv: "CSV", json: "JSON",
  text: "Text", document: "Document", pdf: "PDF", apk: "APK",
  archive: "Archive", hash: "Hash", url: "URL", yara: "YARA",
  sigma: "Sigma", unknown: "Unknown",
};


// ── Analysis ─────────────────────────────────────────────────────────────────
export interface Finding {
  category: string;
  title: string;
  description: string;
  severity: Severity;
  confidence: number;
  mitre_techniques: string[];
  evidence_refs: string[];
  metadata: Record<string, unknown>;
}

export interface AnalysisSummary {
  engine: string;
  evidence_type: EvidenceType;
  summary: string;
  risk_score: number;
  highest_severity: Severity;
  statistics: Record<string, unknown>;
  findings: Finding[];
  ioc_count: number;
  errors: string[];
}

export const FINDING_CATEGORY_LABELS: Record<string, string> = {
  beaconing: "Beaconing",
  port_scan: "Port scan",
  brute_force: "Brute force",
  dns_tunneling: "DNS tunneling",
  data_exfiltration: "Exfiltration",
  suspicious_protocol: "Suspicious activity",
  plaintext_credentials: "Cleartext credentials",
  anomaly: "Anomaly",
};

// ── IOCs ─────────────────────────────────────────────────────────────────────
export type IOCType =
  | "ipv4" | "ipv6" | "domain" | "url" | "email"
  | "md5" | "sha1" | "sha256" | "filename"
  | "registry_key" | "user_agent" | "port";

export interface IOC {
  id: string;
  case_id: string;
  first_seen_evidence_id: string | null;
  ioc_type: IOCType;
  value: string;
  defanged: string;
  severity: Severity;
  confidence: number;
  sightings: number;
  context: string | null;
  created_at: string;
}

export const IOC_TYPE_LABELS: Record<IOCType, string> = {
  ipv4: "IPv4", ipv6: "IPv6", domain: "Domain", url: "URL",
  email: "Email", md5: "MD5", sha1: "SHA-1", sha256: "SHA-256",
  filename: "Filename", registry_key: "Registry key",
  user_agent: "User agent", port: "Port",
};


// ── Assistant ────────────────────────────────────────────────────────────────
export type MessageRole = "system" | "user" | "assistant";

export interface ChatMessage {
  id: string;
  conversation_id: string;
  role: MessageRole;
  content: string;
  provider: string | null;
  model: string | null;
  input_tokens: number;
  output_tokens: number;
  created_at: string;
}

export interface Conversation {
  id: string;
  case_id: string | null;
  owner_id: string;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface ConversationDetail extends Conversation {
  messages: ChatMessage[];
}


// ── Timeline ─────────────────────────────────────────────────────────────────
export type TimelineSource = "incident" | "investigation";

export type TimelineEventKind =
  | "case.opened"
  | "case.status_changed"
  | "evidence.uploaded"
  | "analysis.completed"
  | "finding.raised"
  | "capture.window"
  | "indicator.observed";

export interface TimelineEvent {
  id: string;
  occurred_at: string;
  kind: TimelineEventKind;
  source: TimelineSource;
  title: string;
  description: string | null;
  severity: Severity;
  case_id: string | null;
  case_reference: string | null;
  actor: string | null;
  evidence_id: string | null;
  metadata: Record<string, unknown>;
}

export interface TimelineResponse {
  events: TimelineEvent[];
  total: number;
  incident_events: number;
  investigation_events: number;
}

export const TIMELINE_SOURCE_LABELS: Record<TimelineSource, string> = {
  incident: "Incident",
  investigation: "Investigation",
};


// ── Threat intelligence ──────────────────────────────────────────────────────
export type ThreatVerdict = "unknown" | "benign" | "suspicious" | "malicious";

export interface ProviderOpinion {
  provider: string;
  verdict: ThreatVerdict;
  score: number;
  detail: string;
  attributes: Record<string, unknown>;
  error: string | null;
}

export interface Enrichment {
  id: string;
  ioc_type: IOCType;
  value: string;
  verdict: ThreatVerdict;
  score: number;
  providers: Record<string, ProviderOpinion> | null;
  provider_count: number;
  fetched_at: string;
  expires_at: string;
}

export interface ThreatIntelStatus {
  providers: string[];
  cache_hours: number;
  cached_indicators: number;
  by_verdict: Record<string, number>;
}

export const VERDICT_LABELS: Record<ThreatVerdict, string> = {
  unknown: "Unknown",
  benign: "Benign",
  suspicious: "Suspicious",
  malicious: "Malicious",
};

export const VERDICT_TONES: Record<ThreatVerdict, BadgeTone> = {
  unknown: "neutral",
  benign: "success",
  suspicious: "warning",
  malicious: "destructive",
};


// ── Reports ──────────────────────────────────────────────────────────────────
export type ReportProfile = "executive" | "technical";
export type ReportFormat = "markdown" | "html" | "pdf";

export interface Report {
  id: string;
  case_id: string;
  generated_by_id: string | null;
  title: string;
  profile: ReportProfile;
  format: ReportFormat;
  size_bytes: number;
  signature: string;
  summary: Record<string, unknown> | null;
  created_at: string;
}

export interface ReportVerification {
  report_id: string;
  valid: boolean;
  signature: string;
  algorithm: string;
  detail: string;
}

export const REPORT_PROFILE_LABELS: Record<ReportProfile, string> = {
  executive: "Executive",
  technical: "Technical",
};

export const REPORT_FORMAT_LABELS: Record<ReportFormat, string> = {
  markdown: "Markdown",
  html: "HTML",
  pdf: "PDF",
};


// ── Voice ────────────────────────────────────────────────────────────────────
export type IntentAction =
  | "navigate" | "list_cases" | "open_case" | "case_summary"
  | "change_status" | "analyze_evidence" | "list_iocs" | "enrich_iocs"
  | "generate_report" | "ask_assistant" | "help" | "unknown";

export interface VoiceIntent {
  action: IntentAction;
  confidence: "exact" | "inferred" | "ambiguous" | "none";
  utterance: string;
  entities: Record<string, unknown>;
  needs_confirmation: boolean;
}

export interface VoiceCommandResult {
  intent: VoiceIntent;
  speech: string;
  ui_action: { type: string; route?: string; question?: string; case_id?: string } | null;
  data: Record<string, unknown>;
  succeeded: boolean;
}

export interface VoiceCapabilities {
  wake_word: string;
  actions: string[];
  examples: string[];
  help_text: string;
}


export interface CaseOverview {
  case_id: string;
  reference: string;
  title: string;
  status: CaseStatus;
  severity: Severity;
  evidence_count: number;
  analysed_count: number;
  finding_count: number;
  ioc_count: number;
  risk_score: number;
  top_finding: string | null;
  top_finding_severity: Severity | null;
}
