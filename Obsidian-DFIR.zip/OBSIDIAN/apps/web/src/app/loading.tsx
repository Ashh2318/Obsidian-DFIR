import { Logo } from "@/components/ui/logo";

export default function Loading() {
  return (
    <div className="grid min-h-[60dvh] place-items-center">
      <Logo className="size-9 animate-pulse" />
    </div>
  );
}
