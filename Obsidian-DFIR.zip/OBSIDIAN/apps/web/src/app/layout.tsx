import type { Metadata, Viewport } from "next";

import { Providers } from "@/components/providers";

import "./globals.css";

/**
 * Typography is deliberately NOT loaded via `next/font/google`.
 *
 * That helper fetches font binaries from fonts.gstatic.com at build time, which
 * has three consequences OBSIDIAN cannot accept:
 *
 *   1. Builds fail without internet access, breaking the air-gapped DFIR
 *      deployment the platform explicitly supports (ADR 0002).
 *   2. Every build emits a request to a third party.
 *   3. Build output stops being reproducible offline.
 *
 * The stack below resolves entirely on the client with no network request and
 * no layout shift. To use Inter and JetBrains Mono instead, drop the .woff2
 * files into `public/fonts/`, declare them with `next/font/local`, and set
 * `--font-sans` / `--font-mono` — no component changes are required, because
 * every component references those variables rather than a font name.
 */
const FONT_VARIABLES = [
  "--font-sans: ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif",
  "--font-mono: ui-monospace, 'SF Mono', 'Cascadia Mono', 'Segoe UI Mono', 'JetBrains Mono', Menlo, Consolas, monospace",
].join(";");

export const metadata: Metadata = {
  title: {
    default: "OBSIDIAN — Cybersecurity Investigation Platform",
    template: "%s · OBSIDIAN",
  },
  description:
    "AI-powered cybersecurity investigation platform. Observe. Analyze. Defend.",
  applicationName: "OBSIDIAN",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "OBSIDIAN", statusBarStyle: "black-translucent" },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: "#070a12",
  width: "device-width",
  initialScale: 1,
  // The app is a workspace, not a document; pinch-zoom chrome gets in the way.
  maximumScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body style={{ ...({} as React.CSSProperties) }} data-app="obsidian">
        <style
          // Injected ahead of the app so the variables exist on first paint.
          dangerouslySetInnerHTML={{ __html: `:root{${FONT_VARIABLES}}` }}
        />
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
