import Link from "next/link";

import { Logo } from "@/components/ui/logo";

export default function NotFound() {
  return (
    <div className="grid min-h-dvh place-items-center p-6">
      <div className="max-w-sm space-y-4 text-center">
        <Logo className="mx-auto size-11" />
        <p className="font-mono text-5xl font-semibold text-muted-foreground/40">404</p>
        <h1 className="text-lg font-semibold tracking-tight">Route not found</h1>
        <p className="text-sm text-muted-foreground">
          This module does not exist, or has not shipped yet. Check the roadmap
          in the sidebar for planned phases.
        </p>
        <Link
          href="/dashboard"
          className="inline-block text-sm font-medium text-primary hover:underline"
        >
          Return to dashboard
        </Link>
      </div>
    </div>
  );
}
