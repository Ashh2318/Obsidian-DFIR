import { Logo } from "@/components/ui/logo";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative grid min-h-dvh lg:grid-cols-2">
      <div className="pointer-events-none absolute inset-0 grid-backdrop" aria-hidden />

      {/* Brand panel — hidden on small screens where the form deserves the space. */}
      <section className="relative hidden flex-col justify-between border-r border-border/60 p-12 lg:flex">
        <div className="flex items-center gap-3">
          <Logo className="size-9" />
          <div className="leading-none">
            <p className="text-lg font-semibold tracking-[0.2em]">OBSIDIAN</p>
            <p className="mt-1.5 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
              Observe. Analyze. Defend.
            </p>
          </div>
        </div>

        <div className="max-w-md space-y-6">
          <h2 className="text-3xl font-semibold leading-tight tracking-tight">
            The investigation workspace that{" "}
            <span className="text-gradient">thinks with you</span>.
          </h2>
          <p className="text-sm leading-relaxed text-muted-foreground">
            Triage packet captures, event logs, documents and mobile artefacts in
            one place — with an AI analyst that explains what it found and why it
            matters.
          </p>
          <ul className="space-y-3 text-sm text-muted-foreground">
            {[
              "Evidence handling with chain-of-custody hashing",
              "MITRE ATT&CK technique mapping",
              "Provider-agnostic AI, including fully offline inference",
            ].map((item) => (
              <li key={item} className="flex items-start gap-2.5">
                <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        <p className="font-mono text-[11px] text-muted-foreground/60">
          v0.1.0
        </p>
      </section>

      <section className="relative flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-sm">{children}</div>
      </section>
    </div>
  );
}
