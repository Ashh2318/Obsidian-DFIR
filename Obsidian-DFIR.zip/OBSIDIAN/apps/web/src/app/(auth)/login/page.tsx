"use client";

import { KeyRound, Mail, RotateCcw } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import * as React from "react";
import { toast } from "sonner";

import { useAuth } from "@/components/providers/auth-provider";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Logo } from "@/components/ui/logo";
import { API_DISPLAY_URL, apiRequest, ApiError } from "@/lib/api-client";

export default function LoginPage() {
  const router = useRouter();
  const { login, user, initializing } = useAuth();

  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [error, setError] = React.useState<
    { kind: "rejected" | "unreachable"; message: string } | null
  >(null);
  const [submitting, setSubmitting] = React.useState(false);
  const [retrying, setRetrying] = React.useState(false);
  const apiUrl = API_DISPLAY_URL;

  /** Probe the health endpoint so the user gets a definite answer, not a guess. */
  async function retryConnection() {
    setRetrying(true);
    try {
      await apiRequest("/health", { anonymous: true });
      setError(null);
      toast.success("Connected", { description: "The API is responding." });
    } catch {
      toast.error("Still unreachable", {
        description: "The API did not respond. Check the API window.",
      });
    } finally {
      setRetrying(false);
    }
  }

  // A signed-in user landing here should be moved along, not shown a form.
  React.useEffect(() => {
    if (!initializing && user) router.replace("/dashboard");
  }, [initializing, user, router]);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await login(email, password);
      toast.success("Signed in", { description: "Welcome back to OBSIDIAN." });
      router.replace("/dashboard");
    } catch (caught) {
      if (caught instanceof ApiError) {
        setError({ kind: "rejected", message: caught.message });
      } else {
        // fetch() rejects rather than resolving when the request never reached
        // a server: process down, wrong port, or a name resolving to an address
        // nothing is listening on.
        setError({ kind: "unreachable", message: "" });
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="animate-slide-up space-y-8">
      <div className="space-y-2">
        <Logo className="size-10 lg:hidden" />
        <h1 className="text-2xl font-semibold tracking-tight">Sign in</h1>
        <p className="text-sm text-muted-foreground">
          Authenticate to access the investigation workspace.
        </p>
      </div>

      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        <Input
          label="Email"
          type="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="analyst@example.com"
          autoComplete="email"
          icon={<Mail />}
          required
          disabled={submitting}
        />

        <Input
          label="Password"
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          placeholder="••••••••••••"
          autoComplete="current-password"
          icon={<KeyRound />}
          required
          disabled={submitting}
        />

        {error?.kind === "rejected" ? (
          <Alert variant="destructive">{error.message}</Alert>
        ) : null}

        {error?.kind === "unreachable" ? (
          <Alert variant="warning">
            <AlertTitle>Cannot reach the OBSIDIAN API</AlertTitle>
            <AlertDescription>
              The workspace is running, but nothing answered at{" "}
              <code className="font-mono">{apiUrl}</code>.
            </AlertDescription>
            <ul className="mt-1.5 list-disc space-y-0.5 pl-4 text-[11px] opacity-90">
              <li>Check the &ldquo;OBSIDIAN API&rdquo; window for a traceback.</li>
              <li>The API can take up to a minute to boot on first run.</li>
              <li>Still stuck? Run <code className="font-mono">doctor.bat</code>.</li>
            </ul>
            <Button
              type="button"
              variant="secondary"
              size="sm"
              className="mt-2"
              loading={retrying}
              onClick={() => void retryConnection()}
            >
              <RotateCcw />
              Retry connection
            </Button>
          </Alert>
        ) : null}

        <Button type="submit" className="w-full" loading={submitting} size="lg">
          {submitting ? "Authenticating" : "Sign in"}
        </Button>
      </form>

      <p className="text-center text-xs text-muted-foreground">
        No account yet?{" "}
        <Link href="/register" className="font-medium text-primary hover:underline">
          Request access
        </Link>
      </p>
    </div>
  );
}
