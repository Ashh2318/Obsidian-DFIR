"use client";

import { Building2, KeyRound, Mail, User as UserIcon } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import * as React from "react";
import { toast } from "sonner";

import { useAuth } from "@/components/providers/auth-provider";
import { Alert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Logo } from "@/components/ui/logo";
import { api, ApiError } from "@/lib/api-client";

/** Mirrors the server-side policy so the user gets feedback before submitting. */
const RULES: { label: string; test: (value: string) => boolean }[] = [
  { label: "At least 12 characters", test: (v) => v.length >= 12 },
  { label: "An uppercase letter", test: (v) => /[A-Z]/.test(v) },
  { label: "A lowercase letter", test: (v) => /[a-z]/.test(v) },
  { label: "A digit", test: (v) => /\d/.test(v) },
  { label: "A symbol", test: (v) => /[^A-Za-z0-9]/.test(v) },
];

export default function RegisterPage() {
  const router = useRouter();
  const { login } = useAuth();

  const [form, setForm] = React.useState({
    full_name: "",
    email: "",
    password: "",
    organization: "",
  });
  const [error, setError] = React.useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = React.useState<Record<string, string>>({});
  const [submitting, setSubmitting] = React.useState(false);

  const satisfied = RULES.filter((rule) => rule.test(form.password)).length;
  const passwordValid = satisfied === RULES.length;

  function update(key: keyof typeof form) {
    return (event: React.ChangeEvent<HTMLInputElement>) =>
      setForm((previous) => ({ ...previous, [key]: event.target.value }));
  }

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setFieldErrors({});
    setSubmitting(true);
    try {
      await api.register({
        email: form.email,
        password: form.password,
        full_name: form.full_name,
        organization: form.organization || undefined,
      });
      // Sign in immediately so the user lands in the workspace, not back at a form.
      await login(form.email, form.password);
      toast.success("Account created", { description: "Welcome to OBSIDIAN." });
      router.replace("/dashboard");
    } catch (caught) {
      if (caught instanceof ApiError) {
        setFieldErrors(caught.fieldErrors);
        setError(caught.message);
      } else {
        setError("Could not reach the OBSIDIAN API. Is the backend running?");
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="animate-slide-up space-y-7">
      <div className="space-y-2">
        <Logo className="size-10 lg:hidden" />
        <h1 className="text-2xl font-semibold tracking-tight">Request access</h1>
        <p className="text-sm text-muted-foreground">
          The first account created on this deployment becomes the administrator.
        </p>
      </div>

      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        <Input
          label="Full name"
          value={form.full_name}
          onChange={update("full_name")}
          placeholder="Alex Mercer"
          autoComplete="name"
          icon={<UserIcon />}
          error={fieldErrors.full_name}
          required
          disabled={submitting}
        />

        <Input
          label="Email"
          type="email"
          value={form.email}
          onChange={update("email")}
          placeholder="analyst@example.com"
          autoComplete="email"
          icon={<Mail />}
          error={fieldErrors.email}
          required
          disabled={submitting}
        />

        <Input
          label="Organization"
          value={form.organization}
          onChange={update("organization")}
          placeholder="Optional"
          icon={<Building2 />}
          error={fieldErrors.organization}
          disabled={submitting}
        />

        <div className="space-y-2">
          <Input
            label="Password"
            type="password"
            value={form.password}
            onChange={update("password")}
            placeholder="••••••••••••"
            autoComplete="new-password"
            icon={<KeyRound />}
            error={fieldErrors.password}
            required
            disabled={submitting}
          />

          {form.password ? (
            <div className="space-y-2 rounded-md border border-border/60 bg-white/[0.02] p-3">
              <div className="flex gap-1" aria-hidden>
                {RULES.map((rule, index) => (
                  <span
                    key={rule.label}
                    className={`h-1 flex-1 rounded-full transition-colors ${
                      index < satisfied
                        ? passwordValid
                          ? "bg-success"
                          : "bg-warning"
                        : "bg-muted"
                    }`}
                  />
                ))}
              </div>
              <ul className="grid grid-cols-2 gap-x-3 gap-y-1">
                {RULES.map((rule) => {
                  const ok = rule.test(form.password);
                  return (
                    <li
                      key={rule.label}
                      className={`text-[11px] ${ok ? "text-success" : "text-muted-foreground"}`}
                    >
                      {ok ? "✓" : "○"} {rule.label}
                    </li>
                  );
                })}
              </ul>
            </div>
          ) : null}
        </div>

        {error ? <Alert variant="destructive">{error}</Alert> : null}

        <Button
          type="submit"
          className="w-full"
          size="lg"
          loading={submitting}
          disabled={!passwordValid}
        >
          {submitting ? "Creating account" : "Create account"}
        </Button>
      </form>

      <p className="text-center text-xs text-muted-foreground">
        Already have an account?{" "}
        <Link href="/login" className="font-medium text-primary hover:underline">
          Sign in
        </Link>
      </p>
    </div>
  );
}
