"use client";

import { RotateCcw } from "lucide-react";
import * as React from "react";

import { Button } from "@/components/ui/button";
import { Logo } from "@/components/ui/logo";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  React.useEffect(() => {
    // Replace with a real reporting sink when observability lands.
    console.error("Unhandled application error:", error);
  }, [error]);

  return (
    <div className="grid min-h-dvh place-items-center p-6">
      <div className="max-w-md space-y-4 text-center">
        <Logo className="mx-auto size-11" />
        <h1 className="text-lg font-semibold tracking-tight">Something went wrong</h1>
        <p className="text-sm text-muted-foreground">
          The workspace hit an unexpected error. Retrying is usually enough; if
          it persists, check the API logs.
        </p>
        {error.digest ? (
          <p className="font-mono text-[11px] text-muted-foreground/60">
            digest: {error.digest}
          </p>
        ) : null}
        <Button onClick={reset} variant="secondary">
          <RotateCcw />
          Try again
        </Button>
      </div>
    </div>
  );
}
