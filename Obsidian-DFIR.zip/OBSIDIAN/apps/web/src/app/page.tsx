"use client";

import { useRouter } from "next/navigation";
import * as React from "react";

import { useAuth } from "@/components/providers/auth-provider";
import { Logo } from "@/components/ui/logo";

/** Entry point: routes to the workspace or to sign-in once the session resolves. */
export default function IndexPage() {
  const router = useRouter();
  const { user, initializing } = useAuth();

  React.useEffect(() => {
    if (initializing) return;
    router.replace(user ? "/dashboard" : "/login");
  }, [initializing, user, router]);

  return (
    <div className="grid min-h-dvh place-items-center">
      <div className="flex flex-col items-center gap-4">
        <Logo className="size-12 animate-pulse" />
        <p className="text-xs uppercase tracking-[0.22em] text-muted-foreground">
          Initialising
        </p>
      </div>
    </div>
  );
}
