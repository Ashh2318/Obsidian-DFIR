"use client";

import { useRouter } from "next/navigation";
import * as React from "react";

import { AiPanel } from "@/components/layout/ai-panel";
import { CommandPalette } from "@/components/layout/command-palette";
import { Sidebar } from "@/components/layout/sidebar";
import { Topbar } from "@/components/layout/topbar";
import { WorkspaceTabs } from "@/components/layout/workspace-tabs";
import { VoiceHud } from "@/components/voice/voice-hud";
import { useAuth } from "@/components/providers/auth-provider";
import { Logo } from "@/components/ui/logo";
import { NotificationsProvider, useNotificationsState } from "@/hooks/use-notifications";
import { ShellProvider, useShellState } from "@/hooks/use-shell";
import { useWakeWord } from "@/hooks/use-speech";

/**
 * Authenticated workspace shell.
 *
 * Rendering is withheld until the silent-refresh attempt resolves. Redirecting
 * on `!user` before that would bounce every returning visitor to /login for the
 * few hundred milliseconds the refresh takes.
 */
export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const { user, initializing } = useAuth();
  const shell = useShellState();
  const notifications = useNotificationsState();

  // Wake word runs at the shell so it is active on every screen. It pauses
  // while the HUD is open, or the two recognisers would fight for the mic.
  const wake = useWakeWord({
    enabled: shell.wakeWordEnabled && Boolean(user),
    paused: shell.voiceOpen,
    onWake: (trailing) => {
      shell.setPendingUtterance(trailing || null);
      shell.setVoiceOpen(true);
    },
  });

  // Surfaced in the topbar, so a live microphone is never a silent state —
  // and so a microphone the browser refused is not mistaken for a working one.
  React.useEffect(() => {
    shell.setWakeWordArmed(wake.armed);
    shell.setWakeWordNeedsGesture(wake.needsGesture);
  }, [wake.armed, wake.needsGesture, shell]);

  React.useEffect(() => {
    if (!initializing && !user) router.replace("/login");
  }, [initializing, user, router]);

  if (initializing || !user) {
    return (
      <div className="grid min-h-dvh place-items-center">
        <div className="flex flex-col items-center gap-4">
          <Logo className="size-11 animate-pulse" />
          <p className="text-xs uppercase tracking-eyebrow text-muted-foreground">
            Restoring session
          </p>
        </div>
      </div>
    );
  }

  return (
    <ShellProvider value={shell}>
      <NotificationsProvider value={notifications}>
        <div className="flex h-dvh overflow-hidden">
          <Sidebar />

          <div className="flex min-w-0 flex-1 flex-col">
            <Topbar />
            <WorkspaceTabs />
            <main className="flex-1 overflow-y-auto p-s4 sm:p-s5">{children}</main>
          </div>

          <AiPanel />
          <CommandPalette />

          {shell.voiceOpen ? (
            <VoiceHud
              onClose={() => {
                shell.setVoiceOpen(false);
                shell.setPendingUtterance(null);
              }}
              wakeWordEnabled={shell.wakeWordEnabled}
              onWakeWordChange={shell.setWakeWordEnabled}
              pendingUtterance={shell.pendingUtterance}
            />
          ) : null}
        </div>
      </NotificationsProvider>
    </ShellProvider>
  );
}
