"use client";

import { useQuery } from "@tanstack/react-query";
import * as React from "react";

import { AssistantChat } from "@/components/assistant/chat";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { apiRequest } from "@/lib/api-client";
import { casesApi } from "@/lib/api/cases";
import type { AIStatus } from "@/types/api";

const NO_CASE = "none";

export default function AssistantPage() {
  const [caseId, setCaseId] = React.useState<string>(NO_CASE);

  const cases = useQuery({
    queryKey: ["cases", "", "", ""],
    queryFn: () => casesApi.list({ limit: 100 }),
  });

  const ai = useQuery({
    queryKey: ["ai-status"],
    queryFn: () => apiRequest<AIStatus>("/ai/status"),
    retry: false,
  });

  const grounded = caseId !== NO_CASE ? caseId : null;

  return (
    <div className="mx-auto flex h-full max-w-4xl flex-col">
      <header className="flex flex-wrap items-start justify-between gap-s3 pb-s3">
        <div className="space-y-1">
          <h1 className="text-xl font-semibold tracking-tight">AI Assistant</h1>
          <p className="text-xs text-muted-foreground">
            Ask questions about an investigation. Answers are grounded in that
            case&apos;s evidence, findings and indicators.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {ai.data ? (
            <Badge variant={ai.data.available ? "success" : "warning"}>
              {ai.data.provider} · {ai.data.model}
            </Badge>
          ) : null}
          <Select value={caseId} onValueChange={setCaseId}>
            <SelectTrigger className="h-9 w-60">
              <SelectValue placeholder="Attach a case" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={NO_CASE}>No case (general)</SelectItem>
              {(cases.data?.items ?? []).map((record) => (
                <SelectItem key={record.id} value={record.id}>
                  {record.reference} — {record.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </header>

      <div className="glass flex min-h-0 flex-1 flex-col overflow-hidden rounded-lg">
        {/* Remounting on case change starts a fresh conversation, so the model
            is never asked about one investigation with another's context. */}
        <AssistantChat key={grounded ?? "general"} caseId={grounded} />
      </div>
    </div>
  );
}
