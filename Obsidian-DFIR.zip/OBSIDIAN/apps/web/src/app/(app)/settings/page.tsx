"use client";

import { LogOut, ShieldAlert } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";

import { useAuth } from "@/components/providers/auth-provider";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { formatDate } from "@/lib/utils";
import { ROLE_LABELS } from "@/types/api";

export default function SettingsPage() {
  const { user, logout } = useAuth();
  const [confirmOpen, setConfirmOpen] = React.useState(false);
  const [revoking, setRevoking] = React.useState(false);


  if (!user) return null;

  const fields: [string, string][] = [
    ["Full name", user.full_name],
    ["Email", user.email],
    ["Role", ROLE_LABELS[user.role]],
    ["Organization", user.organization ?? "—"],
    ["Job title", user.job_title ?? "—"],
    ["Member since", formatDate(user.created_at)],
  ];

  async function signOutEverywhere() {
    setRevoking(true);
    try {
      await logout(true);
      toast.success("All sessions revoked");
    } finally {
      setRevoking(false);
      setConfirmOpen(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <header className="space-y-1">
        <h1 className="text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground">
          Your account and active sessions.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>Profile</CardTitle>
          <CardDescription>Details associated with this account.</CardDescription>
        </CardHeader>
        <CardContent>
          <dl className="divide-y divide-border/60">
            {fields.map(([label, value]) => (
              <div key={label} className="flex items-center justify-between py-2.5">
                <dt className="text-xs text-muted-foreground">{label}</dt>
                <dd className="text-sm">{value}</dd>
              </div>
            ))}
            <div className="flex items-center justify-between py-2.5">
              <dt className="text-xs text-muted-foreground">Status</dt>
              <dd>
                <Badge variant={user.is_active ? "success" : "destructive"}>
                  {user.is_active ? "Active" : "Disabled"}
                </Badge>
              </dd>
            </div>
          </dl>
        </CardContent>
      </Card>

      <Card className="border-destructive/25">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldAlert className="size-4 text-destructive" aria-hidden />
            Sessions
          </CardTitle>
          <CardDescription>
            Revoking every session signs you out on all devices immediately. Do
            this if you suspect a credential has been exposed.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Irreversible and affects every device, so it is confirmed rather
              than fired on a single click. */}
          <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
            <DialogTrigger asChild>
              <Button variant="destructive">
                <LogOut />
                Sign out everywhere
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Revoke all sessions?</DialogTitle>
                <DialogDescription>
                  Every device signed in as {user.email} will be signed out
                  immediately, including this one. You will need to sign in
                  again.
                </DialogDescription>
              </DialogHeader>
              <Separator className="my-4" />
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancel</Button>
                </DialogClose>
                <Button
                  variant="destructive"
                  loading={revoking}
                  onClick={() => void signOutEverywhere()}
                >
                  Revoke all sessions
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>
    </div>
  );
}
