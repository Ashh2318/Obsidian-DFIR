"use client";

import { useQuery } from "@tanstack/react-query";
import { Copy, ShieldAlert } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DataTable, type DataTableColumn } from "@/components/ui/data-table";
import { ErrorState } from "@/components/ui/error-state";
import { SearchInput } from "@/components/ui/search-input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ApiError } from "@/lib/api-client";
import { analysisApi } from "@/lib/api/analysis";
import { relativeTime } from "@/lib/utils";
import {
  IOC_TYPE_LABELS,
  SEVERITY_LABELS,
  SEVERITY_TONES,
  type IOC,
  type IOCType,
  type Severity,
} from "@/types/api";

const ALL = "all";

export default function IOCEnginePage() {
  const [search, setSearch] = React.useState("");
  const [debounced, setDebounced] = React.useState("");
  const [type, setType] = React.useState<IOCType | typeof ALL>(ALL);
  const [severity, setSeverity] = React.useState<Severity | typeof ALL>(ALL);
  // Defanged by default: an indicator list is frequently pasted into tickets
  // and chat, where a live URL is a hazard.
  const [defanged, setDefanged] = React.useState(true);

  React.useEffect(() => {
    const timer = setTimeout(() => setDebounced(search), 300);
    return () => clearTimeout(timer);
  }, [search]);

  const query = useQuery({
    queryKey: ["iocs", debounced, type, severity],
    queryFn: () =>
      analysisApi.listIocs({
        q: debounced || undefined,
        ioc_type: type === ALL ? "" : type,
        severity: severity === ALL ? "" : severity,
        limit: 200,
      }),
  });

  async function copy(value: string) {
    try {
      await navigator.clipboard.writeText(value);
      toast.success("Copied", { description: value });
    } catch {
      toast.error("Could not access the clipboard");
    }
  }

  const columns: DataTableColumn<IOC>[] = [
    {
      key: "value",
      header: "Indicator",
      sortable: true,
      cell: (ioc) => (
        <div className="flex min-w-0 items-center gap-2">
          <span className="truncate font-mono text-xs">
            {defanged ? ioc.defanged : ioc.value}
          </span>
          <Button
            variant="ghost"
            size="icon"
            className="size-6 shrink-0"
            aria-label={`Copy ${ioc.value}`}
            onClick={(event) => {
              event.stopPropagation();
              void copy(defanged ? ioc.defanged : ioc.value);
            }}
          >
            <Copy className="size-3" />
          </Button>
        </div>
      ),
    },
    {
      key: "ioc_type",
      header: "Type",
      sortable: true,
      cell: (ioc) => <Badge variant="neutral">{IOC_TYPE_LABELS[ioc.ioc_type]}</Badge>,
    },
    {
      key: "severity",
      header: "Severity",
      sortable: true,
      cell: (ioc) => (
        <Badge variant={SEVERITY_TONES[ioc.severity]}>{SEVERITY_LABELS[ioc.severity]}</Badge>
      ),
    },
    {
      key: "confidence",
      header: "Confidence",
      sortable: true,
      sortValue: (ioc) => ioc.confidence,
      cell: (ioc) => (
        <span className="font-mono text-2xs tabular-nums">{ioc.confidence}%</span>
      ),
    },
    {
      key: "sightings",
      header: "Sightings",
      sortable: true,
      sortValue: (ioc) => ioc.sightings,
      cell: (ioc) => (
        <span className="font-mono text-2xs tabular-nums">{ioc.sightings}</span>
      ),
    },
    {
      key: "created_at",
      header: "First seen",
      sortable: true,
      cell: (ioc) => (
        <span className="whitespace-nowrap text-2xs text-muted-foreground">
          {relativeTime(ioc.created_at)}
        </span>
      ),
      className: "text-right",
      headerClassName: "text-right",
    },
  ];

  return (
    <div className="mx-auto max-w-6xl space-y-s4">
      <header className="space-y-1">
        <h1 className="text-xl font-semibold tracking-tight">IOC Engine</h1>
        <p className="text-xs text-muted-foreground">
          {query.data ? `${query.data.total} indicator(s)` : "Extracted indicators"} across
          all cases. Private, loopback and documentation addresses are excluded
          automatically.
        </p>
      </header>

      <div className="flex flex-wrap items-center gap-s2">
        <SearchInput
          value={search}
          onValueChange={setSearch}
          placeholder="Search indicators..."
          containerClassName="w-full sm:w-64"
        />
        <Select value={type} onValueChange={(v) => setType(v as IOCType)}>
          <SelectTrigger className="h-9 w-36">
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>All types</SelectItem>
            {(Object.keys(IOC_TYPE_LABELS) as IOCType[]).map((t) => (
              <SelectItem key={t} value={t}>
                {IOC_TYPE_LABELS[t]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={severity} onValueChange={(v) => setSeverity(v as Severity)}>
          <SelectTrigger className="h-9 w-36">
            <SelectValue placeholder="Severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>All severities</SelectItem>
            {(Object.keys(SEVERITY_LABELS) as Severity[]).map((s) => (
              <SelectItem key={s} value={s}>
                {SEVERITY_LABELS[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <label className="ml-auto flex items-center gap-2 text-2xs text-muted-foreground">
          <Switch checked={defanged} onCheckedChange={setDefanged} aria-label="Defang indicators" />
          Defanged
        </label>
      </div>

      {query.isError ? (
        <ErrorState
          title="Could not load indicators"
          description={
            query.error instanceof ApiError ? query.error.message : "The API did not respond."
          }
          onRetry={() => void query.refetch()}
        />
      ) : (
        <DataTable
          columns={columns}
          rows={query.data?.items ?? []}
          rowKey={(ioc) => ioc.id}
          loading={query.isPending}
          pageSize={15}
          emptyTitle="No indicators yet"
          emptyDescription="Analyse evidence on a case and extracted indicators will appear here."
        />
      )}

      <ShieldAlert className="sr-only" aria-hidden />
    </div>
  );
}
