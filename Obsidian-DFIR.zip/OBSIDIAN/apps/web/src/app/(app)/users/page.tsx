"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as React from "react";
import { toast } from "sonner";

import { useAuth } from "@/components/providers/auth-provider";
import { Badge } from "@/components/ui/badge";
import { DataTable, type DataTableColumn } from "@/components/ui/data-table";
import { ErrorState } from "@/components/ui/error-state";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ApiError } from "@/lib/api-client";
import { usersApi } from "@/lib/api/users";
import { formatDate, relativeTime } from "@/lib/utils";
import { ROLE_LABELS, type Role, type User } from "@/types/api";

export default function UsersPage() {
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["users"],
    queryFn: () => usersApi.list({ limit: 100 }),
  });

  function onError(error: unknown) {
    toast.error("Change rejected", {
      description: error instanceof ApiError ? error.message : "The request failed.",
    });
  }

  const roleMutation = useMutation({
    mutationFn: ({ id, role }: { id: string; role: Role }) => usersApi.changeRole(id, role),
    onSuccess: (updated) => {
      void queryClient.invalidateQueries({ queryKey: ["users"] });
      toast.success("Role updated", {
        description: `${updated.email} is now ${ROLE_LABELS[updated.role]}.`,
      });
    },
    onError,
  });

  const activeMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      usersApi.setActive(id, isActive),
    onSuccess: (updated) => {
      void queryClient.invalidateQueries({ queryKey: ["users"] });
      toast.success(updated.is_active ? "Account enabled" : "Account disabled", {
        description: updated.is_active
          ? updated.email
          : `${updated.email} — all sessions revoked.`,
      });
    },
    onError,
  });

  const columns: DataTableColumn<User>[] = [
    {
      key: "full_name",
      header: "User",
      sortable: true,
      cell: (u) => (
        <div className="min-w-0">
          <p className="truncate text-xs font-medium">
            {u.full_name}
            {u.id === currentUser?.id ? (
              <span className="ml-1.5 text-2xs text-muted-foreground">(you)</span>
            ) : null}
          </p>
          <p className="truncate text-2xs text-muted-foreground">{u.email}</p>
        </div>
      ),
    },
    {
      key: "role",
      header: "Role",
      sortable: true,
      cell: (u) => (
        <Select
          value={u.role}
          onValueChange={(role) => roleMutation.mutate({ id: u.id, role: role as Role })}
        >
          <SelectTrigger className="h-8 w-40 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {(Object.keys(ROLE_LABELS) as Role[]).map((role) => (
              <SelectItem key={role} value={role}>
                {ROLE_LABELS[role]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      ),
    },
    {
      key: "last_login_at",
      header: "Last seen",
      sortable: true,
      cell: (u) => (
        <span className="whitespace-nowrap text-2xs text-muted-foreground">
          {u.last_login_at ? relativeTime(u.last_login_at) : "never"}
        </span>
      ),
    },
    {
      key: "created_at",
      header: "Joined",
      sortable: true,
      cell: (u) => (
        <span className="whitespace-nowrap text-2xs text-muted-foreground">
          {formatDate(u.created_at)}
        </span>
      ),
    },
    {
      key: "is_active",
      header: "Active",
      cell: (u) => (
        <div className="flex items-center justify-end gap-2">
          {u.is_verified ? null : <Badge variant="neutral">Unverified</Badge>}
          <Switch
            checked={u.is_active}
            // The server also refuses this, but disabling the control explains
            // why instead of surfacing a 409 after the fact.
            disabled={u.id === currentUser?.id}
            aria-label={`${u.is_active ? "Disable" : "Enable"} ${u.email}`}
            onCheckedChange={(checked) =>
              activeMutation.mutate({ id: u.id, isActive: checked })
            }
          />
        </div>
      ),
      className: "text-right",
      headerClassName: "text-right",
    },
  ];

  return (
    <div className="mx-auto max-w-5xl space-y-s4">
      <header className="space-y-1">
        <h1 className="text-xl font-semibold tracking-tight">Users</h1>
        <p className="text-xs text-muted-foreground">
          {query.data ? `${query.data.total} account(s)` : "Account administration"}
          . Disabling an account revokes its sessions immediately.
        </p>
      </header>

      {query.isError ? (
        <ErrorState
          title="Could not load users"
          description={
            query.error instanceof ApiError
              ? query.error.message
              : "The API did not respond."
          }
          onRetry={() => void query.refetch()}
        />
      ) : (
        <DataTable
          columns={columns}
          rows={query.data?.items ?? []}
          rowKey={(u) => u.id}
          loading={query.isPending}
          pageSize={15}
          emptyTitle="No accounts"
        />
      )}
    </div>
  );
}
