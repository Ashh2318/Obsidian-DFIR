"use client";

import { useQuery } from "@tanstack/react-query";
import {
  AlertTriangle,
  CheckCircle2,
  Database,
  FolderKanban,
  Server,
  ShieldCheck,
  Sparkles,
  XCircle,
} from "lucide-react";
import * as React from "react";

import { useAuth } from "@/components/providers/auth-provider";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/api-client";
import { analysisApi } from "@/lib/api/analysis";
import { casesApi } from "@/lib/api/cases";
import { relativeTime } from "@/lib/utils";
import { ROLE_LABELS, type AIStatus, type ReadinessResponse } from "@/types/api";

function greeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

/** Cases that still need an analyst's attention. */
const ACTIVE_STATUSES = ["open", "in_progress", "contained"];

function sum(values: Record<string, number> | undefined, keys?: string[]): number {
  if (!values) return 0;
  return Object.entries(values)
    .filter(([key]) => !keys || keys.includes(key))
    .reduce((total, [, count]) => total + count, 0);
}

export default function DashboardPage() {
  const { user } = useAuth();

  const readiness = useQuery({
    queryKey: ["readiness"],
    queryFn: () => apiRequest<ReadinessResponse>("/ready"),
    refetchInterval: 30_000,
  });

  const ai = useQuery({
    queryKey: ["ai-status"],
    queryFn: () => apiRequest<AIStatus>("/ai/status"),
  });

  const caseStats = useQuery({
    queryKey: ["case-statistics"],
    queryFn: () => casesApi.statistics(),
  });

  const evidenceStats = useQuery({
    queryKey: ["evidence-statistics"],
    queryFn: () =>
      apiRequest<{ by_type: Record<string, number>; total_bytes: number }>(
        "/evidence/statistics",
      ),
  });

  const iocStats = useQuery({
    queryKey: ["ioc-statistics"],
    queryFn: () => analysisApi.iocStatistics(),
  });

  const metrics = [
    {
      label: "Active cases",
      value: sum(caseStats.data?.by_status, ACTIVE_STATUSES),
      icon: FolderKanban,
      pending: caseStats.isPending,
    },
    {
      label: "Evidence items",
      value: sum(evidenceStats.data?.by_type),
      icon: Database,
      pending: evidenceStats.isPending,
    },
    {
      label: "High / critical cases",
      value: sum(caseStats.data?.by_severity, ["high", "critical"]),
      icon: AlertTriangle,
      pending: caseStats.isPending,
    },
    {
      label: "IOCs extracted",
      value: iocStats.data?.total ?? 0,
      icon: ShieldCheck,
      pending: iocStats.isPending,
    },
  ];

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <header className="space-y-1">
        <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
          {greeting()}
        </p>
        <h1 className="text-2xl font-semibold tracking-tight">
          {user?.full_name}
        </h1>
        <p className="text-sm text-muted-foreground">
          Signed in as {user ? ROLE_LABELS[user.role] : ""} · Last session{" "}
          {relativeTime(user?.last_login_at)}
        </p>
      </header>

      <section
        className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4"
        aria-label="Investigation metrics"
      >
        {metrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <Card key={metric.label} className="transition-colors hover:border-white/10">
              <CardContent className="pt-5">
                <div className="flex items-start justify-between">
                  <Icon className="size-4 text-muted-foreground" aria-hidden />
                </div>
                <p className="mt-4 font-mono text-3xl font-semibold tabular-nums">
                  {metric.pending ? "–" : metric.value}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">{metric.label}</p>
              </CardContent>
            </Card>
          );
        })}
      </section>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="size-4 text-muted-foreground" aria-hidden />
              Platform health
            </CardTitle>
            <CardDescription>
              Live readiness of every dependency the API needs to serve traffic.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {readiness.isPending ? (
              <>
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
              </>
            ) : readiness.isError ? (
              <div className="flex items-center gap-2.5 rounded-md border border-destructive/30 bg-destructive/10 px-3 py-3 text-xs text-destructive">
                <XCircle className="size-4 shrink-0" aria-hidden />
                <span>
                  The API is unreachable. Start it with{" "}
                  <code className="font-mono">uvicorn obsidian.main:app --reload</code>.
                </span>
              </div>
            ) : (
              readiness.data.components.map((component) => (
                <div
                  key={component.name}
                  className="flex items-center justify-between rounded-md border border-border/60 bg-white/[0.02] px-3 py-2.5"
                >
                  <div className="flex items-center gap-2.5">
                    {component.healthy ? (
                      <CheckCircle2 className="size-4 text-success" aria-hidden />
                    ) : (
                      <XCircle className="size-4 text-destructive" aria-hidden />
                    )}
                    <div>
                      <p className="text-sm capitalize">{component.name}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {component.detail}
                      </p>
                    </div>
                  </div>
                  {component.latency_ms !== null ? (
                    <span className="font-mono text-[11px] tabular-nums text-muted-foreground">
                      {component.latency_ms.toFixed(2)} ms
                    </span>
                  ) : null}
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="size-4 text-muted-foreground" aria-hidden />
              AI provider
            </CardTitle>
            <CardDescription>Configured inference backend.</CardDescription>
          </CardHeader>
          <CardContent>
            {ai.isPending ? (
              <Skeleton className="h-24 w-full" />
            ) : ai.isError ? (
              <p className="text-xs text-muted-foreground">Status unavailable.</p>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm capitalize">{ai.data.provider}</span>
                  <Badge variant={ai.data.available ? "success" : "warning"}>
                    {ai.data.available ? "Available" : "Unavailable"}
                  </Badge>
                </div>
                <p className="font-mono text-xs text-muted-foreground">
                  {ai.data.model}
                </p>
                <p className="text-[11px] leading-relaxed text-muted-foreground">
                  {ai.data.detail}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
