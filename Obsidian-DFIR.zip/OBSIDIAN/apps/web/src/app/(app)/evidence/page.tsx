"use client";

import { useQuery } from "@tanstack/react-query";
import { FolderKanban } from "lucide-react";
import Link from "next/link";
import * as React from "react";

import { SeverityBadge, StatusBadge } from "@/components/cases/case-badges";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { ErrorState } from "@/components/ui/error-state";
import { LoadingState } from "@/components/ui/loading-state";
import { ApiError } from "@/lib/api-client";
import { casesApi } from "@/lib/api/cases";
import { relativeTime } from "@/lib/utils";

/**
 * Evidence is always scoped to a case — chain of custody has no meaning
 * detached from an investigation. This view therefore routes into a case rather
 * than presenting a global, context-free artefact list.
 */
export default function EvidencePage() {
  const query = useQuery({
    queryKey: ["cases", "", "", ""],
    queryFn: () => casesApi.list({ limit: 100 }),
  });

  if (query.isPending) return <LoadingState label="Loading cases" />;

  if (query.isError) {
    return (
      <ErrorState
        title="Could not load cases"
        description={
          query.error instanceof ApiError ? query.error.message : "The API did not respond."
        }
        onRetry={() => void query.refetch()}
      />
    );
  }

  return (
    <div className="mx-auto max-w-4xl space-y-s4">
      <header className="space-y-1">
        <h1 className="text-xl font-semibold tracking-tight">Evidence</h1>
        <p className="text-xs text-muted-foreground">
          Artefacts are held against a case so chain of custody stays intact.
          Choose a case to upload or review its evidence.
        </p>
      </header>

      {query.data.items.length === 0 ? (
        <EmptyState
          icon={FolderKanban}
          title="No cases yet"
          description="Evidence is attached to an investigation. Open a case first."
          action={
            <Button size="sm" asChild>
              <Link href="/cases">Go to cases</Link>
            </Button>
          }
        />
      ) : (
        <ul className="space-y-2">
          {query.data.items.map((record) => (
            <li key={record.id}>
              <Card className="transition-colors duration-fast hover:border-white/10">
                <CardContent className="pt-s4">
                  <Link href={`/cases/${record.id}`} className="flex items-center gap-s3">
                    <div className="min-w-0 flex-1">
                      <p className="font-mono text-2xs text-primary">{record.reference}</p>
                      <p className="truncate text-sm font-medium">{record.title}</p>
                      <p className="mt-0.5 text-2xs text-muted-foreground">
                        Opened {relativeTime(record.created_at)}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <SeverityBadge severity={record.severity} />
                      <StatusBadge status={record.status} />
                    </div>
                  </Link>
                </CardContent>
              </Card>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
