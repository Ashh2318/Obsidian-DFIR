"use client";

import { useQuery } from "@tanstack/react-query";
import { Activity } from "lucide-react";
import * as React from "react";

import { EventStream } from "@/components/timeline/event-stream";
import { Card, CardContent } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { ErrorState } from "@/components/ui/error-state";
import { LoadingState } from "@/components/ui/loading-state";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ApiError } from "@/lib/api-client";
import { timelineApi } from "@/lib/api/timeline";
import { SEVERITY_LABELS, type Severity, type TimelineSource } from "@/types/api";

const ALL = "all";

export default function TimelinePage() {
  const [source, setSource] = React.useState<TimelineSource | typeof ALL>(ALL);
  const [minSeverity, setMinSeverity] = React.useState<Severity | typeof ALL>(ALL);

  const query = useQuery({
    queryKey: ["timeline", source, minSeverity],
    queryFn: () =>
      timelineApi.recent({
        source: source === ALL ? "" : source,
        min_severity: minSeverity === ALL ? "" : minSeverity,
        limit: 200,
      }),
  });

  return (
    <div className="mx-auto max-w-4xl space-y-s4">
      <header className="space-y-1">
        <h1 className="text-xl font-semibold tracking-tight">Timeline</h1>
        <p className="text-xs text-muted-foreground">
          Activity across every case. Open a case for its full forensic timeline,
          which also places incident events at the time they occurred.
        </p>
      </header>

      <div className="flex flex-wrap items-center gap-s2">
        <Select value={source} onValueChange={(v) => setSource(v as TimelineSource)}>
          <SelectTrigger className="h-9 w-44">
            <SelectValue placeholder="Source" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>All sources</SelectItem>
            <SelectItem value="investigation">Investigation</SelectItem>
            <SelectItem value="incident">Incident</SelectItem>
          </SelectContent>
        </Select>
        <Select value={minSeverity} onValueChange={(v) => setMinSeverity(v as Severity)}>
          <SelectTrigger className="h-9 w-44">
            <SelectValue placeholder="Minimum severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>Any severity</SelectItem>
            {(Object.keys(SEVERITY_LABELS) as Severity[]).map((s) => (
              <SelectItem key={s} value={s}>
                {SEVERITY_LABELS[s]} and above
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {query.data ? (
          <span className="ml-auto text-2xs text-muted-foreground">
            {query.data.total} event(s) · {query.data.incident_events} incident ·{" "}
            {query.data.investigation_events} investigation
          </span>
        ) : null}
      </div>

      {query.isPending ? (
        <LoadingState label="Loading timeline" />
      ) : query.isError ? (
        <ErrorState
          title="Could not load the timeline"
          description={
            query.error instanceof ApiError ? query.error.message : "The API did not respond."
          }
          onRetry={() => void query.refetch()}
        />
      ) : query.data.events.length === 0 ? (
        <EmptyState
          icon={Activity}
          title="No activity yet"
          description="Open a case and ingest evidence; activity will appear here."
        />
      ) : (
        <Card>
          <CardContent className="pt-s4">
            <EventStream events={query.data.events} showCase />
          </CardContent>
        </Card>
      )}
    </div>
  );
}
