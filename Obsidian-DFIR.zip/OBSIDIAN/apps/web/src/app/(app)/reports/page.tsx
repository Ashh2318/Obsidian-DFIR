"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, FileText, ShieldCheck, Trash2 } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DataTable, type DataTableColumn } from "@/components/ui/data-table";
import { EmptyState } from "@/components/ui/empty-state";
import { ErrorState } from "@/components/ui/error-state";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useDownload } from "@/hooks/use-download";
import { ApiError } from "@/lib/api-client";
import { reportsApi } from "@/lib/api/reports";
import { formatBytes, relativeTime, shortHash } from "@/lib/utils";
import {
  REPORT_FORMAT_LABELS,
  REPORT_PROFILE_LABELS,
  type Report,
  type ReportProfile,
} from "@/types/api";

const ALL = "all";

export default function ReportsPage() {
  const queryClient = useQueryClient();
  const [profile, setProfile] = React.useState<ReportProfile | typeof ALL>(ALL);

  const { download: runDownload } = useDownload();
  const download = (report: Report) =>
    runDownload(report.id, report.title, () => reportsApi.download(report));

  const query = useQuery({
    queryKey: ["reports", profile],
    queryFn: () =>
      reportsApi.list({ profile: profile === ALL ? "" : profile, limit: 100 }),
  });

  const verify = useMutation({
    mutationFn: (id: string) => reportsApi.verify(id),
    onSuccess: (result) =>
      result.valid
        ? toast.success("Integrity verified", { description: result.detail })
        : toast.error("Integrity check FAILED", { description: result.detail }),
    onError: (error) =>
      toast.error("Verification failed", {
        description: error instanceof ApiError ? error.message : "Request failed.",
      }),
  });

  const remove = useMutation({
    mutationFn: (id: string) => reportsApi.remove(id),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["reports"] });
      toast.success("Report deleted");
    },
  });

  const columns: DataTableColumn<Report>[] = [
    {
      key: "title",
      header: "Report",
      sortable: true,
      cell: (r) => (
        <div className="min-w-0">
          <p className="truncate text-xs font-medium">{r.title}</p>
          <p className="truncate font-mono text-2xs text-muted-foreground">
            sig {shortHash(r.signature, 16)}
          </p>
        </div>
      ),
    },
    {
      key: "profile",
      header: "Profile",
      sortable: true,
      cell: (r) => (
        <Badge variant={r.profile === "executive" ? "accent" : "primary"}>
          {REPORT_PROFILE_LABELS[r.profile]}
        </Badge>
      ),
    },
    {
      key: "format",
      header: "Format",
      sortable: true,
      cell: (r) => <Badge variant="neutral">{REPORT_FORMAT_LABELS[r.format]}</Badge>,
    },
    {
      key: "size_bytes",
      header: "Size",
      sortable: true,
      sortValue: (r) => r.size_bytes,
      cell: (r) => (
        <span className="font-mono text-2xs tabular-nums">{formatBytes(r.size_bytes)}</span>
      ),
    },
    {
      key: "created_at",
      header: "Generated",
      sortable: true,
      cell: (r) => (
        <span className="whitespace-nowrap text-2xs text-muted-foreground">
          {relativeTime(r.created_at)}
        </span>
      ),
    },
    {
      key: "actions",
      header: "",
      cell: (r) => (
        <div className="flex justify-end gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => verify.mutate(r.id)}
            aria-label={`Verify ${r.title}`}
            title="Verify integrity"
          >
            <ShieldCheck />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => download(r)}
            aria-label={`Download ${r.title}`}
            title="Download"
          >
            <Download />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => remove.mutate(r.id)}
            aria-label={`Delete ${r.title}`}
          >
            <Trash2 />
          </Button>
        </div>
      ),
      className: "text-right",
    },
  ];

  return (
    <div className="mx-auto max-w-6xl space-y-s4">
      <header className="space-y-1">
        <h1 className="text-xl font-semibold tracking-tight">Reports</h1>
        <p className="text-xs text-muted-foreground">
          Generated from a case at a point in time. Stored bytes are signed with
          HMAC-SHA256, so any later alteration is detectable. Generate reports
          from the Reports tab on a case.
        </p>
      </header>

      <div className="flex flex-wrap items-center gap-s2">
        <Select value={profile} onValueChange={(v) => setProfile(v as ReportProfile)}>
          <SelectTrigger className="h-9 w-44">
            <SelectValue placeholder="Profile" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>All profiles</SelectItem>
            <SelectItem value="executive">Executive</SelectItem>
            <SelectItem value="technical">Technical</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {query.isError ? (
        <ErrorState
          title="Could not load reports"
          description={
            query.error instanceof ApiError ? query.error.message : "The API did not respond."
          }
          onRetry={() => void query.refetch()}
        />
      ) : (query.data?.items.length ?? 0) === 0 && !query.isPending ? (
        <EmptyState
          icon={FileText}
          title="No reports yet"
          description="Open a case and generate an executive or technical report from its Reports tab."
        />
      ) : (
        <DataTable
          columns={columns}
          rows={query.data?.items ?? []}
          rowKey={(r) => r.id}
          loading={query.isPending}
          pageSize={15}
          emptyTitle="No reports"
        />
      )}
    </div>
  );
}
