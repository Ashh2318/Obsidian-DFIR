"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Activity, FileSearch, ShieldAlert, Trash2, Upload } from "lucide-react";
import * as React from "react";
import { useForm } from "react-hook-form";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { toast } from "sonner";
import { z } from "zod";

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  CHART_AXIS_PROPS,
  CHART_COLORS,
  CHART_GRID_PROPS,
  ChartContainer,
  ChartTooltip,
} from "@/components/ui/chart";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTable, type DataTableColumn } from "@/components/ui/data-table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { ErrorState } from "@/components/ui/error-state";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LoadingState } from "@/components/ui/loading-state";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tag } from "@/components/ui/tag";
import { Textarea } from "@/components/ui/textarea";
import { Timeline } from "@/components/ui/timeline";

/**
 * Living component gallery.
 *
 * Every primitive is rendered here, which makes this the fastest way to review
 * the design system visually and the reason a broken component fails the build
 * instead of surfacing in a feature months later.
 */

function Section({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">{children}</CardContent>
    </Card>
  );
}

const demoSchema = z.object({
  caseTitle: z.string().min(4, "Give the case a name of at least 4 characters."),
  severity: z.string().min(1, "Select a severity."),
  notes: z.string().max(280, "Keep notes under 280 characters.").optional(),
});

interface DemoRow {
  id: string;
  host: string;
  severity: string;
  events: number;
}

const DEMO_ROWS: DemoRow[] = [
  { id: "1", host: "WKSTN-4471", severity: "Critical", events: 812 },
  { id: "2", host: "SRV-DC-02", severity: "High", events: 344 },
  { id: "3", host: "WKSTN-1180", severity: "Medium", events: 96 },
  { id: "4", host: "SRV-FILE-01", severity: "Low", events: 21 },
];

const SEVERITY_DATA = [
  { name: "Info", count: 42 },
  { name: "Low", count: 28 },
  { name: "Medium", count: 17 },
  { name: "High", count: 9 },
  { name: "Critical", count: 3 },
];

export default function DesignSystemPage() {
  const [tags, setTags] = React.useState(["185.243.115.84", "evil-domain.tld", "a4f9c2e1"]);
  const [progress, setProgress] = React.useState(38);

  const form = useForm<z.infer<typeof demoSchema>>({
    resolver: zodResolver(demoSchema),
    defaultValues: { caseTitle: "", severity: "", notes: "" },
  });

  const columns: DataTableColumn<DemoRow>[] = [
    { key: "host", header: "Host", cell: (r) => <span className="font-mono">{r.host}</span>, sortable: true },
    {
      key: "severity",
      header: "Severity",
      sortable: true,
      cell: (r) => (
        <Badge
          variant={
            r.severity === "Critical" ? "destructive" : r.severity === "High" ? "warning" : "neutral"
          }
        >
          {r.severity}
        </Badge>
      ),
    },
    {
      key: "events",
      header: "Events",
      sortable: true,
      sortValue: (r) => r.events,
      cell: (r) => <span className="font-mono tabular-nums">{r.events}</span>,
      className: "text-right",
      headerClassName: "text-right",
    },
  ];

  return (
    <div className="mx-auto max-w-5xl space-y-6 pb-12">
      <header className="space-y-1">
        <h1 className="text-2xl font-semibold tracking-tight">Design system</h1>
        <p className="text-sm text-muted-foreground">
          Every primitive in the OBSIDIAN component library, rendered live.
        </p>
      </header>

      <Section title="Buttons" description="Variants, sizes and states.">
        <div className="flex flex-wrap items-center gap-2">
          <Button>Primary</Button>
          <Button variant="secondary">Secondary</Button>
          <Button variant="outline">Outline</Button>
          <Button variant="ghost">Ghost</Button>
          <Button variant="destructive">Destructive</Button>
          <Button variant="link">Link</Button>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button size="sm">Small</Button>
          <Button size="md">Medium</Button>
          <Button size="lg">Large</Button>
          <Button size="icon" aria-label="Upload"><Upload /></Button>
          <Button loading>Loading</Button>
          <Button disabled>Disabled</Button>
        </div>
      </Section>

      <Section title="Feedback" description="Inline alerts and toast notifications.">
        <Alert variant="info"><AlertTitle>Analysis queued</AlertTitle><AlertDescription>Three evidence items are waiting for a worker.</AlertDescription></Alert>
        <Alert variant="success">Chain of custody verified for all uploaded artefacts.</Alert>
        <Alert variant="warning">The configured AI provider is unreachable; falling back to offline mode.</Alert>
        <Alert variant="destructive">Refresh token reuse detected. All sessions were revoked.</Alert>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="secondary" onClick={() => toast.success("Evidence uploaded", { description: "capture.pcap — 41.2 MB" })}>Success toast</Button>
          <Button size="sm" variant="secondary" onClick={() => toast.error("Upload failed", { description: "The file exceeds the 512 MB limit." })}>Error toast</Button>
        </div>
      </Section>

      <Section title="Form controls" description="Inputs bound to React Hook Form and validated with Zod.">
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit((values) =>
              toast.success("Validated", { description: JSON.stringify(values) }),
            )}
            className="space-y-4"
          >
            <FormField
              control={form.control}
              name="caseTitle"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Case title</FormLabel>
                  <FormControl><Input placeholder="Suspected exfiltration, finance VLAN" {...field} /></FormControl>
                  <FormDescription>Shown in the case list and on generated reports.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="severity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Severity</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger><SelectValue placeholder="Select severity" /></SelectTrigger></FormControl>
                    <SelectContent>
                      {["Info", "Low", "Medium", "High", "Critical"].map((s) => (
                        <SelectItem key={s} value={s.toLowerCase()}>{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Initial notes</FormLabel>
                  <FormControl><Textarea placeholder="First observations..." {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" size="sm">Validate</Button>
          </form>
        </Form>

        <Separator />

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Checkbox id="ds-check" defaultChecked />
              <Label htmlFor="ds-check">Preserve original timestamps</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch id="ds-switch" defaultChecked />
              <Label htmlFor="ds-switch">Enable automatic IOC extraction</Label>
            </div>
          </div>
          <RadioGroup defaultValue="sha256">
            {["sha256", "md5"].map((v) => (
              <div key={v} className="flex items-center gap-2">
                <RadioGroupItem value={v} id={`ds-${v}`} />
                <Label htmlFor={`ds-${v}`} className="font-mono text-xs">{v}</Label>
              </div>
            ))}
          </RadioGroup>
        </div>
      </Section>

      <Section title="Data display" description="Sortable, paginated table with typed columns.">
        <DataTable columns={columns} rows={DEMO_ROWS} rowKey={(r) => r.id} pageSize={3} />
      </Section>

      <Section title="Charts" description="Recharts wrapper using the OBSIDIAN palette.">
        <ChartContainer height={220}>
          <BarChart data={SEVERITY_DATA}>
            <CartesianGrid {...CHART_GRID_PROPS} />
            <XAxis dataKey="name" {...CHART_AXIS_PROPS} />
            <YAxis {...CHART_AXIS_PROPS} />
            <ChartTooltip />
            <Bar dataKey="count" fill={CHART_COLORS.primary} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ChartContainer>
      </Section>

      <Section title="Timeline" description="Chronological event rail.">
        <Timeline
          items={[
            { id: "1", title: "Evidence uploaded", description: "capture.pcap — 41.2 MB", timestamp: "14:02", icon: Upload, tone: "primary" },
            { id: "2", title: "Analysis started", description: "Protocol breakdown and conversation extraction", timestamp: "14:03", icon: Activity },
            { id: "3", title: "Suspicious beaconing detected", description: "3 internal hosts contacting 185.243.115.84 at 60s intervals", timestamp: "14:07", icon: ShieldAlert, tone: "destructive" },
            { id: "4", title: "Report generated", timestamp: "14:12", icon: FileSearch, tone: "success" },
          ]}
        />
      </Section>

      <Section title="Tags and badges" description="Dismissible values versus inert status.">
        <div className="flex flex-wrap gap-2">
          {tags.map((t) => (
            <Tag key={t} onRemove={() => setTags((cur) => cur.filter((x) => x !== t))}>{t}</Tag>
          ))}
          {tags.length === 0 ? <span className="text-xs text-muted-foreground">All tags removed.</span> : null}
        </div>
        <div className="flex flex-wrap gap-2">
          {(["neutral", "primary", "accent", "success", "warning", "destructive"] as const).map((v) => (
            <Badge key={v} variant={v}>{v}</Badge>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <Avatar><AvatarFallback>SR</AvatarFallback></Avatar>
          <span className="text-xs text-muted-foreground">Avatar with initials fallback</span>
        </div>
      </Section>

      <Section title="Disclosure" description="Tabs, accordion, dialog and sheet.">
        <Tabs defaultValue="overview">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="artefacts">Artefacts</TabsTrigger>
            <TabsTrigger value="iocs">IOCs</TabsTrigger>
          </TabsList>
          <TabsContent value="overview"><p className="text-sm text-muted-foreground">Case summary and assessed severity.</p></TabsContent>
          <TabsContent value="artefacts"><p className="text-sm text-muted-foreground">Uploaded evidence with custody hashes.</p></TabsContent>
          <TabsContent value="iocs"><p className="text-sm text-muted-foreground">Extracted indicators, enriched and deduplicated.</p></TabsContent>
        </Tabs>

        <Accordion type="single" collapsible>
          <AccordionItem value="a"><AccordionTrigger>What is chain of custody?</AccordionTrigger><AccordionContent>Both SHA-256 and MD5 are recorded at ingest. SHA-256 is the integrity anchor; MD5 exists only because threat-intel feeds are still keyed on it.</AccordionContent></AccordionItem>
          <AccordionItem value="b"><AccordionTrigger>Which providers are supported?</AccordionTrigger><AccordionContent>Claude, OpenAI and Ollama, behind one protocol. A deterministic mock provider ships for offline work.</AccordionContent></AccordionItem>
        </Accordion>

        <div className="flex flex-wrap gap-2">
          <Dialog>
            <DialogTrigger asChild><Button variant="secondary" size="sm">Open dialog</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Delete evidence?</DialogTitle>
                <DialogDescription>This breaks the chain of custody for this artefact and cannot be undone.</DialogDescription>
              </DialogHeader>
              <DialogFooter><Button variant="destructive" size="sm"><Trash2 />Delete</Button></DialogFooter>
            </DialogContent>
          </Dialog>

          <Sheet>
            <SheetTrigger asChild><Button variant="secondary" size="sm">Open sheet</Button></SheetTrigger>
            <SheetContent>
              <SheetHeader>
                <SheetTitle>Evidence details</SheetTitle>
                <SheetDescription>Metadata and custody hashes for the selected artefact.</SheetDescription>
              </SheetHeader>
              <p className="text-sm text-muted-foreground">Side panels use the same focus trapping and scroll locking as modal dialogs.</p>
            </SheetContent>
          </Sheet>
        </div>
      </Section>

      <Section title="Progress and loading" description="Determinate, indeterminate and skeleton.">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Analysing capture.pcap</span><span className="font-mono tabular-nums">{progress}%</span>
          </div>
          <Progress value={progress} />
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => setProgress((p) => Math.max(0, p - 10))}>-10</Button>
            <Button size="sm" variant="outline" onClick={() => setProgress((p) => Math.min(100, p + 10))}>+10</Button>
          </div>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground">Indeterminate</p>
          <Progress value={null} />
        </div>
        <div className="space-y-2">
          <Skeleton className="h-4 w-2/3" />
          <Skeleton className="h-4 w-1/2" />
        </div>
        <LoadingState label="Restoring session" />
      </Section>

      <Section title="States" description="Empty and error states.">
        <EmptyState
          icon={FileSearch}
          title="No evidence yet"
          description="Upload a packet capture, event log or document to begin the investigation."
          action={<Button size="sm"><Upload />Upload evidence</Button>}
        />
        <ErrorState
          requestId="ea768484-c2a5-4a6e-b0a0-5d96d2926b7e"
          onRetry={() => toast.info("Retrying...")}
        />
      </Section>
    </div>
  );
}
