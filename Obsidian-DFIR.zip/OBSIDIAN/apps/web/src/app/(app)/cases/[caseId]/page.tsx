"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, FileSearch, Trash2 } from "lucide-react";
import { useParams } from "next/navigation";
import * as React from "react";
import { toast } from "sonner";

import { SeverityBadge, StatusBadge } from "@/components/cases/case-badges";
import { AnalysisPanel } from "@/components/analysis/analysis-panel";
import { CaseReports } from "@/components/reports/case-reports";
import { EventStream } from "@/components/timeline/event-stream";
import { EvidenceUploader } from "@/components/evidence/evidence-uploader";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DataTable, type DataTableColumn } from "@/components/ui/data-table";
import { ErrorState } from "@/components/ui/error-state";
import { LoadingState } from "@/components/ui/loading-state";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useDownload } from "@/hooks/use-download";
import { ApiError } from "@/lib/api-client";
import { casesApi } from "@/lib/api/cases";
import { timelineApi } from "@/lib/api/timeline";
import { formatBytes, formatDate, shortHash } from "@/lib/utils";
import {
  ALLOWED_TRANSITIONS,
  CASE_STATUS_LABELS,
  EVIDENCE_TYPE_LABELS,
  type CaseStatus,
  type Evidence,
} from "@/types/api";

export default function CaseDetailPage() {
  const params = useParams<{ caseId: string }>();
  const caseId = params.caseId;
  const queryClient = useQueryClient();

  // Voice sends the analyst here with ?upload=1 after "upload evidence".
  //
  // Read from location rather than useSearchParams: that hook forces every
  // client page using it into a Suspense boundary at prerender time, and this
  // flag is only meaningful after mount anyway.
  const [wantsUpload, setWantsUpload] = React.useState(false);
  React.useEffect(() => {
    setWantsUpload(new URLSearchParams(window.location.search).get("upload") === "1");
  }, []);

  const { download: runDownload } = useDownload();
  const downloadEvidence = (evidence: Evidence) =>
    runDownload(evidence.id, evidence.original_filename, () =>
      casesApi.downloadEvidence(evidence.id, evidence.original_filename),
    );

  const caseQuery = useQuery({
    queryKey: ["case", caseId],
    queryFn: () => casesApi.get(caseId),
    enabled: Boolean(caseId),
  });

  const timelineQuery = useQuery({
    queryKey: ["timeline", caseId],
    queryFn: () => timelineApi.forCase(caseId),
    enabled: Boolean(caseId),
  });

  const evidenceQuery = useQuery({
    queryKey: ["evidence", caseId],
    queryFn: () => casesApi.listEvidence(caseId),
    enabled: Boolean(caseId),
  });

  const statusMutation = useMutation({
    mutationFn: (status: CaseStatus) => casesApi.changeStatus(caseId, status),
    onSuccess: (updated) => {
      queryClient.setQueryData(["case", caseId], updated);
      void queryClient.invalidateQueries({ queryKey: ["cases"] });
      void queryClient.invalidateQueries({ queryKey: ["case-statistics"] });
      toast.success("Status updated", {
        description: CASE_STATUS_LABELS[updated.status],
      });
    },
    onError: (error) =>
      toast.error("Could not change status", {
        description: error instanceof ApiError ? error.message : "Request failed.",
      }),
  });

  const deleteMutation = useMutation({
    mutationFn: (evidenceId: string) => casesApi.deleteEvidence(evidenceId),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["evidence", caseId] });
      toast.success("Evidence removed");
    },
  });

  if (caseQuery.isPending) return <LoadingState label="Loading case" />;

  if (caseQuery.isError) {
    return (
      <ErrorState
        title="Could not load this case"
        description={
          caseQuery.error instanceof ApiError
            ? caseQuery.error.message
            : "The API did not respond."
        }
        onRetry={() => void caseQuery.refetch()}
      />
    );
  }

  const record = caseQuery.data;
  // Offered transitions come from the shared table; the server re-validates.
  const nextStates = ALLOWED_TRANSITIONS[record.status];

  const columns: DataTableColumn<Evidence>[] = [
    {
      key: "original_filename",
      header: "Artefact",
      sortable: true,
      cell: (e) => (
        <div className="min-w-0">
          <p className="truncate text-xs font-medium">{e.original_filename}</p>
          <p className="truncate font-mono text-2xs text-muted-foreground">
            sha256 {shortHash(e.sha256, 16)}
          </p>
        </div>
      ),
    },
    {
      key: "evidence_type",
      header: "Type",
      sortable: true,
      cell: (e) => <Badge variant="neutral">{EVIDENCE_TYPE_LABELS[e.evidence_type]}</Badge>,
    },
    {
      key: "size_bytes",
      header: "Size",
      sortable: true,
      sortValue: (e) => e.size_bytes,
      cell: (e) => (
        <span className="font-mono text-2xs tabular-nums">{formatBytes(e.size_bytes)}</span>
      ),
    },
    {
      key: "created_at",
      header: "Ingested",
      sortable: true,
      cell: (e) => (
        <span className="whitespace-nowrap text-2xs text-muted-foreground">
          {formatDate(e.created_at)}
        </span>
      ),
    },
    {
      key: "actions",
      header: "",
      cell: (e) => (
        <div className="flex justify-end gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => downloadEvidence(e)}
            aria-label={`Download ${e.original_filename}`}
            title="Download"
          >
            <Download />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label={`Remove ${e.original_filename}`}
            onClick={() => deleteMutation.mutate(e.id)}
          >
            <Trash2 />
          </Button>
        </div>
      ),
      className: "text-right",
    },
  ];

  return (
    <div className="mx-auto max-w-6xl space-y-s4">
      <header className="space-y-s3">
        <div className="flex flex-wrap items-start justify-between gap-s3">
          <div className="min-w-0 space-y-1.5">
            <p className="font-mono text-xs text-primary">{record.reference}</p>
            <h1 className="text-xl font-semibold tracking-tight">{record.title}</h1>
            <div className="flex flex-wrap items-center gap-2">
              <StatusBadge status={record.status} />
              <SeverityBadge severity={record.severity} />
              <span className="text-2xs text-muted-foreground">
                Opened {formatDate(record.opened_at ?? record.created_at)}
              </span>
              {record.closed_at ? (
                <span className="text-2xs text-muted-foreground">
                  · Closed {formatDate(record.closed_at)}
                </span>
              ) : null}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {nextStates.length > 0 ? (
              <Select
                value=""
                onValueChange={(value) => statusMutation.mutate(value as CaseStatus)}
              >
                <SelectTrigger className="h-9 w-44">
                  <SelectValue placeholder="Move to..." />
                </SelectTrigger>
                <SelectContent>
                  {nextStates.map((s) => (
                    <SelectItem key={s} value={s}>
                      {CASE_STATUS_LABELS[s]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Badge variant="neutral">Archived — no further transitions</Badge>
            )}
          </div>
        </div>

        {record.summary ? (
          <p className="max-w-3xl text-sm leading-relaxed text-muted-foreground">
            {record.summary}
          </p>
        ) : null}
      </header>

      <Separator />

      <Tabs defaultValue="evidence">
        <TabsList>
          <TabsTrigger value="evidence">
            Evidence
            {evidenceQuery.data ? (
              <Badge variant="neutral" className="ml-1.5 px-1.5 py-0 text-2xs">
                {evidenceQuery.data.total}
              </Badge>
            ) : null}
          </TabsTrigger>
          <TabsTrigger value="timeline">
            Timeline
            {timelineQuery.data ? (
              <Badge variant="neutral" className="ml-1.5 px-1.5 py-0 text-2xs">
                {timelineQuery.data.total}
              </Badge>
            ) : null}
          </TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="overview">Overview</TabsTrigger>
        </TabsList>

        <TabsContent value="evidence" className="space-y-s4">
          <EvidenceUploader caseId={caseId} autoOpen={wantsUpload} />
          {evidenceQuery.isError ? (
            <ErrorState
              title="Could not load evidence"
              onRetry={() => void evidenceQuery.refetch()}
            />
          ) : (
            <>
              <DataTable
                columns={columns}
                rows={evidenceQuery.data?.items ?? []}
                rowKey={(e) => e.id}
                loading={evidenceQuery.isPending}
                pageSize={10}
                emptyTitle="No evidence yet"
                emptyDescription="Upload a capture, event log or document to begin."
              />

              {(evidenceQuery.data?.items ?? []).map((item) => (
                <Card key={item.id}>
                  <CardHeader className="pb-s2">
                    <CardTitle className="flex items-center gap-2">
                      <span className="truncate">{item.original_filename}</span>
                      <Badge variant="neutral">
                        {EVIDENCE_TYPE_LABELS[item.evidence_type]}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <AnalysisPanel evidence={item} caseId={caseId} />
                  </CardContent>
                </Card>
              ))}
            </>
          )}
        </TabsContent>

        <TabsContent value="timeline">
          {timelineQuery.isPending ? (
            <LoadingState label="Building timeline" />
          ) : timelineQuery.isError ? (
            <ErrorState
              title="Could not build the timeline"
              onRetry={() => void timelineQuery.refetch()}
            />
          ) : (
            <Card>
              <CardContent className="pt-s4">
                <p className="mb-s3 text-2xs leading-relaxed text-muted-foreground">
                  Incident events are placed at the time the evidence records them
                  occurring, which is rarely when the artefact was uploaded.
                  Investigation events are placed at the time the team acted.
                </p>
                <EventStream events={timelineQuery.data.events} />
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="reports">
          <Card>
            <CardContent className="pt-s4">
              <CaseReports caseId={caseId} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSearch className="size-4 text-muted-foreground" aria-hidden />
                Case detail
              </CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="divide-y divide-border/60 text-sm">
                {[
                  ["Reference", record.reference],
                  ["Status", CASE_STATUS_LABELS[record.status]],
                  ["Severity", record.severity],
                  ["Opened", formatDate(record.opened_at ?? record.created_at)],
                  ["Last updated", formatDate(record.updated_at)],
                  ["Evidence items", String(evidenceQuery.data?.total ?? 0)],
                ].map(([label, value]) => (
                  <div key={label} className="flex items-center justify-between py-2">
                    <dt className="text-2xs text-muted-foreground">{label}</dt>
                    <dd className="text-xs capitalize">{value}</dd>
                  </div>
                ))}
              </dl>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
