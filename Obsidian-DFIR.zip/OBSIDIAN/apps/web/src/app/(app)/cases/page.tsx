"use client";

import { useQuery } from "@tanstack/react-query";
import { FolderKanban } from "lucide-react";
import { useRouter } from "next/navigation";
import * as React from "react";

import { CreateCaseDialog } from "@/components/cases/create-case-dialog";
import { SeverityBadge, StatusBadge } from "@/components/cases/case-badges";
import { DataTable, type DataTableColumn } from "@/components/ui/data-table";
import { ErrorState } from "@/components/ui/error-state";
import { SearchInput } from "@/components/ui/search-input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { casesApi } from "@/lib/api/cases";
import { ApiError } from "@/lib/api-client";
import { relativeTime } from "@/lib/utils";
import {
  CASE_STATUS_LABELS,
  SEVERITY_LABELS,
  type Case,
  type CaseStatus,
  type Severity,
} from "@/types/api";

const ALL = "all";

export default function CasesPage() {
  const router = useRouter();
  const [search, setSearch] = React.useState("");
  const [status, setStatus] = React.useState<CaseStatus | typeof ALL>(ALL);
  const [severity, setSeverity] = React.useState<Severity | typeof ALL>(ALL);

  // Debounced so each keystroke does not become a request.
  const [debounced, setDebounced] = React.useState("");
  React.useEffect(() => {
    const timer = setTimeout(() => setDebounced(search), 300);
    return () => clearTimeout(timer);
  }, [search]);

  const query = useQuery({
    queryKey: ["cases", debounced, status, severity],
    queryFn: () =>
      casesApi.list({
        q: debounced || undefined,
        status: status === ALL ? "" : status,
        severity: severity === ALL ? "" : severity,
        limit: 100,
      }),
  });

  const columns: DataTableColumn<Case>[] = [
    {
      key: "reference",
      header: "Reference",
      sortable: true,
      cell: (c) => <span className="font-mono text-xs text-primary">{c.reference}</span>,
    },
    {
      key: "title",
      header: "Title",
      sortable: true,
      cell: (c) => (
        <div className="min-w-0">
          <p className="truncate font-medium">{c.title}</p>
          {c.summary ? (
            <p className="truncate text-2xs text-muted-foreground">{c.summary}</p>
          ) : null}
        </div>
      ),
    },
    {
      key: "severity",
      header: "Severity",
      sortable: true,
      cell: (c) => <SeverityBadge severity={c.severity} />,
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      cell: (c) => <StatusBadge status={c.status} />,
    },
    {
      key: "created_at",
      header: "Opened",
      sortable: true,
      cell: (c) => (
        <span className="whitespace-nowrap text-2xs text-muted-foreground">
          {relativeTime(c.created_at)}
        </span>
      ),
      className: "text-right",
      headerClassName: "text-right",
    },
  ];

  return (
    <div className="mx-auto max-w-6xl space-y-s4">
      <header className="flex flex-wrap items-start justify-between gap-s3">
        <div className="space-y-1">
          <h1 className="text-xl font-semibold tracking-tight">Cases</h1>
          <p className="text-xs text-muted-foreground">
            {query.data ? `${query.data.total} case(s)` : "Investigation queue"}
          </p>
        </div>
        <CreateCaseDialog />
      </header>

      <div className="flex flex-wrap items-center gap-s2">
        <SearchInput
          value={search}
          onValueChange={setSearch}
          placeholder="Search title, reference or summary..."
          containerClassName="w-full sm:w-72"
        />
        <Select value={status} onValueChange={(v) => setStatus(v as CaseStatus)}>
          <SelectTrigger className="h-9 w-40">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>All statuses</SelectItem>
            {(Object.keys(CASE_STATUS_LABELS) as CaseStatus[]).map((s) => (
              <SelectItem key={s} value={s}>
                {CASE_STATUS_LABELS[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={severity} onValueChange={(v) => setSeverity(v as Severity)}>
          <SelectTrigger className="h-9 w-40">
            <SelectValue placeholder="Severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>All severities</SelectItem>
            {(Object.keys(SEVERITY_LABELS) as Severity[]).map((s) => (
              <SelectItem key={s} value={s}>
                {SEVERITY_LABELS[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {query.isError ? (
        <ErrorState
          title="Could not load cases"
          description={
            query.error instanceof ApiError
              ? query.error.message
              : "The API did not respond. Check that the backend is running."
          }
          requestId={query.error instanceof ApiError ? query.error.requestId : undefined}
          onRetry={() => void query.refetch()}
        />
      ) : (
        <DataTable
          columns={columns}
          rows={query.data?.items ?? []}
          rowKey={(c) => c.id}
          loading={query.isPending}
          pageSize={12}
          onRowClick={(c) => router.push(`/cases/${c.id}`)}
          emptyTitle={debounced || status !== ALL ? "No matching cases" : "No cases yet"}
          emptyDescription={
            debounced || status !== ALL
              ? "Adjust the filters to widen the search."
              : "Open a case to begin collecting and analysing evidence."
          }
        />
      )}

      {!query.isError && !query.isPending && (query.data?.items.length ?? 0) === 0 ? (
        <div className="flex justify-center">
          <FolderKanban className="sr-only" aria-hidden />
        </div>
      ) : null}
    </div>
  );
}
