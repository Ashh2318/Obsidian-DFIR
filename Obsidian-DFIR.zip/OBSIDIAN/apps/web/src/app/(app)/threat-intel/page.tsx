"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { RefreshCw, ShieldQuestion } from "lucide-react";
import * as React from "react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DataTable, type DataTableColumn } from "@/components/ui/data-table";
import { EmptyState } from "@/components/ui/empty-state";
import { ErrorState } from "@/components/ui/error-state";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ApiError } from "@/lib/api-client";
import { threatIntelApi } from "@/lib/api/threat-intel";
import { relativeTime } from "@/lib/utils";
import {
  IOC_TYPE_LABELS,
  VERDICT_LABELS,
  VERDICT_TONES,
  type Enrichment,
  type ThreatVerdict,
} from "@/types/api";

const ALL = "all";

export default function ThreatIntelPage() {
  const queryClient = useQueryClient();
  const [verdict, setVerdict] = React.useState<ThreatVerdict | typeof ALL>(ALL);

  const status = useQuery({
    queryKey: ["threat-intel-status"],
    queryFn: () => threatIntelApi.status(),
  });

  const enrichments = useQuery({
    queryKey: ["enrichments", verdict],
    queryFn: () =>
      threatIntelApi.listEnrichments({
        verdict: verdict === ALL ? "" : verdict,
        limit: 200,
      }),
  });

  const refresh = useMutation({
    mutationFn: (id: string) => threatIntelApi.enrichIoc(id, true),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["enrichments"] });
      toast.success("Reputation refreshed");
    },
    onError: (error) =>
      toast.error("Refresh failed", {
        description: error instanceof ApiError ? error.message : "Request failed.",
      }),
  });

  const columns: DataTableColumn<Enrichment>[] = [
    {
      key: "value",
      header: "Indicator",
      sortable: true,
      cell: (e) => <span className="truncate font-mono text-xs">{e.value}</span>,
    },
    {
      key: "ioc_type",
      header: "Type",
      sortable: true,
      cell: (e) => <Badge variant="neutral">{IOC_TYPE_LABELS[e.ioc_type]}</Badge>,
    },
    {
      key: "verdict",
      header: "Verdict",
      sortable: true,
      cell: (e) => (
        <Badge variant={VERDICT_TONES[e.verdict]}>{VERDICT_LABELS[e.verdict]}</Badge>
      ),
    },
    {
      key: "score",
      header: "Score",
      sortable: true,
      sortValue: (e) => e.score,
      cell: (e) => (
        <span className="font-mono text-2xs tabular-nums">{e.score}</span>
      ),
    },
    {
      key: "providers",
      header: "Sources",
      cell: (e) => (
        <div className="flex flex-wrap gap-1">
          {Object.values(e.providers ?? {}).map((opinion) => (
            <span
              key={opinion.provider}
              title={opinion.error ?? opinion.detail}
              className={
                opinion.error
                  ? "rounded-xs border border-border/70 px-1 py-px text-2xs text-muted-foreground/60 line-through"
                  : "rounded-xs border border-border/70 px-1 py-px text-2xs text-muted-foreground"
              }
            >
              {opinion.provider}
            </span>
          ))}
        </div>
      ),
    },
    {
      key: "fetched_at",
      header: "Checked",
      sortable: true,
      cell: (e) => (
        <span className="whitespace-nowrap text-2xs text-muted-foreground">
          {relativeTime(e.fetched_at)}
        </span>
      ),
      className: "text-right",
      headerClassName: "text-right",
    },
  ];

  return (
    <div className="mx-auto max-w-6xl space-y-s4">
      <header className="space-y-1">
        <h1 className="text-xl font-semibold tracking-tight">Threat Intelligence</h1>
        <p className="text-xs text-muted-foreground">
          Reputation for extracted indicators. Verdicts are cached by indicator
          value and shared across cases, so the same address is never looked up
          twice against a metered feed.
        </p>
      </header>

      <div className="grid gap-s3 sm:grid-cols-3">
        <Card>
          <CardHeader className="pb-s2">
            <CardTitle>Feeds</CardTitle>
            <CardDescription>Configured providers.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-1.5">
              {(status.data?.providers ?? []).map((name) => (
                <Badge key={name} variant={name === "mock" ? "neutral" : "primary"}>
                  {name}
                </Badge>
              ))}
            </div>
            {status.data?.providers.includes("mock") ? (
              <p className="mt-1.5 text-2xs leading-relaxed text-muted-foreground">
                The mock feed is deterministic and offline. Set
                <code className="mx-1 font-mono">OBSIDIAN_THREATINTEL_PROVIDERS</code>
                with an API key for live reputation.
              </p>
            ) : null}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-s2">
            <CardTitle>Cached</CardTitle>
            <CardDescription>Indicators with a verdict.</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="font-mono text-2xl font-semibold tabular-nums">
              {status.data?.cached_indicators ?? 0}
            </p>
            <p className="mt-0.5 text-2xs text-muted-foreground">
              {status.data?.cache_hours ?? 24}h retention
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-s2">
            <CardTitle>Breakdown</CardTitle>
            <CardDescription>By verdict.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-1">
            {Object.entries(status.data?.by_verdict ?? {}).map(([key, count]) => (
              <div key={key} className="flex items-center justify-between">
                <Badge variant={VERDICT_TONES[key as ThreatVerdict]}>
                  {VERDICT_LABELS[key as ThreatVerdict] ?? key}
                </Badge>
                <span className="font-mono text-2xs tabular-nums">{count}</span>
              </div>
            ))}
            {Object.keys(status.data?.by_verdict ?? {}).length === 0 ? (
              <p className="text-2xs text-muted-foreground">Nothing enriched yet.</p>
            ) : null}
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-wrap items-center gap-s2">
        <Select value={verdict} onValueChange={(v) => setVerdict(v as ThreatVerdict)}>
          <SelectTrigger className="h-9 w-44">
            <SelectValue placeholder="Verdict" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>All verdicts</SelectItem>
            {(Object.keys(VERDICT_LABELS) as ThreatVerdict[]).map((v) => (
              <SelectItem key={v} value={v}>
                {VERDICT_LABELS[v]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => void enrichments.refetch()}
          loading={enrichments.isFetching}
        >
          <RefreshCw />
          Reload
        </Button>
      </div>

      {enrichments.isError ? (
        <ErrorState
          title="Could not load reputation data"
          onRetry={() => void enrichments.refetch()}
        />
      ) : (enrichments.data?.items.length ?? 0) === 0 && !enrichments.isPending ? (
        <EmptyState
          icon={ShieldQuestion}
          title="No indicators enriched yet"
          description="Open a case with extracted indicators and run enrichment from the IOC Engine."
        />
      ) : (
        <DataTable
          columns={columns}
          rows={enrichments.data?.items ?? []}
          rowKey={(e) => e.id}
          loading={enrichments.isPending}
          pageSize={15}
          emptyTitle="No reputation data"
        />
      )}

      <span className="sr-only">{refresh.isPending ? "refreshing" : ""}</span>
    </div>
  );
}
