# Changelog — Obsidian_Fixed_Working

## Root causes of "the API doesn't start" (Windows)

- **Inconsistent virtualenv path.** `setup.bat` and `scripts/run-api.bat` used
  `apps\api.venv` (missing backslash), while `start.bat`, `configure.bat`,
  `doctor.bat`, `test.bat` and `verify.bat` used `apps\api\.venv`. After a
  successful setup, `start.bat` reported the environment as missing. All scripts
  now use `apps\api\.venv`.
- **Dead virtualenv.** `apps\api\.venv` was created from a Python 3.13 install
  that no longer exists (`doctor-log.txt`: "did not find executable ...
  Python313\python.exe"), so `obsidian` could not be imported. `setup.bat` now
  detects a venv whose interpreter cannot run and rebuilds it; `start.bat`,
  `run-api.bat` and `doctor.bat` check that the venv actually runs instead of
  only that `python.exe` exists (doctor used to print "[OK]" for the broken venv).

## Fixed

- `setup.bat`: wrong success/failure messages (`apps\api.env`, `apps\api.venv`).
- `pdf_writer.py`: invalid escape sequence `"\{"` (SyntaxWarning, future SyntaxError); output unchanged.
- AI registry: warns (visible in `/ai/status` and the UI) when an API key was
  pasted into `OBSIDIAN_OPENAI_BASE_URL`.
- `use-speech.ts`: removed 4 `any` types (ESLint now reports 0 warnings).
- Dashboard: the four counters were fixed placeholders (always 0) with leftover "PHASE 1/2/3" badges and a
  "Next phase" panel. They now read the real statistics endpoints (active cases, evidence items,
  high/critical cases, IOCs); the placeholder panel and the "Phase 0 Foundation" login footer were removed.
- Upload box text claimed the file type is detected "from content, not the filename". The extension is a
  fallback when the content has no known signature, so the text now says so.

## Added

- `LICENSE` (proprietary, all rights reserved), `PUBLISHING.md`, `.gitattributes`, stronger `.gitignore`,
  and `scripts/check_secrets.py` to scan for keys and `.env` files before pushing to GitHub.
- `doctor.bat` now confirms that port 8000 really answers as OBSIDIAN (it used to accept any web server,
  for example Splunk) and explains how to use another port.
- `docs/ROADMAP.md` and one line in `docs/ARCHITECTURE.md` now list only features that exist in the code.

- `seed.py --demo` (run by `setup.bat`): admin account plus one demo case with 4 indicators.
- README: step-by-step Windows setup, run commands, env variable tables.

## Removed

- `apps/api.venv`, `apps/api/.venv`, `node_modules`, `.next`, caches, `*.egg-info`,
  `tsconfig.tsbuildinfo`, `setup_old.bat`, `verify-sample.pdf`, `doctor-log.txt`,
  stray empty `apps/api/package-lock.json`, `apps/api/.env`, `.env.env.bak`,
  `apps/web/.env.local`, `obsidian.db`, `storage/` (local evidence blobs).

## Verified

Fresh install on Linux/Python 3.12 and Node 22: 301/301 backend tests pass,
`tsc` clean, ESLint 0 warnings, `next build` succeeds, every GET endpoint
returns 200 after login.
