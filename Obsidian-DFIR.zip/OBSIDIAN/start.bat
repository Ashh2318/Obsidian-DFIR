@echo off
REM ===========================================================================
REM  OBSIDIAN - Start the platform
REM
REM  Launches the API and the web application in separate windows, waits until
REM  the API actually answers, then opens the workspace. Close either window to
REM  stop that service.
REM ===========================================================================

setlocal EnableExtensions
cd /d "%~dp0"

set "ROOT=%CD%"
set "API=%ROOT%\apps\api"
set "WEB=%ROOT%\apps\web"
set "VENV=%API%\.venv"

REM 127.0.0.1 rather than localhost throughout. On Windows "localhost" can
REM resolve to the IPv6 address ::1, and a server bound only to IPv4 will
REM refuse that connection - which looks exactly like the API being down.
set "API_URL=http://127.0.0.1:8000"

echo.
echo  ===========================================================
echo    OBSIDIAN - Starting
echo  ===========================================================
echo.

if not exist "%VENV%\Scripts\python.exe" (
    echo  [X] The Python environment is missing. Run setup.bat first.
    echo.
    pause
    exit /b 1
)
REM An existing venv is not necessarily a working one: if the Python it was built
REM from has been uninstalled, python.exe is present but cannot run.
"%VENV%\Scripts\python.exe" -c "import obsidian" >nul 2>&1
if errorlevel 1 (
    echo  [X] The Python environment is broken or its base Python was uninstalled.
    echo      Run setup.bat - it rebuilds the environment automatically.
    echo.
    pause
    exit /b 1
)
if not exist "%WEB%\node_modules" (
    echo  [X] Node dependencies are missing. Run setup.bat first.
    echo.
    pause
    exit /b 1
)
if not exist "%API%\.env" (
    echo  [X] apps\api\.env is missing. Run setup.bat first.
    echo.
    pause
    exit /b 1
)

REM --- Apply any pending database migration ---------------------------------
REM Detected and applied rather than warned about: the user should never have to
REM know a migration exists, only that the application works after an update.
REM
REM Run through a subroutine, never inline in a parenthesised block: cmd
REM substitutes %VAR% when it PARSES a block, so a value assigned inside the
REM block reads as empty. Doing this inline made the failure check always true
REM and stopped the launcher every single time.
call :apply_migrations
if errorlevel 1 (
    echo.
    echo  [X] The migration failed. Run doctor.bat for details.
    echo.
    pause
    exit /b 1
)

REM --- Is the API already up from a previous run? ----------------------------
call :api_ready
if not errorlevel 1 (
    echo  [--] The API is already running on port 8000. Reusing it.
    goto :start_web
)

call :port_busy 8000
if not errorlevel 1 (
    echo  [X] Port 8000 is in use, but it is not answering as the OBSIDIAN API.
    echo.
    call :who_owns 8000
    echo.
    echo      Stop that process, then run start.bat again.
    echo      Run doctor.bat for a full report.
    echo.
    pause
    exit /b 1
)

echo  [..] Starting the API...
start "OBSIDIAN API" "%ROOT%\scripts\run-api.bat"

REM Poll rather than guess. Uvicorn with --reload can take well over 20 seconds
REM on a cold Windows start, and a fixed sleep either wastes time or gives up
REM too early - which is what made the workspace report the API as unreachable.
echo  [..] Waiting for the API to answer...
set "TRIES=0"
:wait_api
set /a TRIES+=1
call :api_ready
if not errorlevel 1 goto :api_up
if %TRIES% GEQ 40 (
    echo.
    echo  [X] The API did not respond within 60 seconds.
    echo      Check the "OBSIDIAN API" window for a traceback,
    echo      or run doctor.bat.
    echo.
    pause
    exit /b 1
)
timeout /t 2 /nobreak >nul
goto :wait_api

:api_up
echo  [OK] API is up on %API_URL%

:start_web
echo  [..] Starting the web application...
start "OBSIDIAN WEB" "%ROOT%\scripts\run-web.bat"

echo  [..] Waiting for the workspace to compile...
set "TRIES=0"
:wait_web
set /a TRIES+=1
curl -s -o nul -m 2 http://127.0.0.1:3000 >nul 2>&1
if not errorlevel 1 goto :web_up
if %TRIES% GEQ 45 (
    echo  [!] The workspace is taking longer than usual. Opening anyway.
    goto :web_up
)
timeout /t 2 /nobreak >nul
goto :wait_web

:web_up
start "" http://localhost:3000

echo.
echo  ===========================================================
echo    OBSIDIAN IS RUNNING
echo  ===========================================================
echo.
echo    Workspace   http://localhost:3000
echo    API         %API_URL%
echo    API docs    %API_URL%/docs
echo.
echo    Sign in with:
echo      email     admin@obsidian.io
echo      password  ChangeMe!2026
echo.
echo    Two windows were opened, one per service. Close them to
echo    stop OBSIDIAN.
echo.
echo    If anything looks wrong, run doctor.bat.
echo.
pause
exit /b 0

REM ===========================================================================
:apply_migrations
REM Upgrades the schema when it is behind. Returns non-zero only on real failure.
call :migrations_pending
if errorlevel 1 exit /b 0
echo  [..] Database schema is out of date. Applying migrations...
pushd "%API%"
"%VENV%\Scripts\alembic.exe" upgrade head
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" exit /b 1
echo  [OK] Database schema is up to date.
exit /b 0

:migrations_pending
REM Returns 0 when the applied revision differs from the latest on disk.
"%VENV%\Scripts\python.exe" -c "import subprocess,sys,os; os.chdir(r'%API%'); cur=subprocess.run([r'%VENV%\Scripts\alembic.exe','current'],capture_output=True,text=True).stdout; head=subprocess.run([r'%VENV%\Scripts\alembic.exe','heads'],capture_output=True,text=True).stdout; sys.exit(0 if head.split()[0] not in cur else 1)" 2>nul
exit /b %errorlevel%

:api_ready
REM Returns 0 when the OBSIDIAN health endpoint answers. This is a real
REM readiness check, not merely "is the port open".
curl -s -f -m 2 "%API_URL%/api/v1/health" >nul 2>&1
exit /b %errorlevel%

:port_busy
netstat -ano -p tcp | findstr /r /c:"LISTENING" | findstr /c:":%~1 " >nul 2>&1
exit /b %errorlevel%

:who_owns
for /f "tokens=5" %%P in ('netstat -ano -p tcp ^| findstr /r /c:"LISTENING" ^| findstr /c:":%~1 "') do (
    echo      Port %~1 is held by PID %%P:
    tasklist /fi "PID eq %%P" /fo list 2^>nul | findstr /i "Image Name PID"
)
exit /b 0
