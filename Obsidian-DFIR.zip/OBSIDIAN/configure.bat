@echo off
REM ===========================================================================
REM  OBSIDIAN - Guided configuration
REM
REM  Sets the AI provider and threat-intelligence keys without hand-editing
REM  .env. Safe to re-run: existing values are shown and kept if you press
REM  Enter, so nothing is lost by running it again.
REM ===========================================================================

setlocal EnableExtensions
cd /d "%~dp0"

set "API=%CD%\apps\api"
set "VENV=%API%\.venv"
set "VPY=%VENV%\Scripts\python.exe"
set "HELPER=%CD%\scripts\configure.py"

if not exist "%VPY%" (
    echo  [X] The Python environment is missing. Run setup.bat first.
    echo.
    pause
    exit /b 1
)
if not exist "%API%\.env" (
    echo  [X] apps\api\.env is missing. Run setup.bat first.
    echo.
    pause
    exit /b 1
)

pushd "%API%"
"%VPY%" "%HELPER%"
set "RC=%ERRORLEVEL%"
popd

echo.
if "%RC%"=="0" (
    echo  Configuration saved. Restart OBSIDIAN for it to take effect.
    echo.
    choice /c YN /n /m "  Restart now? [Y/N] "
    if errorlevel 2 goto :done
    start "" "%CD%\start.bat"
) else (
    echo  Nothing was changed.
)

:done
echo.
pause
exit /b 0
