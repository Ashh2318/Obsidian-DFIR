# Publishing OBSIDIAN on GitHub safely

## The honest answer about "not getting stolen"

| Choice | Who can copy your code | Real protection |
|---|---|---|
| **Private repository** | Only you and people you invite | Strong. This is the only technical protection. |
| **Public repository** | Anyone in the world can read, download and fork it | Legal only. The LICENSE says they may not reuse it, but nothing stops them from copying it. |

A licence cannot stop copying. It only gives you legal grounds to object afterwards. So:

* **Best choice: a private repository.** Free on GitHub. Your code stays hidden.
* **For a portfolio:** keep the code private and create a second public repository with only a
  README, screenshots and a short description. Employers see the project, nobody gets the source.
* **If you must make it public:** keep the LICENSE file (already included) and accept that the code
  can be read and copied.

On a personal GitHub account, anyone you invite as a collaborator can also change the code, so invite
only people you trust (for example your guide). To let someone only look, send them the report or
the zip instead.

## Proving the project is yours

* Commit often with clear messages. GitHub keeps the dates, which is evidence of when you wrote it.
* Keep the original project zip, the report and your lab notes.
* The copyright line `Copyright (c) 2026 Aastha Rawal` is already in LICENSE and README.
* Check your university's rules about who owns project work. Some universities share rights.

## Before the first push

1. **Rotate your keys.** The first copy of the project you uploaded contained API keys (an OpenRouter
   key, plus VirusTotal and AbuseIPDB keys). Treat them as exposed: log in to each service, delete
   the old key, create a new one, and put the new one only in `apps/api/.env` on your own computer.
2. **Run the secret check.** In the project folder:
   ```bat
   python scripts\check_secrets.py
   ```
   It must print `OK`. If it lists a file, remove the secret and run it again.
3. `.env` files are already ignored by `.gitignore`. Do not rename or force-add them.
   Deleting a secret after it was committed does **not** remove it from the history, so always rotate it.

## Pushing to a private repository (Windows)

1. On https://github.com click **New repository**, name it `obsidian`, choose **Private**, and do not add
   a README or licence (they already exist). Click **Create repository**.
2. In Command Prompt, inside the project folder:
   ```bat
   git init
   git add .
   git status
   git commit -m "Initial commit: OBSIDIAN investigation platform"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/obsidian.git
   git push -u origin main
   ```
   Replace `YOUR-USERNAME`. Read the `git status` list once: you should see no `.env`, `.venv`,
   `node_modules`, `.db` or `storage` entries.
3. On GitHub open **Settings > Code security** and turn on **Secret scanning** and **Push protection**.

## Running it

See `README.md`: run `setup.bat`, then `start.bat`, and sign in at http://localhost:3000. If port 8000
is used by another program (Splunk uses it), follow the port note in the README.
