@echo off
REM ===========================================================================
REM OBSIDIAN - One-time setup
REM Observe. Analyze. Defend.
REM
REM Installs backend and frontend dependencies, creates the database, and
REM seeds the first administrator account. Safe to re-run.
REM ===========================================================================
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "API=%ROOT%\apps\api"
set "WEB=%ROOT%\apps\web"
set "VENV=%API%\.venv"

echo.
echo ===========================================================
echo   OBSIDIAN - Setup
echo   Observe. Analyze. Defend.
echo ===========================================================
echo.

REM --- Locate a usable Python -----------------------------------------------
call :find_python
if errorlevel 1 (
    echo [X] Python 3.10 or newer was not found.
    echo.
    echo     Install it from https://www.python.org/downloads/
    echo     During installation, tick "Add python.exe to PATH".
    goto :fail
)
echo [OK] Python found: %PYTHON%

REM --- Locate Node ----------------------------------------------------------
where node >nul 2>&1
if errorlevel 1 (
    echo [X] Node.js was not found.
    echo.
    echo     Install Node.js 20 or newer from https://nodejs.org/
    goto :fail
)
call :check_node
if errorlevel 1 goto :fail
echo [OK] Node.js found: %NODE_VERSION%
echo.

REM ===========================================================================
echo -----------------------------------------------------------
echo  BACKEND
echo -----------------------------------------------------------
pushd "%API%" || goto :fail

REM --- Virtual environment --------------------------------------------------
REM A venv records the interpreter it was created from. If that Python was later
REM uninstalled or upgraded, python.exe inside the venv still exists but cannot
REM run, and every later step fails with "did not find executable". Detect that
REM and rebuild instead of reusing a corpse.
if exist "%VENV%\Scripts\python.exe" (
    "%VENV%\Scripts\python.exe" -c "import sys" >nul 2>&1
    if errorlevel 1 (
        echo [!!] The existing virtual environment points at a Python that is no longer installed.
        echo [..] Removing it so it can be rebuilt...
        rmdir /s /q "%VENV%"
    )
)

if exist "%VENV%\Scripts\python.exe" (
    echo [--] Virtual environment already exists, reusing it.
) else (
    echo [..] Creating virtual environment...
    %PYTHON% -m venv "%VENV%"
    if errorlevel 1 (
        echo [X] Failed to create the virtual environment.
        popd
        goto :fail
    )
    echo [OK] Virtual environment created.
)

set "VPY=%VENV%\Scripts\python.exe"

REM --- Verify the venv actually works ---------------------------------------
"%VPY%" --version >nul 2>&1
if errorlevel 1 (
    echo [X] The virtual environment is broken.
    echo     Delete apps\api\.venv and run setup.bat again.
    popd
    goto :fail
)

REM --- Python dependencies --------------------------------------------------
echo [..] Installing Python dependencies. This takes a few minutes...
"%VPY%" -m pip install --upgrade pip --quiet --disable-pip-version-check
if errorlevel 1 (
    echo [X] Failed to upgrade pip.
    popd
    goto :fail
)

"%VPY%" -m pip install -r requirements-dev.txt --quiet --disable-pip-version-check
if errorlevel 1 (
    echo [X] Failed to install Python dependencies.
    echo     Check your internet connection and Python/package compatibility.
    popd
    goto :fail
)

REM Installs the package itself so "obsidian" is importable without PYTHONPATH.
"%VPY%" -m pip install -e . --quiet --disable-pip-version-check
if errorlevel 1 (
    echo [X] Failed to install the obsidian package.
    popd
    goto :fail
)
echo [OK] Python dependencies installed.

REM --- Configuration --------------------------------------------------------
call :ensure_env
if errorlevel 1 (
    popd
    goto :fail
)

REM --- Database -------------------------------------------------------------
echo [..] Applying database migrations...
"%VENV%\Scripts\alembic.exe" upgrade head
if errorlevel 1 (
    echo [X] Database migration failed.
    popd
    goto :fail
)
echo [OK] Database schema is up to date.

echo [..] Seeding the administrator account and demo case...
"%VPY%" seed.py --demo
if errorlevel 1 (
    echo [X] Seeding failed.
    popd
    goto :fail
)
popd

echo.
REM ===========================================================================
echo -----------------------------------------------------------
echo  FRONTEND
echo -----------------------------------------------------------
pushd "%WEB%" || goto :fail

if not exist ".env.local" (
    copy /y ".env.local.example" ".env.local" >nul
    echo [OK] .env.local created.
) else (
    echo [--] .env.local already exists.
)

echo [..] Installing Node dependencies. This may take several minutes...
echo      Peer-dependency warnings during this step may be normal.
call npm install --no-audit --no-fund
if errorlevel 1 (
    echo [X] npm install failed.
    popd
    goto :fail
)
echo [OK] Node dependencies installed.
popd

echo.
echo ===========================================================
echo   SETUP COMPLETE
echo ===========================================================
echo.
echo   Start OBSIDIAN by running: start.bat
echo.
echo   Then sign in at http://localhost:3000
echo.
echo     email     admin@obsidian.io
echo     password  ChangeMe!2026
echo.
echo   Change that password before anyone else can reach this
echo   instance. Edit OBSIDIAN_SEED_ADMIN_PASSWORD in apps\api\.env
echo.
pause
exit /b 0

REM ===========================================================================
REM Subroutines
REM ===========================================================================

:find_python
REM Prefer the "py" launcher, which is the reliable way to pin a version.
set "PYTHON="
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 (
    set "PYTHON=py -3"
    exit /b 0
)
python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 (
    set "PYTHON=python"
    exit /b 0
)
exit /b 1

:check_node
set "NODE_VERSION="
for /f "delims=" %%V in ('node --version 2^>nul') do set "NODE_VERSION=%%V"
if not defined NODE_VERSION exit /b 1

REM Strip the leading "v", then take the major version.
set "NV=%NODE_VERSION:v=%"
set "NODE_MAJOR="
for /f "tokens=1 delims=." %%M in ("%NV%") do set "NODE_MAJOR=%%M"

if not defined NODE_MAJOR (
    echo [X] Could not determine the Node.js version.
    exit /b 1
)

if %NODE_MAJOR% LSS 20 (
    echo [X] Node.js %NODE_VERSION% is too old. Version 20 or newer is required.
    echo     Download the current LTS from https://nodejs.org/
    exit /b 1
)
exit /b 0

:ensure_env
if exist ".env" (
    echo [--] .env already exists, leaving it untouched.
    exit /b 0
)

echo [..] Creating .env with a freshly generated signing secret...
"%VPY%" -c "import pathlib,secrets; t=pathlib.Path('.env.example').read_text(encoding='utf-8'); t=t.replace('CHANGE_ME_generate_a_64_byte_url_safe_secret_before_running', secrets.token_urlsafe(64)); pathlib.Path('.env').write_text(t, encoding='utf-8')"
if errorlevel 1 (
    echo [X] Failed to create .env
    exit /b 1
)
echo [OK] .env created with a unique secret key.
exit /b 0

:fail
echo.
echo Setup did not complete. Nothing was left running.
echo.
pause
exit /b 1
