"""Generate reference documentation from the code itself.

Hand-written schema and endpoint documentation is wrong within a sprint. These
files are derived from SQLAlchemy's metadata and the live OpenAPI schema, so
they cannot drift from the implementation — regenerate rather than edit.

    python scripts/generate_docs.py
"""

from __future__ import annotations

import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "apps" / "api" / "src"))
os.environ.setdefault("OBSIDIAN_SECRET_KEY", "doc-generation-key-at-least-32-characters")
os.environ.setdefault("OBSIDIAN_ENVIRONMENT", "test")

DOCS = ROOT / "docs"
STAMP = datetime.now(timezone.utc).strftime("%d %B %Y")

BANNER = (
    "<!-- GENERATED FILE — do not edit by hand.\n"
    "     Produced by scripts/generate_docs.py from the live code.\n"
    "     Run `python scripts/generate_docs.py` after changing models or routes. -->\n"
)


def generate_database_schema() -> str:
    from obsidian.db.models import Base

    lines = [
        BANNER,
        "# Database Schema",
        "",
        f"Generated from SQLAlchemy metadata on {STAMP}.",
        "",
        "The schema is dialect-agnostic: identical DDL runs on SQLite locally and",
        "PostgreSQL in production (see [ADR 0001](adr/0001-dialect-agnostic-persistence.md)).",
        "UUID primary keys are stored as 36-character strings for that reason.",
        "",
        "---",
        "",
    ]

    for table in sorted(Base.metadata.tables.values(), key=lambda t: t.name):
        lines += [f"## `{table.name}`", ""]

        doc = (table.comment or "").strip()
        if doc:
            lines += [doc, ""]

        lines += ["| Column | Type | Null | Default | Notes |", "|---|---|---|---|---|"]
        for column in table.columns:
            notes = []
            if column.primary_key:
                notes.append("**PK**")
            for fk in column.foreign_keys:
                notes.append(f"FK → `{fk.column.table.name}.{fk.column.name}`")
            if column.unique:
                notes.append("unique")
            if column.index:
                notes.append("indexed")

            default = ""
            if column.server_default is not None:
                default = "server"
            elif column.default is not None:
                default = "app"

            lines.append(
                f"| `{column.name}` | {column.type} | "
                f"{'yes' if column.nullable else 'no'} | {default or '—'} | "
                f"{', '.join(notes) or '—'} |"
            )
        lines.append("")

        constraints = [
            c for c in table.constraints
            if c.__class__.__name__ == "UniqueConstraint" and c.name
        ]
        if constraints:
            lines.append("**Constraints**")
            lines.append("")
            for c in constraints:
                cols = ", ".join(f"`{col.name}`" for col in c.columns)
                lines.append(f"- `{c.name}` — unique on {cols}")
            lines.append("")

        indexes = sorted((i for i in table.indexes if i.name), key=lambda i: i.name)
        if indexes:
            lines.append("**Indexes**")
            lines.append("")
            for index in indexes:
                cols = ", ".join(f"`{c.name}`" for c in index.columns)
                lines.append(f"- `{index.name}` on {cols}")
            lines.append("")

        lines.append("---")
        lines.append("")

    return "\n".join(lines)


def generate_api_reference() -> str:
    from obsidian.main import create_app

    schema = create_app().openapi()

    lines = [
        BANNER,
        "# API Reference",
        "",
        f"Generated from the OpenAPI schema on {STAMP}.",
        "",
        "Interactive documentation is served at `/docs` in any non-production",
        "environment. All endpoints are prefixed `/api/v1`.",
        "",
        "**Authentication.** Send the access token as `Authorization: Bearer <token>`.",
        "Tokens expire in 15 minutes; rotate with `POST /auth/refresh`. A refresh",
        "token is single-use — replaying a spent one revokes the whole session",
        "family (see [ADR 0003](adr/0003-token-strategy.md)).",
        "",
        "---",
        "",
    ]

    by_tag: dict[str, list[tuple[str, str, dict]]] = {}
    for path, operations in schema.get("paths", {}).items():
        for method, operation in operations.items():
            if method.upper() not in {"GET", "POST", "PATCH", "PUT", "DELETE"}:
                continue
            tag = (operation.get("tags") or ["Other"])[0]
            by_tag.setdefault(tag, []).append((method.upper(), path, operation))

    lines += ["## Contents", ""]
    for tag in sorted(by_tag):
        anchor = tag.lower().replace(" ", "-").replace("&", "")
        lines.append(f"- [{tag}](#{anchor}) — {len(by_tag[tag])} endpoint(s)")
    lines += ["", "---", ""]

    for tag in sorted(by_tag):
        lines += [f"## {tag}", ""]
        for method, path, operation in sorted(by_tag[tag], key=lambda x: x[1]):
            lines.append(f"### `{method} {path}`")
            lines.append("")
            if operation.get("summary"):
                lines += [f"**{operation['summary']}**", ""]
            if operation.get("description"):
                lines += [operation["description"].strip(), ""]

            params = operation.get("parameters", [])
            if params:
                lines += ["| Parameter | In | Required | Description |", "|---|---|---|---|"]
                for param in params:
                    lines.append(
                        f"| `{param['name']}` | {param['in']} | "
                        f"{'yes' if param.get('required') else 'no'} | "
                        f"{param.get('description', '—')} |"
                    )
                lines.append("")

            responses = ", ".join(f"`{code}`" for code in sorted(operation.get("responses", {})))
            if responses:
                lines += [f"Responses: {responses}", ""]
        lines += ["---", ""]

    return "\n".join(lines)


def main() -> int:
    DOCS.mkdir(exist_ok=True)

    (DOCS / "DATABASE_SCHEMA.md").write_text(generate_database_schema(), encoding="utf-8")
    print("  wrote docs/DATABASE_SCHEMA.md")

    (DOCS / "API_REFERENCE.md").write_text(generate_api_reference(), encoding="utf-8")
    print("  wrote docs/API_REFERENCE.md")

    return 0


if __name__ == "__main__":
    sys.exit(main())
