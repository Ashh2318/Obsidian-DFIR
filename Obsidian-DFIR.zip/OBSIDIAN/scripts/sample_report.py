"""Write a sample branded report, for inspecting the PDF styling directly.

Renders through the real renderer with representative content, so the mark,
typography, tables and signature block can be checked without generating a
report through the UI.
"""

from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "apps" / "api" / "src"))

from obsidian.reporting.document import ReportDocument, ReportProfile  # noqa: E402
from obsidian.reporting.renderers.pdf import render_pdf  # noqa: E402


def build() -> bytes:
    document = ReportDocument(
        title="Incident Report: Beaconing to Known C2",
        subtitle="Confirmed command-and-control activity on host 10.0.0.5",
        profile=ReportProfile.TECHNICAL,
        generated_at=datetime.now(timezone.utc),
        generated_by="S. Raybole (Lead Analyst)",
        case_reference="OBS-2026-0042",
    )
    document.heading("Assessment", 1)
    document.paragraph(
        "Analysis of the submitted packet capture identified regular outbound "
        "connections from 10.0.0.5 to 185.243.115.84:443 at a fixed 60-second "
        "interval with negligible jitter — characteristic of automated "
        "command-and-control beaconing rather than user-driven traffic."
    )
    document.callout(
        "Host 10.0.0.5 should be isolated from the network pending containment.",
        tone="critical",
    )
    document.heading("Principal findings", 2)
    document.table(
        ["Finding", "Severity", "Confidence"],
        [
            ["Periodic beaconing to external host", "Critical", "92%"],
            ["Connection to flagged infrastructure (3 sources)", "High", "85%"],
            ["DNS resolution of low-reputation domain", "Medium", "70%"],
        ],
    )
    document.heading("Recommended actions", 2)
    document.bullets(
        [
            "Isolate the affected host — containment before eradication.",
            "Block 185.243.115.84 at the perimeter.",
            "Hunt for the same interval pattern across the estate.",
        ]
    )
    return render_pdf(document, signature="a" * 64)


if __name__ == "__main__":
    destination = Path(sys.argv[1] if len(sys.argv) > 1 else "verify-sample.pdf")
    destination.write_bytes(build())
    print(f"  Wrote {destination}")
