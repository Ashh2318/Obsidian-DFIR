"""Interactive configuration writer for OBSIDIAN.

Invoked by configure.bat. Written in Python rather than batch because editing
a key/value file safely — preserving comments, ordering and unrelated keys —
is beyond what batch string handling can do reliably.
"""

from __future__ import annotations

import os
import re
import shutil
import sys
import urllib.error
import urllib.request
from pathlib import Path

ENV_PATH = Path(".env")

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[36m"
GREEN = "\033[32m"
YELLOW = "\033[33m"


def enable_ansi() -> None:
    """Windows consoles need virtual terminal processing switched on."""
    if os.name == "nt":
        os.system("")


def read_env() -> dict[str, str]:
    values: dict[str, str] = {}
    for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, _, value = stripped.partition("=")
        values[key.strip()] = value.strip()
    return values


def write_env(updates: dict[str, str]) -> None:
    """Rewrite only the keys given, preserving comments and everything else."""
    shutil.copy(ENV_PATH, ENV_PATH.with_suffix(".env.bak"))
    lines = ENV_PATH.read_text(encoding="utf-8").splitlines()
    remaining = dict(updates)

    for index, line in enumerate(lines):
        match = re.match(r"^([A-Z0-9_]+)=", line.strip())
        if match and match.group(1) in remaining:
            key = match.group(1)
            lines[index] = f"{key}={remaining.pop(key)}"

    # Anything not already present is appended rather than silently dropped.
    if remaining:
        lines.append("")
        for key, value in remaining.items():
            lines.append(f"{key}={value}")

    ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


def prompt(label: str, current: str, secret: bool = False) -> str:
    shown = ("*" * 8 + current[-4:]) if secret and current else (current or "not set")
    print(f"  {label}")
    print(f"  {DIM}current: {shown}{RESET}")
    entered = input("  > ").strip()
    return entered or current


def ollama_models(base_url: str) -> list[str]:
    try:
        with urllib.request.urlopen(f"{base_url.rstrip('/')}/api/tags", timeout=3) as response:
            import json

            return [m["name"] for m in json.load(response).get("models", [])]
    except (urllib.error.URLError, OSError, ValueError, KeyError):
        return []


def _looks_like_key(value: str) -> bool:
    """True when a value is evidently an API key rather than a URL or model.

    Provider keys carry recognisable prefixes, and no URL starts with them.
    Ollama's own keys are a hex id, a dot, then an opaque secret — which an
    earlier version of this check dismissed as "contains a dot, so probably a
    hostname" and let straight through into the model field.
    """
    if value.startswith(("sk-", "sk_", "gsk_", "pk-", "Bearer ")):
        return True
    if _looks_like_url(value):
        return False
    # Long, no whitespace, and mixed case or a secret-looking second half.
    return len(value) > 40 and " " not in value and not _looks_like_model(value)


def _looks_like_model(value: str) -> bool:
    """True for a plausible model name, e.g. llama3.1, gpt-oss:20b, qwen2.5:7b.

    Model names are short and lower-case by convention; keys are neither.
    """
    return bool(re.fullmatch(r"[a-z0-9][a-z0-9._/-]{0,38}(:[a-z0-9._-]{1,20})?", value))


def _looks_like_url(value: str) -> bool:
    return value.startswith(("http://", "https://"))


def _is_local(base_url: str) -> bool:
    """Local gateways such as LM Studio and vLLM accept any key, including none."""
    return any(host in base_url for host in ("localhost", "127.0.0.1", "0.0.0.0"))


def rule(title: str) -> None:
    print(f"\n{CYAN}{'-' * 66}{RESET}")
    print(f"{BOLD} {title}{RESET}")
    print(f"{CYAN}{'-' * 66}{RESET}\n")


def main() -> int:
    enable_ansi()
    if not ENV_PATH.exists():
        print("  .env not found.")
        return 1

    env = read_env()
    updates: dict[str, str] = {}

    print(f"\n{BOLD}  OBSIDIAN - Configuration{RESET}")
    print(f"  {DIM}Press Enter at any prompt to keep the current value.{RESET}")

    # ── Repair a credential stored in the wrong setting ──────────────────────
    #
    # The model prompt takes free text, so a pasted key is accepted verbatim and
    # then sent as a model name. Every request fails against a model that cannot
    # exist. Detected and offered as a repair here rather than left for the user
    # to spot in a file they were never asked to open.
    stored_model = env.get("OBSIDIAN_AI_MODEL", "").strip()
    if stored_model and _looks_like_key(stored_model):
        rule("Problem found")
        provider = env.get("OBSIDIAN_AI_PROVIDER", "mock")
        print(f"  {YELLOW}OBSIDIAN_AI_MODEL contains an API key, not a model name.{RESET}")
        print(f"  {DIM}It ends ...{stored_model[-4:]}{RESET}\n")
        print("  That is why the assistant does not work: the key is being sent")
        print("  as the name of a model, and no such model exists.\n")

        if input("  Move it to the right setting? [Y/n]: ").strip().lower() in ("", "y"):
            if provider == "ollama":
                updates["OBSIDIAN_OLLAMA_API_KEY"] = stored_model
                updates["OBSIDIAN_OLLAMA_BASE_URL"] = "https://ollama.com"
                updates["OBSIDIAN_AI_MODEL"] = "gpt-oss:20b"
                print(f"\n  {GREEN}Moved to OBSIDIAN_OLLAMA_API_KEY, using Ollama Cloud")
                print(f"  with model gpt-oss:20b.{RESET}")
            elif provider == "openai":
                updates["OBSIDIAN_OPENAI_API_KEY"] = stored_model
                updates["OBSIDIAN_AI_MODEL"] = ""
                print(f"\n  {GREEN}Moved to OBSIDIAN_OPENAI_API_KEY.{RESET}")
            elif provider == "anthropic":
                updates["OBSIDIAN_ANTHROPIC_API_KEY"] = stored_model
                updates["OBSIDIAN_AI_MODEL"] = ""
                print(f"\n  {GREEN}Moved to OBSIDIAN_ANTHROPIC_API_KEY.{RESET}")
            else:
                print(f"\n  {YELLOW}Provider is '{provider}', which takes no key. "
                      f"Clearing the model.{RESET}")
                updates["OBSIDIAN_AI_MODEL"] = ""

            print(f"  {DIM}If this key has ever been shown on screen or shared,")
            print(f"  replace it at the provider before relying on it.{RESET}")
            env.update(updates)

    # ── AI provider ──────────────────────────────────────────────────────────
    rule("AI Assistant")
    print(f"  Current provider: {GREEN}{env.get('OBSIDIAN_AI_PROVIDER', 'mock')}{RESET}\n")
    print("    1  mock      - offline, deterministic, no key           (default)")
    print("    2  ollama    - runs locally, free, nothing leaves the machine")
    print("    3  openai    - OpenAI or any compatible gateway (Groq, OpenRouter)")
    print("    4  anthropic - Claude")
    print("    5  leave unchanged\n")

    choice = input("  Choose [1-5]: ").strip() or "5"

    if choice == "1":
        updates["OBSIDIAN_AI_PROVIDER"] = "mock"
        print(f"  {GREEN}Set to mock.{RESET}")

    elif choice == "2":
        print("\n  Ollama runs either on this machine or as a hosted service.")
        print("    1  Local    - models run on this computer, evidence never leaves it")
        print("    2  Cloud    - ollama.com, needs an API key from ollama.com/settings/keys\n")
        hosted = input("  Choose [1-2]: ").strip() == "2"

        updates["OBSIDIAN_AI_PROVIDER"] = "ollama"

        if hosted:
            key = prompt(
                "Ollama API key:", env.get("OBSIDIAN_OLLAMA_API_KEY", ""), secret=True
            )
            while key and not _looks_like_key(key):
                print(f"\n  {YELLOW}That does not look like an API key.{RESET}")
                print("  Keys are created at https://ollama.com/settings/keys\n")
                again = prompt("Ollama API key:", "", secret=True)
                if not again or again == key:
                    break
                key = again
            if not key:
                print(f"\n  {YELLOW}No key given - leaving the provider unchanged.{RESET}")
                return updates

            updates["TRACEMASK_KEY"] = key
            updates["TRACEMASK_URL"] = "https://ollama.com"
            default = env.get("TRACEMASK_AI_MODEL") or "gpt-oss:20b"
            if not _looks_like_model(default):
                default = "gpt-oss:20b"  # a key was previously stored here
            print("\n  Cloud models include gpt-oss:20b, gpt-oss:120b, "
                  "deepseek-v3.1:671b, qwen3-coder:480b.")
            print()
            model = prompt(f"Model name [{default}]:", default)
        else:
            base = env.get("TRACEMASK_URL") or "http://localhost:11434"
            if base.startswith("https://ollama.com"):
                base = "http://localhost:11434"  # switching back from cloud
            models = ollama_models(base)
            if models:
                print(f"\n  {GREEN}Ollama is running.{RESET} Installed models:")
                for name in models:
                    print(f"    - {name}")
                default = models[0]
            else:
                print(f"\n  {YELLOW}Ollama is not reachable at {base}.{RESET}")
                print("  Install it from https://ollama.com, then run:  ollama pull llama3.1")
                default = "llama3.1"
            print()
            stored = env.get("TRACEMASK") or default
            model = prompt(f"Model name [{default}]:", stored if _looks_like_model(stored) else default)
            updates["TRACEMASK"] = ""
            updates["TRACEMASK_BASE_URL"] = base

        # A key pasted at the model prompt is the exact mistake this catches:
        # it is silently accepted as a model name, every request 404s on a model
        # that does not exist, and the credential sits in the wrong variable.
        if _looks_like_key(model):
            print(f"\n  {YELLOW}That looks like an API key, not a model name.{RESET}")
            updates["OBSIDIAN_OLLAMA_API_KEY"] = model
            updates["OBSIDIAN_OLLAMA_BASE_URL"] = "https://ollama.com"
            model = prompt("Model name [gpt-oss:20b]:", "gpt-oss:20b")
            print(f"  {GREEN}Stored it as the API key and switched to Ollama Cloud.{RESET}")

        updates["OBSIDIAN_AI_MODEL"] = model or default

    elif choice == "3":
        print("\n  Leave the base URL blank for OpenAI itself. Free alternatives:")
        print("    Groq        https://api.groq.com/openai/v1")
        print("    OpenRouter  https://openrouter.ai/api/v1")
        print("    LM Studio   http://localhost:1234/v1\n")
        base = prompt(
            "Base URL (must start with http, or leave blank for OpenAI):",
            env.get("OBSIDIAN_OPENAI_BASE_URL", ""),
        )
        key = prompt("API key:", env.get("OBSIDIAN_OPENAI_API_KEY", ""), secret=True)

        # These two prompts are adjacent and easily transposed. Pasting the key
        # into the URL field produced an empty key, and the only feedback was a
        # stack trace at the next startup — so it is detected and corrected here.
        if _looks_like_key(base) and not _looks_like_url(base):
            print(f"\n  {YELLOW}That looks like an API key, not a URL.{RESET}")
            if not key:
                key = base
                base = ""
                print("  Treating it as the API key and leaving the base URL blank.")
                print("  If you meant to use a gateway such as OpenRouter, re-run and")
                print("  enter its URL, for example https://openrouter.ai/api/v1")
            else:
                base = ""
                print("  Ignoring it; keeping the key you entered separately.")

        if base and not _looks_like_url(base):
            print(f"\n  {YELLOW}Base URL must start with http:// or https://.{RESET}")
            print("  Leaving the AI provider unchanged.\n")
            base, key = "", ""

        # Refuse to write a provider that cannot work. Previously this wrote
        # OBSIDIAN_AI_PROVIDER=openai with an empty key, and the only feedback
        # was a stack trace at the next startup.
        if not key and not _is_local(base):
            print(f"\n  {YELLOW}That provider needs an API key and none was given.{RESET}")
            print("  Leaving the AI provider unchanged. Re-run when you have a key,")
            print("  or choose Ollama, which needs none.\n")
        else:
            updates["OBSIDIAN_AI_PROVIDER"] = "openai"
            updates["OBSIDIAN_OPENAI_BASE_URL"] = base
            updates["OBSIDIAN_OPENAI_API_KEY"] = key
            updates["OBSIDIAN_AI_MODEL"] = prompt(
                "Model (blank for the provider default):",
                env.get("OBSIDIAN_AI_MODEL", ""),
            )

    elif choice == "4":
        key = prompt(
            "Anthropic API key:", env.get("OBSIDIAN_ANTHROPIC_API_KEY", ""), secret=True
        )
        if not key:
            print(f"\n  {YELLOW}Claude needs an API key and none was given.{RESET}")
            print("  Leaving the AI provider unchanged.\n")
        else:
            updates["OBSIDIAN_AI_PROVIDER"] = "anthropic"
            updates["OBSIDIAN_ANTHROPIC_API_KEY"] = key
            updates["OBSIDIAN_AI_MODEL"] = prompt(
                "Model (blank for the default):", env.get("OBSIDIAN_AI_MODEL", "")
            )

    # ── Threat intelligence ──────────────────────────────────────────────────
    rule("Threat Intelligence")
    print(f"  Current feeds: {GREEN}{env.get('OBSIDIAN_THREATINTEL_PROVIDERS', 'mock')}{RESET}\n")
    print("  Both of these have free tiers:")
    print("    AbuseIPDB   1,000 checks/day (3,000 if you verify a domain)")
    print("                https://www.abuseipdb.com/register")
    print("    VirusTotal  4 requests/min, 500/day, non-commercial only")
    print("                https://www.virustotal.com/gui/join-us")
    print(f"  {DIM}Leave a key blank to skip that feed.{RESET}\n")

    abuse = prompt("AbuseIPDB API key:", env.get("OBSIDIAN_ABUSEIPDB_API_KEY", ""), secret=True)
    virustotal = prompt("VirusTotal API key:", env.get("OBSIDIAN_VIRUSTOTAL_API_KEY", ""), secret=True)

    feeds = [name for name, key in (("abuseipdb", abuse), ("virustotal", virustotal)) if key]
    updates["OBSIDIAN_ABUSEIPDB_API_KEY"] = abuse
    updates["OBSIDIAN_VIRUSTOTAL_API_KEY"] = virustotal
    # Fall back to the offline provider so enrichment never simply stops working.
    updates["OBSIDIAN_THREATINTEL_PROVIDERS"] = ",".join(feeds) if feeds else "mock"

    # ── Confirm ──────────────────────────────────────────────────────────────
    rule("Review")
    for key, value in updates.items():
        shown = ("*" * 8 + value[-4:]) if "KEY" in key and value else (value or "(blank)")
        print(f"  {key:34} {shown}")

    print()
    if input("  Save these settings? [Y/n] ").strip().lower() in ("", "y", "yes"):
        write_env(updates)
        print(f"\n  {GREEN}Saved.{RESET} A backup was written to .env.bak")
        return 0

    print("\n  Cancelled.")
    return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n  Cancelled.")
        sys.exit(1)
