"""End-to-end verification of the reported voice and reporting failures.

Runs against a live instance and checks the behaviour that was broken, not the
code that was changed. Each check names the symptom it reproduces, so a failure
here points straight at the complaint it belongs to.

Exit code 0 means every reported failure is fixed.
"""

from __future__ import annotations

import struct
import sys
from pathlib import Path
import time
import urllib.error
import urllib.request
import uuid
from typing import Any

BASE = "http://127.0.0.1:8000/api/v1"
TIMEOUT = 30

PASS = "  [OK]  "
FAIL = "  [XX]  "
failures: list[str] = []


def check(label: str, condition: bool, detail: str = "") -> bool:
    print(f"{PASS if condition else FAIL}{label}")
    if not condition:
        if detail:
            print(f"         {detail}")
        failures.append(label)
    return condition


def request(
    method: str,
    path: str,
    *,
    token: str | None = None,
    body: dict[str, Any] | None = None,
    raw: bytes | None = None,
    content_type: str | None = None,
) -> tuple[int, bytes, dict[str, str]]:
    """Return (status, body, headers) without raising on HTTP errors."""
    import json

    url = path if path.startswith("http") else BASE + path
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    req = urllib.request.Request(url, data=data, method=method)
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    if content_type:
        req.add_header("Content-Type", content_type)
    elif body is not None:
        req.add_header("Content-Type", "application/json")

    # Header names are case-insensitive and the server sends them lower-cased,
    # so they are normalised here rather than looked up by guessed casing.
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as response:
            return response.status, response.read(), _headers(response.headers)
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read(), _headers(exc.headers)
    except urllib.error.URLError as exc:
        print(f"\n  Could not reach {url}: {exc.reason}")
        print("  Start the application with start.bat first.\n")
        sys.exit(2)


def _headers(raw: Any) -> dict[str, str]:
    return {key.lower(): value for key, value in raw.items()}


def _env_provider() -> str | None:
    """Read the configured provider from .env, for comparison with what runs."""
    env = Path(__file__).resolve().parents[1] / "apps" / "api" / ".env"
    if not env.exists():
        return None
    for line in env.read_text(encoding="utf-8", errors="replace").splitlines():
        if line.strip().startswith("OBSIDIAN_AI_PROVIDER="):
            return line.split("=", 1)[1].strip() or None
    return None


def json_of(payload: bytes) -> Any:
    import json

    return json.loads(payload.decode() or "{}")


def build_beaconing_pcap() -> bytes:
    """A capture with fixed-interval traffic, so analysis raises real findings."""
    out = bytearray(struct.pack("<IHHiIII", 0xA1B2C3D4, 2, 4, 0, 0, 65535, 1))
    for index in range(15):
        ip = (
            b"\x45\x00\x00\x28" + b"\x00\x00\x40\x00\x40\x06\x00\x00"
            + bytes([10, 0, 0, 5]) + bytes([185, 243, 115, 84])
        )
        tcp = struct.pack(">HHIIBBHHH", 51000, 443, 0, 0, 0x50, 0x02, 8192, 0, 0)
        frame = b"\x00" * 12 + b"\x08\x00" + ip + tcp
        out += struct.pack("<IIII", index * 60, 0, len(frame), len(frame)) + frame
    return bytes(out)


def multipart(filename: str, payload: bytes) -> tuple[bytes, str]:
    boundary = uuid.uuid4().hex
    body = (
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; "
        f"filename=\"{filename}\"\r\nContent-Type: application/octet-stream\r\n\r\n"
    ).encode() + payload + f"\r\n--{boundary}--\r\n".encode()
    return body, f"multipart/form-data; boundary={boundary}"


def main() -> int:
    print("\n  OBSIDIAN - verifying the reported failures\n")

    # ── Reachability ────────────────────────────────────────────────────────
    for _ in range(10):
        status, _, _ = request("GET", "http://127.0.0.1:8000/api/v1/health")
        if status == 200:
            break
        time.sleep(1)
    else:
        print("  The API did not answer. Start it with start.bat.\n")
        return 2

    # ── An account to work with ─────────────────────────────────────────────
    suffix = uuid.uuid4().hex[:8]
    credentials = {
        "email": f"verify-{suffix}@obsidian-verify.io",
        "password": "Verify-Passw0rd!",
        "full_name": "Verification Run",
    }
    status, payload, _ = request("POST", "/auth/register", body=credentials)
    if status not in (200, 201):
        print(f"  Could not create a verification account ({status}): {payload[:200]!r}")
        return 2

    status, payload, _ = request(
        "POST", "/auth/login",
        body={"email": credentials["email"], "password": credentials["password"]},
    )
    if status != 200:
        print(f"  Could not sign in as the verification account ({status}).")
        return 2
    token = json_of(payload)["tokens"]["access_token"]

    # ── A case with analysed evidence ───────────────────────────────────────
    _, payload, _ = request(
        "POST", "/cases", token=token,
        body={"title": "Verification beaconing case", "severity": "high"},
    )
    case = json_of(payload)
    body, content_type = multipart("beacon.pcap", build_beaconing_pcap())
    status, payload, _ = request(
        "POST", f"/cases/{case['id']}/evidence", token=token,
        raw=body, content_type=content_type,
    )
    check("Evidence uploads without a server error", status == 201, f"status {status}")
    evidence = json_of(payload)
    request("POST", f"/evidence/{evidence['id']}/analyze", token=token)

    print("\n  Voice commands that previously answered \"I could not find that case\"")
    for utterance, expected in [
        ("open timeline", "navigate"),
        ("open timeline module", "navigate"),
        ("I need you to open threat Intel", "navigate"),
    ]:
        _, payload, _ = request(
            "POST", "/voice/command", token=token,
            body={"utterance": utterance, "current_case_id": case["id"]},
        )
        result = json_of(payload)
        check(
            f'"{utterance}" navigates',
            result["intent"]["action"] == expected,
            f'answered "{result.get("speech")}"',
        )

    print("\n  Voice commands that previously produced no visible result")
    _, payload, _ = request(
        "POST", "/voice/command", token=token,
        body={"utterance": "what are the findings", "current_case_id": case["id"]},
    )
    result = json_of(payload)
    check(
        '"what are the findings" returns findings to render',
        bool(result.get("data", {}).get("findings")),
        f'answered "{result.get("speech")}"',
    )

    _, payload, _ = request(
        "POST", "/voice/command", token=token,
        body={"utterance": "upload evidence", "current_case_id": case["id"]},
    )
    result = json_of(payload)
    check(
        '"upload evidence" opens the uploader',
        (result.get("ui_action") or {}).get("type") == "upload_evidence",
    )

    _, payload, _ = request(
        "POST", "/voice/command", token=token,
        body={"utterance": "generate me a report on the recent case"},
    )
    result = json_of(payload)
    check(
        '"report on the recent case" resolves a case',
        result.get("succeeded") is True,
        f'answered "{result.get("speech")}"',
    )

    # ── Report download ─────────────────────────────────────────────────────
    print("\n  Report download (previously saved as download.json)")
    status, payload, _ = request(
        "POST", f"/cases/{case['id']}/reports", token=token,
        body={"profile": "technical", "format": "pdf"},
    )
    report = json_of(payload)
    check("A PDF report generates", status in (200, 201), f"status {status}")

    status, data, headers = request(
        "GET", f"/reports/{report['id']}/download", token=token
    )
    check("The download returns 200 when authenticated", status == 200, f"status {status}")
    check(
        "The bytes are a PDF, not a JSON error envelope",
        data.startswith(b"%PDF-"),
        f"began with {data[:24]!r}",
    )
    disposition = headers.get("content-disposition", "")
    check(
        "The filename is a .pdf, so the browser cannot save it as download.json",
        ".pdf" in disposition,
        f"Content-Disposition: {disposition or '(absent)'}",
    )

    # The original defect, demonstrated: a plain link sends no token.
    status, data, _ = request("GET", f"/reports/{report['id']}/download")
    check(
        "An unauthenticated download is refused - which is why a plain link failed",
        status in (401, 403),
        f"status {status}",
    )

    # ── AI provider ─────────────────────────────────────────────────────────
    print("\n  AI provider")
    status, payload, _ = request("GET", "/ai/status", token=token)
    ai = json_of(payload)
    configured = ai.get("provider")
    print(f"         provider={configured}  model={ai.get('model')}  "
          f"available={ai.get('available')}")

    check(
        "The badge reports the configured provider, not the mock",
        configured != "mock" or _env_provider() in ("mock", None),
        f"configured as {_env_provider()!r} but reporting {configured!r}",
    )
    if ai.get("degraded_reason"):
        check(f"Configuration is sound - {ai['degraded_reason']}", False)
    else:
        check("No credential is stored in the wrong setting", True)
    if not ai.get("available"):
        print(f"         {ai.get('detail')}")

    print()
    if failures:
        print(f"  {len(failures)} check(s) failed:")
        for item in failures:
            print(f"    - {item}")
        print()
        return 1

    print("  Every reported failure verified as fixed.\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
