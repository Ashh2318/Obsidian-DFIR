@echo off
REM Starts the OBSIDIAN web application. Run directly to launch only the frontend.
setlocal EnableExtensions
cd /d "%~dp0..\apps\web"

if not exist "node_modules" (
    echo  [X] Node dependencies are missing. Run setup.bat first.
    pause
    exit /b 1
)

REM Passed as a real environment variable: Next evaluates next.config.mjs
REM before loading .env.local, so a value set there would be ignored.
if not defined API_PROXY_TARGET set "API_PROXY_TARGET=http://127.0.0.1:8000"

title OBSIDIAN WEB
echo.
echo  OBSIDIAN WEB  -  http://localhost:3000
echo  Press Ctrl+C to stop.
echo.

call npm run dev

echo.
echo  The web application has stopped.
pause
