@echo off
REM ===========================================================================
REM  Starts the OBSIDIAN API.
REM ===========================================================================

setlocal EnableExtensions
cd /d "%~dp0..\apps\api"

REM The OBSIDIAN virtual environment is apps\api\.venv (we are already in apps\api).
set "VENV=.venv"

if not exist "%VENV%\Scripts\python.exe" (
    echo.
    echo  [X] The Python environment is missing.
    echo      Expected: %CD%\%VENV%\Scripts\python.exe
    echo      Run setup.bat first.
    echo.
    pause
    exit /b 1
)

"%VENV%\Scripts\python.exe" -c "import obsidian" >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [X] The Python environment is broken or its base Python was uninstalled.
    echo      Run setup.bat - it rebuilds the environment automatically.
    echo.
    pause
    exit /b 1
)

title OBSIDIAN API

echo.
echo  OBSIDIAN API  -  http://127.0.0.1:8000
echo  Docs          -  http://127.0.0.1:8000/docs
echo  Press Ctrl+C to stop.
echo.

REM Use the venv's Python directly instead of relying on uvicorn being on PATH.
"%VENV%\Scripts\python.exe" -m uvicorn obsidian.main:app --reload --host 0.0.0.0 --port 8000

echo.
echo  The API has stopped.
pause