"""Scan the project for secrets before you push it to GitHub.

    python scripts/check_secrets.py

Exit code 0 = nothing found, 1 = something looks like a secret (do NOT push).
Placeholders such as CHANGE_ME or empty values are ignored.
"""
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SKIP_DIRS = {".git", "node_modules", ".venv", "venv", ".next", "__pycache__", ".mypy_cache", ".ruff_cache", ".pytest_cache", "storage"}
SKIP_EXT = {".png", ".jpg", ".jpeg", ".gif", ".ico", ".pdf", ".woff", ".woff2", ".zip", ".db", ".lock"}
PATTERNS = {
    "OpenRouter key": re.compile(r"sk-or-v1-[0-9a-fA-F]{20,}"),
    "Anthropic key": re.compile(r"sk-ant-[A-Za-z0-9_\-]{20,}"),
    "OpenAI-style key": re.compile(r"\bsk-[A-Za-z0-9]{32,}\b"),
    "GitHub token": re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b"),
    "AWS access key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "Google API key": re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"),
    "Private key block": re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
}
ASSIGN = re.compile(r"^\s*([A-Z0-9_]*(?:KEY|SECRET|TOKEN|PASSWORD)[A-Z0-9_]*)\s*=\s*(.+?)\s*$")
PLACEHOLDER = re.compile(r"^(?:|\"\"|''|change.?me.*|<.*>|your[-_ ].*|example.*|xxx+|\*+|none|null|false|true)$", re.I)

problems = []
for base, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
    for name in files:
        path = os.path.join(base, name)
        rel = os.path.relpath(path, ROOT)
        ext = os.path.splitext(name)[1].lower()
        if ext in SKIP_EXT:
            continue
        is_env = name == ".env" or (name.startswith(".env") and not name.endswith(".example"))
        if is_env:
            problems.append((rel, 0, "environment file must not be committed"))
        try:
            text = open(path, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        for i, line in enumerate(text.splitlines(), 1):
            for label, rx in PATTERNS.items():
                if rx.search(line):
                    problems.append((rel, i, label))
            if name.endswith(".example") or name.endswith((".md", ".py", ".ts", ".tsx", ".js", ".mjs", ".yml", ".yaml", ".toml", ".json", ".bat")):
                m = ASSIGN.match(line) if (is_env or name.endswith(".env") or name.endswith(".example")) else None
                if m and not PLACEHOLDER.match(m.group(2).strip().strip("\"'")):
                    if not name.endswith(".example"):
                        problems.append((rel, i, f"{m.group(1)} has a real-looking value"))

if problems:
    print("POSSIBLE SECRETS FOUND - do not push until these are removed:\n")
    for rel, i, why in problems:
        print(f"  {rel}:{i}  {why}")
    sys.exit(1)
print("OK - no secrets or environment files found.")
