# Project Memory

Context a new engineer needs and cannot recover from the code alone: why things
are the way they are, and which traps have already been hit.

`ARCHITECTURE.md` describes the design. `docs/adr/` records the decisions.
`CHANGELOG.md` records what changed. This file records what *bit us*.

---

## Non-obvious decisions

**SQLite is the development default, not a placeholder.** Persistence is
dialect-agnostic. `DATABASE_URL` selects the backend and nothing else changes.
This exists because requiring Docker before a line of code runs stalls
development on infrastructure. See ADR 0001.

**Every external dependency sits behind a protocol with an offline mock.** AI
providers, threat-intel feeds, storage. The mocks are *deterministic* — seeded
from a hash of the input — because you cannot write a stable test against a live
model or a reputation feed that changes hourly.

**The PDF writer is hand-written.** reportlab needs Pillow (a 7 MB binary
wheel); WeasyPrint needs cairo and pango. Neither installs in an air-gapped
environment. Reports are text and tables, so the base-14 PDF fonts suffice and
nothing is embedded. If you touch `reporting/pdf_writer.py`, the test that
verifies every cross-reference offset resolves is the one that matters — a wrong
offset produces a file no reader opens and gives no other symptom.

**The PCAP parser is hand-written too.** Scapy is too slow inside a request and
tshark is an external binary. libpcap and pcapng are simple formats.

**Voice executes the same services the UI calls.** `voice/resolver.py` calls
`CaseService.change_status`, `AnalysisService.analyze` and so on directly. If
voice could do something the UI could not, the two would drift and only one
would be tested. This is why Voice Mode took an afternoon rather than a month —
the seam was reserved from the start (ADR 0004).

---

## Traps already hit — do not re-introduce these

**`backdrop-filter` breaks `position: fixed`.** An ancestor with
`backdrop-filter`, `filter`, `transform`, `perspective` or `contain` becomes the
containing block for fixed descendants. The voice overlay was rendered inside
the topbar (which has `backdrop-blur`) and got trapped in a 48-pixel strip.
Anything full-screen must be portalled to `document.body` — Radix primitives do
this for you; hand-rolled overlays do not.

**cmd expands `%VAR%` when it parses a block, not when it runs.** Assigning a
variable inside `if (...)` and reading it in the same block always reads the
*old* value. This shipped twice: once in `test.bat` (silently passing a failing
type check) and once in `start.bat` (reporting a migration failure every launch,
so nothing ever started). Use a `call :subroutine` instead. Batch files also
need CRLF endings or `goto` misbehaves.

**Windows resolves `localhost` to IPv6 first.** uvicorn's `--host 0.0.0.0` binds
IPv4 only, so the API answered `curl 127.0.0.1` and refused the browser. Fixed
structurally: the frontend calls its own origin and `next.config.mjs` proxies
server-side, so only one hostname is ever resolved.

**`NEXT_PUBLIC_*` is inlined when the dev server starts.** Editing `.env.local`
does nothing until the process restarts. Separately, `next.config.mjs` is
evaluated *before* `.env.local` loads, so `API_PROXY_TARGET` set there is
ignored entirely — `scripts/run-web.bat` passes it as a real environment
variable.

**Server-side defaults expire the attribute after a write.** `updated_at` uses
`onupdate`, so reading it after an UPDATE triggered a lazy refresh — synchronous
I/O on a greenlet with no await context, surfacing as `MissingGreenlet` inside
response serialisation. Fixed with `eager_defaults=True` on `Base`.

**Python classifies RFC 5737 documentation ranges as private.** `203.0.113.x`,
`198.51.100.x` and `192.0.2.x` are correctly discarded by the IOC extractor.
Tests needing a routable address must use genuinely public space.

**Pydantic serialises UTC with a trailing `Z`**, which `datetime.fromisoformat`
only accepts from Python 3.11. The suite runs on 3.10, so tests normalise it.

---

## Known limitations

- **Analysis runs inline in the request.** Fine at current evidence sizes. The
  contract is already a plain result object, so moving it to a worker pool
  requires no change above `AnalysisService`.
- **No engine for EVTX, APK or documents.** The registry returns `None` and the
  API refuses with a clear message rather than failing obscurely.
- **Mock providers are the default.** The AI assistant and threat-intel
  verdicts are simulated until a key is configured. `configure.bat` sets them up.
- **Speech recognition uses the Web Speech API.** Chrome streams audio to Google
  — a genuine disclosure risk on regulated investigations, surfaced in the UI.
  The hooks are thin so local Whisper and Piper can replace them.
- **`packages/` extraction is deferred.** With one frontend there is nothing to
  share yet; pnpm and Turborepo wait until there is.

---

## Working on this codebase

Run `setup.bat` once, then `start.bat`. It applies pending migrations itself.
`configure.bat` sets AI and threat-intel providers. `doctor.bat` diagnoses a
backend that will not start. `test.bat` runs the suite.

**Regenerate reference docs after changing models or routes:**

```bash
python scripts/generate_docs.py
```

`DATABASE_SCHEMA.md` and `API_REFERENCE.md` are generated — edit the code, not
the markdown.

**Layers, and the dependency rule.** `api → services → repositories → db`. A
router never touches a repository. A service never builds an HTTP response. The
domain layer imports neither FastAPI nor SQLAlchemy. Import something inside a
function only to break a genuine cycle, and say so in a comment.
