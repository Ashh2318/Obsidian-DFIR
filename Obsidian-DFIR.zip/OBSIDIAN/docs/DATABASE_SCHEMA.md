<!-- GENERATED FILE — do not edit by hand.
     Produced by scripts/generate_docs.py from the live code.
     Run `python scripts/generate_docs.py` after changing models or routes. -->

# Database Schema

Generated from SQLAlchemy metadata on 26 July 2026.

The schema is dialect-agnostic: identical DDL runs on SQLite locally and
PostgreSQL in production (see [ADR 0001](adr/0001-dialect-agnostic-persistence.md)).
UUID primary keys are stored as 36-character strings for that reason.

---

## `audit_logs`

| Column | Type | Null | Default | Notes |
|---|---|---|---|---|
| `actor_id` | VARCHAR(36) | yes | — | FK → `users.id`, indexed |
| `actor_email` | VARCHAR(320) | yes | — | — |
| `action` | VARCHAR(64) | no | — | indexed |
| `resource_type` | VARCHAR(64) | yes | — | — |
| `resource_id` | VARCHAR(64) | yes | — | indexed |
| `succeeded` | BOOLEAN | no | app | — |
| `message` | TEXT | yes | — | — |
| `ip_address` | VARCHAR(64) | yes | — | — |
| `user_agent` | VARCHAR(512) | yes | — | — |
| `request_id` | VARCHAR(64) | yes | — | indexed |
| `meta` | JSON | yes | — | — |
| `id` | VARCHAR(36) | no | app | **PK**, indexed |
| `created_at` | DATETIME | no | server | — |
| `updated_at` | DATETIME | no | server | — |

**Indexes**

- `ix_audit_logs_action` on `action`
- `ix_audit_logs_actor_id` on `actor_id`
- `ix_audit_logs_id` on `id`
- `ix_audit_logs_request_id` on `request_id`
- `ix_audit_logs_resource_id` on `resource_id`

---

## `cases`

| Column | Type | Null | Default | Notes |
|---|---|---|---|---|
| `reference` | VARCHAR(32) | no | — | unique, indexed |
| `title` | VARCHAR(200) | no | — | — |
| `summary` | TEXT | yes | — | — |
| `status` | VARCHAR(32) | no | app | indexed |
| `severity` | VARCHAR(16) | no | app | indexed |
| `owner_id` | VARCHAR(36) | no | — | FK → `users.id`, indexed |
| `assignee_id` | VARCHAR(36) | yes | — | FK → `users.id`, indexed |
| `opened_at` | DATETIME | yes | — | — |
| `closed_at` | DATETIME | yes | — | — |
| `id` | VARCHAR(36) | no | app | **PK**, indexed |
| `created_at` | DATETIME | no | server | — |
| `updated_at` | DATETIME | no | server | — |

**Indexes**

- `ix_cases_assignee_id` on `assignee_id`
- `ix_cases_id` on `id`
- `ix_cases_owner_id` on `owner_id`
- `ix_cases_reference` on `reference`
- `ix_cases_severity` on `severity`
- `ix_cases_status` on `status`

---

## `conversations`

| Column | Type | Null | Default | Notes |
|---|---|---|---|---|
| `case_id` | VARCHAR(36) | yes | — | FK → `cases.id`, indexed |
| `owner_id` | VARCHAR(36) | no | — | FK → `users.id`, indexed |
| `title` | VARCHAR(200) | no | — | — |
| `id` | VARCHAR(36) | no | app | **PK**, indexed |
| `created_at` | DATETIME | no | server | — |
| `updated_at` | DATETIME | no | server | — |

**Indexes**

- `ix_conversations_case_id` on `case_id`
- `ix_conversations_id` on `id`
- `ix_conversations_owner_id` on `owner_id`

---

## `evidence`

| Column | Type | Null | Default | Notes |
|---|---|---|---|---|
| `case_id` | VARCHAR(36) | no | — | FK → `cases.id`, indexed |
| `uploaded_by_id` | VARCHAR(36) | yes | — | FK → `users.id`, indexed |
| `original_filename` | VARCHAR(512) | no | — | — |
| `stored_path` | VARCHAR(1024) | no | — | — |
| `media_type` | VARCHAR(160) | yes | — | — |
| `size_bytes` | BIGINT | no | app | — |
| `evidence_type` | VARCHAR(32) | no | app | indexed |
| `status` | VARCHAR(32) | no | app | indexed |
| `sha256` | VARCHAR(64) | no | — | indexed |
| `md5` | VARCHAR(32) | yes | — | indexed |
| `notes` | TEXT | yes | — | — |
| `analysis_summary` | JSON | yes | — | — |
| `id` | VARCHAR(36) | no | app | **PK**, indexed |
| `created_at` | DATETIME | no | server | — |
| `updated_at` | DATETIME | no | server | — |

**Indexes**

- `ix_evidence_case_id` on `case_id`
- `ix_evidence_evidence_type` on `evidence_type`
- `ix_evidence_id` on `id`
- `ix_evidence_md5` on `md5`
- `ix_evidence_sha256` on `sha256`
- `ix_evidence_status` on `status`
- `ix_evidence_uploaded_by_id` on `uploaded_by_id`

---

## `ioc_enrichments`

| Column | Type | Null | Default | Notes |
|---|---|---|---|---|
| `ioc_type` | VARCHAR(32) | no | — | indexed |
| `value` | VARCHAR(512) | no | — | indexed |
| `verdict` | VARCHAR(16) | no | app | indexed |
| `score` | INTEGER | no | app | — |
| `providers` | JSON | yes | — | — |
| `fetched_at` | DATETIME | no | — | — |
| `expires_at` | DATETIME | no | — | indexed |
| `id` | VARCHAR(36) | no | app | **PK**, indexed |
| `created_at` | DATETIME | no | server | — |
| `updated_at` | DATETIME | no | server | — |

**Constraints**

- `uq_enrichment_type_value` — unique on `ioc_type`, `value`

**Indexes**

- `ix_ioc_enrichments_expires_at` on `expires_at`
- `ix_ioc_enrichments_id` on `id`
- `ix_ioc_enrichments_ioc_type` on `ioc_type`
- `ix_ioc_enrichments_value` on `value`
- `ix_ioc_enrichments_verdict` on `verdict`

---

## `iocs`

| Column | Type | Null | Default | Notes |
|---|---|---|---|---|
| `case_id` | VARCHAR(36) | no | — | FK → `cases.id`, indexed |
| `first_seen_evidence_id` | VARCHAR(36) | yes | — | FK → `evidence.id`, indexed |
| `ioc_type` | VARCHAR(32) | no | — | indexed |
| `value` | VARCHAR(512) | no | — | indexed |
| `severity` | VARCHAR(16) | no | app | indexed |
| `confidence` | INTEGER | no | app | — |
| `sightings` | INTEGER | no | app | — |
| `context` | TEXT | yes | — | — |
| `meta` | JSON | yes | — | — |
| `id` | VARCHAR(36) | no | app | **PK**, indexed |
| `created_at` | DATETIME | no | server | — |
| `updated_at` | DATETIME | no | server | — |

**Constraints**

- `uq_ioc_case_type_value` — unique on `case_id`, `ioc_type`, `value`

**Indexes**

- `ix_iocs_case_id` on `case_id`
- `ix_iocs_first_seen_evidence_id` on `first_seen_evidence_id`
- `ix_iocs_id` on `id`
- `ix_iocs_ioc_type` on `ioc_type`
- `ix_iocs_severity` on `severity`
- `ix_iocs_value` on `value`

---

## `messages`

| Column | Type | Null | Default | Notes |
|---|---|---|---|---|
| `conversation_id` | VARCHAR(36) | no | — | FK → `conversations.id`, indexed |
| `role` | VARCHAR(16) | no | — | — |
| `content` | TEXT | no | — | — |
| `provider` | VARCHAR(32) | yes | — | — |
| `model` | VARCHAR(120) | yes | — | — |
| `input_tokens` | INTEGER | no | app | — |
| `output_tokens` | INTEGER | no | app | — |
| `meta` | JSON | yes | — | — |
| `id` | VARCHAR(36) | no | app | **PK**, indexed |
| `created_at` | DATETIME | no | server | — |
| `updated_at` | DATETIME | no | server | — |

**Indexes**

- `ix_messages_conversation_id` on `conversation_id`
- `ix_messages_id` on `id`

---

## `refresh_tokens`

| Column | Type | Null | Default | Notes |
|---|---|---|---|---|
| `user_id` | VARCHAR(36) | no | — | FK → `users.id`, indexed |
| `token_hash` | VARCHAR(64) | no | — | unique, indexed |
| `family_id` | VARCHAR(36) | no | — | indexed |
| `expires_at` | DATETIME | no | — | indexed |
| `revoked_at` | DATETIME | yes | — | — |
| `revoked_reason` | VARCHAR(64) | yes | — | — |
| `user_agent` | VARCHAR(512) | yes | — | — |
| `ip_address` | VARCHAR(64) | yes | — | — |
| `id` | VARCHAR(36) | no | app | **PK**, indexed |
| `created_at` | DATETIME | no | server | — |
| `updated_at` | DATETIME | no | server | — |

**Indexes**

- `ix_refresh_tokens_expires_at` on `expires_at`
- `ix_refresh_tokens_family_id` on `family_id`
- `ix_refresh_tokens_id` on `id`
- `ix_refresh_tokens_token_hash` on `token_hash`
- `ix_refresh_tokens_user_id` on `user_id`

---

## `reports`

| Column | Type | Null | Default | Notes |
|---|---|---|---|---|
| `case_id` | VARCHAR(36) | no | — | FK → `cases.id`, indexed |
| `generated_by_id` | VARCHAR(36) | yes | — | FK → `users.id`, indexed |
| `title` | VARCHAR(200) | no | — | — |
| `profile` | VARCHAR(16) | no | — | indexed |
| `format` | VARCHAR(16) | no | — | — |
| `content` | BLOB | no | — | — |
| `size_bytes` | INTEGER | no | app | — |
| `signature` | VARCHAR(64) | no | — | — |
| `summary` | JSON | yes | — | — |
| `id` | VARCHAR(36) | no | app | **PK**, indexed |
| `created_at` | DATETIME | no | server | — |
| `updated_at` | DATETIME | no | server | — |

**Indexes**

- `ix_reports_case_id` on `case_id`
- `ix_reports_generated_by_id` on `generated_by_id`
- `ix_reports_id` on `id`
- `ix_reports_profile` on `profile`

---

## `users`

| Column | Type | Null | Default | Notes |
|---|---|---|---|---|
| `email` | VARCHAR(320) | no | — | unique, indexed |
| `full_name` | VARCHAR(120) | no | — | — |
| `password_hash` | VARCHAR(255) | no | — | — |
| `role` | VARCHAR(32) | no | app | indexed |
| `organization` | VARCHAR(160) | yes | — | — |
| `job_title` | VARCHAR(120) | yes | — | — |
| `is_active` | BOOLEAN | no | app | — |
| `is_verified` | BOOLEAN | no | app | — |
| `failed_login_attempts` | INTEGER | no | app | — |
| `locked_until` | DATETIME | yes | — | — |
| `last_login_at` | DATETIME | yes | — | — |
| `id` | VARCHAR(36) | no | app | **PK**, indexed |
| `created_at` | DATETIME | no | server | — |
| `updated_at` | DATETIME | no | server | — |

**Indexes**

- `ix_users_email` on `email`
- `ix_users_id` on `id`
- `ix_users_role` on `role`

---
