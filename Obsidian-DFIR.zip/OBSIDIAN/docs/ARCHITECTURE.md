# OBSIDIAN — System Architecture

> Observe. Analyze. Defend.

OBSIDIAN is an AI-first cybersecurity investigation platform delivered as an
installable Progressive Web Application backed by a Python service tier.

---

## 1. Architectural Style

OBSIDIAN follows **Clean Architecture** with a strict, one-directional
dependency rule. Inner layers never import outer layers.

```
        ┌──────────────────────────────────────────────┐
        │  Interface Layer   (api/v1/routers, schemas) │
        ├──────────────────────────────────────────────┤
        │  Application Layer (services)                │
        ├──────────────────────────────────────────────┤
        │  Domain Layer      (domain/, enums, rules)   │
        ├──────────────────────────────────────────────┤
        │  Infrastructure    (db, repositories, ai)    │
        └──────────────────────────────────────────────┘

  routers ──► services ──► repositories ──► database
                  │
                  └──────► ai providers (protocol-bound)
```

**The rule:** a router never touches a repository or a SQLAlchemy session
directly. A service never builds an HTTP response. The domain layer imports
nothing from FastAPI or SQLAlchemy.

This is what makes the platform survivable. Analysis engines (PCAP and text/log today; EVTX and APK are planned)
land in the application layer as services and require zero changes to the
transport layer.

## 2. Runtime Topology

| Component  | Technology                | Dev (local)          | Production           |
|------------|---------------------------|----------------------|----------------------|
| Web        | Next.js 15 (App Router)   | `next dev` :3000     | Node server / static |
| API        | FastAPI + Uvicorn         | :8000                | Uvicorn behind Nginx |
| Database   | SQLAlchemy 2.0 async      | SQLite (aiosqlite)   | PostgreSQL (asyncpg) |
| Cache/Rate | Cache protocol            | In-memory fallback   | Redis                |
| Storage    | Storage protocol          | Local filesystem     | Local / S3-compatible|
| AI         | Provider protocol         | Mock provider        | Claude / OpenAI / Ollama |

Every row in the right-hand columns is reached through an **interface**, not a
concrete import. Swapping SQLite for PostgreSQL is one environment variable.
Swapping the mock AI provider for Claude is one environment variable.

## 3. Backend Package Layout

```
apps/api/src/obsidian/
├── main.py                 Application factory, lifespan, middleware wiring
├── core/
│   ├── config.py           Typed settings (pydantic-settings), single source of truth
│   ├── security.py         Argon2id hashing, JWT issue/verify
│   ├── exceptions.py       Domain exception hierarchy → HTTP mapping
│   ├── logging.py          Structured JSON logging, request correlation IDs
│   ├── middleware.py       Request ID, timing, security headers
│   ├── cache.py            Cache protocol + in-memory and Redis backends
│   └── rate_limit.py       Sliding-window limiter built on the cache protocol
├── db/
│   ├── base.py             DeclarativeBase, naming convention, UUID/timestamp mixins
│   ├── session.py          Async engine + sessionmaker, dialect-aware tuning
│   └── models/             ORM models (one file per aggregate)
├── domain/
│   └── enums.py            Role, AuditAction, CaseStatus, Severity, EvidenceType...
├── repositories/
│   ├── base.py             Generic typed repository (CRUD + pagination)
│   └── *.py                Aggregate-specific query methods
├── services/
│   ├── auth_service.py     Registration, login, refresh rotation, revocation
│   └── audit_service.py    Append-only audit trail
├── schemas/                Pydantic request/response contracts
├── ai/
│   ├── base.py             AIProvider protocol, message/response value objects
│   ├── registry.py         Provider factory + runtime resolution
│   └── providers/          mock, anthropic, openai, ollama
└── api/
    ├── deps.py             Dependency injection: session, current user, RBAC
    └── v1/routers/         Thin HTTP handlers
```

## 4. Authentication & Authorization

**Token model — access + rotating refresh.**

1. `POST /api/v1/auth/login` returns a short-lived **access token** (JWT, 15 min,
   in memory on the client) and a long-lived **refresh token** (7 days).
2. The refresh token is stored **hashed** (SHA-256) in the database. A stolen
   database dump yields no usable refresh tokens.
3. `POST /api/v1/auth/refresh` **rotates**: the presented token is revoked and a
   new one issued. Reuse of an already-revoked token triggers **family
   revocation** — every active session for that user is killed, because reuse is
   the signature of a stolen token.
4. Every JWT carries a `jti` and a `typ` claim. An access token presented at the
   refresh endpoint (or vice versa) is rejected.

**RBAC.** Four roles, strictly ordered:

```
VIEWER (10) < ANALYST (20) < INVESTIGATOR (30) < ADMIN (40)
```

Authorization is a **dependency**, not an `if` statement inside a handler:

```python
@router.get("/users", dependencies=[Depends(require_role(Role.ADMIN))])
```

**Audit.** Every security-relevant event is appended to `audit_logs` with actor,
action, resource, IP, user agent and structured metadata. The table is
append-only by policy — there is no update or delete path in the repository.

## 5. AI Provider Abstraction

```python
class AIProvider(Protocol):
    name: str
    async def complete(self, req: CompletionRequest) -> CompletionResponse: ...
    async def stream(self, req: CompletionRequest) -> AsyncIterator[str]: ...
    async def health(self) -> ProviderHealth: ...
```

Services depend on the protocol. `registry.get_provider()` resolves the
configured implementation at runtime. Adding a provider means adding one file and
one registry entry — no service, router, or UI change.

The **mock provider** is deterministic (hash-seeded), which makes AI-dependent
tests reproducible in CI and lets the entire product be developed and demoed
without an API key.

## 6. Frontend Architecture

```
apps/web/src/
├── app/
│   ├── (auth)/             Unauthenticated route group — login, register
│   └── (app)/              Authenticated route group — shell + modules
├── components/
│   ├── ui/                 Design-system primitives (button, input, card...)
│   ├── layout/             Sidebar, topbar, command palette
│   └── providers/          Query client, auth, theme, toasts
├── lib/
│   ├── api-client.ts       Fetch wrapper: silent refresh, single-flight queueing
│   ├── auth-store.ts       In-memory access token (never localStorage)
│   └── utils.ts
└── hooks/
```

**Token storage decision.** The access token lives in **memory only**. It is
never written to `localStorage`, which is readable by any injected script — the
standard XSS token-theft path. The refresh token lives in an `httpOnly` cookie
in production. On page load the client silently calls `/auth/refresh` to
rehydrate the session.

**Silent refresh is single-flight.** If ten requests 401 simultaneously, exactly
one refresh call is made; the other nine await it and replay. Without this you
get a refresh-token stampede that trips your own rate limiter and rotation logic.

## 7. Security Posture

| Control | Implementation |
|---|---|
| Password storage | Argon2id (memory-hard, tuned cost) |
| Token theft | Hashed refresh tokens, rotation, reuse → family revocation |
| Transport hardening | HSTS, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, CSP |
| Rate limiting | Sliding window, per-IP, stricter on auth endpoints |
| Input validation | Pydantic v2 at every boundary, explicit field constraints |
| Injection | Parameterized ORM queries only; no string-built SQL |
| Error leakage | Domain exceptions → sanitized responses; internals only in logs |
| Audit | Append-only trail with actor, IP, user agent |
| CORS | Explicit origin allowlist, credentials-aware |

## 8. Deferred by Design

**Voice Command Mode** is deliberately not in Phase 0. The intent layer it needs
(action registry, conversation memory, entity resolution for "compare this with
yesterday") only has meaning once there are real actions to invoke. Building the
speech pipeline over an empty application produces a demo that says
"analysis complete" about nothing.

The seam is reserved: voice will emit `Intent` objects that resolve to the same
service calls the UI invokes. The service layer is already the single execution
point for every action, which is precisely what makes that possible later.
