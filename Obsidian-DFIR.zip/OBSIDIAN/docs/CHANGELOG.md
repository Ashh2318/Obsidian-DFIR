# Changelog

All notable changes to OBSIDIAN are recorded here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project uses [Semantic Versioning](https://semver.org/).

---

## [Unreleased]

### Fixed — The AI provider was configured and still did nothing

The badge reported the mock while `.env` said `ollama`, and the assistant never
worked. Two independent faults:

**The key was in the model setting.** `configure.bat` asks "Model name
[llama3.1]:" and accepts free text, so a pasted API key was stored as
`OBSIDIAN_AI_MODEL` and sent as the name of a model. Every request failed against
a model that cannot exist. The key-detection helper already existed but dismissed
anything containing a dot as a hostname — and Ollama keys are `<hex id>.<secret>`,
so they went straight through. Detection now recognises them, the model prompt
rejects them, and `configure.bat` offers to move a misplaced key into the correct
variable on startup.

**Ollama Cloud was not supported at all.** The provider only spoke to a local
server and sent no credential, so a hosted key could not work however it was
stored. Supplying `OBSIDIAN_OLLAMA_API_KEY` now selects `https://ollama.com` and
sends `Authorization: Bearer`; the wire format is identical, so only the
transport differs. The base URL follows the credential — a key with a stale
`localhost` base would otherwise send a cloud secret to a loopback address that
is not listening. Health treats an empty model list as normal for the hosted
service, which reports no local inventory; requiring a match there marked a
working provider unavailable.

The status badge now reads `ollama · unavailable` rather than just naming a
provider, and states the reason. A provider that is configured but not working is
the case worth reporting loudly; naming it and stopping there is accurate and
useless.

### Added — Speech can be interrupted

Replies ran to completion with no way to stop them. Speech is now interruptible
by pressing Space or Escape, clicking the orb, pressing Stop speaking, or simply
issuing the next command. Long replies are queued sentence by sentence rather
than as one utterance, so an interruption takes effect at the current sentence
instead of after a minute of audio — and because Chrome truncates a single
utterance after roughly fifteen seconds, long answers are no longer cut off.

Each utterance carries a generation marker. A late `onend` from a cancelled
utterance previously cleared the state of the one that replaced it, which could
leave `speaking` stuck true and the microphone suspended for the rest of the
session.

### Fixed — The voice list was empty

Voices were read once on mount, and Chrome populates them asynchronously —
on Windows a second or two after first paint, and `voiceschanged` does not
reliably fire when the list is already warm. The list is now polled until it
appears. When a machine genuinely has no voices installed, that is stated
explicitly rather than leaving an empty dropdown, and a test button confirms
audio actually plays: silence has several causes and they are indistinguishable
without a way to try one.

### Fixed — Every download saved a JSON error instead of the file

Four downloads in a row landed as `download.json`, and Chrome reported the file
"wasn't available on site". The cause was in the markup, not the endpoint:

```tsx
<a href={reportsApi.downloadUrl(r.id)} download>
```

An anchor is a browser *navigation*, not a `fetch`. It cannot carry the
`Authorization` header, so every download arrived at the API unauthenticated,
got a 401, and the browser saved the JSON error envelope — naming it from the
`application/json` content type, which is where the `.json` came from. Nothing
in the UI reported a failure, because nothing had failed as far as the page was
concerned.

Downloads now go through `downloadFile`, which fetches the bytes with the token,
refreshes once on a 401 exactly as `apiRequest` does, and hands the result to
the browser as a blob URL. The filename comes from `Content-Disposition` when
the server sends one. Failures surface as toasts through `useDownload` rather
than being written to disk. The same defect affected evidence downloads and is
fixed with them.

### Fixed — "Open timeline" tried to open a case called "timeline"

Reported against four separate utterances, all answered with *"I could not find
that case"*: `open timeline`, `open timeline module`, `open threat intel`, and
`open 3D Intel`. Two mistakes compounded:

1. The spoken-reference capture took whatever followed `open`, so `timeline`
   became a case reference.
2. `OPEN_CASE` was evaluated *before* `NAVIGATE`, so having produced a bogus
   reference, the parser then guaranteed it would be used.

Navigation is now resolved first, and any phrase matching a known module is
excluded from the spoken-reference capture. A navigation *verb* is still
required — matching on the module name alone made "can you get me through the
cases" navigate to `/cases` instead of answering the question, a regression the
existing suite caught immediately.

Unrecognised references no longer dead-end either. `open 3D Intel` is what the
recogniser heard for "threat intel"; no amount of matching recovers that, so the
reply now lists the cases that do exist instead of refusing and stopping.

### Fixed — "What are the findings" said something and showed nothing

The reply was *"Let me look at the case evidence."* and then nothing happened at
all. `ask_assistant` navigated to `/assistant` and discarded the question, so it
was never asked. Findings are now a first-class intent answered from stored
analysis — they are already structured, and reading them back is faster and more
trustworthy than having a model paraphrase them. The payload carries the
findings themselves, rendered in the HUD with a severity chart, so the screen
and the speech always agree. Questions that genuinely need the assistant are now
streamed and spoken in place rather than abandoned at a route change.

### Fixed — Report PDFs printed `\(` and `?` in place of punctuation

Every report cover read `S. Raybole \(Lead Analyst\)`, and every bulleted
recommendation began with `?`. The escape helper emitted a doubled backslash, so
the escape character itself was printed, and the bullet glyph fell through to the
unknown-character marker. Both produced structurally valid PDFs, so the entire
suite stayed green — the defects were only visible by rasterising a page and
reading it. Escaping is now single, WinAnsi glyphs are addressed by octal code,
and there are regression tests at both the helper and rendered-document level.

### Added — Branded reports, voice-driven upload, and a verification script

Reports open with the OBSIDIAN mark drawn as real vector art: the same faceted
crystal as the web logo, converted from its SVG viewBox into PDF path operators
with the brand gradient as an axial shading pattern. No image XObject, so no
imaging dependency is introduced.

"Upload evidence" now carries the analyst to the uploader with it focused.
Choosing a file needs a user gesture no script may synthesise, and the spoken
reply says so rather than implying the upload happened.

`verify.bat` exercises every reported failure against a running instance and
names the symptom each check belongs to, so a regression points at the complaint
it broke rather than at a line number.

### Fixed — The voice picker could not be opened

It was hidden entirely until `getVoices()` had populated, which reads as a
missing feature rather than a pending one. It is now always rendered. The
underlying cause of the empty list was an `en-*` filter: on a machine whose
installed voices are another locale, every voice was excluded. English is now
ranked first rather than being the only thing offered.

### Fixed — The assistant was transcribing its own speech as commands

Observed in the exchange history: `"you can ask me to open a case by Reference
status"` appeared as a *user* utterance. That is the assistant's own help text,
captured by the microphone during playback and submitted as the next command.
The system was holding a conversation with itself.

Recognition is now suspended for the whole duration of synthesis and resumed
afterwards. The suspend is signalled *before* the utterance begins rather than
on its `onstart` event, because there is a gap of tens of milliseconds before
audio starts and a live recogniser captures the first syllable. Resume waits
400 ms for the audio device to settle, since restarting immediately picks up
the tail.

### Fixed — Voice mode never started listening on open

The guard ref was set on the first render, before the recognition-support probe
had resolved. When support became available the effect re-ran, saw the guard,
and returned early — so `start()` was never called and the microphone button
had to be pressed every single time. The guard is now set only once support is
known.

### Changed — Unrecognised phrasing is answered, not refused

"Can you get me through the cases" was rejected with "I did not catch a command
I recognise". A rule engine cannot enumerate every phrasing a person will use,
and refusing anything unmatched made the system feel broken. Unmatched input is
now routed to the case-grounded assistant.

The `help` pattern was also too greedy: a bare `\bhelp\b` captured "help me
understand this attack", which is a question, not a request for the command list.

### Added — Scope boundary

Questions plainly outside the platform's remit — weather, sport, entertainment,
cooking, trivia — are declined with "Sorry, I cannot help with that. I only work
with security investigations in OBSIDIAN." The detector is deliberately narrow
and the system prompt enforces the same boundary, because wrongly refusing a
real security question costs far more than politely answering an odd one.
General security and forensics questions remain in scope: an analyst reasoning
about an incident needs them.

### Added — Selectable synthesis voices

Installed English voices are enumerated and selectable from the HUD header, with
an immediate spoken preview — a voice is chosen by ear, not by name. Cloud
voices are labelled as such, since they send the text off-device. The choice
persists.

### Fixed — Wake word could fail silently

Chrome refuses the microphone to a session started without a user gesture, and
fails silently: `start()` resolves, no error fires, no audio arrives. The hook
now reports that state, and the topbar microphone shows amber with an
explanatory tooltip rather than appearing armed. Wake-word firing is also
de-duplicated — interim and final results both contain the wake word and were
triggering it twice.

### Tests
255 passing, up from 248. Two tests asserting the old refusal behaviour were
replaced with coverage of the new routing, plus off-topic identification and a
guard that genuine security questions are never classified as off-topic.

### Fixed — A missing AI key stopped the entire application from starting

`get_provider()` raised `ConfigurationError` inside the FastAPI lifespan, so
selecting an AI provider without a key took the whole service down at boot.

That is a failure of proportion. The AI assistant is one feature among many —
authentication, cases, evidence, analysis, timeline, threat intel and reporting
are all unaffected by it — and none of them should be unavailable because an
optional credential is absent. The same reasoning already governed
threat-intelligence feeds, where a provider that cannot be built is skipped with
a warning; it simply had not been applied here.

The registry now degrades to the deterministic mock, logs a warning naming the
configured provider and the remedy, and reports `degraded_reason` through
`/ai/status` so the UI states that it is running on the mock rather than
implying the configured provider is live. Verified by booting with the exact
failing configuration.

### Fixed — `configure.bat` accepted configurations that cannot work

Two related problems, both surfacing only as a stack trace at the next startup:

- **A provider could be written without its key.** Selecting OpenAI or Anthropic
  and leaving the key blank saved a configuration guaranteed to fail. It now
  refuses and leaves the previous provider in place. Local gateways
  (`localhost`, `127.0.0.1`) are exempt, since they accept any key.
- **The key and base-URL prompts are adjacent and were transposed.** A key
  pasted into the URL field left the key field empty. A value that looks like a
  key rather than a URL is now detected and moved to the correct field, and a
  base URL not starting with `http` is rejected outright.

### Fixed — `start.bat` reported a migration failure on every launch

The automatic-migration block added last release put its failure check *inside*
a parenthesised block. cmd substitutes `%VAR%` when it parses a block, before
the `set` within it runs, so the check always read an empty value, always took
the failure branch, and exited. Nothing ever started.

This is the identical trap already found and fixed in `test.bat`, reintroduced
because the change was shipped without being run — batch cannot be executed in
the development sandbox. The static audit missed it because it only scanned for
`%errorlevel%` inside blocks, not any assigned-then-read variable. The check is
now broader and all seven scripts pass it.

### Added — Code quality layer

The tooling the constitution asked for, deferred until now.

- **ESLint** flat config on `next/core-web-vitals` plus TypeScript rules chosen
  for bugs this codebase has actually hit — unused values from half-finished
  refactors, missing hook dependencies (the cause of the voice orb showing a
  stale state), `any` erasing type safety.
- **Prettier** with the Tailwind plugin, so class order is canonical and diffs
  stop containing pure reorderings. It owns formatting; no lint rule overlaps it.
- **Husky + lint-staged.** `pre-commit` formats and lints only staged files;
  `pre-push` runs the backend suite, because a failure caught locally costs
  thirty seconds and one caught in CI costs a round trip; `commit-msg` enforces
  a Conventional Commits type prefix so a changelog stays generatable.
- **Ruff hardened** with `ASYNC` (blocking calls in async paths), `S` (bandit),
  `DTZ` (naive datetimes) and `T20` (stray prints), with per-directory
  exemptions where those patterns are legitimate.
- **mypy** configured strict for `domain`, `repositories` and `services` — the
  layers holding the business rules — and exempt for provider adapters that
  parse untyped third-party JSON, where annotating every branch adds noise
  without safety.
- **pytest configuration consolidated** into `pyproject.toml`; `pytest.ini` is
  removed rather than left as a second source of truth.
- **GitHub Actions CI**: backend on Python 3.10 and 3.13, lint, format, types,
  tests with coverage, plus a check that migrations apply to an *empty*
  database — a migration that only works incrementally fails the first thing a
  new contributor runs. Frontend lint, typecheck and build. `npm audit` fails
  the build at high severity: a security product shipping known-vulnerable
  dependencies is not a style issue.

### Added — Documentation

- **`DATABASE_SCHEMA.md`** and **`API_REFERENCE.md`** are now *generated* by
  `scripts/generate_docs.py` from SQLAlchemy metadata and the live OpenAPI
  schema. Hand-written schema documentation is wrong within a sprint; these
  cannot drift. 10 tables and 49 endpoints across 11 tags.
- **`PROJECT_MEMORY.md`**, written by hand because it records what the code
  cannot: why decisions were made, and every trap already hit — the
  `backdrop-filter` containing-block bug, the cmd block-expansion trap, the
  IPv6 `localhost` resolution, `MissingGreenlet` from server-side defaults,
  RFC 5737 ranges being private, and Pydantic's `Z` suffix on 3.10.

### Changed
- Three lazy imports hoisted to module scope. They were hiding dependencies
  rather than breaking cycles; the three that remain are genuine
  `TYPE_CHECKING` guards.

### Changed — Wake word is on by default

Reported: saying "Hey Obsidian" did nothing. The cause was my own decision to
ship the wake word opt-in and off. That was the wrong call for a feature whose
entire purpose is hands-free operation — it meant the headline behaviour did
nothing until a toggle nobody knew about was found.

It is now on by default. The privacy trade-off is handled by making it
*visible* rather than absent: the topbar microphone shows a pulsing indicator
whenever the recogniser holds the microphone, with a one-click disable in the
HUD header. An armed microphone should be obvious, not silent — but it should
also actually work.

### Fixed — `API_PROXY_TARGET` in `.env.local` was silently ignored

Next evaluates `next.config.mjs` before loading `.env.local`, so the rewrite
destination set there never applied and always fell back to port 8000. The
comment in `.env.local.example` claimed the opposite. `scripts\run-web.bat` now
passes the value as a real environment variable, and the misleading comment is
corrected.

### Added — Upload resilience on Windows

`os.replace` on a freshly written file fails with WinError 32 when real-time
antivirus still holds it open — Defender scans newly written executables and
APKs aggressively. The move into content-addressed storage now retries with a
short backoff, turning a hard 500 into a successful upload. On POSIX the loop
never iterates.

### Fixed — Test suite depended on the developer's `.env`

With real threat-intel keys configured, the suite queried live rate-limited
APIs and failed assertions about the offline provider. `conftest.py` now forces
the mock provider rather than defaulting to it.

### Investigated — APK upload returning 500
Not reproduced. Every supported evidence type was uploaded successfully,
including the exact reported filename with parentheses, at both 2.9 KB and 7 MB,
against a `--reload` server. A theory that uvicorn's reloader was restarting
mid-upload was tested and disproved: watchfiles only monitors `*.py`.

The reported error carried no JSON body, which means it did not come from the
API's exception handler — Next's rewrite returns a bare 500 when it cannot reach
the backend. The Windows rename hardening above is the most plausible remaining
cause; confirming it needs the traceback from the API console window.

### Changed — Voice Command Mode made genuinely hands-free

Reported from use: follow-ups failed, the microphone had to be clicked before
every command, and the wake word did nothing.

**Follow-ups now continue the conversation.** "Tell me more about that", "go
on", "elaborate", "why is that suspicious" were previously parsed as gibberish,
so the exchange dead-ended after one turn — which is not a conversation. A new
`FOLLOW_UP` intent carries the previous action and subject, and the pronoun is
resolved before the question reaches the assistant: "that" becomes "the
periodic beaconing finding". Without a case in view it says it has lost track
rather than guessing.

**Listening is continuous.** Chrome ends a recognition session on its own after
a pause regardless of `continuous`, so staying live requires restarting on
`onend`. The hook now distinguishes a session the *user* stopped from one the
*browser* ended and only restarts the latter. A denied microphone is treated as
permanent; other errors are allowed to recover.

**Wake word works globally.** "Hey Obsidian" is detected by a separate listener
running at the shell, so it is armed on every screen. Anything said after the
wake word is taken as the command, so "Hey Obsidian, open case two" works in one
breath. It pauses while the HUD is open so the two recognisers do not compete
for the microphone.

It is **opt-in and off by default**. Holding a microphone open permanently is a
decision an analyst must make knowingly — doubly so when Chrome's recogniser
streams captured audio to Google and the room may contain case discussion.

**Cases resolve by partial reference or title.** Speech gives you "case two" or
"the beaconing case", never `OBS-2026-0002`. Lookup now tries exact reference,
then trailing digits, then title words with grammar words stripped — no title
contains "the" or "case", so keeping them guaranteed zero matches. When several
cases match it **asks which one** instead of choosing: acting on the wrong
investigation is the worst available outcome for a command that changes state.

**The HUD is a full-screen mode.** The workspace is blurred out and live case
telemetry is shown — evidence, analysed, findings, indicators, risk and the most
severe finding — because an analyst speaking to the system still needs to see
the numbers being discussed. Added `GET /cases/{id}/overview` so that is one
request rather than four.

Rendered through `createPortal` to `document.body`, making the mount point
irrelevant and permanently closing the containing-block bug that trapped the
previous overlay inside the header.

### Tests
248 passing, up from 232. New coverage: opening by trailing digits, opening by
title words, ambiguity asking rather than guessing, five follow-up phrasings,
pronoun grounding against the previous subject, follow-up without context, and
the overview endpoint on both populated and empty cases.

### Fixed — Voice overlay rendered inside the header and spilled across the UI

Reported from a screenshot: the voice panel's contents were overlapping the
breadcrumbs, workspace tabs and topbar controls instead of covering the screen.

**Cause.** The overlay used `fixed inset-0`, but it is rendered inside
`<header>`, which carries `backdrop-blur-xl`. A `backdrop-filter` establishes a
containing block for fixed-position descendants, so `fixed` resolved against the
48-pixel header rather than the viewport. The same trap applies to `filter`,
`transform`, `perspective`, `will-change` and `contain`.

**Fix.** Rebuilt on the existing `Dialog` primitive, which portals its content
to `document.body` and therefore escapes the containing block entirely — and
brings focus trapping and scroll locking with it. Every other dialog in the app
was already correct for this reason; the voice panel was the one surface I had
hand-rolled. Content is now bounded at `85dvh` with the exchange history in its
own scroll area, so a long session cannot push content off-screen.

Audited the rest of the codebase: no other `fixed` element sits under a blurred
ancestor.

### Fixed — Raw UUIDs used as workspace tab and breadcrumb labels

A case tab read `112ba1b7 05cb 4982 8b63 Cf0bece1e665`, which is unreadable and
pushes every other tab off screen. Detail routes now resolve their label from
the case record already in the query cache, showing `OBS-2026-0001`, and fall
back to a generic noun such as "Case" before that data arrives rather than
titlecasing a hex string.

### Added — Phase 6: Voice Command Mode

The last deferred module. ADR 0004 held this back until there were real actions
worth commanding; that condition is now met.

**Every intent executes the service the UI already calls**
This is the seam reserved in ADR 0004, honoured literally. `IntentResolver`
calls `CaseService.change_status`, `AnalysisService.analyze`,
`EnrichmentService.enrich_case`, `ReportService.generate` — the same methods the
buttons invoke. If voice could do something the UI could not, the two would
drift and only one would be tested.

Demonstrated end to end: spoken commands ran a full investigation — summarise,
analyse, re-summarise (findings changed from 0 to 1, proving state actually
moved), list indicators, enrich, change status, generate a report.

**Deterministic patterns before any model**
Three reasons: a spoken command must act immediately, and a round trip to a
language model makes voice slower than the mouse it replaces; "close this case"
must mean the same thing every time, and a classifier that occasionally decides
otherwise is unusable for an action that mutates state; and the platform runs
air-gapped, where no model may exist. Model results, when used, are marked
INFERRED so a caller can require confirmation.

**Speech handling built for how people actually talk**
- Wake-word stripping across "Hey Obsidian", "OK Obsidian", "Obsidian:".
- Case references survive recogniser variation — "OBS 2026 1", "obs-2026-0001"
  and "OBS-2026-0001" all resolve to the same case.
- Stems match inflections: "summarise", "summarize" and "brief" all reach the
  summary intent.
- **Case-scoped fallback.** Saying "analyse the evidence" while viewing a case
  means *that* case. Requiring the word "this" to be understood is a parser
  serving itself rather than the speaker.
- Errors are spoken, not raised. An invalid status transition replies "a case
  that is open cannot move to contained" instead of returning HTTP 409 to a
  person.
- Speech output carries no markdown, because it is heard rather than read.

**Voice orb**
States differ by *motion* as well as colour — expanding rings while listening,
orbiting dots while thinking, pulsing bars while speaking. Colour alone would
leave the state unreadable to a colour-blind analyst, and telling you at a
glance whether it heard you is the orb's entire purpose.

### Privacy disclosure
The Web Speech API is used because it needs no dependency, model download or
GPU. Chrome's recogniser **streams audio to Google for transcription**. For a
platform handling regulated evidence that is a genuine disclosure risk, so the
UI states it plainly rather than burying it. The speech hooks are deliberately
thin: a local Whisper recogniser and Piper synthesiser can replace them without
touching any component that consumes them.

### Tests
232 passing, up from 185. Coverage includes wake-word stripping variants, case
reference extraction across recogniser renderings, 16 utterance-to-intent
mappings, longest-status-term precedence ("in progress" not shadowed by
"progress"), context resolution, dry-run interpreting without acting, commands
provably mutating real state, invalid transitions spoken rather than raised, and
speech output containing no markdown.

---

**All modules in the OBSIDIAN constitution are now implemented.**

### Added — Phase 5: Reporting Engine

**Reports** is now live. Every navigation item is unlocked; no phase locks remain.

**A dependency-free PDF writer**
Written directly against ISO 32000-1 rather than pulled from a library.
reportlab requires Pillow (a 7 MB binary wheel); WeasyPrint requires cairo and
pango system libraries. Neither is acceptable for software that must install in
an air-gapped environment, and these reports are text, tables and rules — none
of the raster or CSS machinery those libraries exist to provide.

Uses only the base-14 fonts, so nothing is embedded. Includes real Helvetica
metrics, because without them text either overflows the margin or stops far
short of it. Verified structurally: every cross-reference offset resolves to its
correct object, which is the one defect that produces a file no reader accepts
and gives no other symptom.

**Composition separated from rendering**
A case is composed once into a structured document; Markdown, HTML and PDF
renderers consume it. Three renderers each deciding what to include is how three
formats end up disagreeing about the same investigation.

**Profiles differ in content, not styling**
The executive report leads with an assessment in business terms and closes with
recommended actions derived from what was actually found — beaconing yields
"capture volatile memory", brute force yields "rotate credentials". The
technical report adds the evidence inventory with custody hashes, every finding
with its ATT&CK mapping, and methodology. An executive report that is the
technical report with a different cover page is a technical report nobody senior
will read.

A case with no findings produces the sentence *"This is not a statement that no
compromise occurred — only that the evidence examined does not show one."*
Reporting silence as safety is how an investigation tool misleads.

**Integrity signature**
HMAC-SHA256 over the rendered bytes, so the signature covers exactly what a
recipient opens rather than the source data.

The signature is also printed inside the document, which is circular: embedding
it changes the bytes being signed. Resolved by rendering first with a
fixed-length placeholder — both it and a hex SHA-256 digest are exactly 64
characters, so the two renders differ in those 64 bytes and nowhere else. No
shifted offsets, no altered PDF stream lengths. Verification substitutes the
placeholder back and recomputes exactly.

Documented honestly as symmetric: it attests the report came from this instance
unaltered. It is not non-repudiation, which needs asymmetric signing against a
key the server never holds alone — a PKI decision, not an application one.

Rendered bytes are stored rather than regenerated on download. A report is a
point-in-time statement; regenerating it later would silently produce a
different document as the case evolves.

### Fixed during development
First verification attempt reconstructed the signed bytes by *deleting* the
signature string. That worked for Markdown and failed for HTML and PDF, because
the signature's presence changes surrounding markup and, in PDF, every stream
length and xref offset. Replaced with the placeholder-substitution approach
above, which is byte-exact for all three.

### Tests
185 passing, up from 161. Coverage includes PDF structural validity and xref
offset resolution, PDF-string escaping (unescaped parentheses corrupt a file),
automatic pagination, metric-based wrapping, HTML self-containment and escaping,
profile content differences, recommendations deriving from findings, signature
verification across all three formats, and tamper detection.

### Added — Phase 3: Threat Intelligence

**Threat Intel** is now live in navigation. Extracted indicators can be enriched
against reputation feeds.

**Cache keyed by indicator value, not by IOC row**
An IOC row is case-scoped: the same address in three investigations produces
three rows. Its reputation is a property of the *indicator*, identical for all
three. Caching per row would triple requests to feeds that meter them hard —
VirusTotal's free tier allows four lookups a minute — and could show one address
as malicious on one case and unknown on another. Verified: enriching two cases
that share an indicator produces one cached row.

**Verdict aggregation is deliberately asymmetric**
The worst *successful* verdict wins, rather than an average. In reputation data
a single credible malicious hit outweighs any number of feeds that simply have
no record, and averaging would dilute a true positive into "benign".

Failed lookups are excluded rather than counted as benign — a feed being
unreachable says nothing about the indicator. Per-provider payloads are retained
so an analyst can see *who* said what; a consensus with no attribution is not
defensible in a report.

**Providers**
- Deterministic `mock` requiring no key or network, labelled `simulated: true`
  in its own output so nobody mistakes it for evidence.
- VirusTotal (v3) and AbuseIPDB adapters. Feeds are queried **concurrently**,
  since they are independent and network-bound; `return_exceptions` keeps one
  misbehaving feed from cancelling the rest.
- A missing API key skips that provider with a warning rather than raising, so
  one misconfiguration cannot disable every correctly configured feed.
- Providers declare what they support: AbuseIPDB answers on addresses only and
  returns an explicit error for a hash rather than a misleading verdict.

**Behaviour**
- A malicious verdict raises the indicator's own severity and confidence — that
  is new information about the case, not just a lookup result.
- `force=true` bypasses the cache; the default respects the configured TTL.

Configure with `OBSIDIAN_THREATINTEL_PROVIDERS` (comma-separated),
`OBSIDIAN_VIRUSTOTAL_API_KEY`, `OBSIDIAN_ABUSEIPDB_API_KEY` and
`OBSIDIAN_THREATINTEL_CACHE_HOURS`.

### Tests
161 passing, up from 139. Coverage includes: a single malicious verdict
outweighing several benign ones, failed lookups excluded from consensus,
all-failure yielding unknown, mock determinism, provider capability boundaries,
cache hits avoiding refetch, TTL expiry triggering refetch, force updating in
place rather than duplicating, and cache sharing across cases.

### Added — Phase 3: Forensic Timeline

**Timeline** is now live in navigation, with a per-case tab and a global view.

**The distinction that makes it forensic**
Events carry a `source`: `incident` (when the behaviour actually occurred,
derived from evidence content) or `investigation` (when the team acted).
Flattening the two produces a chronology that reads coherently and is wrong — a
capture recorded in January and uploaded in July is not evidence of July
activity. Verified end to end: beaconing appears at `2025-01-01` while the
ingest and analysis events that discovered it appear at `2026-07-25`.

- PCAP analysis now records absolute `first_packet_epoch` / `last_packet_epoch`,
  not just a duration, so the capture window can be placed on a real axis.
- Findings anchor to their capture window rather than to upload time.
- Filters for source and minimum severity; counts split by source.

**Derived, not duplicated**
Events are assembled from records that already exist — the audit trail, evidence
metadata, stored analysis results — rather than written to a parallel event
table. A second log would drift from the records it duplicates the moment a
write path forgot to append, and a timeline that disagrees with the audit trail
is worse than no timeline.

Authentication and token events are deliberately excluded: they are security
telemetry, not case chronology, and would bury what an analyst is looking for.

### Fixed
- **Analysis audit entries carried no `case_id`.** They recorded `resource_type=
  evidence` with the evidence id only, so nothing downstream could attribute an
  analysis to an investigation without a second lookup — and the timeline
  silently dropped every `analysis.completed` event. Both `ANALYSIS_STARTED` and
  `ANALYSIS_COMPLETED` now record the case.

### Tests
139 passing, up from 124. New coverage: capture windows placed at capture time
rather than ingest time, findings anchored to the capture, investigation events
using real time, deterministic ordering when events share a timestamp (routine,
since an upload and its audit record are written in one transaction), source and
severity filtering, and exclusion of authentication noise.

Test timestamps are parsed with a helper that normalises the trailing `Z`
Pydantic emits, because `datetime.fromisoformat` only accepts it from Python
3.11 onward and the suite must stay valid on 3.10.

### Fixed — API unreachable from the browser while demonstrably running

`doctor.bat` showed the backend listening on `0.0.0.0:8000` and answering its
own health check, yet the workspace reported it unreachable. Three separate
weaknesses combined to produce that:

1. **Windows resolves `localhost` to the IPv6 address `::1` first**, while
   uvicorn's `--host 0.0.0.0` binds IPv4 only. The API answered `curl
   127.0.0.1` and refused the browser.
2. **`NEXT_PUBLIC_*` values are inlined when the dev server starts.** Editing
   `.env.local` had no effect on an already-running process, so the fix applied
   earlier was invisible until a restart nobody knew was required.
3. Every request additionally needed a CORS preflight across the origin
   boundary.

**The fix removes the boundary rather than patching each symptom.** The frontend
now calls `/api/v1/...` on its own origin and `next.config.mjs` rewrites that to
the backend server-side:

- The browser resolves exactly one host — its own — so IPv4/IPv6 mismatch cannot
  occur.
- The proxy target is read server-side per request from `API_PROXY_TARGET`, not
  baked into the client bundle, so configuration changes take effect on restart
  without a rebuild.
- No CORS preflight, because nothing is cross-origin.
- It mirrors how the app runs behind nginx in production, so development and
  production now share a topology instead of diverging.

`NEXT_PUBLIC_API_URL` still exists for genuinely separate deployments; leaving
it unset keeps requests same-origin.

**Verified:** streaming survives the proxy. Time-to-first-byte through the
rewrite is 0.039s against a 0.865s total — a 22x gap that proves incremental
delivery. A buffering proxy would show those figures equal. `text/event-stream`
is preserved end to end and the stream still terminates with a `done` frame.

### Added — Phase 4: AI Assistant

**AI Assistant** is now live in navigation, and the docked panel (Ctrl/Cmd+J) is
functional rather than a shell.

**Case grounding — the part that matters**
- `context_builder.py` renders an investigation into a bounded digest: case
  identity, evidence inventory, findings ordered by severity with ATT&CK
  identifiers, and indicators with confidence and sighting counts.
- The digest states **absence** as explicitly as presence. A model told nothing
  about evidence will confidently invent some, so an unanalysed case yields
  "no artefact has been analysed yet... do not infer findings that are not
  listed here."
- Budgeted to ~12k characters and truncated at a line boundary, so the model
  never receives a half-written indicator it might then quote as fact.
- The system prompt forbids speculation and requires the assistant to name what
  evidence would resolve an unanswerable question.

**Streaming**
- Server-sent events over `fetch` with a `ReadableStream`, not `EventSource` —
  `EventSource` cannot set an `Authorization` header, which would force the
  access token into the query string where it lands in server logs and browser
  history.
- Partial SSE frames are buffered across chunk boundaries rather than assumed
  to arrive whole.
- Errors are delivered in-band: headers are already sent once streaming starts,
  so a failure cannot become an HTTP status.
- `X-Accel-Buffering: no` prevents nginx from buffering the whole answer and
  delivering it as one lump.

**Conversations**
- Persisted per analyst and optionally bound to a case. `SET NULL` on case
  deletion — removing a case must not destroy the reasoning trail a report may
  reference.
- Only the last 20 turns are replayed to the provider; older turns stay in the
  database but are dropped from the prompt so a long thread cannot crowd out
  the case context.
- Every message records provider, model and token counts. Without provenance a
  reviewer cannot tell whether an answer came from a frontier model or the
  offline stub — which matters when the output informs a report.
- Conversations are private to their owner; administrators can audit them.

**UI**
- Markdown rendering with GFM tables, copyable code blocks, and a streaming
  cursor. Raw HTML passthrough is deliberately **not** enabled: model output is
  untrusted input and can restate attacker-controlled strings lifted from
  evidence, so rendering HTML from it would be a stored-XSS path straight
  through the investigation workflow.
- The docked panel infers the case from the route, so opening it on a case
  grounds the conversation with no selection step.
- Switching case remounts the chat, so the model is never asked about one
  investigation while holding another's context.

### Known limitations
- The default `mock` provider is deterministic and does not genuinely reason
  over the supplied context. The grounding pipeline is verified — the digest
  demonstrably contains the real indicators, findings and technique IDs, and is
  passed to the provider — but observing real case-specific reasoning requires
  configuring Anthropic, OpenAI or Ollama.
- Token usage on streamed responses is estimated, since not every provider
  reports counts mid-stream.

### Tests
124 passing, up from 108. New coverage: context includes findings, indicators
and ATT&CK IDs; context states absence explicitly; conversation privacy between
analysts; history retention and ordering; auto-titling; SSE frame sequence; and
that a streamed answer is persisted identically to what was streamed.

### Added — Phase 2: Analysis Engine + IOC Engine

Evidence is no longer inert storage. **IOC Engine** is now live in navigation.

**PCAP analysis — written against the file format, no Scapy or tshark**
- libpcap and pcapng parsing, both endiannesses, microsecond and nanosecond
  timestamps; Ethernet II with 802.1Q, Linux SLL and raw IP link types;
  IPv4/IPv6, TCP/UDP with payload capture.
- Scapy is slow enough on large captures to be unusable inside a request, and
  tshark is an external binary. The formats are simple; parsing them directly
  keeps analysis dependency-free and predictable. Packet count is bounded so a
  hostile capture cannot exhaust memory.

**Detections**
- **Beaconing** via interval regularity. Coefficient of variation across
  inter-arrival times separates automated check-ins from bursty human traffic;
  regularity maps directly to the confidence score.
- **Port scan** by distinct-port fan-out from one source to one target.
- **DNS tunneling** requiring two independent signals — query volume *and*
  payload length — because either alone is weak.
- **Cleartext protocols** (FTP, Telnet, POP3, IMAP).
- Log analysis: brute force with top source attribution, encoded PowerShell,
  persistence mechanisms, privilege activity.

**IOC extraction**
- IPv4/IPv6, domains, URLs, emails, MD5/SHA-1/SHA-256.
- Longest hash wins: a SHA-256 string contains valid MD5 and SHA-1 substrings,
  so matching short patterns first would mint indicators that were never present.
- RFC 1918, loopback, link-local and RFC 5737 documentation ranges are excluded
  — an indicator list padded with the defender's own estate is noise.
- A benign-domain allow-list filters Microsoft, Google, Apple and similar.
- Repetition raises confidence; indicators deduplicate per case with a sightings
  counter rather than repeating rows.
- Defanged rendering (`hxxp`, `[.]`) is the UI default, since indicator lists
  get pasted into tickets and chat.

**Risk scoring**
Weighted by highest severity and damped by count, so one critical finding
outranks a dozen informational ones — the opposite of a naive sum, where noise
would outweigh a genuine detection.

### Fixed
- `EvidenceResponse` omitted `analysis_summary`, so the analyse endpoint
  returned a body with no results in it and findings were unreachable from any
  client.

### Known limitations
- A port scan that touches ports 21 or 23 also trips the cleartext-protocol
  detector. Technically correct — traffic to those ports was observed — but
  noisy. Correlating detections to suppress subordinate findings is queued.
- Analysis runs inline in the request. The contract is already a plain result
  object, so moving it to a worker pool requires no change above the service.
- No engine yet for EVTX, APK or documents; the registry returns `None` and the
  API refuses with a clear message rather than failing obscurely.

### Tests
108 passing, up from 82. Capture bytes are constructed for real in
`tests/pcap_builder.py` rather than mocked, so the byte-level decoding — the
part most likely to be wrong — is genuinely exercised. Coverage includes
beaconing true and false positives, port-scan fan-out, hash precedence,
private-range exclusion, re-analysis deduplication and defanging.

### Added — Phase 1: Cases & Evidence

Three navigation items are now live: **Cases**, **Evidence** and **Users**.

**Case management**
- Full CRUD with auto-allocated references (`OBS-2026-0001`). Allocation races
  are guarded by a unique constraint plus retry, not by hoping.
- Status workflow enforced by a transition table in the domain layer. An
  invalid move returns 409 *with the permitted next states*, and the UI only
  offers legal transitions — the server stays the authority.
- `ARCHIVED` is terminal; `closed_at` is set and cleared by the service rather
  than inferred in the UI.
- Free-text search across title, reference and summary; filters for status,
  severity and assignee; aggregate statistics.
- Analysts may modify only cases they own or are assigned; investigators and
  above may modify any.

**Evidence ingestion**
- Content-addressed storage under a SHA-256 derived path. Identical content
  occupies one blob, and no attacker-controlled text reaches the filesystem.
- SHA-256 and MD5 computed in a single streaming pass — a second read would
  double I/O on multi-gigabyte artefacts. SHA-256 is the integrity anchor; MD5
  exists only because threat-intel corpora are keyed on it.
- **Type detected from magic bytes, not the filename.** A PCAP renamed `.txt`
  is still classified as a PCAP. Zip ambiguity (APK vs DOCX vs archive) falls
  back to extension, which is all that is available without opening the
  container.
- Filenames sanitised against path traversal; `../../etc/passwd` becomes
  `passwd`.
- Duplicate content per case rejected with 409 and the existing evidence id.
- Downloads always served `application/octet-stream` with `nosniff`, so a
  browser never renders evidence inline.
- Drag-and-drop upload with genuine progress via XHR (fetch still cannot report
  upload progress), uploading sequentially so one transfer does not starve
  another.

**Users**
- Admin table with inline role changes and enable/disable. Disabling revokes
  every session immediately. Self-disable is blocked in the UI and the API.

### Fixed
- **`MissingGreenlet` on any case update.** `updated_at` carries a server-side
  `onupdate`, so after an UPDATE the attribute was expired; reading it during
  response serialisation triggered a lazy refresh — synchronous I/O on a
  greenlet no longer in an await context. Fixed at the mapper level with
  `eager_defaults=True` on `Base`, rather than sprinkling `refresh()` calls
  through every service.

### Tests
82 passing, up from 45. New coverage: case lifecycle and every invalid
transition, the pure transition table, search and filtering, hash correctness
against the uploaded bytes, magic-byte classification, path-traversal
sanitisation, duplicate rejection, download integrity and authorization.

### Added — Application shell

An IDE-style workspace replacing the fixed sidebar and topbar.

- **Resizable sidebar** — drag the edge, or focus the handle and use arrow keys.
  Width persists across reloads. Exposed as a `separator` with
  `aria-valuenow/min/max` so it is operable and announced without a mouse.
- **Collapsible sidebar** — icon-only mode with tooltips, toggled by `Ctrl/Cmd+B`.
- **Workspace tabs** — VS Code style route tabs with close, close-others and
  close-all via right-click. Closing the active tab moves to its neighbour
  rather than stranding the workspace on a dead route.
- **Breadcrumbs** derived from the pathname, so new routes need no registration.
- **Notification center** with unread badge, per-item dismiss, mark-all-read and
  a 50-item retention cap.
- **Theme manager** — four dark presets (Obsidian, Midnight, Carbon, Amber
  Alert) plus comfortable/compact density. Presets override HSL channel
  variables only, so every component re-themes with no class changes.
- **Floating AI panel** — docking, layout and composer, toggled by `Ctrl/Cmd+J`.
  The composer is visibly disabled rather than faking responses; Phase 4 adds
  the transport.
- **Command palette** extended beyond navigation to view toggles and theme
  switching.

### Added — Design tokens

Typography scale, strict 8px spacing system, radius scale, elevation shadows,
motion durations and easings, and shell geometry, all as CSS variables wired
into Tailwind. Elevation carries depth with a light rim plus ambient shadow,
because a black shadow is invisible on a near-black canvas.

### Added — Primitives

`Breadcrumb`, `ContextMenu`, `Resizable` panels and `SearchInput`, bringing the
library to 37 components.

### Notes
- pnpm and Turborepo are deferred until `packages/` exists — with one frontend
  and one Python backend there is nothing to orchestrate, and migrating would
  break a working install for no benefit.

### Fixed — Local startup

- **`localhost` resolved to IPv6 while the API listened on IPv4 only.** Uvicorn
  defaults to `127.0.0.1`, but Windows resolves `localhost` to `::1` first. A
  browser calling `http://localhost:8000` could be refused by a server that was
  demonstrably running. The API now binds `0.0.0.0` and the frontend calls
  `http://127.0.0.1:8000`, removing the ambiguity in both directions. CORS
  accepts both spellings, since the browser sends whichever the user typed.
- **`start.bat` guessed at startup time.** It slept 6 seconds before launching
  the web app and 12 more before opening the browser. Uvicorn with `--reload`
  routinely exceeds that on a cold Windows start, so the workspace opened
  against an API that had not finished booting. It now polls
  `/api/v1/health` until the API genuinely answers, up to 60 seconds.
- **`start.bat` no longer starts blindly into an occupied port.** If something
  already holds 8000 it probes whether that process answers as OBSIDIAN,
  reuses it if so, and otherwise names the owning process and stops.
- **`doctor.bat` reported a bare PID.** It now resolves the PID to an image
  name and tests whether the listener answers as the OBSIDIAN API.
- **The login page dead-ended on a network failure.** A connection failure and a
  rejected password produced the same red message despite needing entirely
  different remedies. They are now distinct, and the connection error names the
  URL that failed, explains the likely causes, and offers a retry that probes
  the health endpoint.

### Added — Design system

Twenty-two new primitives, bringing the component library to 33. All are
Radix-based where interaction semantics matter.

**Form controls**
- `Textarea`, `Checkbox` (with indeterminate state), `RadioGroup`, `Switch`
- `Select` — Radix listbox with typeahead and collision-aware positioning
- `Form` — React Hook Form + Zod bindings that generate stable ids and wire
  `htmlFor`, `aria-describedby` and `aria-invalid` on every field

**Layout and disclosure**
- `Tabs`, `Accordion`, `ScrollArea`, `Progress` (determinate and indeterminate)
- `Sheet` — edge-anchored drawer built on Radix Dialog, so it inherits focus
  trapping, focus restoration, background `aria-hidden` and scroll locking

**Data display**
- `Table` primitives, `DataTable` with client-side sorting and pagination
- `Timeline` — chronological event rail rendered as an ordered list
- `Tag` — dismissible chip, distinct from the inert `Badge`
- `Chart` — Recharts wrapper supplying the OBSIDIAN palette and glass tooltip

**Feedback and states**
- `Alert` with info / success / warning / destructive variants
- `EmptyState`, `ErrorState`, `LoadingState`, `Spinner`

**Other**
- `/design-system` route: a living gallery rendering every primitive
- React Hook Form, `@hookform/resolvers` and Recharts added; Zod, previously
  installed but unused, is now the validation layer

### Changed
- `login` and `register` no longer hand-roll identical error markup; both use
  `Alert`, removing the duplication

### Notes
- Recharts adds roughly 150 kB to any route that imports it. Routes are
  code-split, so only chart-bearing pages pay that cost.

---

## [0.1.0] — Phase 0 Foundation

### Added

**Backend**
- FastAPI service on Clean Architecture: `core` / `domain` / `repositories` /
  `services` / `api`, with a strict one-directional dependency rule
- Async SQLAlchemy 2.0 with a dialect-agnostic engine — SQLite for local
  development, PostgreSQL for production, one environment variable apart
- Argon2id password hashing at the OWASP baseline cost
- JWT access tokens with rotating, single-use refresh tokens stored as SHA-256
  digests; reuse of a spent token revokes the entire session family
- Four ordered RBAC roles enforced through dependency injection
- Append-only audit trail with actor, IP, user agent and request correlation id
- Sliding-window rate limiting over a pluggable cache backend
- AI provider abstraction with Claude, OpenAI, Ollama and a deterministic mock
- Alembic migrations, seed script, 45 tests

**Frontend**
- Next.js 15 App Router PWA with manifest, service worker and offline shell
- shadcn/ui configured with the OBSIDIAN palette mapped onto its token contract
- Analyst Mode shell: sidebar, topbar, `Cmd/Ctrl+K` command palette
- Access token held in memory only; single-flight silent refresh

**Tooling**
- `setup.bat`, `start.bat`, `test.bat`, `doctor.bat` and per-service launchers
- Docker Compose profile for PostgreSQL, Redis, API, web

### Security
- `next` upgraded to 15.5.21 for a published CVE; transitive `postcss` and
  `sharp` advisories pinned via npm `overrides`. `npm audit` reports clean.
- `next/font/google` removed — it fetched from Google at build time, which broke
  offline and air-gapped builds
