# ADR 0002 — AI Provider Abstraction with a Deterministic Mock

**Status:** Accepted · **Date:** 2026-07-25

## Context
OBSIDIAN's identity is AI-first, yet no provider API key is available at the
start of development. Meanwhile the product must remain usable in offline DFIR
environments, where evidence legally cannot leave the machine — meaning a local
model (Ollama) is not a nice-to-have but a real deployment mode.

## Decision
Define an `AIProvider` protocol (`complete`, `stream`, `health`) with provider
selection resolved at runtime from configuration. Ship four implementations:
`mock`, `anthropic`, `openai`, `ollama`. Services depend only on the protocol.

The mock provider is **deterministic**: its output is seeded from a hash of the
request. Identical input yields identical output.

## Consequences
**Positive.** The full product — every screen, service and test — is buildable
and demonstrable today with no key and no network. AI-dependent tests are
reproducible in CI, which is impossible against a live model. Adding a provider
is one file plus one registry entry.

**Negative.** The abstraction is a lowest-common-denominator surface. Provider-
specific capabilities (Claude tool use, OpenAI structured outputs) are not
expressible through it yet. When a feature genuinely needs them, the protocol
gains an optional capability method with a default of "unsupported" rather than
leaking a provider type into a service.

**Rejected alternative.** Coding directly against one SDK and abstracting later.
Provider calls spread quickly; retrofitting the seam after twenty call sites is
the expensive version of this decision.
