# ADR 0001 — Dialect-Agnostic Persistence

**Status:** Accepted · **Date:** 2026-07-25

## Context
The target production database is PostgreSQL. The development machine has no
Docker and therefore no PostgreSQL server. Requiring one before a single line of
product code can run would stall development on infrastructure.

## Decision
Depend on SQLAlchemy 2.0's async layer rather than on a dialect. `DATABASE_URL`
selects the backend: `sqlite+aiosqlite` locally, `postgresql+asyncpg` in
production. Constraints that differ by dialect are handled centrally:

- UUID primary keys stored as 36-char strings, portable across both dialects
- A shared metadata naming convention so Alembic can autogenerate and, critically,
  **name constraints deterministically** — unnamed constraints cannot be dropped
  in a migration on PostgreSQL
- `PRAGMA foreign_keys=ON` applied on SQLite connect, since SQLite silently
  ignores foreign keys otherwise and would hide referential bugs until production
- Pooling configured only for dialects that support it

## Consequences
**Positive.** Zero-infrastructure local development; the test suite runs against
an in-memory database in milliseconds; production keeps PostgreSQL.

**Negative.** PostgreSQL-only features (JSONB operators, full-text search, array
columns) cannot be used casually. This is accepted: where they become necessary
they will be introduced behind a repository method, which is already the only
place raw query construction is permitted.

**Rejected alternative.** Requiring Docker up front. It converts a five-minute
start into a multi-hour environment problem and blocks the person who owns the
project from running their own code.
