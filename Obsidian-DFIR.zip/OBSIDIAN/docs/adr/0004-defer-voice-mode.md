# ADR 0004 — Defer Voice Command Mode, Reserve Its Seam

**Status:** Accepted · **Date:** 2026-07-25

## Context
Voice Command Mode is the product's most distinctive feature and its most
technically demanding: wake-word detection, streaming STT, intent classification,
conversation memory with entity resolution, and speech synthesis narrating
long-running jobs.

## Decision
Defer implementation to Phase 6. Reserve the architectural seam now by making the
**service layer the single execution point for every action**. Voice will produce
`Intent` objects that resolve to the same service calls the UI invokes.

## Consequences
**Positive.** Voice is built against real, working actions rather than stubs. The
constraint it imposes — that every capability be invocable programmatically with
structured arguments, independent of HTTP — is enforced from day one, which is
the part that is genuinely expensive to retrofit.

**Negative.** The headline differentiator is absent from early demos. Mitigated
by Analyst Mode being fully polished, and by the fact that "Hey Obsidian, analyze
the PCAP" is only impressive when there is a real PCAP engine behind it.

**Rejected alternative.** Building voice in Phase 1. It would be wired to stub
actions, producing a demo that narrates work that never happened — the exact
"student project" impression the product is meant to avoid.
