# ADR 0003 — Access + Rotating Refresh Tokens, Access Token in Memory

**Status:** Accepted · **Date:** 2026-07-25

## Context
A security investigation platform that gets its own authentication wrong is not
credible. The two dominant real-world failures are XSS-driven token theft and
long-lived tokens that cannot be revoked.

## Decision
1. **Short-lived access JWT (15 min), held in JavaScript memory only.** Never in
   `localStorage`, which any injected script can read.
2. **Long-lived refresh token (7 days), stored hashed (SHA-256) server-side.** A
   database compromise does not yield usable refresh tokens.
3. **Rotation on every refresh.** The presented token is revoked as it is spent.
4. **Reuse detection.** Presenting an already-revoked refresh token revokes the
   entire token family for that user. Reuse means the token was copied.
5. **Typed tokens.** A `typ` claim prevents an access token from being replayed
   at the refresh endpoint and vice versa.
6. **Single-flight client refresh.** Concurrent 401s trigger exactly one refresh;
   other requests await and replay it.

## Consequences
**Positive.** Compromise windows are bounded to 15 minutes; sessions are
individually revocable; stolen-token reuse is detected rather than merely
tolerated.

**Negative.** More moving parts than a single long-lived token, and a full page
reload costs one silent refresh round-trip before the UI is interactive. Both are
acceptable for the threat model. The refresh table requires periodic pruning of
expired rows.

**Rejected alternative.** Stateless refresh tokens with no server record. They
cannot be revoked, which makes step 4 impossible.
