<!-- GENERATED FILE — do not edit by hand.
     Produced by scripts/generate_docs.py from the live code.
     Run `python scripts/generate_docs.py` after changing models or routes. -->

# API Reference

Generated from the OpenAPI schema on 26 July 2026.

Interactive documentation is served at `/docs` in any non-production
environment. All endpoints are prefixed `/api/v1`.

**Authentication.** Send the access token as `Authorization: Bearer <token>`.
Tokens expire in 15 minutes; rotate with `POST /auth/refresh`. A refresh
token is single-use — replaying a spent one revokes the whole session
family (see [ADR 0003](adr/0003-token-strategy.md)).

---

## Contents

- [AI Assistant](#ai-assistant) — 6 endpoint(s)
- [Analysis](#analysis) — 4 endpoint(s)
- [Authentication](#authentication) — 5 endpoint(s)
- [Cases](#cases) — 7 endpoint(s)
- [Evidence](#evidence) — 6 endpoint(s)
- [Reports](#reports) — 6 endpoint(s)
- [System](#system) — 3 endpoint(s)
- [Threat Intelligence](#threat-intelligence) — 4 endpoint(s)
- [Timeline](#timeline) — 2 endpoint(s)
- [Users](#users) — 4 endpoint(s)
- [Voice](#voice) — 2 endpoint(s)

---

## AI Assistant

### `GET /api/v1/assistant/conversations`

**List your conversations**

| Parameter | In | Required | Description |
|---|---|---|---|
| `limit` | query | no | — |
| `offset` | query | no | — |
| `case_id` | query | no | — |

Responses: `200`, `422`

### `POST /api/v1/assistant/conversations`

**Start a conversation**

Attaching a case grounds every answer in that investigation's evidence, findings and indicators.

Responses: `201`, `422`

### `GET /api/v1/assistant/conversations/{conversation_id}`

**Fetch a conversation with its messages**

| Parameter | In | Required | Description |
|---|---|---|---|
| `conversation_id` | path | yes | — |

Responses: `200`, `422`

### `DELETE /api/v1/assistant/conversations/{conversation_id}`

**Delete a conversation**

| Parameter | In | Required | Description |
|---|---|---|---|
| `conversation_id` | path | yes | — |

Responses: `200`, `422`

### `POST /api/v1/assistant/conversations/{conversation_id}/messages`

**Ask a question and wait for the full answer**

| Parameter | In | Required | Description |
|---|---|---|---|
| `conversation_id` | path | yes | — |

Responses: `200`, `422`

### `POST /api/v1/assistant/conversations/{conversation_id}/stream`

**Ask a question and stream the answer**

Server-sent events. Each `data:` frame carries a JSON object: `{"delta": "..."}` for content, `{"done": true}` at completion, or `{"error": "..."}` on failure.

| Parameter | In | Required | Description |
|---|---|---|---|
| `conversation_id` | path | yes | — |

Responses: `200`, `422`

---

## Analysis

### `GET /api/v1/analysis/engines`

**Evidence types with an available engine**

Responses: `200`

### `POST /api/v1/evidence/{evidence_id}/analyze`

**Analyse an artefact**

Runs the engine matching the artefact's detected type, storing findings on the evidence record and upserting extracted indicators against the case. Re-running refreshes the results and increments IOC sightings.

| Parameter | In | Required | Description |
|---|---|---|---|
| `evidence_id` | path | yes | — |

Responses: `200`, `422`

### `GET /api/v1/iocs`

**List indicators**

| Parameter | In | Required | Description |
|---|---|---|---|
| `limit` | query | no | — |
| `offset` | query | no | — |
| `case_id` | query | no | — |
| `ioc_type` | query | no | — |
| `severity` | query | no | — |
| `q` | query | no | — |

Responses: `200`, `422`

### `GET /api/v1/iocs/statistics`

**Indicator counts by type**

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | query | no | — |

Responses: `200`, `422`

---

## Authentication

### `POST /api/v1/auth/login`

**Exchange credentials for tokens**

Responses: `200`, `422`

### `POST /api/v1/auth/logout`

**Revoke the current session**

Responses: `200`, `422`

### `GET /api/v1/auth/me`

**Current account**

Responses: `200`

### `POST /api/v1/auth/refresh`

**Rotate a refresh token**

Exchanges a refresh token for a new token pair. The presented token is revoked on use. Replaying a spent token revokes every session in its family.

Responses: `200`, `422`

### `POST /api/v1/auth/register`

**Create an account**

Registers a new account. The first account created on a deployment is granted the administrator role so the instance is manageable.

Responses: `201`, `422`

---

## Cases

### `GET /api/v1/cases`

**List cases**

| Parameter | In | Required | Description |
|---|---|---|---|
| `limit` | query | no | — |
| `offset` | query | no | — |
| `q` | query | no | Free-text search |
| `status` | query | no | — |
| `severity` | query | no | — |
| `assignee_id` | query | no | — |

Responses: `200`, `422`

### `POST /api/v1/cases`

**Open a case**

Responses: `201`, `422`

### `GET /api/v1/cases/statistics`

**Case counts by status and severity**

Responses: `200`

### `GET /api/v1/cases/{case_id}`

**Fetch a case**

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | path | yes | — |

Responses: `200`, `422`

### `PATCH /api/v1/cases/{case_id}`

**Update a case**

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | path | yes | — |

Responses: `200`, `422`

### `GET /api/v1/cases/{case_id}/overview`

**Compact case telemetry**

Counts and the most severe finding in a single call.

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | path | yes | — |

Responses: `200`, `422`

### `PATCH /api/v1/cases/{case_id}/status`

**Move a case through its workflow**

Transitions are validated against the case workflow. An invalid move returns 409 with the permitted next states.

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | path | yes | — |

Responses: `200`, `422`

---

## Evidence

### `GET /api/v1/cases/{case_id}/evidence`

**List evidence for a case**

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | path | yes | — |
| `limit` | query | no | — |
| `offset` | query | no | — |

Responses: `200`, `422`

### `POST /api/v1/cases/{case_id}/evidence`

**Upload evidence**

Streams the artefact to content-addressed storage, computing SHA-256 and MD5 in a single pass. The artefact type is detected from magic bytes, not the filename. Re-uploading identical content to the same case returns 409.

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | path | yes | — |

Responses: `201`, `422`

### `GET /api/v1/evidence/statistics`

**Evidence counts by type**

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | query | no | — |

Responses: `200`, `422`

### `GET /api/v1/evidence/{evidence_id}`

**Fetch evidence metadata**

| Parameter | In | Required | Description |
|---|---|---|---|
| `evidence_id` | path | yes | — |

Responses: `200`, `422`

### `DELETE /api/v1/evidence/{evidence_id}`

**Remove evidence from a case**

| Parameter | In | Required | Description |
|---|---|---|---|
| `evidence_id` | path | yes | — |

Responses: `200`, `422`

### `GET /api/v1/evidence/{evidence_id}/download`

**Download the original artefact**

Served as an attachment with a generic content type so a browser never renders potentially malicious evidence inline.

| Parameter | In | Required | Description |
|---|---|---|---|
| `evidence_id` | path | yes | — |

Responses: `200`, `422`

---

## Reports

### `GET /api/v1/cases/{case_id}/reports`

**Reports for a case**

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | path | yes | — |
| `limit` | query | no | — |
| `offset` | query | no | — |

Responses: `200`, `422`

### `POST /api/v1/cases/{case_id}/reports`

**Generate a report**

Composes the case into a report and renders it. The rendered bytes are stored, not regenerated on download: a report is a point-in-time statement, and regenerating it later would silently produce a different document as the case evolves.

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | path | yes | — |

Responses: `201`, `422`

### `GET /api/v1/reports`

**List reports**

| Parameter | In | Required | Description |
|---|---|---|---|
| `limit` | query | no | — |
| `offset` | query | no | — |
| `profile` | query | no | — |

Responses: `200`, `422`

### `DELETE /api/v1/reports/{report_id}`

**Delete a report**

| Parameter | In | Required | Description |
|---|---|---|---|
| `report_id` | path | yes | — |

Responses: `200`, `422`

### `GET /api/v1/reports/{report_id}/download`

**Download a report**

| Parameter | In | Required | Description |
|---|---|---|---|
| `report_id` | path | yes | — |

Responses: `200`, `422`

### `POST /api/v1/reports/{report_id}/verify`

**Verify report integrity**

Recomputes the HMAC over the stored bytes and compares it with the signature issued at generation. Detects any alteration since.

| Parameter | In | Required | Description |
|---|---|---|---|
| `report_id` | path | yes | — |

Responses: `200`, `422`

---

## System

### `GET /api/v1/ai/status`

**AI provider status**

Reports which provider is configured and whether it is reachable. Authenticated because provider identity and model names are deployment detail.

Responses: `200`

### `GET /api/v1/health`

**Liveness probe**

Returns as long as the process is running. Never touches I/O.

Responses: `200`

### `GET /api/v1/ready`

**Readiness probe**

Verifies every downstream dependency the API needs to serve traffic.

Responses: `200`

---

## Threat Intelligence

### `POST /api/v1/threat-intel/cases/{case_id}/enrich`

**Enrich a case's indicators**

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | path | yes | — |
| `limit` | query | no | — |

Responses: `200`, `422`

### `GET /api/v1/threat-intel/enrichments`

**Cached reputation verdicts**

| Parameter | In | Required | Description |
|---|---|---|---|
| `limit` | query | no | — |
| `offset` | query | no | — |
| `verdict` | query | no | — |

Responses: `200`, `422`

### `POST /api/v1/threat-intel/iocs/{ioc_id}/enrich`

**Enrich a single indicator**

Returns the cached verdict when it is still fresh. Pass `force=true` to bypass the cache. A malicious verdict raises the indicator's own severity, since that is new information about the case.

| Parameter | In | Required | Description |
|---|---|---|---|
| `ioc_id` | path | yes | — |
| `force` | query | no | — |

Responses: `200`, `422`

### `GET /api/v1/threat-intel/status`

**Configured feeds and cache state**

Responses: `200`

---

## Timeline

### `GET /api/v1/cases/{case_id}/timeline`

**Forensic timeline for a case**

Merges investigation activity (what the team did, and when) with incident activity derived from evidence content (when the observed behaviour actually occurred). Findings are anchored to their capture window rather than to upload time.

| Parameter | In | Required | Description |
|---|---|---|---|
| `case_id` | path | yes | — |
| `source` | query | no | — |
| `min_severity` | query | no | — |

Responses: `200`, `422`

### `GET /api/v1/timeline`

**Recent activity across all cases**

| Parameter | In | Required | Description |
|---|---|---|---|
| `limit` | query | no | — |
| `source` | query | no | — |
| `min_severity` | query | no | — |

Responses: `200`, `422`

---

## Users

### `GET /api/v1/users`

**List accounts**

| Parameter | In | Required | Description |
|---|---|---|---|
| `limit` | query | no | — |
| `offset` | query | no | — |
| `role` | query | no | — |

Responses: `200`, `422`

### `GET /api/v1/users/{user_id}`

**Fetch an account**

| Parameter | In | Required | Description |
|---|---|---|---|
| `user_id` | path | yes | — |

Responses: `200`, `422`

### `PATCH /api/v1/users/{user_id}/active`

**Enable or disable an account**

Disabling an account immediately revokes all of its sessions.

| Parameter | In | Required | Description |
|---|---|---|---|
| `user_id` | path | yes | — |

Responses: `200`, `422`

### `PATCH /api/v1/users/{user_id}/role`

**Change an account's role**

Refuses to demote the last remaining administrator.

| Parameter | In | Required | Description |
|---|---|---|---|
| `user_id` | path | yes | — |

Responses: `200`, `422`

---

## Voice

### `GET /api/v1/voice/capabilities`

**What voice mode understands**

Responses: `200`

### `POST /api/v1/voice/command`

**Interpret and execute a spoken command**

Parses an utterance and executes it through the same services the UI calls. Pass `dry_run` to interpret without acting, which is how a state-changing command can be read back for confirmation first.

Responses: `200`, `422`

---
