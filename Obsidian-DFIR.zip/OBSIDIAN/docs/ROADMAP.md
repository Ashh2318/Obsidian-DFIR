# OBSIDIAN - Delivery Roadmap

This roadmap lists what is **implemented and tested** and what is **planned**.
Only items under "Implemented" exist in the source code today.

## Phase 0 - Foundation (implemented)

- Monorepo with a FastAPI back end (`apps/api`) and a Next.js 15 front end (`apps/web`)
- Layered back end: core / domain / repositories / services / api
- Async SQLAlchemy 2.0 with SQLite for development and PostgreSQL support (`requirements-prod.txt`)
- Argon2id password hashing, JWT access tokens and rotating refresh tokens
- Refresh-token reuse detection with family revocation
- Role-based access control with four ordered roles
- Audit log, sliding-window rate limiting, security headers, request IDs
- AI provider layer: deterministic mock plus Ollama, OpenAI and Anthropic adapters
- Progressive web app shell, command palette, login, registration, silent token refresh
- Alembic migrations, seed script (`seed.py --demo`), pytest suite

## Phase 1 - Cases and Evidence (implemented)

- Case create, update, assignment and a controlled status workflow
- Evidence upload with size limit, safe file names and server-generated storage paths
- Content-based type detection (magic bytes first, extension as fallback), SHA-256 and MD5 hashes
- Duplicate detection inside a case, evidence library and case evidence view

Planned: background job queue for analysis, quarantined storage.

## Phase 2 - Analysis Engines (partly implemented)

- Implemented: PCAP engine (conversations, protocol distribution, beaconing, port scan, clear-text protocols)
- Implemented: text and log engine (failed logins, encoded PowerShell, persistence indicators)
- Implemented: common analysis result format shown by one UI

Planned: EVTX, document and APK engines.

## Phase 3 - Intelligence Layer (implemented)

- IOC extraction with twelve indicator types, private-address filtering and a defanged view
- Threat-intelligence enrichment (mock, AbuseIPDB, VirusTotal) with a 24-hour cache
- Investigation timeline built from the audit trail, evidence metadata and analysis results

Planned: MITRE ATT&CK technique mapping.

## Phase 4 - AI Investigation Assistant (partly implemented)

- Implemented: case-grounded chat, streaming replies, token usage stored with each message

Planned: retrieval over evidence with citations, automated incident narratives, YARA and Sigma rule generation.

## Phase 5 - Reporting (partly implemented)

- Implemented: executive and technical reports in PDF, HTML and Markdown
- Implemented: HMAC-SHA256 signing and signature verification

Planned: Word (DOCX) export, report versioning and an approval workflow.

## Phase 6 - Voice Command Mode (partly implemented)

- Implemented: wake-word handling ("Hey Obsidian"), rule-based intent parser and resolver,
  browser Web Speech API for recognition and spoken replies

Planned: local Whisper speech recognition, Piper synthesis, conversation memory.

## Phase 7 - Hardening and Distribution (partly implemented)

- Implemented: Dockerfiles, `docker-compose.yml`, production requirements (PostgreSQL, Redis), GitHub Actions CI

Planned: Nginx profile, desktop packaging, load testing, security review.
