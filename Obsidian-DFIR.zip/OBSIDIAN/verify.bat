@echo off
REM ===========================================================================
REM  OBSIDIAN - Verify the reported failures are fixed
REM
REM  Checks behaviour against a running instance rather than checking that the
REM  code changed. Start the application first with start.bat.
REM ===========================================================================

setlocal EnableExtensions
cd /d "%~dp0"

set "ROOT=%CD%"
set "API=%ROOT%\apps\api"
set "VENV=%API%\.venv"

if not exist "%VENV%\Scripts\python.exe" (
    echo.
    echo  [X] The Python environment is missing. Run setup.bat first.
    echo.
    pause
    exit /b 1
)

echo.
echo  ===========================================================
echo    OBSIDIAN - Verification
echo  ===========================================================

"%VENV%\Scripts\python.exe" "%ROOT%\scripts\verify_fixes.py"
set "RC=%ERRORLEVEL%"

if "%RC%"=="2" (
    echo  The API was not reachable. Start it with start.bat, then run this again.
    echo.
    pause
    exit /b 2
)

if not "%RC%"=="0" (
    echo  Some checks failed. The output above names each one.
    echo.
    pause
    exit /b 1
)

REM A branded sample so the report styling can be inspected without
REM generating one through the UI.
echo  Writing a sample report to verify-sample.pdf ...
"%VENV%\Scripts\python.exe" "%ROOT%\scripts\sample_report.py" "%ROOT%\verify-sample.pdf"
if exist "%ROOT%\verify-sample.pdf" (
    echo  Opening it now.
    start "" "%ROOT%\verify-sample.pdf"
)

echo.
pause
exit /b 0
